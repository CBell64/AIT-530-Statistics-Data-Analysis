!...
! -------------------------------------------------------------------
!...
SUBROUTINE PEARSN(X,Y,N,R,PROB,Z)
!...
!...GIVEN TWO ARRAYS X AND Y OF THE SAME SIZE, THIS ROUTINE COMPUTES THEIR CORRELATION COEFFICIENT
!...R (RETURNED AS R), THE SIGNIFICANCE LEVEL AT WHICH THE NULL HYPOTHESIS OF ZERO CORRELATION
!...IS DISPROVED (PROB WHOSE SMALL VALUE INDICATES A SIGNIFICANT CORRELATION), AND FISHER'S Z
!...(RETURNED AS Z), WHOSE VALUE CAN BE USED IN FURTHER STATISTICAL TESTS AS DESCRIBED ABOVE THE
!...ROUTINE IN VOLUME 1.
!...
!...PARAMETER: TINY WILL REGULARIZE THE UNUSUAL CASE OF COMPLETE CORRELATION.
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ASSERT_EQ
USE NR_SP,  ONLY : BETAI
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ABS, ERFC, DIM, DOT_PRODUCT, LOG, SIZE, SUM
!...
!...TRANSMITTED VARIABLES
INTEGER(I4B), INTENT(IN)                            :: N
REAL(SP), INTENT(OUT)                               :: R, PROB, Z
REAL(SP), DIMENSION(1:N), INTENT(IN)                :: X, Y
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: NN
REAL(SP), DIMENSION(SIZE(X))                        :: XT, YT
REAL(SP)                                            :: AX, AY, DF, SXX, SXY, SYY, T
!REAL(SP)                                               :: TINY_S=1.0E-20_SP ==> USE SMALL_S INSTEAD
!...
!...VERIFY ARRAY SIZES ARE EQUAL SIZES
NN = ASSERT_EQ(SIZE(X),SIZE(Y),"PEARSN")
!...
!...FIND THE MEANS
AX = SUM(X,DIM=1)/NN
AY = SUM(Y,DIM=1)/NN
!...
!...COMPUTE THE CORRELATION COEFFICIENT
XT(:) = X(:)-AX
YT(:) = Y(:)-AY
SXX = DOT_PRODUCT(XT,XT)
SYY = DOT_PRODUCT(YT,YT)
SXY = DOT_PRODUCT(XT,YT)
!...
!...CORRELATION COEFFICIENT
R = SXY/(SQRT(SXX*SYY)+SMALL_S)
!...
!...FISHER'S Z TRANSFORMATION.
Z = HALF_S*LOG(((ONE_S+R)+SMALL_S)/((ONE_S-R)+SMALL_S))
DF = NN-2
!...
!...STUDENT'S T
T = R*SQRT(DF/(((ONE_S-R)+SMALL_S)*((ONE_S+R)+SMALL_S)))
IF ((DF/(DF+T**2) >= ZERO_S) .AND. (DF/(DF+T**2) <= ONE_S)) THEN
    PROB = BETAI(HALF_S*DF,HALF_S,DF/(DF+T**2))                         ! PROBABILITY OF CORRELATION --- BETTER METHOD
ELSE
    PROB = ERFC(ABS(Z*SQRT(NN-ONE_S))/SQRT2_S)                          ! PROBABILITY OF CORRELATION --- USED WHEN BETAI ERROR
ENDIF
!                                                                         FOR LARGE N, THE LATTER EASIER COMPUTATION OF PROB,
!                                                                         USING THE SHORT ROUTINE ERFCC, WOULD GIVE
!                                                                         APPROXIMATELY THE SAME VALUE.
!...
!...DONE
END SUBROUTINE PEARSN
!...
! -------------------------------------------------------------------
!...
FUNCTION BETAI_S(A,B,X)
!...
!...PURPOSE: RETURNS THE INCOMPLETE BETA FUNCTION I_X(A, B).
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ASSERT
USE NR_SP,  ONLY : BETACF
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: LOG
!...
!...TRANSMITTED VARIABLES
REAL(SP), INTENT(IN)                                :: A, B, X
!...
!...LOCAL VARIABLES
REAL(SP)                                            :: BETAI_S
REAL(SP)                                            :: BT
!...
!...VERIFY THAT X EQUAL OR GREATER THAN ZERO AND X LESS THAN OR EQUAL TO ONE
CALL ASSERT(X >= ZERO_S, X <= ONE_S, "BETAI_S ARG")
!...
!...CALCULATIONS
IF (X == ZERO_S .OR. X == ONE_S) THEN
    BT = ZERO_S
ELSE                                                                    ! FACTORS IN FRONT OF THE CONTINUED FRACTION.
    BT = EXP(ALGAMA(A+B)-ALGAMA(A)-ALGAMA(B)+A*LOG(X)+B*LOG(ONE_S-X))
ENDIF
IF (X < (A+ONE_S)/(A+B+TWO_S)) THEN                                     ! USE CONTINUED FRACTION DIRECTLY.
    BETAI_S = BT*BETACF(A,B,X)/A
ELSE                                                                    ! USE CONTINUED FRACTION AFTER MAKING THE
    BETAI_S = ONE_S-BT*BETACF(B,A,ONE_S-X)/B                            ! SYMMETRY TRANSFORMATION.
ENDIF
!...
!...DONE
END FUNCTION BETAI_S
!...
! -------------------------------------------------------------------
!...
FUNCTION BETACF_S(A,B,X)
!...
!...PURPOSE: USED BY BETAI TO EVALUATE CONTINUED FRACTION FOR INCOMPLETE BETA FUNCTION BY MODIFIED
!...LENTZ'S METHOD (SECTION 5.2).
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : NRERROR
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ABS, EPSILON, TINY
!...
!...TRANSMITTED VARIABLES
REAL(SP), INTENT(IN)                                :: A, B, X
!...
!...LOCAL VARIABLES
REAL(SP)                                            :: BETACF_S
INTEGER(I4B), PARAMETER                             :: MAXIT=100
REAL(SP), PARAMETER                                 :: EPS=EPSILON(X), FPMIN=TINY(X)/EPS
REAL(SP)                                            :: AA, C, D, DEL, H, QAB, QAM, QAP
INTEGER(I4B)                                        :: M, M2
!...
!...CALCULATION
QAB = A+B                                                               ! THESE Q'S WILL BE USED IN FACTORS THAT OCCUR
QAP = A+ONE_S                                                           ! IN THE COEFFICIENTS (6.4.6).
QAM = A-ONE_S
C = ONE_S                                                               ! FIRST STEP OF LENTZ"S METHOD.
D = ONE_S-QAB*X/QAP
IF (ABS(D) < FPMIN) D = FPMIN
D = ONE_S/D
H = D
DO M = 1,MAXIT
    M2 = 2*M
    AA = M*(B-M)*X/((QAM+M2)*(A+M2))
    D = ONE_S+AA*D                                                      ! ONE STEP (THE EVEN ONE) OF THE RECURRENCE.
    IF (ABS(D) < FPMIN) D = FPMIN
    C = ONE_S+AA/C
    IF (ABS(C) < FPMIN) C = FPMIN
    D = ONE_S/D
    H = H*D*C
    AA = -(A+M)*(QAB+M)*X/((A+M2)*(QAP+M2))
    D = ONE_S+AA*D                                                      ! NEXT STEP OF THE RECURRENCE (THE ODD ONE).
    IF (ABS(D) < FPMIN) D = FPMIN
    C = ONE_S+AA/C
    IF (ABS(C) < FPMIN) C = FPMIN
    D = ONE_S/D
    DEL = D*C
    H = H*DEL
    IF (ABS(DEL-ONE_S) <= EPS) EXIT                                     ! ARE WE DONE?
ENDDO
IF (M > MAXIT) CALL NRERROR("A OR B TOO BIG, OR MAXIT TOO SMALL IN BETACF_S")
BETACF_S = H
!...
!...DONE
END FUNCTION BETACF_S
!...
! -------------------------------------------------------------------
!...
FUNCTION GAMMP_S(A,X)
!...
!...PURPOSE: RETURNS THE INCOMPLETE GAMMA FUNCTION P(A, X).
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ASSERT
USE NR_SP,  ONLY : GCF_S, GSER_S
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...TRANSMITTED VARIABLES
REAL(SP), INTENT(IN)                                :: A, X
REAL(SP)                                            :: GAMMP_S
!...
!...VERIFY THAT X AND A ARE EQUAL OR GREATER THAN ZERO
CALL ASSERT(X >= ZERO_S, A > ZERO_S, "GAMMP_S ARGS")
!...
!...CALCULATION
IF (X < A+ONE_S) THEN                                                   ! USE THE SERIES REPRESENTATION.
    GAMMP_S = GSER_S(A,X)
ELSE                                                                    ! USE THE CONTINUED FRACTION REPRESENTATION
    GAMMP_S = ONE_S-GCF_S(A,X)                                          ! AND TAKE ITS COMPLEMENT.
ENDIF
!...
!...DONE
END FUNCTION GAMMP_S
!...
! -------------------------------------------------------------------
!...
FUNCTION GAMMQ_S(A,X)
!...
!...PURPOSE: RETURNS THE INCOMPLETE GAMMA FUNCTION Q(A, X) = 1 - P(A, X).
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ASSERT
USE NR_SP,  ONLY : GCF_S, GSER_S
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...TRANSMITTED VARIABLES
REAL(SP), INTENT(IN)                                :: A, X
!...
!...LOCAL VARIABLES
REAL(SP)                                            :: GAMMQ_S
!...
!...VERIFY THAT X AND A ARE EQUAL OR GREATER THAN ZERO
CALL ASSERT(X >= ZERO_S, A > ZERO_S, "GAMMQ_S ARGS")
!...
!...CALCULATION
IF (X < A+ONE_S) THEN                                                   ! USE THE SERIES REPRESENTATION
    GAMMQ_S = ONE_S-GSER_S(A,X)                                         ! AND TAKE ITS COMPLEMENT.
ELSE                                                                    ! USE THE CONTINUED FRACTION REPRESENTATION.
    GAMMQ_S = GCF_S(A,X)
ENDIF
!...
!...DONE
END FUNCTION GAMMQ_S
!...
! -------------------------------------------------------------------
!...
FUNCTION GSER_S(A,X,GLN)
!...
!...PURPOSE: RETURNS THE INCOMPLETE GAMMA FUNCTION P(A, X) EVALUATED BY ITS SERIES REPRESENTATION AS
!...GAMSER. ALSO OPTIONALLY RETURNS LN G(A) AS GLN.
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : NRERROR
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ABS, EPSILON, LOG, PRESENT
!...
!...TRANSMITTED VARIABLES
REAL(SP), INTENT(IN)                                :: A, X
REAL(SP), OPTIONAL, INTENT(OUT)                     :: GLN
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: N
INTEGER(I4B), PARAMETER                             :: ITMAX=100
REAL(SP)                                            :: GSER_S
REAL(SP)                                            :: AP, DEL, SUMM
REAL(SP), PARAMETER                                 :: EPS=EPSILON(X)
!...
!...CALCULATION
IF (X == ZERO_S) THEN
    GSER_S = ZERO_S
    RETURN
ENDIF
AP = A
SUMM = ONE_S/A
DEL = SUMM
DO N = 1,ITMAX
    AP = AP+ONE_S
    DEL = DEL*X/AP
    SUMM=SUMM+DEL
    IF (ABS(DEL) < ABS(SUMM)*EPS) EXIT
ENDDO
IF (N > ITMAX) CALL NRERROR("A TOO LARGE, ITMAX TOO SMALL IN GSER_S")
IF (PRESENT(GLN)) THEN
    GLN = ALGAMA(A)
    GSER_S = SUMM*EXP(-X+A*LOG(X)-GLN)
ELSE
    GSER_S = SUMM*EXP(-X+A*LOG(X)-ALGAMA(A))
ENDIF
!...
!...DONE
END FUNCTION GSER_S
!...
! -------------------------------------------------------------------
!...
FUNCTION GCF_S(A,X,GLN)
!...
!...PURPOSE: RETURNS THE INCOMPLETE GAMMA FUNCTION Q(A, X) EVALUATED BY ITS CONTINUED FRACTION REPRESENTATION
!...AS GAMMCF. ALSO OPTIONALLY RETURNS LN G(A) AS GLN.
!...
!...PARAMETERS: ITMAX IS THE MAXIMUM ALLOWED NUMBER OF ITERATIONS; EPS IS THE RELATIVE ACCURACY;
!...FPMIN IS A NUMBER NEAR THE SMALLEST REPRESENTABLE FLOATING-POINT NUMBER.
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : NRERROR
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ABS, EPSILON, LOG, PRESENT, TINY
!...
!...TRANSMITTED VARIABLES
REAL(SP), INTENT(IN)                                :: A, X
REAL(SP), OPTIONAL, INTENT(OUT)                     :: GLN
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: I
INTEGER(I4B), PARAMETER                             :: ITMAX=100
REAL(SP)                                            :: GCF_S
REAL(SP)                                            :: AN, B, C, D, DEL, H
REAL(SP), PARAMETER                                 :: EPS=EPSILON(X), FPMIN=TINY(X)/EPS
!...
!...CALCULATION
IF (X == ZERO_S) THEN
    GCF_S = ONE_S
    RETURN
ENDIF
B = X+ONE_S-A                                                           ! SET UP FOR EVALUATING CONTINUED FRACTION BY MODIFIED
C = ONE_S/FPMIN                                                         ! LENTZ"S METHOD (§5.2) WITH B0 = 0.
D = ONE_S/B
H = D
DO I = 1,ITMAX                                                          ! ITERATE TO CONVERGENCE.
    AN = -I*(I-A)
    B = B+TWO_S
    D = AN*D+B
    IF (ABS(D) < FPMIN) D = FPMIN
    C = B+AN/C
    IF (ABS(C) < FPMIN) C = FPMIN
    D = ONE_S/D
    DEL = D*C
    H = H*DEL
    IF (ABS(DEL-ONE_S) <= EPS) EXIT
ENDDO
IF (I > ITMAX) CALL NRERROR("A TOO LARGE, ITMAX TOO SMALL IN GCF_S")
IF (PRESENT(GLN)) THEN
    GLN = ALGAMA(A)
    GCF_S = EXP(-X+A*LOG(X)-GLN)*H                                      ! PUT FACTORS IN FRONT.
ELSE
    GCF_S = EXP(-X+A*LOG(X)-ALGAMA(A))*H
ENDIF
!...
!...DONE
END FUNCTION GCF_S
!...
! -------------------------------------------------------------------
!...
FUNCTION ERFC_SS(X)
!...
!...PURPOSE: RETURNS THE COMPLEMENTARY ERROR FUNCTION ERFC(X).
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NR_SP, ONLY : GAMMP, GAMMQ
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ERFC, MERGE
!...
!...TRANSMITTED VARIABLES
REAL(SP), INTENT(IN)                                :: X
!...
!...LOCAL VARIABLES
REAL(SP)                                            :: ERFC_SS
!...
!...CALCULATION
ERFC_SS = ERFC(MERGE(ONE_S+GAMMP(HALF_S,X**2), GAMMQ(HALF_S,X**2), X < ZERO_S))
!...
!...DONE
END FUNCTION ERFC_SS
!...
! -------------------------------------------------------------------
!...
ELEMENTAL FUNCTION ERFCC_SS(X)
!...
!...PURPOSE: RETURNS THE COMPLEMENTARY ERROR FUNCTION ERFC(X) WITH FRACTIONAL ERROR EVERYWHERE LESS THAN 1.2 × 10^-7.
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : POLYY
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ABS, ERFC
!...
!...TRANSMITTED VARIABLES
REAL(SP), INTENT(IN)                                :: X
!...
!...LOCAL VARIABLES
REAL(SP)                                            :: T, Z, ERFCC_SS
REAL(SP), PARAMETER                                 :: COEF(10) = (/ -1.26551223_SP, 1.00002368_SP,         &
                                                                      0.37409196_SP, 0.09678418_SP,         &
                                                                     -0.18628806_SP, 0.27886807_SP,         &
                                                                     -1.13520398_SP, 1.48851587_SP,         &
                                                                     -0.82215223_SP, 0.17087277_SP /)
!...
!...CALCULATION
Z = ABS(X)
T = ONE_S/(ONE_S+HALF_S*Z)
ERFCC_SS = ERFC(T*EXP(-Z*Z + POLYY(T,COEF)))
IF (X < ZERO_S) ERFCC_SS = TWO_S-ERFCC_SS
!...
!...DONE
END FUNCTION ERFCC_SS
!...
! =======================================================================================
!...
SUBROUTINE SPEAR(DATA1,DATA2,N,D,ZD,PROBD,RS,PROBRS)
!...
!...GIVEN TWO DATA ARRAYS OF THE SAME SIZE, DATA1 AND DATA2, THIS ROUTINE RETURNS THEIR SUM-
!...SQUARED DIFFERENCE OF RANKS AS D, THE NUMBER OF STANDARD DEVIATIONS BY WHICH D DEVIATES
!...FROM ITS NULL-HYPOTHESIS EXPECTED VALUE AS ZD, THE TWO-SIDED SIGNIFICANCE LEVEL OF THIS
!...DEVIATION AS PROBD, SPEARMAN’S RANK CORRELATION RS AS RS, AND THE TWO-SIDED SIGNIFICANCE
!...LEVEL OF ITS DEVIATION FROM ZERO AS PROBRS. DATA1 AND DATA2 ARE NOT MODIFIED. A SMALL VALUE
!...OF EITHER PROBD OR PROBRS INDICATES A SIGNIFICANT CORRELATION (RS POSITIVE) OR ANTICORRELATION
!...(RS NEGATIVE).
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ASSERT_EQ
USE NR_SP,  ONLY : BETAI, SORT2
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ABS, DOT_PRODUCT, ERFC, SIZE
!...
!...TRANSMITTED VARIABLES
INTEGER(I4B)                                        :: N
REAL(SP), INTENT(OUT)                               :: D, ZD, PROBD, RS, PROBRS
REAL(SP), DIMENSION(1:N), INTENT(IN)                :: DATA1, DATA2
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: NN
REAL(SP)                                            :: AVED, DF, EN, EN3N, FAC, SF, SG, T, VARD
REAL(SP), DIMENSION(SIZE(DATA1))                    :: WKSP1, WKSP2
!...
!...VERIFY THAT ARRAY SIZES ARE EQUAL
NN = ASSERT_EQ(SIZE(DATA1),SIZE(DATA2),"SPEAR")
!...
!...CALCULATION
WKSP1(:) = DATA1(:)
WKSP2(:) = DATA2(:)
CALL SORT2 (WKSP1,WKSP2)                                                ! SORT EACH OF THE DATA ARRAYS, AND CONVERT THE
CALL CRANK (WKSP1,SF)                                                   ! ENTRIES TO RANKS. THE VALUES SF AND SG
CALL SORT2 (WKSP2,WKSP1)                                                ! RETURN THE SUMS (F^3_K - F_K) AND
CALL CRANK (WKSP2,SG)                                                   ! (G^3_M - G_M), RESPECTIVELY.
WKSP1(:) = WKSP1(:)-WKSP2(:)
D     = DOT_PRODUCT(WKSP1,WKSP1)                                        ! SUM THE SQUARED DIFFERENCE OF RANKS.
EN    = REAL(N, KIND=SP)
EN3N  = EN**3-EN
AVED  = EN3N/SIX_S-(SF+SG)/TWELVE_S                                     ! EXPECTATION VALUE OF D,
FAC   = (ONE_S-SF/EN3N)*(ONE_S-SG/EN3N)
VARD  = ((EN-ONE_S)*EN**2*(EN+ONE_S)**2/36.0_SP)*FAC                    ! AND VARIANCE OF D GIVE
ZD    = (D-AVED)/SQRT(VARD)                                             ! NUMBER OF STANDARD DEVIATIONS,
PROBD = ERFC(ABS(ZD)/SQRT2_S)                                           ! AND SIGNIFICANCE.
RS    = (ONE_S-(SIX_S/EN3N)*(D+(SF+SG)/TWELVE_S))/SQRT(FAC)             ! RANK CORRELATION COEFFICIENT,
FAC   = (ONE_S+RS)*(ONE_S-RS)
IF (FAC > ZERO_S) THEN
    T  = RS*SQRT((EN-TWO_S)/FAC)                                        ! AND ITS T VALUE,
    DF = EN-TWO_S
    PROBRS = BETAI(HALF_S*DF,HALF_S,DF/(DF+T**2))                       ! GIVE ITS SIGNIFICANCE.
ELSE
    PROBRS = ZERO_S
ENDIF
CONTAINS
!...
! -------------------------------------------------------------------
!...
    SUBROUTINE CRANK(W,S)
!...
!...PURPOSE: GIVEN A SORTED ARRAY W, REPLACES THE ELEMENTS BY THEIR RANK, INCLUDING MIDRANKING OF TIES,
!...AND RETURNS AS S THE SUM OF F^3 - F, WHERE F IS THE NUMBER OF ELEMENTS IN EACH TIE.
!...
!...ADD TYPE AND UTILITY MODULES
    USE NRTYPE
    USE NRUTIL, ONLY : ARTH, ARRAY_COPY
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                           :: EOSHIFT, MERGE, PACK, SIZE, SUM
!...
!...TRANSMITTED VARIABLES
    REAL(SP), INTENT(OUT)                               :: S
    REAL(SP), DIMENSION(:), INTENT(INOUT)               :: W
!...
!...LOCAL VARIABLES
    INTEGER(I4B)                                        :: I, N, NDUM, NTIES
    INTEGER(I4B), DIMENSION(SIZE(W))                    :: TSTART, TEND, TIE, IDX
!...
!...CALCULATION
    N = SIZE(W)
    IDX(:) = ARTH(1,1,N)                                                ! INDEX VECTOR.
    TIE(:) = MERGE(1,0,W == EOSHIFT(W,-1))
!...
!...LOOK FOR TIES: COMPARE EACH ELEMENT TO THE ONE BEFORE. IF IT'S EQUAL, IT'S PART OF A TIE, AND
!...WE PUT 1 INTO TIE. OTHERWISE WE PUT 0.
!...
    TIE(1) = 0                                                          ! BOUNDARY; THE FIRST ELEMENT MUST BE ZERO.
    W(:) = IDX(:)                                                       ! ASSIGN RANKS IGNORING POSSIBLE TIES.
    IF (ALL(TIE == 0)) THEN                                             ! NO TIES--WE'RE DONE.
        S = ZERO_S
        RETURN
    ENDIF
    CALL ARRAY_COPY(PACK(IDX(:),TIE(:) < EOSHIFT(TIE(:),1)),TSTART,NTIES,NDUM)
!...
!...LOOK FOR 0 -> 1 TRANSITIONS IN TIE, WHICH MEAN THAT THE 0 ELEMENT IS THE START OF A TIE RUN.
!...STORE INDEX OF EACH TRANSITION IN TSTART.  NTIES IS THE NUMBER OF TIES FOUND.
!...
    TEND(1:NTIES) = PACK(IDX(:),TIE(:) > EOSHIFT(TIE(:),1))
!...
!...LOOK FOR 1 -> 0 TRANSITIONS IN TIE, WHICH MEAN THAT THE 1 ELEMENT IS THE END OF A TIE RUN.
!...
    DO I = 1,NTIES                                                      ! MIDRANK ASSIGNMENTS.
        W(TSTART(I):TEND(I)) = (TSTART(I)+TEND(I))/TWO_S
    ENDDO
    TEND(1:NTIES) = TEND(1:NTIES)-TSTART(1:NTIES)+1                     ! NOW CALCULATE S.
    S = SUM(TEND(1:NTIES)**3-TEND(1:NTIES))
!...
!...DONE
    END SUBROUTINE CRANK
END SUBROUTINE SPEAR
!...
! -------------------------------------------------------------------
!...
SUBROUTINE SORT2(ARR,SLAVE)
!...
!...PURPOSE: SORTS AN ARRAY ARR INTO ASCENDING ORDER USING QUICKSORT, WHILE MAKING THE CORRESPONDING
!...REARRANGEMENT OF THE SAME-SIZE ARRAY SLAVE.  THE SORTING AND REARRANGEMENT ARE PERFORMED
!...BY MEANS OF AN INDEX ARRAY.
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ASSERT_EQ
USE NR_SP,  ONLY : INDEXX
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: SIZE
!...
!...TRANSMITTED VARIABLES
REAL(SP), DIMENSION(:), INTENT(INOUT)               :: ARR, SLAVE
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: NDUM
INTEGER(I4B), DIMENSION(SIZE(ARR))                  :: INDEX1
!...
!...VERIFY ARRAY SIZES ARE EQUAL
NDUM = ASSERT_EQ(SIZE(ARR),SIZE(SLAVE),"SORT2")
!...
!...CALCULATION
CALL INDEXX(ARR,INDEX1)                                                  ! MAKE THE INDEX ARRAY.
ARR   = ARR(INDEX1)                                                      ! SORT ARR.
SLAVE = SLAVE(INDEX1)                                                    ! REARRANGE SLAVE.
!...
!...DONE
END SUBROUTINE SORT2
!...
! -------------------------------------------------------------------
!...
SUBROUTINE INDEXX_SP(ARR,INDEX1)
!...
!...PURPOSE: INDEXES AN ARRAY ARR, i.e., OUTPUTS THE ARRAY INDEX OF LENGTH N SUCH THAT ARR(INDEX(J))
!...IS IN ASCENDING ORDER FOR J = 1,2,...,N.  THE INPUT QUANTITY ARR IS NOT CHANGED.
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ARTH, ASSERT_EQ, NRERROR, SWAP
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: SIZE
!...
!...TRANSMITTED VARIABLES
INTEGER(I4B), DIMENSION(:), INTENT(OUT)             :: INDEX1
REAL(SP), DIMENSION(:), INTENT(IN)                  :: ARR
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: N, K, I, J, INDEXT, JSTACK, L, R
INTEGER(I4B), PARAMETER                             :: NN=15, NSTACK=50
INTEGER(I4B), DIMENSION(NSTACK)                     :: ISTACK
REAL(SP)                                            :: A
!...
!...VERIFY ARRAY SIZES ARE EQUAL
N = ASSERT_EQ(SIZE(INDEX1),SIZE(ARR),"INDEXX_SP")
!...
!...CALCULATION
INDEX1 = ARTH(1,1,N)
JSTACK = 0
L = 1
R = N
DO
    IF (R-L < NN) THEN
        DO J = L+1,R
            INDEXT = INDEX1(J)
            A = ARR(INDEXT)
            DO I = J-1,L,-1
                IF (ARR(INDEX1(I)) <= A) EXIT
                INDEX1(I+1) = INDEX1(I)
            ENDDO
            INDEX1(I+1) = INDEXT
        ENDDO
        IF (JSTACK == 0) RETURN
        R = ISTACK(JSTACK)
        L = ISTACK(JSTACK-1)
        JSTACK = JSTACK-2
    ELSE
        K = (L+R)/2
        CALL SWAP(INDEX1(K),INDEX1(L+1))
        CALL ICOMP_XCHG(INDEX1(L),  INDEX1(R))
        CALL ICOMP_XCHG(INDEX1(L+1),INDEX1(R))
        CALL ICOMP_XCHG(INDEX1(L),  INDEX1(L+1))
        I = L+1
        J = R
        INDEXT = INDEX1(L+1)
        A = ARR(INDEXT)
        DO
            DO
                I = I+1
                IF (ARR(INDEX1(I)) >= A) EXIT
            ENDDO
            DO
                J = J-1
                IF (ARR(INDEX1(J)) <= A) EXIT
            ENDDO
            IF (J < I) EXIT
            CALL SWAP(INDEX1(I),INDEX1(J))
        ENDDO
        INDEX1(L+1) = INDEX1(J)
        INDEX1(J) = INDEXT
        JSTACK = JSTACK+2
!        IF (JSTACK > NSTACK) CALL NRERROR("INDEXX: NSTACK TOO SMALL")
        IF (JSTACK > NSTACK) THEN
            WRITE(*,*) "                 INDEXX: NSTACK TOO SMALL"
            RETURN
        ENDIF
        IF (R-I+1 >= J-L) THEN
            ISTACK(JSTACK) = R
            ISTACK(JSTACK-1) = I
            R = J-1
        ELSE
            ISTACK(JSTACK) = J-1
            ISTACK(JSTACK-1) = L
            L = I
        ENDIF
    ENDIF
ENDDO
    CONTAINS
!...
! -------------------------------------------------------------------
!...
    SUBROUTINE ICOMP_XCHG(I,J)
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...TRANSMITTED VARIABLES
    INTEGER(I4B), INTENT(INOUT)                         :: I, J
!...
!...TRANSMITTED VARIABLES
    INTEGER(I4B)                                        :: SWP
!...
!...CALCULATION
    IF (ARR(J) < ARR(I)) THEN
        SWP = I
        I = J
        J = SWP
    ENDIF
!...
!...DONE
    END SUBROUTINE ICOMP_XCHG
END SUBROUTINE INDEXX_SP
!...
! -------------------------------------------------------------------
!...
SUBROUTINE INDEXX_I4B(IARR,INDEX1)
!...
!...PURPOSE: INDEXES AN ARRAY ARR, I.E., OUTPUTS THE ARRAY INDEX OF LENGTH N SUCH THAT ARR(INDEX(J))
!...IS IN ASCENDING ORDER FOR J = 1,2,...,N.  THE INPUT QUANTITY ARR IS NOT CHANGED.
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ARTH, ASSERT_EQ, NRERROR, SWAP
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: SIZE
!...
!...TRANSMITTED VARIABLES
INTEGER(I4B), DIMENSION(:), INTENT(IN)              :: IARR
INTEGER(I4B), DIMENSION(:), INTENT(OUT)             :: INDEX1
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: A
INTEGER(I4B)                                        :: N, K, I, J, INDEXT, JSTACK, L, R
INTEGER(I4B), PARAMETER                             :: NN=15, NSTACK=50
INTEGER(I4B), DIMENSION(NSTACK)                     :: ISTACK
!...
!...VERIFY ARRAY SIZES ARE EQUAL
N = ASSERT_EQ(SIZE(INDEX1),SIZE(IARR),"INDEXX_SP")
!...
!...CALCULATION
INDEX1 = ARTH(1,1,N)
JSTACK = 0
L = 1
R = N
DO
    IF (R-L < NN) THEN
        DO J = L+1,R
            INDEXT = INDEX1(J)
            A=IARR(INDEXT)
            DO I = J-1,L,-1
                IF (IARR(INDEX1(I)) <= A) EXIT
                INDEX1(I+1) = INDEX1(I)
            END DO
            INDEX1(I+1) = INDEXT
        END DO
        IF (JSTACK == 0) RETURN
        R = ISTACK(JSTACK)
        L = ISTACK(JSTACK-1)
        JSTACK = JSTACK-2
    ELSE
        K = (L+R)/2
        CALL SWAP(INDEX1(K),INDEX1(L+1))
        CALL ICOMP_XCHG(INDEX1(L),  INDEX1(R))
        CALL ICOMP_XCHG(INDEX1(L+1),INDEX1(R))
        CALL ICOMP_XCHG(INDEX1(L),  INDEX1(L+1))
        I = L+1
        J = R
        INDEXT = INDEX1(L+1)
        A = IARR(INDEXT)
        DO
            DO
                I = I+1
                IF (IARR(INDEX1(I)) >= A) EXIT
            ENDDO
            DO
                J = J-1
                IF (IARR(INDEX1(J)) <= A) EXIT
            ENDDO
            IF (J < I) EXIT
            CALL SWAP(INDEX1(I),INDEX1(J))
        ENDDO
        INDEX1(L+1) = INDEX1(J)
        INDEX1(J) = INDEXT
        JSTACK = JSTACK+2
!        IF (JSTACK > NSTACK) CALL NRERROR("INDEXX: NSTACK TOO SMALL")
        IF (JSTACK > NSTACK) THEN
            WRITE(*,*) "                    INDEXX: NSTACK TOO SMALL"
            RETURN
        ENDIF
        IF (R-I+1 >= J-L) THEN
            ISTACK(JSTACK) = R
            ISTACK(JSTACK-1) = I
            R = J-1
        ELSE
            ISTACK(JSTACK) = J-1
            ISTACK(JSTACK-1) = L
            L=I
        ENDIF
    ENDIF
ENDDO
CONTAINS
!...
! -------------------------------------------------------------------
!...
    SUBROUTINE ICOMP_XCHG(I,J)
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...TRANSMITTED VARIABLES
    INTEGER(I4B), INTENT(INOUT)                         :: I, J
!...
!...LOCAL VARIABLES
    INTEGER(I4B)                                        :: SWP
!...
!...CALCULATION
    IF (IARR(J) < IARR(I)) THEN
        SWP = I
        I = J
        J = SWP
    ENDIF
!...
!...DONE
    END SUBROUTINE ICOMP_XCHG
END SUBROUTINE INDEXX_I4B
!...
! -------------------------------------------------------------------
!...
SUBROUTINE KENDL1(DATA1,DATA2,N,TAU,Z,PROB)
!...
!...GIVEN SAME-SIZE DATA ARRAYS DATA1 AND DATA2, THIS PROGRAM RETURNS KENDALL'S T AS TAU, ITS
!...NUMBER OF STANDARD DEVIATIONS FROM ZERO AS Z, AND ITS TWO-SIDED SIGNIFICANCE LEVEL AS PROB.
!...SMALL VALUES OF PROB INDICATE A SIGNIFICANT CORRELATION (TAU POSITIVE) OR ANTICORRELATION
!...(TAU NEGATIVE).
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ASSERT_EQ
USE NR_SP,  ONLY : ERFCC
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ABS, COUNT, ERFC, SIZE
!...
!...TRANSMITTED VARIABLES
INTEGER(I4B)                                        :: N
REAL(SP), INTENT(OUT)                               :: TAU,Z, PROB
REAL(SP), DIMENSION(1:N), INTENT(IN)                :: DATA1, DATA2
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: IS, J, N1, N2, NN
REAL(SP)                                            :: VAR
REAL(SP), DIMENSION(SIZE(DATA1))                    :: A1, A2
!...
!...VERIFY ARRAY SIZES ARE EQUAL
NN = ASSERT_EQ(SIZE(DATA1),SIZE(DATA2),"KENDL1")
!...
!...CALCULATION
N1 = 0                                                                  ! THIS WILL BE THE ARGUMENT OF ONE SQUARE ROOT
N2 = 0                                                                  ! IN (14.6.8), AND THIS IS THE OTHER.
IS = 0                                                                  ! THIS WILL BE THE NUMERATOR IN (14.6.8).
DO J = 1,N-1                                                            ! LOOP OVER FIRST MEMBER OF PAIR,
    A1(J+1:N) = DATA1(J)-DATA1(J+1:N)                                   ! AND SECOND MEMBER.
    A2(J+1:N) = DATA2(J)-DATA2(J+1:N)
    N1 = N1+COUNT(A1(J+1:N) /= ZERO_S)
    N2 = N2+COUNT(A2(J+1:N) /= ZERO_S)
                                                                        ! NOW ACCUMULATE THE NUMERATOR IN (14.6.8):
    IS = IS+COUNT((A1(J+1:N) > ZERO_S .AND. A2(J+1:N) > ZERO_S)                                             &
        .OR.      (A1(J+1:N) < ZERO_S .AND. A2(J+1:N) < ZERO_S)) -                                          &
            COUNT((A1(J+1:N) > ZERO_S .AND. A2(J+1:N) < ZERO_S)                                             &
        .OR.      (A1(J+1:N) < ZERO_S .AND. A2(J+1:N) > ZERO_S))
ENDDO
TAU = REAL(IS, KIND=SP)/SQRT(REAL(N1, KIND=SP)*REAL(N2, KIND=SP))       ! EQUATION (14.6.8).
VAR = (FOUR_S*N+TEN_S)/(NINE_S*N*(N-ONE_S))                             ! EQUATION (14.6.9)
Z = TAU/SQRT(VAR)
PROB = ERFC(ABS(Z)/SQRT2_S)                                             ! SIGNIFICANCE.
!...
!...DONE
END SUBROUTINE KENDL1
!...
! -------------------------------------------------------------------
!...
SUBROUTINE NASHSU(X,Y,N,ES)
!...
!...NASH-SUTCLIFF COEFFICIENT
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ASSERT_EQ
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: DIM, SIZE, SUM
!...
!...TRANSMITTED VARIABLES
INTEGER(I4B), INTENT(IN)                            :: N
REAL(SP), DIMENSION(1:N), INTENT(IN)                :: X, Y
REAL(SP), INTENT(OUT)                               :: ES
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: NN
REAL(SP)                                            :: XT, NS
REAL(SP)                                            :: AX, AY
!...
!...VERIFY ARRAY SIZES ARE EQUAL
NN = ASSERT_EQ(SIZE(X),SIZE(Y),"NASHSU")
NS = REAL(N, KIND=SP)
!...
!...CALCULATION
AY = SUM(ABS(X(:)-Y(:))**2)                                             ! NUMERATOR
AX = SUM(Y(:),DIM=1)/NS                                                 ! MEAN OF SIMULATED VALUES
XT = SUM((X(:)-AX)**2)                                                  ! DENOMINATOR
ES = ONE_S-(AY/XT)                                                      ! SOLVE FOR NASH-SUTCLIFF COEFFICIENT (ES)
!...
!...DONE
END SUBROUTINE NASHSU
!...
! -------------------------------------------------------------------
!...
SUBROUTINE ROOT_MEAN(X,Y,ME,MAE,MSE,MLE,MALE,MSLE,RMSE,RMSLE,NRMSE,CVRMSE,RSR,N)
!...
!...ROOT MEAN ERROR CALCULATIONS
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ARRAY_COPY, ASSERT_EQ
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: DIM, MAXVAL, MINVAL, SIZE, SUM
!...
!...TRANSMITTED VARIABLES
INTEGER(I4B), INTENT(IN)                            :: N
REAL(SP), DIMENSION(1:N), INTENT(IN)                :: X, Y
REAL(SP), INTENT(OUT)                               :: ME, MAE, MSE, MLE, MALE, MSLE, RMSE, RMSLE, NRMSE, CVRMSE, RSR
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: NN, N_COPIED, N_NOT_COPIED
REAL(SP)                                            :: NS, XAVE, COEF
REAL(SP), DIMENSION(1:N)                            :: X1, Y1
!...
!...VERIFY ARRAY SIZES ARE EQUAL
NN   = ASSERT_EQ(SIZE(X),SIZE(Y),"ROOT_MEAN")
NS   = REAL(N, KIND=SP)
XAVE = SUM(X(:),DIM=1)/NS                                               ! MEAN OF MEASURED VALUES
!...
!...TRANSFORM DATA FOR NEGATIVE AND ZERO VALUES FOR USE WHERE NECESSARY
COEF = ONE_S
10  CONTINUE
IF ((MINVAL(X) <= ZERO_S) .OR. (MINVAL(Y) <= ZERO_S)) THEN
    X1(:) = LOG10(COEF+X(:)-MINVAL(X))
    Y1(:) = LOG10(COEF+Y(:)-MINVAL(Y))
    IF ((MINVAL(X1) <= ZERO_S) .OR. (MINVAL(Y1) <= ZERO_S)) THEN
        COEF = COEF*TEN_S
        GOTO 10
    ENDIF
ELSE
    CALL ARRAY_COPY (X,X1,N_COPIED,N_NOT_COPIED)
    CALL ARRAY_COPY (Y,Y1,N_COPIED,N_NOT_COPIED)
ENDIF
!...
!...CALCULATION
ME     =  SUM(Y(:)-X(:))/NS                                             ! MEAN ERROR
MAE    =  SUM(ABS(Y(:)-X(:)))/NS                                        ! MEAN ABSOLUTE ERROR
MSE    =  SUM(Y(:)-X(:))**2/NS                                          ! MEAN SQUARED ERROR
MLE    =  LOG(SUM(Y1(:)/X1(:)))/NS                                      ! MEAN LOG ERROR
MALE   =  ABS(LOG(SUM(Y1(:)/X1(:))))/NS                                 ! MEAN ABSOLUTE LOG ERROR
MSLE   = (LOG(SUM(Y1(:)/X1(:))))**2/NS                                  ! MEAN SQUARED LOG ERROR
RMSE   =  SQRT(SUM(ABS(Y(:)-X(:))**2)/NS)                               ! ROOT MEAN SQUARE ERROR
RMSLE  =  SQRT(SUM(LOG(Y1(:)/X1(:))**2)/NS)                             ! ROOT MEAN SQUARE OF LOG ERROR
NRMSE  =  HUND_S*(RMSE/(MAXVAL(X(:))-MINVAL(X(:))))                     ! NORMALIZED ROOT MEAN SQUARE ERROR
CVRMSE =  RMSE/XAVE                                                     ! CV-ROOT MEAN SQUARE ERROR
RSR    =  RMSE/SQRT(SUM((X(:)-XAVE)**2))                                ! STANDARD DEVIATION RATIO OF RMSE-OBSERVATIONS
!!RSR = SUM((X(:)-Y(:))**2)
!...
!...DONE
END SUBROUTINE ROOT_MEAN
!...
!--------------------------------------------------------------------
!...
SUBROUTINE PERCENT_BIAS(X,Y,BIAS,PBIAS,N)
!...
!...BIAS AND PERCENT BIAS CALCULATIONS
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ASSERT_EQ
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: SIZE, SUM
!...
!...TRANSMITTED VARIABLES
INTEGER(I4B), INTENT(IN)                            :: N
REAL(SP), DIMENSION(1:N), INTENT(IN)                :: X, Y
REAL(SP), INTENT(OUT)                               :: BIAS, PBIAS
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: NN
!...
!...VERIFY ARRAY SIZES ARE EQUAL
NN = ASSERT_EQ(SIZE(X),SIZE(Y),"PERCENT_BIAS")
!...
!...CALCULATIONS
    BIAS  = SUM(Y(:)-X(:))/SUM(Y(:))
    PBIAS = HUND_S*BIAS
!...
!...DONE
END SUBROUTINE PERCENT_BIAS
!...
!--------------------------------------------------------------------
!...
SUBROUTINE KS2D1S(X1,Y1,N,QUADVL,D1,PROB)
!...
!...TWO-DIMENSIONAL KOLMOGOROV-SMIRNOV TEST OF ONE SAMPLE AGAINST A MODEL. GIVEN THE X- AND
!...Y-COORDINATES OF A SET OF DATA POINTS IN ARRAYS X1 AND Y1 OF THE SAME LENGTH, AND GIVEN
!...A USER-SUPPLIED FUNCTION QUADVL THAT EXEMPLIFIES THE MODEL, THIS ROUTINE RETURNS THE TWO-DIMENSIONAL
!...K-S STATISTIC AS D1, AND ITS SIGNIFICANCE LEVEL AS PROB. SMALL VALUES OF PROB
!...SHOW THAT THE SAMPLE IS SIGNIFICANTLY DIFFERENT FROM THE MODEL. NOTE THAT THE TEST IS SLIGHTLY
!...DISTRIBUTION-DEPENDENT, SO PROB IS ONLY AN ESTIMATE.
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ASSERT_EQ
USE NR_SP,  ONLY : PEARSN, PROBKS, QUADCT
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ABS, MAX, SIZE
!...
!...TRANSMITTED VARIABLES
INTEGER(I4B), INTENT(IN)                            :: N
REAL(SP), DIMENSION(1:N), INTENT(IN)                :: X1, Y1
REAL(SP), INTENT(OUT)                               :: D1, PROB
!...
!...INTERFACE TO QUADVL
INTERFACE
    SUBROUTINE QUADVL(X,Y,FA,FB,FC,FD)
    USE NRTYPE
    IMPLICIT NONE
    REAL(SP), INTENT(IN)                            :: X, Y
    REAL(SP), INTENT(OUT)                           :: FA, FB, FC, FD
    END SUBROUTINE QUADVL
END INTERFACE
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: J, N1
REAL(SP)                                            :: DUM, DUMM, FA, FB, FC, FD, GA, GB, GC, GD, R1, RR, SQEN
!...
!...VERIFY ARRAY SIZES MATCH
N1 = ASSERT_EQ(SIZE(X1),SIZE(Y1),"KS2D1S")
!...
!...INITIALIZE D1
D1 = ZERO_S
!...
!...LOOP OVER THE DATA POINTS
DO J = 1,N1
    CALL QUADCT(X1(J),Y1(J),X1,Y1,FA,FB,FC,FD)
    CALL QUADVL(X1(J),Y1(J),GA,GB,GC,GD)
    D1 = MAX(D1,ABS(FA-GA),ABS(FB-GB),ABS(FC-GC),ABS(FD-GD))
                                                                        ! FOR BOTH THE SAMPLE AND THE MODEL,
                                                                        ! THE DISTRIBUTION IS INTEGRATED IN EACH
                                                                        ! OF FOUR QUADRANTS, AND THE MAXIMUM
                                                                        ! DIFFERENCE IS SAVED.
ENDDO
CALL PEARSN(X1,Y1,N1,R1,DUM,DUMM)                                       ! GET THE LINEAR CORRELATION COEFFICIENT R1.
SQEN = SQRT(REAL(N1, KIND=SP))
  RR = SQRT(ONE_S-R1**2)
!...
!...ESTIMATE THE PROBABILITY USING THE K-S PROBABILITY FUNCTION PROBKS
PROB = PROBKS(D1*SQEN/(ONE_S+RR*(QUART_S-0.75_SP/SQEN)))
!...
!...DONE
END SUBROUTINE KS2D1S
!...
!--------------------------------------------------------------------
!...
SUBROUTINE QUADVL(X,Y,FA,FB,FC,FD)
!...
!...THIS IS A SAMPLE OF A USER-SUPPLIED ROUTINE TO BE USED WITH KS2D1S. IN THIS CASE, THE MODEL
!...DISTRIBUTION IS UNIFORM INSIDE THE SQUARE −1 < X < 1, −1 < Y < 1. IN GENERAL THIS ROUTINE
!...SHOULD RETURN, FOR ANY POINT (X; Y), THE FRACTION OF THE TOTAL DISTRIBUTION IN EACH OF THE
!...FOUR QUADRANTS AROUND THAT POINT. THE FRACTIONS, FA, FB, FC, AND FD, MUST ADD UP TO 1.
!...QUADRANTS ARE ALPHABETICAL, COUNTERCLOCKWISE FROM THE UPPER RIGHT.
!...
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: MIN, MAX
!...
!...TRANSMITTED VARIABLES
REAL(SP)                                            :: FA, FB, FC, FD, X, Y
!...
!...LOCAL VARIABLES
REAL(SP)                                            :: QA, QB, QC, QD
!...
QA = MIN(TWO_S,MAX(ZERO_S,ONE_S-X))
QB = MIN(TWO_S,MAX(ZERO_S,ONE_S-Y))
QC = MIN(TWO_S,MAX(ZERO_S,X+ONE_S))
QD = MIN(TWO_S,MAX(ZERO_S,Y+ONE_S))
!...
FA = QUART_S*QA*QB
FB = QUART_S*QB*QC
FC = QUART_S*QC*QD
FD = QUART_S*QD*QA
!...
!...DONE
RETURN
END SUBROUTINE QUADVL
!...
!--------------------------------------------------------------------
!...
SUBROUTINE KS2D2S(X1,Y1,NX,X2,Y2,NY,D,PROB)
!...
!...COMPUTE TWO-DIMENSIONAL KOLMOGOROV-SMIRNOV TEST ON TWO SAMPLES. INPUT ARE THE X- AND
!...Y-COORDINATES OF THE FIRST SAMPLE IN ARRAYS X1 AND Y1 OF THE SAME LENGTH, AND OF THE SECOND
!...SAMPLE IN ARRAYS X2 AND Y2 OF THE SAME LENGTH (POSSIBLY DIFFERENT FROM THE LENGTH OF THE FIRST
!...SAMPLE). THE ROUTINE RETURNS THE TWO-DIMENSIONAL, TWO-SAMPLE K-S STATISTIC AS D, AND ITS
!...SIGNIFICANCE LEVEL AS PROB. SMALL VALUES OF PROB SHOW THAT THE TWO SAMPLES ARE SIGNIFICANTLY
!...DIFFERENT. NOTE THAT THE TEST IS SLIGHTLY DISTRIBUTION-DEPENDENT, SO PROB IS ONLY AN ESTIMATE.
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ASSERT_EQ
USE NR_SP,  ONLY : PEARSN, PROBKS, QUADCT
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ABS, MAX, SIZE
!...
!...TRANSMITTED VARIABLES
INTEGER(I4B), INTENT(IN)                            :: NX, NY
REAL(SP), DIMENSION(1:NX), INTENT(IN)               :: X1, Y1
REAL(SP), DIMENSION(1:NY), INTENT(IN)               :: X2, Y2
REAL(SP), INTENT(OUT)                               :: D, PROB
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: J, N1, N2
REAL(SP)                                            :: D1, D2, DUM, DUMM, FA, FB, FC, FD
REAL(SP)                                            :: GA, GB, GC, GD, R1, R2, RR, SQEN
!...
!...VERIFY ARRAY SIZES MATCH
N1 = ASSERT_EQ(SIZE(X1),SIZE(Y1),"KS2D2S: N1")
N2 = ASSERT_EQ(SIZE(X2),SIZE(Y2),"KS2D2S: N2")
!...
!...! FIRST, USE POINTS IN THE FIRST SAMPLE AS ORIGINS
D1 = ZERO_S
DO J = 1,N1
    CALL QUADCT(X1(J),Y1(J),X1,Y1,FA,FB,FC,FD)
    CALL QUADCT(X1(J),Y1(J),X2,Y2,GA,GB,GC,GD)
    D1 = MAX(D1, ABS(FA-GA), ABS(FB-GB), ABS(FC-GC), ABS(FD-GD))
ENDDO
!...
!...THEN, USE POINTS IN THE SECOND SAMPLE AS ORIGINS
D2 = ZERO_S
DO J = 1,N2
    CALL QUADCT(X2(J),Y2(J),X1,Y1,FA,FB,FC,FD)
    CALL QUADCT(X2(J),Y2(J),X2,Y2,GA,GB,GC,GD)
    D2 = MAX(D2, ABS(FA-GA), ABS(FB-GB), ABS(FC-GC), ABS(FD-GD))
ENDDO
!...
!...AVERAGE THE K-S STATISTICS
D = HALF_S*(D1+D2)
SQEN = SQRT(REAL(N1, KIND=SP)*REAL(N2, KIND=SP)/REAL(N1+N2, KIND=SP))
!...
!...GET THE LINEAR CORRELATION COEFFICIENT FOR EACH SAMPLE.
CALL PEARSN(X1,Y1,N1,R1,DUM,DUMM)
CALL PEARSN(X2,Y2,N1,R2,DUM,DUMM)
!...
!...ESTIMATE THE PROBABILITY USING THE K-S PROBABILITY FUNCTION PROBKS
RR   = SQRT(ONE_S-HALF_S*(R1**2+R2**2))
PROB = PROBKS(D*SQEN/(ONE_S+RR*(QUART_S-0.75_SP/SQEN)))
!...
!...DONE
END SUBROUTINE KS2D2S
!...
! -------------------------------------------------------------------
!...
SUBROUTINE QUADCT(X,Y,XX,YY,FA,FB,FC,FD)
!...
!...GIVEN AN ORIGIN (X, Y), AND AN ARRAY OF POINTS WITH COORDINATES XX AND YY, COUNT HOW MANY OF
!...THEM ARE IN EACH QUADRANT AROUND THE ORIGIN, AND RETURN THE NORMALIZED FRACTIONS. QUADRANTS
!...ARE LABELED ALPHABETICALLY, COUNTERCLOCKWISE FROM THE UPPER RIGHT. USED BY KS2D1S AND KS2D2S.
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ASSERT_EQ
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: COUNT
!...
!...TRANSMITTED VARIABLES
!INTEGER(I4B), INTENT(IN)                            :: N1, N2
REAL(SP), INTENT(IN)                                :: X, Y
REAL(SP), DIMENSION(:), INTENT(IN)                  :: XX, YY
REAL(SP), INTENT(OUT)                               :: FA, FB, FC, FD
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: NA, NB, NC, ND, NN
REAL(SP)                                            :: FF
!...
!...VERIFY ARRAY SIZES MATCH
NN = ASSERT_EQ(SIZE(XX),SIZE(YY),"QUADCT")
!...
!...CALCULATION
NA = COUNT(YY(:) >  Y .AND. XX(:) >  X)
NB = COUNT(YY(:) >  Y .AND. XX(:) <= X)
NC = COUNT(YY(:) <= Y .AND. XX(:) <= X)
ND = NN-NA-NB-NC
FF = ONE_S/NN
FA = FF*NA
FB = FF*NB
FC = FF*NC
FD = FF*ND
!...
!...DONE
END SUBROUTINE QUADCT
!...
! -------------------------------------------------------------------
!...
REAL(SP) FUNCTION PROBKS(ALAM)
!...
!...KOLMOGOROV-SMIRNOV PROBABILITY FUNCTION
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ABS
!...
!...TRANSMITTED VARIABLES
REAL(SP), INTENT(IN)                                :: ALAM
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: J
INTEGER(I4B), PARAMETER                             :: NITER=100
REAL(SP)                                            :: A2, FAC, TERM, TERMBF
REAL(SP), PARAMETER                                 :: EPS1=THOUTH_S, EPS2=1.0E-8_SP
!...
!...CALCULATIONS
A2     = -TWO_S*ALAM**2
FAC    = TWO_S
PROBKS = ZERO_S
TERMBF = ZERO_S                                                             !...PREVIOUS TERM IN SUM.
!
DO J = 1,NITER
    TERM   = FAC*EXP(A2*J**2)
    PROBKS = PROBKS+TERM
    IF (ABS(TERM) <= EPS1*TERMBF .OR. ABS(TERM) <= EPS2*PROBKS) RETURN
    FAC = -FAC                                                              !...ALTERNATING SIGNS IN SUM.
    TERMBF = ABS(TERM)
ENDDO
!
PROBKS = ONE_S                                                              !...GET HERE ONLY BY FAILING TO CONVERGE, WHICH IMPLIES THE FUNCTION IS VERY CLOSE TO 1.
!...
!...DONE
END FUNCTION PROBKS
!...
! -------------------------------------------------------------------
!...
SUBROUTINE HUNT(XX,N,X,JLO)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...TRANSMITTED VARIABLES
INTEGER(I4B), INTENT(IN)                                :: N
INTEGER(I4B), INTENT(INOUT)                             :: JLO
REAL(SP), INTENT(IN)                                    :: X
REAL(SP), DIMENSION(1:N), INTENT(IN)                    :: XX
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                            :: INC, JHI, JM
LOGICAL                                                 :: ASCND
!...
!...CALCULATION
!N=SIZE(XX)
ASCND = (XX(N) >= XX(1))
IF (JLO <= 0 .OR. JLO > N) THEN
    JLO = 0
    JHI = N+1
ELSE
    INC = 1
    IF (X >= XX(JLO) .EQV. ASCND) THEN
        DO
            JHI = JLO+INC
            IF (JHI > N) THEN
                JHI = N+1
                EXIT
            ELSE
                IF (X < XX(JHI) .EQV. ASCND) EXIT
                JLO = JHI
                INC = INC+INC
            ENDIF
        ENDDO
    ELSE
        JHI = JLO
        DO
            JLO = JHI-INC
            IF (JLO < 1) THEN
                JLO = 0
                EXIT
            ELSE
                IF (X >= XX(JLO) .EQV. ASCND) EXIT
                JHI = JLO
                INC = INC+INC
            ENDIF
        ENDDO
    ENDIF
ENDIF
DO
    IF (JHI-JLO <= 1) THEN
        IF (X == XX(N)) JLO = N-1
        IF (X == XX(1)) JLO = 1
        EXIT
    ELSE
        JM = (JHI+JLO)/2
        IF (X >= XX(JM) .EQV. ASCND) THEN
            JLO = JM
        ELSE
            JHI = JM
        ENDIF
    ENDIF
ENDDO
!...
!...DONE
END SUBROUTINE HUNT
!...
! -------------------------------------------------------------------
!...
SUBROUTINE DURBIN(N,YD,YM,DWS,PROBDW)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ARRAY_COPY
USE NR_SP,  ONLY : SORT2
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: SUM
!...
!...TRANSMITTED VARIABLES
INTEGER(I4B), INTENT(IN)                            :: N
REAL(SP), INTENT(OUT)                               :: DWS, PROBDW
REAL(SP), DIMENSION(1:N), INTENT(IN)                :: YD, YM
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: I, N_COPIED, N_NOT_COPIED
REAL(SP)                                            :: EI2, EEI, EEI2, RHO
REAL(SP), DIMENSION(1:N)                            :: EI, YDW, YSLAVE
!...
!...CALCULATE DWS DENOMINATOR
EI(:) = (YD(:)-YM(:))
EI2   = SUM((EI)**2)
!...
!...CALCULATE DWS NUMERATOR
IF (N < 1000) THEN
    EEI2 = ZERO_S
    DO I = 2,N
        EEI2 = EEI2 + (EI(I)-EI(I-1))**2
    ENDDO
ELSE
!...
!...CALCULATE DWS NUMERATOR FOR WHEN N IS LARGE (HOW LARGE IS LARGE? N=1000?)
    EEI = ZERO_S
    DO I = 2,N
        EEI = EEI + (EI(I)*EI(I-1))
    ENDDO
    RHO = EEI/EI2
ENDIF
!...
!...CALCULATE DURBIN-WATSON STATISTIC
IF (N < 1000) THEN
    DWS = EEI2/EI2
ELSE
    DWS = TWO_S-TWO_S*RHO   ! CAN BE USED WHEN N IS LARGE
ENDIF
!...
!...SORT SMOOTHING ARRAY IN PREPARATION FOR CALCULATING DURBIN-WATSON PROBABILITY
CALL ARRAY_COPY (YM,YDW,N_COPIED,N_NOT_COPIED)
IF (N_NOT_COPIED > 0) THEN
    CALL EXECUTE_COMMAND_LINE("CLS")
    CALL EXECUTE_COMMAND_LINE("COLOR 0D")
    DO I = 1,3
        WRITE (*,*)
    ENDDO
    WRITE (*,*)"SERIOUS ERROR --> ARRAY YDW NOT CORRECTLY COPIED, DURBIN-WATSON PROBABILITY NOT CALCULATED"
ENDIF
CALL SORT2(YDW,YSLAVE)
!...
!...CALCULATE DURBIN-WATSON PROBABILITY
CALL GRADSOL(YDW,N,ZERO_S,DWS,15,PROBDW)
!...
!...
CONTAINS
!...
! -------------------------------------------------------------------
!...
    SUBROUTINE GRADSOL(AA,M,CC,DWS,N,PROB)
!...
!...TRANSLATION OF AMENDED VERSION OF APPLIED STATISTICS ALGORITHM
!...AS 153 (AS R52), VOL. 33, 363-366, 1984.
!...BY R.W. FAREBROTHER  (ORIGINALLY NAMED GRADSOL OR PAN)
!...
!...GRADSOL EVALUATES THE PROBABILITY THAT A WEIGHTED SUM OF
!...SQUARED STANDARD NORMAL VARIATES DIVIDED BY X TIMES THE
!...UNWEIGHTED SUM IS LESS THAN A GIVEN CONSTANT, I.E. THAT
!...A1.U1**2 + A2.U2**2 + ... + AM.UM**2 <
!...X*(U1**2 + U2**2 + ... + UM**2) +
!...WHERE THE U'S ARE STANDARD NORMAL VARIABLES.
!...FOR THE DURBIN-WATSON STATISTIC, X = DW, C = 0, AND
!...A ARE THE NON-ZERO EIGENVALUES OF THE "M*A" MATRIX.
!...
!...THE ELEMENTS A(I) MUST BE ORDERED.  A(0) = X
!...N = THE NUMBER OF TERMS IN THE SERIES.  THIS DETERMINES THE
!...ACCURACY AND ALSO THE SPEED.  NORMALLY N SHOULD BE ABOUT 10-15.
!...
!-------------------------------------------------------------------
!...
!...ORIGINALLY FROM STATLIB.  REVISED 5/3/1996 BY CLINT CUMMINS:
!...1. DIMENSION A STARTING FROM 0  (FORTRAN 77)
!...   IF THE USER DOES NOT INITIALIZE A(0) = X,
!...   THERE WOULD BE UNPREDICTABLE RESULTS, SINCE A(0) IS ACCESSED
!...   WHEN J2=0 FOR THE FINAL DO 60 LOOP.
!...2. USE X VARIABLE TO AGREE WITH PUBLISHED CODE
!...3. FIX BUG 2 LINES BELOW  DO 60 L2 = J2, NU, D
!...   PROD = A(J2)  -- PROD = A(L2)
!...   (PRIOR TO THIS FIX, ONLY THE TESTS WITH M=3 WORKED CORRECTLY)
!...4. TRANSLATE TO UPPERCASE AND REMOVE TABS
!...   TESTED SUCCESSFULLY ON THE FOLLOWING BENCHMARKS:
!...1. FAREBROTHER 1984 TABLE (X=0):
!...   A           C   PROBABILITY
!...   1,3,6       1   .0542
!...   1,3,6       7   .4936
!...   1,3,6      20   .8760
!...   1,3,5,7,9   5   .0544
!...   1,3,5,7,9  20   .4853
!...   1,3,5,7,9  50   .9069
!...   3,4,5,6,7   5   .0405
!...   3,4,5,6,7  20   .4603
!...   3,4,5,6,7  50   .9200
!...2. DURBIN-WATSON 1951/71 SPIRITS DATASET, FOR
!...   X=.2,.3,...,3.8, C=0
!...   COMPARED WITH BETA APPROXIMATION  (M=66), A SORTED IN
!...   REVERSE ORDER
!...3. JUDGE, ET AL 2ND ED. P.399 DATASET, FOR X=.2,.3,...,3.8, C=0
!...   COMPARED WITH BETA APPROXIMATION  (M=8), A SORTED IN
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                           :: ABS, COS
!...
!...TRANSMITTED VARIABLES
    INTEGER(I4B), INTENT(IN)                            :: M, N
    REAL(SP), INTENT(IN)                                :: CC, DWS
    REAL(SP), INTENT(OUT)                               :: PROB
    REAL(SP), DIMENSION(0:M), INTENT(IN)                :: AA
!...
!...LOCAL VARIABLES
    INTEGER(I4B)                                        :: D, H, I, J1, J2, J3, J4, K, L1, L2, NU, N2
    REAL(WP)                                            :: NUM, PIN, PROD, SGN, SUMM, SUMM1, X, U, V, Y, C, DW
    REAL(WP), DIMENSION(0:M)                            :: A
!...
!...CONVERT SINGLE PRECISION VARIABLES TO WORK PRECISION
    C  = REAL(CC,  KIND=WP)
    A  = REAL(AA,  KIND=WP)
    DW = REAL(DWS, KIND=WP)
!...
!...SET NU = INDEX OF 1ST A(I) >= X AND ALLOW FOR THE A'S BEING IN REVERSE ORDER
    IF (A(1) > A(M)) THEN
        H =  M
        K = -1
        I =  1
    ELSE
        H =  1
        K =  1
        I =  M
    ENDIF
    X = DW  !A(0)
    DO NU = H,I,K
        IF (A(NU) >= X) GOTO 20
    ENDDO
!...
!...IF ALL A'S ARE -VE AND C >= 0, THEN PROBABILITY = 1
    IF (C >= ZERO_W) THEN
        PROB = ONE_W
        RETURN
    ENDIF
!...
!...SIMILARLY IF ALL THE A'S ARE +VE AND C <= 0, THEN PROBABILITY  = 0
    20 CONTINUE
    IF (NU == H .AND. C <= ZERO_W) THEN
        PROB = ZERO_W
        RETURN
    ENDIF
    IF (K == 1) NU = NU-1
    H = M-NU
    IF (C == ZERO_W) THEN
        Y = H-NU
    ELSE
        Y = C*(A(1) - A(M))
    ENDIF
    IF (Y >= ZERO_W) THEN
         D =  2
         H =  NU
         K = -K
        J1 =  0
        J2 =  2
        J3 =  3
        J4 =  1
    ELSE
         D = -2
        NU =  NU+1
        J1 =  M-2
        J2 =  M-1
        J3 =  M+1
        J4 =  M
    ENDIF
     PIN = TWO_W*ATAN(ONE_W)/REAL(N, KIND=WP)
    SUMM = HALF_W*(K+1)
     SGN = K/REAL(N, KIND=WP)
      N2 = N+N-1
!...
!...FIRST INTEGRALS
    DO L1 = H-2*(H/2),0,-1
        DO L2 = J2,NU,D
            SUMM1 = A(J4)
!...
!...FIX BY CLINT CUMMINS 5/3/96 [PROD = A(J2)]
            PROD = A(L2)
            U = HALF_W*(SUMM1+PROD)
            V = HALF_W*(SUMM1-PROD)
            SUMM1 = ZERO_W
            DO I = 1,N2,2
                Y = U-V*COS(REAL(I, KIND=WP)*PIN)
                NUM = Y-X
                PROD = EXP(-C/NUM)
                DO K = 1,J1
                    PROD = PROD*NUM/(Y-A(K))
                ENDDO
                DO  K = J3,M
                    PROD = PROD*NUM/(Y-A(K))
                ENDDO
                SUMM1 = SUMM1 + SQRT(ABS(PROD))
            ENDDO
            SGN = -SGN
            SUMM = SUMM+SGN*SUMM1
            J1 = J1+D
            J3 = J3+D
            J4 = J4+D
        ENDDO
!...
!...SECOND INTEGRAL
        IF (D == 2) THEN
            J3 = J3-1
        ELSE
            J1 = J1+1
        ENDIF
        J2 = 0
        NU = 0
    ENDDO
    PROB = REAL(SUMM, KIND=SP)
!...
!...DONE
    RETURN
    END SUBROUTINE GRADSOL
!...
!...REALLY DONE
END SUBROUTINE DURBIN
!...
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                   SUBROUTINE CHSONE                  *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 09/27/18          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...SUBROUTINE TO COMPARE ORIGINAL AND FITTED DATA SETS
SUBROUTINE CHSONE (BINS,EBINS,NBINS,KNSTRN,DF,CHSQ,PROB)
!...
!...GIVEN THE SAME-SIZE ARRAYS BINS CONTAINING THE OBSERVED NUMBERS OF EVENTS, AND EBINS
!...CONTAINING THE EXPECTED NUMBERS OF EVENTS, AND GIVEN THE NUMBER OF CONSTRAINTS KNSTRN
!...(NORMALLY ONE), THIS ROUTINE RETURNS (TRIVIALLY) THE NUMBER OF DEGREES OF FREEDOM DF, AND
!...(NONTRIVIALLY) THE CHI-SQUARE CHSQ AND THE SIGNIFICANCE PROB. A SMALL VALUE OF PROB INDICATES
!...A SIGNIFICANT DIFFERENCE BETWEEN THE DISTRIBUTIONS BINS AND EBINS. NOTE THAT BINS
!...AND EBINS ARE BOTH REAL ARRAYS, ALTHOUGH BINS WILL NORMALLY CONTAIN INTEGER VALUES.
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ASSERT_EQ, NRERROR
USE NR_SP,  ONLY : GAMMQ
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ANY, SIZE, SUM
!...
!...IDENTIFY TRANSFERED VALIABLES
INTEGER(I4B), INTENT(IN)                            :: KNSTRN, NBINS
REAL(SP), INTENT(OUT)                               :: DF, CHSQ, PROB
REAL(SP), DIMENSION(1:NBINS), INTENT(IN)            :: BINS, EBINS
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                        :: NDUM
!...
!===================================================================================
!...
NDUM = ASSERT_EQ(SIZE(BINS),SIZE(EBINS),"CHSONE")
!IF (ANY(EBINS(:) <= ZERO_S)) CALL NRERROR('BAD EXPECTED NUMBER IN CHSONE')

DF   = SIZE(BINS)-KNSTRN
CHSQ = SUM((BINS(:)-EBINS(:))**2/EBINS(:))
!...
!...CHI-SQUARE PROBABILITY FUNCTION. SEE §6.2.
PROB = GAMMQ(HALF_S*DF,HALF_S*CHSQ)
!...
!...DONE
END SUBROUTINE CHSONE
!...
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                   SUBROUTINE CHSTWO                  *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 09/27/18          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...SUBROUTINE TO COMPARE ORIGINAL AND FITTED DATA SETS
SUBROUTINE CHSTWO(BINS1,BINS2,NBINS,KNSTRN,DF,CHSQ,PROB)
!...
!...GIVEN THE SAME-SIZE ARRAYS BINS1 AND BINS2, CONTAINING TWO SETS OF BINNED DATA, AND GIVEN
!...THE NUMBER OF CONSTRAINTS KNSTRN (NORMALLY 1 OR 0), THIS ROUTINE RETURNS THE NUMBER OF
!...DEGREES OF FREEDOM DF, THE CHI-SQUARE CHSQ, AND THE SIGNIFICANCE PROB. A SMALL VALUE OF
!...PROB INDICATES A SIGNIFICANT DIFFERENCE BETWEEN THE DISTRIBUTIONS BINS1 AND BINS2. NOTE
!...THAT BINS1 AND BINS2 ARE BOTH REAL ARRAYS, ALTHOUGH THEY WILL NORMALLY CONTAIN INTEGER
!...VALUES.
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ASSERT_EQ
USE NR_SP,  ONLY : GAMMQ
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: COUNT, SIZE, SUM
!...
!...IDENTIFY TRANSFERED VALIABLES
INTEGER(I4B), INTENT(IN)                            :: KNSTRN, NBINS
REAL(SP), INTENT(OUT)                               :: DF, CHSQ, PROB
REAL(SP), DIMENSION(1:NBINS), INTENT(IN)            :: BINS1, BINS2
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                        :: NDUM
LOGICAL(TLG), DIMENSION(SIZE(BINS1))                :: NZEROMASK
!...
!===================================================================================
!...
NDUM = ASSERT_EQ(SIZE(BINS1),SIZE(BINS2),"CHSTWO")
NZEROMASK = BINS1(:) /= ZERO_S .OR. BINS2(:) /= ZERO_S
CHSQ = SUM((BINS1(:)-BINS2(:))**2/(BINS1(:)+BINS2(:)),MASK = NZEROMASK)
!...
!...NO DATA MEANS ONE LESS DEGREE OF FREEDOM.
DF   = COUNT(NZEROMASK)-KNSTRN
!...
!...CHI-SQUARE PROBABILITY FUNCTION. SEE §6.2.
PROB = GAMMQ(HALF_S*DF,HALF_S*CHSQ)
!...
!...DONE
END SUBROUTINE CHSTWO
!...
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                    SUBROUTINE KSTWO                  *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 09/27/18          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...SUBROUTINE TO COMPARE ORIGINAL AND FITTED DATA SETS
SUBROUTINE KSTWO (DATA1,DATA2,D,PROB)
!...
!...GIVEN ARRAYS DATA1 AND DATA2, WHICH CAN BE OF DIFFERENT LENGTH, THIS ROUTINE RETURNS THE
!...K–S STATISTIC D, AND THE SIGNIFICANCE LEVEL PROB FOR THE NULL HYPOTHESIS THAT THE DATA SETS
!...ARE DRAWN FROM THE SAME DISTRIBUTION. SMALL VALUES OF PROB SHOW THAT THE CUMULATIVE
!...DISTRIBUTION FUNCTION OF DATA1 IS SIGNIFICANTLY DIFFERENT FROM THAT OF DATA2. THE ARRAYS
!...DATA1 AND DATA2 ARE NOT MODIFIED.
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : CUMSUM
USE NR_SP,  ONLY : PROBKS, SORT2
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ABS, MAXVAL, SIZE
!...
!...IDENTIFY TRANSFERED VARIABLES
REAL(SP), INTENT(OUT)                               :: D, PROB
REAL(SP), DIMENSION(:), INTENT(IN)                  :: DATA1, DATA2
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                        :: N1, N2
REAL(SP)                                            :: EN1, EN2, EN
REAL(SP), DIMENSION(SIZE(DATA1)+SIZE(DATA2))        :: DAT, ORG
!...
!===================================================================================
!...
N1  = SIZE(DATA1)
N2  = SIZE(DATA2)
EN1 = N1
EN2 = N2

DAT(1:N1)  = DATA1                           !...COPY THE TWO DATA SETS INTO A SINGLE ARRAY
DAT(N1+1:) = DATA2

ORG(1:N1)  = ZERO_S                          !...DEFINE AN ARRAY THAT CONTAINS 0 WHEN THE
                                             !...CORRESPONDING ELEMENT COMES FROM DATA1, 1 FROM DATA2
ORG(N1+1:) = ONE_S
!...
!...SORT THE ARRAY OF 1’S AND 0’S INTO THE ORDER OF THE MERGED DATA SETS
CALL SORT2(DAT,ORG)
!...
!...NOW USE CUMSUM TO GET THE C.D.F. CORRESPONDING TO EACH SET OF DATA
D    = MAXVAL(ABS(CUMSUM(ORG)/EN2-CUMSUM(ONE_S-ORG)/EN1))
EN   = SQRT(EN1*EN2/(EN1+EN2))
PROB = PROBKS((EN+0.12_SP+0.11_SP/EN)*D)     !...COMPUTE SIGNIFICANCE
!...
!...DONE
END SUBROUTINE KSTWO
!...
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!SUBROUTINE CRAM_MISES(N,Y,WN2)
!!...
!!...ADD TYPE AND UTILITY MODULES
!USE NRTYPE
!USE NRUTIL, ONLY : NRERROR, ARRAY_COPY
!!...
!!...ENSURE ALL VARIABLES IDENTIFIED
!IMPLICIT NONE
!!...
!!...INTRINSIC FUNCTIONS
!INTRINSIC                                           :: LOG
!!...
!!...IDENTIFY TRANSFERED VARIABLES
!INTEGER(I4B), INTENT(IN)                            :: N
!REAL(WP), INTENT(OUT)                               :: WN2
!REAL(WP), DIMENSION(1:N), INTENT(IN)                :: Y
!!...
!!...IDENTIFY SUBROUTINE VALIABLES
!INTEGER(I4B)                                        :: I, N_COPIED, N_NOT_COPIED
!REAL(WP)                                            :: S, XN, XI
!REAL(WP), DIMENSION(1:N)                            :: X
!!...
!!===================================================================================
!!...
!!...SET INTEGER N TO REAL XN
!XN = REAL(N, KIND=WP)
!!...
!!...COPY ARRAY Y TO ARRAY X IN PREPARATION TO SORTING
!CALL ARRAY_COPY (Y,X,N_COPIED,N_NOT_COPIED)
!IF (N_NOT_COPIED > 0) THEN
!    CALL EXECUTE_COMMAND_LINE("CLS")
!    CALL EXECUTE_COMMAND_LINE("COLOR 0D")
!    DO I = 1,3
!        WRITE (*,*)
!    ENDDO
!    CALL NRERROR("FATAL ERROR --> ARRAY Y NOT CORRECTLY COPIED TO ARRAY X FOR ANDERSON-DARLING TEST STATISTIC")
!ENDIF
!!...
!!...SORT ARRAY X ARRAY IN ASCENDING ORDER
!CALL SORT_PICKED (N,X)
!!...
!!...CALCULATE THE CRAMER VON MISES STATISTIC
!S = ZERO_S
!DO I = 1,N
!    XI = REAL(I, KIND=WP)
!    S = S + (EV1CDF(X(I)) - (TWO_W*XI - ONE_W)/(TWO_W*XN))**2
!ENDDO
!WN2 = ONE_W/(TWELVE_W*XN) + S
!...
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
SUBROUTINE AND_DAR(N,Y,A2,A3,ADP)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : NRERROR, ARRAY_COPY
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: LOG
!...
!...IDENTIFY TRANSFERED VARIABLES
INTEGER(I4B), INTENT(IN)                            :: N
REAL(WP), INTENT(OUT)                               :: A2, ADP, A3
REAL(WP), DIMENSION(1:N), INTENT(IN)                :: Y
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                        :: I, N_COPIED, N_NOT_COPIED
REAL(WP)                                            :: S, AD, XN, XI
REAL(WP), DIMENSION(1:N)                            :: X
!...
!===================================================================================
!...
!...SET INTEGER N TO REAL XN
XN = REAL(N, KIND=WP)
!...
!...COPY ARRAY Y TO ARRAY X IN PREPARATION TO SORTING
CALL ARRAY_COPY (Y,X,N_COPIED,N_NOT_COPIED)
IF (N_NOT_COPIED > 0) THEN
    CALL EXECUTE_COMMAND_LINE("CLS")
    CALL EXECUTE_COMMAND_LINE("COLOR 0D")
    DO I = 1,3
        WRITE (*,*)
    ENDDO
    CALL NRERROR("FATAL ERROR --> ARRAY Y NOT CORRECTLY COPIED TO ARRAY X FOR ANDERSON-DARLING TEST STATISTIC")
ENDIF
!...
!...SORT ARRAY X ARRAY IN ASCENDING ORDER
CALL SORT_PICKED (N,X)
!...
!...CALCULATE S FOR ANDERSON-DARLING TEST STATISTIC
S = ZERO_S
DO I = 1,N
    XI = REAL(I, KIND=WP)
!    S = S + (REAL((2*I-1)/N, KIND=WP) * (LOG(EV1CDF(X(I))) + LOG(ONE_W-EV1CDF(X(N+1-I)))))
!    S = S + (REAL((2*I-1)/N, KIND=WP) * (LOG(EXPCDF(Y(I))) + LOG(ONE_W-EXPCDF(Y(N+1-I)))))
!    S = S + (REAL((2*I-1)/N, KIND=WP) * (LOG(WEICDF(Y(I),ONE_W)) + LOG(ONE_W-WEICDF(Y(N+1-I),ONE_W))))
!    S = S + (REAL((2*I-1)/N, KIND=WP) * (LOG(GAMCDF(Y(I),ONE_W)) + LOG(ONE_W-GAMCDF(Y(N+1-I),ONE_W))))

    S = S + ((TWO_W*XI-ONE_W)/XN * (LOG(EV1CDF(X(I))) + LOG(ONE_W-EV1CDF(X(N+1-I)))))
!    S = S + ((TWO_W*XI-ONE_W)/XN * (LOG(EXPCDF(X(I))) + LOG(ONE_W-EXPCDF(X(N+1-I)))))
!    S = S + ((TWO_W*XI-ONE_W)/XN * (LOG(WEICDF(X(I),ONE_W)) + LOG(ONE_W-WEICDF(X(N+1-I),ONE_W))))
!    S = S + ((TWO_W*XI-ONE_W)/XN * (LOG(GAMCDF(X(I),ONE_W)) + LOG(ONE_W-GAMCDF(X(N+1-I),ONE_W))))
ENDDO
A2 = -XN-S
A3 = A2*(ONE_W + (FOUR_W/XN) - (25.0_WP/(XN*XN)))
!...
!...CALCULATE ANDERSON-DARLING P-VALUE
AD = A2*(ONE_W + 0.75_WP/XN + 2.25_WP/(XN*XN))
IF (AD < 0.2_WP) THEN
    ADP = ONE_W - EXP(-13.436_WP + 101.14_WP*AD - 223.73_WP*AD**2)
ELSEIF (AD < 0.34_WP) THEN
    ADP = ONE_W - EXP(-8.318_WP + 42.796_WP*AD - 59.938_WP*AD**2)
ELSEIF (AD < 0.6_WP) THEN
    ADP = EXP(0.9177_WP - 4.279_WP*AD - 1.38_WP*AD**2)
ELSEIF (AD < 13.0_WP) THEN
    ADP = EXP(1.2937_WP - 5.709_WP*AD + 0.0186_WP*AD**2)
ELSE
    ADP = ZERO_W
ENDIF
!...
!...
!IF (AD >= 0.6_WP) THEN
!    ADP = EXP(1.2937_WP - 5.709_WP*AD + 0.0186_WP*AD*AD)
!ELSEIF ((AD > 0.34_WP) .AND. (AD < 0.6_WP)) THEN
!    ADP = EXP(0.9177_WP - 4.279_WP*A2 - 1.38_WP*A2*A2)
!ELSEIF ((AD > FIFTH_W) .AND. (A2 < 0.34_WP)) THEN
!    ADP = ONE_W - EXP(-8.318_WP + 42.796_WP*A2 - 59.938_WP*A2*A2)
!ELSEIF ((AD <= FIFTH_W) .AND. (A3 < 0.34_WP)) THEN
!    ADP = ONE_W - EXP(-13.436_WP + 101.14_WP*AD - 223.73_WP*AD*AD)
!ENDIF
!...
!...
CONTAINS
!...
!**********************************************************************************************
!...
!...
!...SUBROUTINE TO SORT DATA1 IN ASCENDING ORDER
    SUBROUTINE SORT_PICKED(NN,ARR)
!...
!...SORTS AN ARRAY ARR INTO ASCENDING NUMERICAL ORDER, BY STRAIGHT INSERTION.  ARR IS REPLACED
!...ON OUTPUT BY ITS SORTED REARRANGEMENT.
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                            :: NN
    REAL(WP), DIMENSION(1:NN), INTENT(INOUT)            :: ARR
!...
!...IDENTIFY LOCAL VARIABLES
    INTEGER(I4B)                                        :: I, J
    REAL(WP)                                            :: AA
!...
!...BEGIN SORTING
    DO J = 2,NN
        AA = ARR(J)
        DO I = J-1,1,-1
            IF (ARR(I) <= AA) EXIT
            ARR(I+1) = ARR(I)
        ENDDO
        ARR(I+1) = AA
    ENDDO
!...
!...DONE WITH SORT ROUTINE
    END SUBROUTINE SORT_PICKED
!...
!**********************************************************************************************
!...
!...
! CODE CONVERTED USING TO_F90 BY ALAN MILLER
! DATE: 2019-03-06  TIME: 09:08:36
!...
    REAL(WP) FUNCTION EV1CDF (X)
!...
!     PURPOSE--THIS SUBROUTINE COMPUTES THE CUMULATIVE DISTRIBUTION
!              FUNCTION VALUE FOR THE EXTREME VALUE TYPE 1
!              DISTRIBUTION.
!              THE EXTREME VALUE TYPE 1 DISTRIBUTION USED
!              HEREIN HAS MEAN = EULER'S NUMBER = 0.57721566
!              AND STANDARD DEVIATION = PI/SQRT(6) = 1.28254983.
!              THIS DISTRIBUTION IS DEFINED FOR ALL X
!              AND HAS THE PROBABILITY DENSITY FUNCTION
!              F(X) = (EXP(-X)) * (EXP(-(EXP(-X))))
!     INPUT  ARGUMENTS--X      = THE SINGLE PRECISION VALUE
!                                AT WHICH THE CUMULATIVE DISTRIBUTION
!                                FUNCTION IS TO BE EVALUATED.
!     OUTPUT ARGUMENTS--CDF    = THE SINGLE PRECISION CUMULATIVE
!                                DISTRIBUTION FUNCTION VALUE.
!     OUTPUT--THE SINGLE PRECISION CUMULATIVE DISTRIBUTION
!             FUNCTION VALUE CDF FOR THE EXTREME VALUE TYPE 1
!             DISTRIBUTION WITH MEAN = EULER'S NUMBER = 0.57721566
!             AND STANDARD DEVIATION = PI/SQRT(6) = 1.28254983.
!     PRINTING--NONE UNLESS AN INPUT ARGUMENT ERROR CONDITION EXISTS.
!     RESTRICTIONS--NONE.
!     OTHER DATAPAC   SUBROUTINES NEEDED--NONE.
!     FORTRAN LIBRARY SUBROUTINES NEEDED--EXP.
!     MODE OF INTERNAL OPERATIONS--SINGLE PRECISION.
!     LANGUAGE--ANSI FORTRAN.
!     REFERENCES--JOHNSON AND KOTZ, CONTINUOUS UNIVARIATE
!                 DISTRIBUTIONS--1, 1970, PAGES 272-295.
!     WRITTEN BY--JAMES J. FILLIBEN
!                 STATISTICAL ENGINEERING LABORATORY (205.03)
!                 NATIONAL BUREAU OF STANDARDS
!                 WASHINGTON, D. C. 20234
!                 PHONE:  301-921-2315
!     ORIGINAL VERSION--NOVEMBER  1975.
!...
!---------------------------------------------------------------------
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                       :: EXP
!...
!...IDENTIFY TRANSFERED VARIABLES
    REAL(WP), INTENT(IN)                            :: X
!...
!-----START POINT-----------------------------------------------------
!...
    EV1CDF = ONE_W-EXP(-(EXP(-X)))
!...
!...DONE
    RETURN
    END FUNCTION EV1CDF
!...
!=====================================================================
!...
! CODE CONVERTED USING TO_F90 BY ALAN MILLER
! DATE: 2019-03-06  TIME: 10:04:56
!...
    REAL(WP) FUNCTION WEICDF(X,GAMA)
!...
!     PURPOSE--THIS SUBROUTINE COMPUTES THE CUMULATIVE DISTRIBUTION
!              FUNCTION VALUE FOR THE WEIBULL
!              DISTRIBUTION WITH SINGLE PRECISION
!              TAIL LENGTH PARAMETER = GAMMA.
!              THE WEIBULL DISTRIBUTION USED
!              HEREIN IS DEFINED FOR ALL POSITIVE X,
!              AND HAS THE PROBABILITY DENSITY FUNCTION
!              F(X) = GAMMA * (X**(GAMMA-1)) * EXP(-(X**GAMMA)).
!     INPUT  ARGUMENTS--X      = THE SINGLE PRECISION VALUE
!                                AT WHICH THE CUMULATIVE DISTRIBUTION
!                                FUNCTION IS TO BE EVALUATED.
!                                X SHOULD BE POSITIVE.
!                     --GAMMA  = THE SINGLE PRECISION VALUE
!                                OF THE TAIL LENGTH PARAMETER.
!                                GAMMA SHOULD BE POSITIVE.
!     OUTPUT ARGUMENTS--CDF    = THE SINGLE PRECISION CUMULATIVE
!                                DISTRIBUTION FUNCTION VALUE.
!     OUTPUT--THE SINGLE PRECISION CUMULATIVE DISTRIBUTION
!             FUNCTION VALUE CDF FOR THE WEIBULL DISTRIBUTION
!             WITH TAIL LENGTH PARAMETER VALUE = GAMMA.
!     PRINTING--NONE UNLESS AN INPUT ARGUMENT ERROR CONDITION EXISTS.
!     RESTRICTIONS--GAMMA SHOULD BE POSITIVE.
!                 --X SHOULD BE POSITIVE.
!     OTHER DATAPAC   SUBROUTINES NEEDED--NONE.
!     FORTRAN LIBRARY SUBROUTINES NEEDED--EXP.
!     MODE OF INTERNAL OPERATIONS--SINGLE PRECISION.
!     LANGUAGE--ANSI FORTRAN.
!     REFERENCES--JOHNSON AND KOTZ, CONTINUOUS UNIVARIATE
!                 DISTRIBUTIONS--1, 1970, PAGES 250-271.
!               --HASTINGS AND PEACOCK, STATISTICAL
!                 DISTRIBUTIONS--A HANDBOOK FOR
!                 STUDENTS AND PRACTITIONERS, 1975,
!                 PAGE 124.
!     WRITTEN BY--JAMES J. FILLIBEN
!                 STATISTICAL ENGINEERING LABORATORY (205.03)
!                 NATIONAL BUREAU OF STANDARDS
!                 WASHINGTON, D. C. 20234
!                 PHONE:  301-921-2315
!     ORIGINAL VERSION--NOVEMBER  1975.

!---------------------------------------------------------------------
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                       :: EXP
!...
!...IDENTIFY TRANSFERED VARIABLES
    REAL(WP), INTENT(IN)                            :: X, GAMA
!...
!...CHECK THE INPUT ARGUMENTS FOR ERRORS
    IF (X <= ZERO_W) GOTO 50
    IF (GAMA <= ZERO_W) GOTO 55
    GOTO 90
50  WRITE(*,4)
    WRITE(*,46) X
    WEICDF = ZERO_W
    RETURN
55  WRITE(*,15)
    WRITE(*,46) GAMA
    WEICDF = ZERO_W
    RETURN
90  CONTINUE
4  FORMAT(1X,"***** NON-FATAL DIAGNOSTIC--THE FIRST INPUT ARGUMENT TO THE WEICDF SUBROUTINE IS NON-POSITIVE *****")
15 FORMAT(1X,"***** FATAL ERROR--THE SECOND INPUT ARGUMENT TO THE WEICDF SUBROUTINE IS NON-POSITIVE *****")
46 FORMAT(1X,"***** THE VALUE OF THE ARGUMENT IS ",E15.8," *****")
!...
!-----START POINT-----------------------------------------------------
!...
    WEICDF = ONE_W-(EXP(-(X**GAMA)))
!...
!...DONE
    RETURN
    END FUNCTION WEICDF
!...
!=====================================================================
!...
! CODE CONVERTED USING TO_F90 BY ALAN MILLER
! DATE: 2019-03-06  TIME: 09:08:36
!...
    REAL(WP) FUNCTION EXPCDF (X)
!...
!     PURPOSE--THIS SUBROUTINE COMPUTES THE CUMULATIVE DISTRIBUTION
!              FUNCTION VALUE FOR THE EXTREME VALUE TYPE 1
!              DISTRIBUTION.
!              THE EXTREME VALUE TYPE 1 DISTRIBUTION USED
!              HEREIN HAS MEAN = EULER'S NUMBER = 0.57721566
!              AND STANDARD DEVIATION = PI/SQRT(6) = 1.28254983.
!              THIS DISTRIBUTION IS DEFINED FOR ALL X
!              AND HAS THE PROBABILITY DENSITY FUNCTION
!              F(X) = (EXP(-X)) * (EXP(-(EXP(-X))))
!     INPUT  ARGUMENTS--X      = THE SINGLE PRECISION VALUE
!                                AT WHICH THE CUMULATIVE DISTRIBUTION
!                                FUNCTION IS TO BE EVALUATED.
!     OUTPUT ARGUMENTS--CDF    = THE SINGLE PRECISION CUMULATIVE
!                                DISTRIBUTION FUNCTION VALUE.
!     OUTPUT--THE SINGLE PRECISION CUMULATIVE DISTRIBUTION
!             FUNCTION VALUE CDF FOR THE EXTREME VALUE TYPE 1
!             DISTRIBUTION WITH MEAN = EULER'S NUMBER = 0.57721566
!             AND STANDARD DEVIATION = PI/SQRT(6) = 1.28254983.
!     PRINTING--NONE UNLESS AN INPUT ARGUMENT ERROR CONDITION EXISTS.
!     RESTRICTIONS--NONE.
!     OTHER DATAPAC   SUBROUTINES NEEDED--NONE.
!     FORTRAN LIBRARY SUBROUTINES NEEDED--EXP.
!     MODE OF INTERNAL OPERATIONS--SINGLE PRECISION.
!     LANGUAGE--ANSI FORTRAN.
!     REFERENCES--JOHNSON AND KOTZ, CONTINUOUS UNIVARIATE
!                 DISTRIBUTIONS--1, 1970, PAGES 272-295.
!     WRITTEN BY--JAMES J. FILLIBEN
!                 STATISTICAL ENGINEERING LABORATORY (205.03)
!                 NATIONAL BUREAU OF STANDARDS
!                 WASHINGTON, D. C. 20234
!                 PHONE:  301-921-2315
!     ORIGINAL VERSION--NOVEMBER  1975.
!...
!---------------------------------------------------------------------
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                       :: EXP
!...
!...IDENTIFY TRANSFERED VARIABLES
    REAL(WP), INTENT(IN)                            :: X
!...
!-----START POINT-----------------------------------------------------
!...
    EXPCDF = ONE_W-EXP(-X)
!...
!...DONE
    RETURN
    END FUNCTION EXPCDF
!...
!=====================================================================
!...
    REAL(WP) FUNCTION GAMCDF(X,GAMA)
!...
!     PURPOSE--THIS SUBROUTINE COMPUTES THE CUMULATIVE DISTRIBUTION
!              FUNCTION VALUE FOR THE GAMMA
!              DISTRIBUTION WITH SINGLE PRECISION
!              TAIL LENGTH PARAMETER = GAMMA.
!              THE GAMMA DISTRIBUTION USED
!              HEREIN HAS MEAN = GAMMA
!              AND STANDARD DEVIATION = SQRT(GAMMA).
!              THIS DISTRIBUTION IS DEFINED FOR ALL POSITIVE X,
!              AND HAS THE PROBABILITY DENSITY FUNCTION
!              F(X) = (1/CONSTANT) * (X**(GAMMA-1)) * EXP(-X)
!              WHERE THE CONSTANT = THE GAMMA FUNCTION EVALUATED
!              AT THE VALUE GAMMA.
!     INPUT  ARGUMENTS--X      = THE SINGLE PRECISION VALUE
!                                AT WHICH THE CUMULATIVE DISTRIBUTION
!                                FUNCTION IS TO BE EVALUATED.
!                                X SHOULD BE POSITIVE.
!                     --GAMMA  = THE SINGLE PRECISION VALUE
!                                OF THE TAIL LENGTH PARAMETER.
!                                GAMMA SHOULD BE POSITIVE.
!     OUTPUT ARGUMENTS--CDF    = THE SINGLE PRECISION CUMULATIVE
!                                DISTRIBUTION FUNCTION VALUE.
!     OUTPUT--THE SINGLE PRECISION CUMULATIVE DISTRIBUTION
!             FUNCTION VALUE CDF FOR THE GAMMA DISTRIBUTION
!             WITH TAIL LENGTH PARAMETER VALUE = GAMMA.
!     PRINTING--NONE UNLESS AN INPUT ARGUMENT ERROR CONDITION EXISTS.
!     RESTRICTIONS--GAMMA SHOULD BE POSITIVE.
!                 --X SHOULD BE POSITIVE.
!     OTHER DATAPAC   SUBROUTINES NEEDED--NONE.
!     FORTRAN LIBRARY SUBROUTINES NEEDED--DEXP, DLOG.
!     MODE OF INTERNAL OPERATIONS--DOUBLE PRECISION.
!     LANGUAGE--ANSI FORTRAN.
!     ACCURACY--(ON THE UNIVAC 1108, EXEC 8 SYSTEM AT NBS)
!               COMPARED TO THE KNOWN GAMMA = 1 (EXPONENTIAL)
!               RESULTS, AGREEMENT WAS HAD OUT TO 7 SIGNIFICANT
!               DIGITS FOR ALL TESTED X.
!               THE TESTED X VALUES COVERED THE ENTIRE
!               RANGE OF THE DISTRIBUTION--FROM THE 0.00001
!               PERCENT POINT UP TO THE 99.99999 PERCENT POINT
!               OF THE DISTRIBUTION.
!     REFERENCES--WILK, GNANADESIKAN, AND HUYETT, 'PROBABILITY
!                 PLOTS FOR THE GAMMA DISTRIBUTION',
!                 TECHNOMETRICS, 1962, PAGES 1-15,
!                 ESPECIALLY PAGES 3-5.
!               --NATIONAL BUREAU OF STANDARDS APPLIED MATHEMATICS
!                 SERIES 55, 1964, PAGE 257, FORMULA 6.1.41.
!               --JOHNSON AND KOTZ, CONTINUOUS UNIVARIATE
!                 DISTRIBUTIONS--1, 1970, PAGES 166-206.
!               --HASTINGS AND PEACOCK, STATISTICAL
!                 DISTRIBUTIONS--A HANDBOOK FOR
!                 STUDENTS AND PRACTITIONERS, 1975,
!                 PAGES 68-73.
!     WRITTEN BY--JAMES J. FILLIBEN
!                 STATISTICAL ENGINEERING LABORATORY (205.03)
!                 NATIONAL BUREAU OF STANDARDS
!                 WASHINGTON, D. C. 20234
!                 PHONE:  301-921-2315
!     ORIGINAL VERSION--NOVEMBER  1975.

!---------------------------------------------------------------------
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                       :: EXP, LOG
!...
!...IDENTIFY TRANSFERED VARIABLES
    REAL(WP), INTENT(IN)                            :: X, GAMA
!...
!...IDENTIFY SUBROUTINE VALIABLES
    INTEGER(I4B), PARAMETER                         :: MAXIT=10000
    REAL(WP)                                        :: DX, DGAMMA, AI, TERM, SUMM, CUT1, CUT2, CUTOFF, T
    REAL(WP)                                        :: Z, Z2, Z3, Z4, Z5, DEN, A, B, G
    REAL(WP), PARAMETER                             :: C=0.918938533204672741_WP
    REAL(WP), DIMENSION(1:10), PARAMETER            :: D=(/ 0.833333333333333333E-1_WP, -0.277777777777777778E-2_WP,      &
                                                            0.793650793650793651E-3_WP, -0.595238095238095238E-3_WP,      &
                                                            0.841750841750841751E-3_WP, -0.191752691752691753E-2_WP,      &
                                                            0.641025641025641025E-2_WP, -0.295506535947712418E-1_WP,      &
                                                            0.179644372368830573000_WP, -0.139243221690590111E+1_WP /)
!...
!...CHECK THE INPUT ARGUMENTS FOR ERRORS
    IF (X <= ZERO_W) GOTO 50
    IF (GAMA <= ZERO_W) GOTO 55
    GOTO 90
50  WRITE(*,4)
    WRITE(*,46) X
    GAMCDF = ZERO_W
    RETURN
    55 WRITE(*,15)
    WRITE(*,46) GAMA
    GAMCDF = ZERO_W
    RETURN
90  CONTINUE
4  FORMAT(1X,"***** NON-FATAL DIAGNOSTIC--THE FIRST  INPUT ARGUMENT TO THE GAMCDF SUBROUTINE IS NON-POSITIVE *****")
15 FORMAT(1X,"***** FATAL ERROR--THE SECOND INPUT ARGUMENT TO THE GAMCDF SUBROUTINE IS NON-POSITIVE *****")
46 FORMAT(1X,"***** THE VALUE OF THE ARGUMENT IS ",E15.8," *****")
!...
!-----START POINT-----------------------------------------------------
!...
    DX = X
    DGAMMA = GAMA
!...
!...COMPUTE THE GAMMA FUNCTION USING THE ALGORITHM IN THE NBS APPLIED MATHEMATICS SERIES REFERENCE.
    Z = DGAMMA
    DEN = ONE_W
300 IF (Z >= TEN_W) GOTO 400
    DEN = DEN*Z
    Z = Z+ONE_W
    GOTO 300
400 Z2 = Z*Z
    Z3 = Z *Z2
    Z4 = Z2*Z2
    Z5 = Z2*Z3
    A  = (Z-HALF_W)*LOG(Z)-Z+C
    B  = D(1)/Z+D(2)/Z3+D(3)/Z5+D(4)/(Z2*Z5)+D(5)/(Z4*Z5)+D(6)/(Z*Z5*Z5)+D(7)/(Z3*Z5*Z5)+D(8)/(Z5*Z5*Z5)+D(9)/(Z2*Z5*Z5*Z5)
    G  = EXP(A+B)/DEN
!...
!...COMPUTE T-SUB-Q AS DEFINED ON PAGE 4 OF THE WILK, GNANADESIKAN, AND HUYETT REFERENCE
    SUMM = ONE_W/DGAMMA
    TERM = ONE_W/DGAMMA
    CUT1 = DX-DGAMMA
    CUT2 = DX*1.0D10
    DO I = 1,MAXIT
        AI = REAL(I, KIND=WP)
        TERM = DX*TERM/(DGAMMA+AI)
        SUMM = SUMM+TERM
        CUTOFF = CUT1+(CUT2*TERM/SUMM)
        IF (AI > CUTOFF) GOTO 250
    ENDDO
    WRITE (*,205) MAXIT
    WRITE (*,206) X
    WRITE (*,207) GAMA
    WRITE (*,208)
    GAMCDF = ONE_W
    RETURN
250 T = SUMM
    GAMCDF = (DX**DGAMMA)*(EXP(-DX))*T/G
!...
!...FORMAT STATEMENTS
205 FORMAT(1X,"*****ERROR IN INTERNAL OPERATIONS IN THE GAMCDF, FUNCTION--THE NUMBER OF ITERATIONS EXCEEDS ",I7)
206 FORMAT(1X,"     THE INPUT VALUE OF X     IS ",E15.8)
207 FORMAT(1X,"     THE INPUT VALUE OF GAMA IS ",E15.8)
208 FORMAT(1X,"     THE OUTPUT VALUE OF CDF HAS BEEN SET TO 1.0")
!...
!...DONE
    RETURN
    END FUNCTION GAMCDF
!...
!...REALLY DONE
END SUBROUTINE AND_DAR
!...
! -------------------------------------------------------------------
!...
SUBROUTINE CORREL (N,DATA1,DATA2)
!...
!...COMPUTES THE CORRELATION OF TWO REAL DATA SETS DATA1 AND DATA2 OF LENGTH N (INCLUDING
!...ANY USER-SUPPLIED ZERO PADDING). N MUST BE AN INTEGER POWER OF 2. THE ANSWER IS
!...RETURNED AS THE FUNCTION CORREL, AN ARRAY OF LENGTH N. THE ANSWER IS STORED IN WRAPAROUND
!...ORDER, i.e., CORRELATIONS AT INCREASINGLY NEGATIVE LAGS ARE IN CORREL(N) ON DOWN TO
!...CORREL(N/2+ 1), WHILE CORRELATIONS AT INCREASINGLY POSITIVE LAGS ARE IN CORREL(1) (ZERO
!...LAG) ON UP TO CORREL(N/2). SIGN CONVENTION OF THIS ROUTINE: IF DATA1 LAGS DATA2, i.e.,
!...IS SHIFTED TO THE RIGHT OF IT, THEN CORREL WILL SHOW A PEAK AT POSITIVE LAGS.
!...
USE NRTYPE
USE NRUTIL, ONLY : ASSERT, ASSERT_EQ
USE REALFT_USE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: AIMAG, CMPLX, CONJG, IAND, SIZE
!...
!...TRANSMITTED VARIABLES
INTEGER(I4B), INTENT(IN)                            :: N
REAL(WP), DIMENSION(:), INTENT(INOUT)               :: DATA1, DATA2
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: NO2                                                      !...NORMALIZATION FOR INVERSE FFT
REAL(WP), DIMENSION(SIZE(DATA1))                    :: CORRE
COMPLEX(WPC), DIMENSION(SIZE(DATA1)/2)              :: CDAT1, CDAT2
!...
!...CHECK THAT DATASETS ARE OF EQUAL SIZES
!N = ASSERT_EQ(SIZE(DATA1),SIZE(DATA2),"CORREL")
WRITE (*,*)(IAND(N,N-1)==0), N, N-1
CALL ASSERT(IAND(N,N-1)==0, "N MUST BE A POWER OF 2 IN CORREL")
NO2 = N/2
!...
!...CALCULATE THE FOURIER TRANSFORM OF A SET OF THE REAL-VALUED DATA POINTS TO TRANSFORM THE DATA
CALL REALFT_WP(N,DATA1,+1,CDAT1)                                                                                !...TRANSFORM BOTH DATA VECTORS
CALL REALFT_WP(N,DATA2,+1,CDAT2)
!...
!...DETERMINE THEIR CORRELATION
CDAT1(1)  = CMPLX(REAL(CDAT1(1))*REAL(CDAT2(1))/NO2,AIMAG(CDAT1(1))*AIMAG(CDAT2(1))/NO2, KIND=WPC)              !...MULTIPLY TO FIND FFT OF THEIR CORRELATION
CDAT1(2:) = CDAT1(2:)*CONJG(CDAT2(2:))/NO2
!...
!...CALCULATE THE FOURIER TRANSFORM OF A SET OF THE REAL-VALUED DATA POINTS INVERSE TRANSFORM FOR CORRELATION
CALL REALFT_WP(N,CORRE,-1,CDAT1)                                                                                !...INVERSE TRANSFORM GIVES CORRELATION
!...
!...DONE
END SUBROUTINE CORREL
