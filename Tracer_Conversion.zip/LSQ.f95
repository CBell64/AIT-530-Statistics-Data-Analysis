MODULE LSQ
!...

!  MODULE FOR UNCONSTRAINED LINEAR LEAST-SQUARES CALCULATIONS.
!  THE ALGORITHM IS SUITABLE FOR UPDATING LS CALCULATIONS AS MORE
!  DATA ARE ADDED.   THIS IS SOMETIMES CALLED RECURSIVE ESTIMATION.
!  ONLY ONE DEPENDENT VARIABLE IS ALLOWED.
!  BASED UPON APPLIED STATISTICS ALGORITHM AS 274.
!  TRANSLATION FROM FORTRAN 77 TO FORTRAN 90 BY ALAN MILLER.
!  A FUNCTION, VARPRD, HAS BEEN ADDED FOR CALCULATING THE VARIANCES
!  OF PREDICTED VALUES, AND THIS USES A SUBROUTINE BKSUB2.

!  VERSION 1.14, 19 AUGUST 2002 - ELF90 COMPATIBLE VERSION
!  AUTHOR: ALAN MILLER
!  E-MAIL : AMILLER @ BIGPOND.NET.AU
!  WWW-PAGES: HTTP://WWW.OZEMAIL.COM.AU/~MILLERAJ
!             HTTP://USERS.BIGPOND.NET.AU/AMILLER/

!  BUG FIXES:
!  1. IN REGCF A CALL TO TOLSET HAS BEEN ADDED IN CASE THE USER HAD
!     NOT SET TOLERANCES.
!  2. IN SING, EACH TIME A SINGULARITY IS DETECTED, UNLESS IT IS IN THE
!     VARIABLES IN THE LAST POSITION, INCLUD IS CALLED.   INCLUD ASSUMES
!     THAT A NEW OBSERVATION IS BEING ADDED AND INCREMENTS THE NUMBER OF
!     CASES, NOBS.   THE LINE:  NOBS = NOBS - 1 HAS BEEN ADDED.
!  3. ROW_PTR WAS LEFT OUT OF THE DEALLOCATE STATEMENT IN ROUTINE STARTUP
!     IN VERSION 1.07.
!  4. IN COV, NOW CALLS SS IF RSS_SET = .FALSE.  29 AUGUST 1997
!  5. IN TOLSET, CORRECTION TO ACCOMODATE NEGATIVE VALUES OF D.  19 AUGUST 2002

!  OTHER CHANGES:
!  1. ARRAY ROW_PTR ADDED 18 JULY 1997.   THIS POINTS TO THE FIRST ELEMENT
!     STORED IN EACH ROW THUS SAVING A SMALL AMOUNT OF TIME NEEDED TO
!     CALCULATE ITS POSITION.
!  2. OPTIONAL PARAMETER, EPS, ADDED TO ROUTINE TOLSET, SO THAT THE USER
!     CAN SPECIFY THE ACCURACY OF THE INPUT DATA.
!  3. COSMETIC CHANGE OF LSQ_KIND TO DP (`DOUBLE PRECISION')
!  4. CHANGE TO ROUTINE SING TO USE ROW_PTR RATHER THAN CALCULATE THE POSITION
!     OF FIRST ELEMENTS IN EACH ROW.

!  THE PUBLIC VARIABLES ARE:
!  DP       = A KIND PARAMETER FOR THE FLOATING-POINT QUANTITIES CALCULATED
!             IN THIS MODULE.   SEE THE MORE DETAILED EXPLANATION BELOW.
!             THIS KIND PARAMETER SHOULD BE USED FOR ALL FLOATING-POINT
!             ARGUMENTS PASSED TO ROUTINES IN THIS MODULE.

!  NOBS    = THE NUMBER OF OBSERVATIONS PROCESSED TO DATE.
!  NCOL    = THE TOTAL NUMBER OF VARIABLES, INCLUDING ONE FOR THE CONSTANT,
!            IF A CONSTANT IS BEING FITTED.
!  R_DIM   = THE DIMENSION OF ARRAY R = NCOL*(NCOL-1)/2
!  VORDER  = AN INTEGER(I4B) VECTOR STORING THE CURRENT ORDER OF THE VARIABLES
!            IN THE QR-FACTORIZATION.   THE INITIAL ORDER IS 0, 1, 2, ...
!            IF A CONSTANT IS BEING FITTED, OR 1, 2, ... OTHERWISE.
!  INITIALIZED = A LOGICAL VARIABLE WHICH INDICATES WHETHER SPACE HAS
!                BEEN ALLOCATED FOR VARIOUS ARRAYS.
!  TOL_SET = A LOGICAL VARIABLE WHICH IS SET WHEN SUBROUTINE TOLSET HAS
!            BEEN CALLED TO CALCULATE TOLERANCES FOR USE IN TESTING FOR
!            SINGULARITIES.
!  RSS_SET = A LOGICAL VARIABLE INDICATING WHETHER RESIDUAL SUMS OF SQUARES
!            ARE AVAILABLE AND USABLE.
!  D()     = ARRAY OF ROW MULTIPLIERS FOR THE CHOLESKY FACTORIZATION.
!            THE FACTORIZATION IS X = Q.SQRT(D).R WHERE Q IS AN ORTHO-
!            NORMAL MATRIX WHICH IS NOT STORED, D IS A DIAGONAL MATRIX
!            WHOSE DIAGONAL ELEMENTS ARE STORED IN ARRAY D, AND R IS AN
!            UPPER-TRIANGULAR MATRIX WITH 1'S AS ITS DIAGONAL ELEMENTS.
!  RHS()   = VECTOR OF RHS PROJECTIONS (AFTER SCALING BY SQRT(D)).
!            THUS Q'Y = SQRT(D).RHS
!  R()     = THE UPPER-TRIANGULAR MATRIX R.   THE UPPER TRIANGLE ONLY,
!            EXCLUDING THE IMPLICIT 1'S ON THE DIAGONAL, ARE STORED BY
!            ROWS.
!  TOL()   = ARRAY OF TOLERANCES USED IN TESTING FOR SINGULARITIES.
!  RSS()   = ARRAY OF RESIDUAL SUMS OF SQUARES.   RSS(I) IS THE RESIDUAL
!            SUM OF SQUARES WITH THE FIRST I VARIABLES IN THE MODEL.
!            BY CHANGING THE ORDER OF VARIABLES, THE RESIDUAL SUMS OF
!            SQUARES CAN BE FOUND FOR ALL POSSIBLE SUBSETS OF THE VARIABLES.
!            THE RESIDUAL SUM OF SQUARES WITH NO VARIABLES IN THE MODEL,
!            THAT IS THE TOTAL SUM OF SQUARES OF THE Y-VALUES, CAN BE
!            CALCULATED AS RSS(1) + D(1)*RHS(1)^2.   IF THE FIRST VARIABLE
!            IS A CONSTANT, THEN RSS(1) IS THE SUM OF SQUARES OF
!            (Y - YBAR) WHERE YBAR IS THE AVERAGE VALUE OF Y.
!  SSERR   = RESIDUAL SUM OF SQUARES WITH ALL OF THE VARIABLES INCLUDED.
!  ROW_PTR() = ARRAY OF INDICES OF FIRST ELEMENTS IN EACH ROW OF R.
!
!--------------------------------------------------------------------------
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...DECLARE MODULE VARIABLES
INTEGER(I4B), SAVE                                  :: NOBS, NCOL, R_DIM
INTEGER(I4B), DIMENSION(:), ALLOCATABLE, SAVE       :: VORDER, ROW_PTR
LOGICAL(FLG), SAVE                                  :: INITIALIZED, TOL_SET, RSS_SET
!...
! NOTE. DP IS BEING SET TO GIVE AT LEAST 12 DECIMAL DIGIT
!       REPRESENTATION OF FLOATING POINT NUMBERS.   THIS SHOULD BE ADEQUATE
!       FOR MOST PROBLEMS EXCEPT THE FITTING OF POLYNOMIALS.   DP IS
!       BEING SET SO THAT THE SAME CODE CAN BE RUN ON PCS AND UNIX SYSTEMS,
!       WHICH WILL USUALLY REPRESENT FLOATING-POINT NUMBERS IN `DOUBLE
!       PRECISION', AND OTHER SYSTEMS WITH LARGER WORD LENGTHS WHICH WILL
!       GIVE SIMILAR ACCURACY IN `SINGLE PRECISION'.
!...
!...SET MODULE VARIABLES
REAL(WP), DIMENSION(:), ALLOCATABLE, SAVE           :: D, RHS, R, TOL, RSS
REAL(WP), SAVE                                      :: VSMALL
REAL(WP), SAVE                                      :: SSERR, TOLY
!...
PUBLIC                                              :: WP, NOBS, NCOL, R_DIM, VORDER, ROW_PTR, &
                                                       INITIALIZED, TOL_SET, RSS_SET,          &
                                                       D, RHS, R, TOL, RSS, SSERR
!...
PRIVATE                                             :: VSMALL


CONTAINS
!...
    SUBROUTINE STARTUP(NVAR,FIT_CONST)
!...
!     ALLOCATES DIMENSIONS FOR ARRAYS AND INITIALIZES TO ZERO
!     THE CALLING PROGRAM MUST SET NVAR = THE NUMBER OF VARIABLES, AND
!     FIT_CONST = .TRUE. IF A CONSTANT IS TO BE INCLUDED IN THE MODEL,
!     OTHERWISE FIT_CONST = .FALSE.
!
!--------------------------------------------------------------------------
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                       :: TINY
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                        :: NVAR
    LOGICAL, INTENT(IN)                             :: FIT_CONST
!...
!...IDENTIFY SUBROUTINE VARIABLES
    INTEGER(I4B)                                    :: I
!...
    VSMALL = TEN_W * TINY(ZERO_W)
!...
    NOBS = 0
    IF (FIT_CONST) THEN
        NCOL = NVAR + 1
    ELSE
        NCOL = NVAR
    ENDIF
!...
    IF (INITIALIZED) DEALLOCATE(D, RHS, R, TOL, RSS, VORDER, ROW_PTR)
    R_DIM = NCOL * (NCOL - 1)/2
    ALLOCATE(D(NCOL), RHS(NCOL), R(R_DIM), TOL(NCOL), RSS(NCOL), VORDER(NCOL), ROW_PTR(NCOL))
!...
    D = ZERO_W
    RHS = ZERO_W
    R = ZERO_W
    SSERR = ZERO_W

    IF (FIT_CONST) THEN
        DO I = 1,NCOL
            VORDER(I) = I-1
        ENDDO
    ELSE
        DO I = 1,NCOL
            VORDER(I) = I
        ENDDO
    ENDIF ! (FIT_CONST)
!...
! ROW_PTR(I) IS THE POSITION OF ELEMENT R(I,I+1) IN ARRAY R().
    ROW_PTR(1) = 1
    DO I = 2,NCOL-1
        ROW_PTR(I) = ROW_PTR(I-1) + NCOL - I + 1
    ENDDO
    ROW_PTR(NCOL) = 0

    INITIALIZED = .TRUE.
    TOL_SET = .FALSE.
    RSS_SET = .FALSE.
!...
!...DONE
    RETURN
    END SUBROUTINE STARTUP
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...
    SUBROUTINE INCLUD(WEIGHT,XROW,YELEM)
!...
!     ALGORITHM AS75.1  APPL. STATIST. (1974) VOL.23, NO. 3

!     CALLING THIS ROUTINE UPDATES D, R, RHS AND SSERR BY THE
!     INCLUSION OF XROW, YELEM WITH THE SPECIFIED WEIGHT.

!     *** WARNING  ARRAY XROW IS OVERWRITTEN.

!     N.B. AS THIS ROUTINE WILL BE CALLED MANY TIMES IN MOST APPLICATIONS,
!          CHECKS HAVE BEEN ELIMINATED.
!
!--------------------------------------------------------------------------
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                       :: ABS
!...
!...DECLARE TRANSFERRED VARIABLES
    REAL(WP),INTENT(IN)                             :: WEIGHT, YELEM
    REAL(WP), DIMENSION(:), INTENT(INOUT)           :: XROW
!...
!...IDENTIFY SUBROUTINE VARIABLES
    INTEGER(I4B)                                    :: I, K, NEXTR
    REAL(WP)                                        :: W, Y, XI, DI, WXI, DPI, CBAR, SBAR, XK
!...
    NOBS = NOBS+1
    W = WEIGHT
    Y = YELEM
    RSS_SET = .FALSE.
    NEXTR = 1
    DO I = 1,NCOL
!...
!     SKIP UNNECESSARY TRANSFORMATIONS.   TEST ON EXACT ZEROES MUST BE
!     USED OR STABILITY CAN BE DESTROYED.
        IF (ABS(W) < VSMALL) RETURN
        XI = XROW(I)
        IF (ABS(XI) < VSMALL) THEN
            NEXTR = NEXTR + NCOL - I
        ELSE
            DI = D(I)
            WXI = W * XI
            DPI = DI + WXI*XI
            CBAR = DI / DPI
            SBAR = WXI / DPI
            W = CBAR * W
            D(I) = DPI
            DO K = I+1,NCOL
                XK = XROW(K)
                XROW(K) = XK - XI * R(NEXTR)
                R(NEXTR) = CBAR * R(NEXTR) + SBAR * XK
                NEXTR = NEXTR + 1
            ENDDO
            XK = Y
            Y = XK - XI * RHS(I)
            RHS(I) = CBAR * RHS(I) + SBAR * XK
        ENDIF
    ENDDO ! I = 1, NCOL

!     Y * SQRT(W) IS NOW EQUAL TO THE BROWN, DURBIN & EVANS RECURSIVE
!     RESIDUAL.

    SSERR = SSERR + W * Y * Y
!...
!...DONE
    RETURN
    END SUBROUTINE INCLUD
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...
    SUBROUTINE REGCF(BETA,NREQ,IFAULT)
!...
!     ALGORITHM AS274  APPL. STATIST. (1992) VOL.41, NO. 2

!     MODIFIED VERSION OF AS75.4 TO CALCULATE REGRESSION COEFFICIENTS
!     FOR THE FIRST NREQ VARIABLES, GIVEN AN ORTHOGONAL REDUCTION FROM
!     AS75.1.
!
!--------------------------------------------------------------------------
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                        :: NREQ
    INTEGER(I4B), INTENT(OUT)                       :: IFAULT
    REAL(WP), DIMENSION(:), INTENT(OUT)             :: BETA
!...
!...IDENTIFY SUBROUTINE VARIABLES
    INTEGER(I4B)                                    :: I, J, NEXTR
!...
!...SOME CHECKS
    IFAULT = 0
    IF (NREQ < 1 .OR. NREQ > NCOL) IFAULT = IFAULT + 4
    IF (IFAULT /= 0) RETURN

    IF (.NOT. TOL_SET) CALL TOLSET()

    DO I = NREQ,1,-1
        IF (SQRT(D(I)) < TOL(I)) THEN
            BETA(I) = ZERO_W
            D(I) = ZERO_W
            IFAULT = -I
        ELSE
            BETA(I) = RHS(I)
            NEXTR = ROW_PTR(I)
            DO J = I+1,NREQ
                BETA(I) = BETA(I) - R(NEXTR)*BETA(J)
                NEXTR = NEXTR + 1
            ENDDO ! J = I+1, NREQ
        ENDIF
    ENDDO ! I = NREQ, 1, -1
!...
!...DONE
    RETURN
    END SUBROUTINE REGCF
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...
    SUBROUTINE TOLSET(EPS)
!...
!     ALGORITHM AS274  APPL. STATIST. (1992) VOL.41, NO. 2

!     SETS UP ARRAY TOL FOR TESTING FOR ZEROES IN AN ORTHOGONAL
!     REDUCTION FORMED USING AS75.1.
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                       :: ABS, EPSILON, MAX, PRESENT
!...
!...DECLARE TRANSFERRED VARIABLES
    REAL(WP), INTENT(IN), OPTIONAL                  :: EPS

!     UNLESS THE ARGUMENT EPS IS SET, IT IS ASSUMED THAT THE INPUT DATA ARE
!     RECORDED TO FULL MACHINE ACCURACY.   THIS IS OFTEN NOT THE CASE.
!     IF, FOR INSTANCE, THE DATA ARE RECORDED TO `SINGLE PRECISION' OF ABOUT
!     6-7 SIGNIFICANT DECIMAL DIGITS, THEN SINGULARITIES WILL NOT BE DETECTED.
!     IT IS SUGGESTED THAT IN THIS CASE EPS SHOULD BE SET EQUAL TO
!     10.0 * EPSILON(1.0)
!     IF THE DATA ARE RECORDED TO SAY 4 SIGNIFICANT DECIMALS, THEN EPS SHOULD
!     BE SET TO 1.0E-03
!     THE ABOVE COMMENTS APPLY TO THE PREDICTOR VARIABLES, NOT TO THE
!     DEPENDENT VARIABLE.

!     CORRECTION - 19 AUGUST 2002
!     WHEN NEGATIVE WEIGHTS ARE USED, IT IS POSSIBLE FOR AN ALEMENT OF D
!     TO BE NEGATIVE.

!     LOCAL VARIABLES.
!
!--------------------------------------------------------------------------
!...
!...IDENTIFY SUBROUTINE VARIABLES
    INTEGER(I4B)                                    :: COL, ROW, POS0
    REAL(WP)                                        :: EPS1, TOTAL
    REAL(WP), DIMENSION(1:NCOL)                     :: WORK
!...
!     EPS IS A MACHINE-DEPENDENT CONSTANT.

    IF (PRESENT(EPS)) THEN
        EPS1 = MAX(ABS(EPS), TEN_W * EPSILON(TEN_W))
    ELSE
        EPS1 = TEN_W * EPSILON(TEN_W)
    ENDIF
!...
!     SET TOL(I) = SUM OF ABSOLUTE VALUES IN COLUMN I OF R AFTER
!     SCALING EACH ELEMENT BY THE SQUARE ROOT OF ITS ROW MULTIPLIER,
!     MULTIPLIED BY EPS1.

    WORK = SQRT(ABS(D))
    DO COL = 1,NCOL
        POS0 = COL - 1
        TOTAL = WORK(COL)
        DO ROW = 1,COL-1
            TOTAL = TOTAL + ABS(R(POS0)) * WORK(ROW)
            POS0 = POS0 + NCOL - ROW - 1
        ENDDO
        TOL(COL) = EPS1 * TOTAL
    ENDDO

    TOL_SET = .TRUE.
!...
!...DONE
    RETURN
    END SUBROUTINE TOLSET
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...
    SUBROUTINE SING(LINDEP,IFAULT)
!...
!     ALGORITHM AS274  APPL. STATIST. (1992) VOL.41, NO. 2

!     CHECKS FOR SINGULARITIES, REPORTS, AND ADJUSTS ORTHOGONAL
!     REDUCTIONS PRODUCED BY AS75.1.

!     CORRECTION - 19 AUGUST 2002
!     WHEN NEGATIVE WEIGHTS ARE USED, IT IS POSSIBLE FOR AN ELEMENT OF D
!     TO BE NEGATIVE.

!     AUXILIARY ROUTINES CALLED: INCLUD, TOLSET
!
!--------------------------------------------------------------------------
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                       :: ABS
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(OUT)                       :: IFAULT
    LOGICAL, DIMENSION(:), INTENT(OUT)              :: LINDEP
!...
!...IDENTIFY SUBROUTINE VARIABLES
    REAL(WP)                                        :: TEMP, Y, WEIGHT
    REAL(WP), DIMENSION(1:NCOL)                     :: X, WORK
    INTEGER(I4B)                                    :: POS0, ROW, POS2
!...
    IFAULT = 0

    WORK = SQRT(ABS(D))
    IF (.NOT. TOL_SET) CALL TOLSET()

    DO ROW = 1,NCOL
        TEMP = TOL(ROW)
        POS0 = ROW_PTR(ROW)         ! POS = LOCATION OF FIRST ELEMENT IN ROW

!     IF DIAGONAL ELEMENT IS NEAR ZERO, SET IT TO ZERO, SET APPROPRIATE
!     ELEMENT OF LINDEP, AND USE INCLUD TO AUGMENT THE PROJECTIONS IN
!     THE LOWER ROWS OF THE ORTHOGONALIZATION.

        LINDEP(ROW) = .FALSE.
        IF (WORK(ROW) <= TEMP) THEN
            LINDEP(ROW) = .TRUE.
            IFAULT = IFAULT - 1
            IF (ROW < NCOL) THEN
                POS2 = POS0 + NCOL - ROW - 1
                X = ZERO_W
                X(ROW+1:NCOL) = R(POS0:POS2)
                Y = RHS(ROW)
                WEIGHT = D(ROW)
                R(POS0:POS2) = ZERO_W
                D(ROW) = ZERO_W
                RHS(ROW) = ZERO_W
                CALL INCLUD(WEIGHT, X, Y)
                             ! INCLUD AUTOMATICALLY INCREASES THE NUMBER
                             ! OF CASES EACH TIME IT IS CALLED.
                NOBS = NOBS - 1
            ELSE
                SSERR = SSERR + D(ROW) * RHS(ROW)**2
            ENDIF ! (ROW < NCOL)
        ENDIF ! (WORK(ROW) <= TEMP)
    ENDDO ! ROW = 1, NCOL
!...
!...DONE
    RETURN
    END SUBROUTINE SING
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...
    SUBROUTINE SS()
!...
!     ALGORITHM AS274  APPL. STATIST. (1992) VOL.41, NO. 2

!     CALCULATES PARTIAL RESIDUAL SUMS OF SQUARES FROM AN ORTHOGONAL
!     REDUCTION FROM AS75.1.
!
!--------------------------------------------------------------------------
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...IDENTIFY SUBROUTINE VARIABLES
    INTEGER(I4B)                                    :: I
    REAL(WP)                                        :: TOTAL
!...
    TOTAL = SSERR
    RSS(NCOL) = SSERR
    DO I = NCOL,2,-1
        TOTAL = TOTAL + D(I) * RHS(I)**2
        RSS(I-1) = TOTAL
    ENDDO

    RSS_SET = .TRUE.
!...
!...DONE
    RETURN
    END SUBROUTINE SS
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...
    SUBROUTINE COV(NREQ,VAR,COVMAT,DIMCOV,STERR,IFAULT)
!...
!     ALGORITHM AS274  APPL. STATIST. (1992) VOL.41, NO. 2

!     CALCULATE COVARIANCE MATRIX FOR REGRESSION COEFFICIENTS FOR THE
!     FIRST NREQ VARIABLES, FROM AN ORTHOGONAL REDUCTION PRODUCED FROM
!     AS75.1.

!     AUXILIARY ROUTINE CALLED: INV
!
!--------------------------------------------------------------------------
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                       :: ABS
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                        :: NREQ, DIMCOV
    INTEGER(I4B), INTENT(OUT)                       :: IFAULT
    REAL(WP), INTENT(OUT)                           :: VAR
    REAL(WP), DIMENSION(:), INTENT(OUT)             :: COVMAT, STERR
!...
!...IDENTIFY SUBROUTINE VARIABLES
    INTEGER(I4B)                                    :: DIM_RINV, POS0, ROW, START, POS2, COL, POS1, K
    REAL(WP)                                        :: TOTAL
    REAL(WP), DIMENSION(:), ALLOCATABLE             :: RINV
!...
!     CHECK THAT DIMENSION OF ARRAY COVMAT IS ADEQUATE.

    IF (DIMCOV < NREQ*(NREQ+1)/2) THEN
        IFAULT = 1
        RETURN
    ENDIF

!     CHECK FOR SMALL OR ZERO MULTIPLIERS ON THE DIAGONAL.

    IFAULT = 0
    DO ROW = 1,NREQ
        IF (ABS(D(ROW)) < VSMALL) IFAULT = -ROW
    ENDDO
    IF (IFAULT /= 0) RETURN

!     CALCULATE ESTIMATE OF THE RESIDUAL VARIANCE.

    IF (NOBS > NREQ) THEN
        IF (.NOT. RSS_SET) CALL SS()
        VAR = RSS(NREQ) / (NOBS - NREQ)
    ELSE
        IFAULT = 2
        RETURN
    ENDIF

    DIM_RINV = NREQ*(NREQ-1)/2
    ALLOCATE (RINV(DIM_RINV))

    CALL INV(NREQ, RINV)
    POS0 = 1
    START = 1
    DO ROW = 1,NREQ
        POS2 = START
        DO COL = ROW,NREQ
            POS1 = START + COL - ROW
            IF (ROW == COL) THEN
                TOTAL = ONE_W / D(COL)
            ELSE
                TOTAL = RINV(POS1-1) / D(COL)
            ENDIF
            DO K = COL+1,NREQ
                TOTAL = TOTAL + RINV(POS1) * RINV(POS2) / D(K)
                POS1 = POS1 + 1
                POS2 = POS2 + 1
            ENDDO ! K = COL+1, NREQ
            COVMAT(POS0) = TOTAL * VAR
            IF (ROW == COL) STERR(ROW) = SQRT(COVMAT(POS0))
            POS0 = POS0 + 1
        ENDDO ! COL = ROW, NREQ
        START = START + NREQ - ROW
    ENDDO ! ROW = 1, NREQ

    DEALLOCATE(RINV)
!...
!...DONE
    RETURN
    END SUBROUTINE COV
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...
    SUBROUTINE INV(NREQ,RINV)
!...
!     ALGORITHM AS274  APPL. STATIST. (1992) VOL.41, NO. 2

!     INVERT FIRST NREQ ROWS AND COLUMNS OF CHOLESKY FACTORIZATION
!     PRODUCED BY AS 75.1.
!
!--------------------------------------------------------------------------
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                        :: NREQ
    REAL(WP), DIMENSION(:), INTENT(OUT)             :: RINV
!...
!...IDENTIFY SUBROUTINE VARIABLES
    INTEGER(I4B)                                    :: POS0, ROW, COL, START, K, POS1, POS2
    REAL(WP)                                        :: TOTAL
!...
!     INVERT R IGNORING ROW MULTIPLIERS, FROM THE BOTTOM UP.

    POS0 = NREQ * (NREQ-1)/2
    DO ROW = NREQ-1,1,-1
        START = ROW_PTR(ROW)
        DO COL = NREQ,ROW+1,-1
            POS1 = START
            POS2 = POS0
            TOTAL = ZERO_W
            DO K = ROW+1,COL-1
                POS2 = POS2 + NREQ - K
                TOTAL = TOTAL - R(POS1) * RINV(POS2)
                POS1 = POS1 + 1
            ENDDO ! K = ROW+1, COL-1
            RINV(POS0) = TOTAL - R(POS1)
            POS0 = POS0 - 1
        ENDDO ! COL = NREQ, ROW+1, -1
    ENDDO ! ROW = NREQ-1, 1, -1
!...
!...DONE
    RETURN
    END SUBROUTINE INV
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...
    SUBROUTINE PARTIAL_CORR(IN1,CORMAT,DIMC,YCORR,IFAULT)
!...
!     REPLACES SUBROUTINES PCORR AND COR OF:
!     ALGORITHM AS274  APPL. STATIST. (1992) VOL.41, NO. 2

!     CALCULATE PARTIAL CORRELATIONS AFTER THE VARIABLES IN ROWS
!     1, 2, ..., IN HAVE BEEN FORCED INTO THE REGRESSION.
!     IF IN = 1, AND THE FIRST ROW OF R REPRESENTS A CONSTANT IN THE
!     MODEL, THEN THE USUAL SIMPLE CORRELATIONS ARE RETURNED.

!     IF IN = 0, THE VALUE RETURNED IN ARRAY CORMAT FOR THE CORRELATION
!     OF VARIABLES XI & XJ IS:
!       SUM ( XI.XJ ) / SQRT ( SUM (XI^2) . SUM (XJ^2) )

!     ON RETURN, ARRAY CORMAT CONTAINS THE UPPER TRIANGLE OF THE MATRIX OF
!     PARTIAL CORRELATIONS STORED BY ROWS, EXCLUDING THE 1'S ON THE DIAGONAL.
!     E.G. IF IN = 2, THE CONSECUTIVE ELEMENTS RETURNED ARE:
!     (3,4) (3,5) ... (3,NCOL), (4,5) (4,6) ... (4,NCOL), ETC.
!     ARRAY YCORR STORES THE PARTIAL CORRELATIONS WITH THE Y-VARIABLE
!     STARTING WITH YCORR(IN+1) = PARTIAL CORRELATION WITH THE VARIABLE IN
!     POSITION (IN+1).
!
!--------------------------------------------------------------------------
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                        :: IN1, DIMC
    INTEGER(I4B), INTENT(OUT)                       :: IFAULT
    REAL(WP), DIMENSION(:), INTENT(OUT)             :: CORMAT, YCORR
!...
!...IDENTIFY SUBROUTINE VARIABLES
    INTEGER(I4B)                                    :: BASE_POS, POS0, ROW, COL, COL1, COL2, POS1, POS2
    REAL(WP)                                        :: SUMXX, SUMXY, SUMYY
    REAL(WP), DIMENSION(IN1+1:NCOL)                  :: RMS, WORK
!...
!     SOME CHECKS.

    IFAULT = 0
    IF (IN1 < 0 .OR. IN1 > NCOL-1) IFAULT = IFAULT + 4
    IF (DIMC < (NCOL-IN1)*(NCOL-IN1-1)/2) IFAULT = IFAULT + 8
    IF (IFAULT /= 0) RETURN

!     BASE POSITION FOR CALCULATING POSITIONS OF ELEMENTS IN ROW (IN+1) OF R.

    BASE_POS = IN1*NCOL - (IN1+1)*(IN1+2)/2

!     CALCULATE 1/RMS OF ELEMENTS IN COLUMNS FROM IN TO (NCOL-1).

    IF (D(IN1+1) > ZERO_W) RMS(IN1+1) = ONE_W / SQRT(D(IN1+1))
    DO COL = IN1+2,NCOL
        POS0 = BASE_POS + COL
        SUMXX = D(COL)
        DO ROW = IN1+1,COL-1
            SUMXX = SUMXX + D(ROW) * R(POS0)**2
            POS0 = POS0 + NCOL - ROW - 1
        ENDDO ! ROW = IN1+1, COL-1
        IF (SUMXX > ZERO_W) THEN
            RMS(COL) = ONE_W / SQRT(SUMXX)
        ELSE
            RMS(COL) = ZERO_W
            IFAULT = -COL
        ENDIF ! (SUMXX > ZERO)
    ENDDO ! COL = IN1+1, NCOL-1

!     CALCULATE 1/RMS FOR THE Y-VARIABLE

    SUMYY = SSERR
    DO ROW = IN1+1,NCOL
        SUMYY = SUMYY + D(ROW) * RHS(ROW)**2
    ENDDO ! ROW = IN1+1, NCOL
    IF (SUMYY > ZERO_W) SUMYY = ONE_W / SQRT(SUMYY)

!     CALCULATE SUMS OF CROSS-PRODUCTS.
!     THESE ARE OBTAINED BY TAKING DOT PRODUCTS OF PAIRS OF COLUMNS OF R,
!     BUT WITH THE PRODUCT FOR EACH ROW MULTIPLIED BY THE ROW MULTIPLIER
!     IN ARRAY D.

    POS0 = 1
    DO COL1 = IN1+1,NCOL
        SUMXY = ZERO_W
        WORK(COL1+1:NCOL) = ZERO_W
        POS1 = BASE_POS + COL1
        DO ROW = IN1+1,COL1-1
            POS2 = POS1 + 1
            DO COL2 = COL1+1,NCOL
                WORK(COL2) = WORK(COL2) + D(ROW) * R(POS1) * R(POS2)
                POS2 = POS2 + 1
            ENDDO ! COL2 = COL1+1, NCOL
            SUMXY = SUMXY + D(ROW) * R(POS1) * RHS(ROW)
            POS1 = POS1 + NCOL - ROW - 1
        ENDDO ! ROW = IN1+1, COL1-1

!     ROW COL1 HAS AN IMPLICIT 1 AS ITS FIRST ELEMENT (IN COLUMN COL1)

        POS2 = POS1 + 1
        DO COL2 = COL1+1,NCOL
            WORK(COL2) = WORK(COL2) + D(COL1) * R(POS2)
            POS2 = POS2 + 1
            CORMAT(POS0) = WORK(COL2) * RMS(COL1) * RMS(COL2)
            POS0 = POS0 + 1
        ENDDO ! COL2 = COL1+1, NCOL
        SUMXY = SUMXY + D(COL1) * RHS(COL1)
        YCORR(COL1) = SUMXY * RMS(COL1) * SUMYY
    ENDDO ! COL1 = IN1+1, NCOL-1

    YCORR(1:IN1) = ZERO_W
!...
!...DONE
    RETURN
    END SUBROUTINE PARTIAL_CORR
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...
    SUBROUTINE VMOVE(FROM,TO1,IFAULT)
!...
!     ALGORITHM AS274 APPL. STATIST. (1992) VOL.41, NO. 2

!     MOVE VARIABLE FROM POSITION FROM TO POSITION TO IN AN
!     ORTHOGONAL REDUCTION PRODUCED BY AS75.1.
!
!--------------------------------------------------------------------------
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                       :: ABS
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                        :: FROM, TO1
    INTEGER(I4B), INTENT(OUT)                       :: IFAULT
!...
!...IDENTIFY SUBROUTINE VARIABLES
    INTEGER(I4B)                                    :: M, FIRST, LAST, INC, M1, M2, MP1, COL, POS0, ROW
    REAL(WP)                                        :: D1, D2, X, D1NEW, D2NEW, CBAR, SBAR, Y

!     CHECK INPUT PARAMETERS

    IFAULT = 0
    IF (FROM < 1 .OR. FROM > NCOL) IFAULT = IFAULT + 4
    IF (TO1 < 1 .OR. TO1 > NCOL) IFAULT = IFAULT + 8
    IF (IFAULT /= 0) RETURN

    IF (FROM == TO1) RETURN

    IF (.NOT. RSS_SET) CALL SS()

    IF (FROM < TO1) THEN
        FIRST = FROM
        LAST = TO1 - 1
        INC = 1
    ELSE
        FIRST = FROM - 1
        LAST = TO1
        INC = -1
    ENDIF

    DO M = FIRST,LAST,INC

!     FIND ADDRESSES OF FIRST ELEMENTS OF R IN ROWS M AND (M+1).

        M1 = ROW_PTR(M)
        M2 = ROW_PTR(M+1)
        MP1 = M + 1
        D1 = D(M)
        D2 = D(MP1)

!     SPECIAL CASES.

        IF (D1 < VSMALL .AND. D2 < VSMALL) GOTO 40
        X = R(M1)
        IF (ABS(X) * SQRT(D1) < TOL(MP1)) THEN
            X = ZERO_W
        ENDIF
        IF (D1 < VSMALL .OR. ABS(X) < VSMALL) THEN
            D(M) = D2
            D(MP1) = D1
            R(M1) = ZERO_W
            DO COL = M+2,NCOL
                M1 = M1 + 1
                X = R(M1)
                R(M1) = R(M2)
                R(M2) = X
                M2 = M2 + 1
            ENDDO ! COL = M+2, NCOL
            X = RHS(M)
            RHS(M) = RHS(MP1)
            RHS(MP1) = X
            GOTO 40
        ELSEIF (D2 < VSMALL) THEN
            D(M) = D1 * X**2
            R(M1) = ONE_W / X
            R(M1+1:M1+NCOL-M-1) = R(M1+1:M1+NCOL-M-1) / X
            RHS(M) = RHS(M) / X
            GOTO 40
        ENDIF

!     PLANAR ROTATION IN REGULAR CASE.

        D1NEW = D2 + D1*X**2
        CBAR = D2 / D1NEW
        SBAR = X * D1 / D1NEW
        D2NEW = D1 * CBAR
        D(M) = D1NEW
        D(MP1) = D2NEW
        R(M1) = SBAR
        DO COL = M+2,NCOL
            M1 = M1 + 1
            Y = R(M1)
            R(M1) = CBAR*R(M2) + SBAR*Y
            R(M2) = Y - X*R(M2)
            M2 = M2 + 1
        ENDDO ! COL = M+2, NCOL
        Y = RHS(M)
        RHS(M) = CBAR*RHS(MP1) + SBAR*Y
        RHS(MP1) = Y - X*RHS(MP1)

!     SWAP COLUMNS M AND (M+1) DOWN TO ROW (M-1).

40      POS0 = M
        DO ROW = 1,M-1
            X = R(POS0)
            R(POS0) = R(POS0-1)
            R(POS0-1) = X
            POS0 = POS0 + NCOL - ROW - 1
        ENDDO ! ROW = 1, M-1

!     ADJUST VARIABLE ORDER (VORDER), THE TOLERANCES (TOL) AND
!     THE VECTOR OF RESIDUAL SUMS OF SQUARES (RSS).

        M1 = VORDER(M)
        VORDER(M) = VORDER(MP1)
        VORDER(MP1) = M1
        X = TOL(M)
        TOL(M) = TOL(MP1)
        TOL(MP1) = X
        RSS(M) = RSS(MP1) + D(MP1) * RHS(MP1)**2
    ENDDO
!...
!...DONE
    RETURN
    END SUBROUTINE VMOVE
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...
    SUBROUTINE REORDR(LIST,N,POS1,IFAULT)
!...
!     ALGORITHM AS274  APPL. STATIST. (1992) VOL.41, NO. 2

!     RE-ORDER THE VARIABLES IN AN ORTHOGONAL REDUCTION PRODUCED BY
!     AS75.1 SO THAT THE N VARIABLES IN LIST START AT POSITION POS1,
!     THOUGH WILL NOT NECESSARILY BE IN THE SAME ORDER AS IN LIST.
!     ANY VARIABLES IN VORDER BEFORE POSITION POS1 ARE NOT MOVED.

!     AUXILIARY ROUTINE CALLED: VMOVE
!
!--------------------------------------------------------------------------
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                        :: N, POS1
    INTEGER(I4B), DIMENSION(:), INTENT(IN)          :: LIST
    INTEGER(I4B), INTENT(OUT)                       :: IFAULT
!...
!...IDENTIFY SUBROUTINE VARIABLES
    INTEGER(I4B)                                    :: NEXT, I, L, J
!...
!     CHECK N.

    IFAULT = 0
    IF (N < 1 .OR. N > NCOL+1-POS1) IFAULT = IFAULT + 4
    IF (IFAULT /= 0) RETURN

!     WORK THROUGH VORDER FINDING VARIABLES WHICH ARE IN LIST.

    NEXT = POS1
    I = POS1
10  L = VORDER(I)
    DO J = 1,N
        IF (L == LIST(J)) GOTO 40
    ENDDO
30  I = I + 1
    IF (I <= NCOL) GOTO 10

!     IF THIS POINT IS REACHED, ONE OR MORE VARIABLES IN LIST HAS NOT
!     BEEN FOUND.

    IFAULT = 8
    RETURN

!     VARIABLE L IS IN LIST; MOVE IT UP TO POSITION NEXT IF IT IS NOT
!     ALREADY THERE.

40  IF (I > NEXT) CALL VMOVE(I, NEXT, IFAULT)
    NEXT = NEXT + 1
    IF (NEXT < N+POS1) GOTO 30
!...
!...DONE
    RETURN
    END SUBROUTINE REORDR
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...
    SUBROUTINE HDIAG(XROW,NREQ,HII,IFAULT)
!...
!     ALGORITHM AS274  APPL. STATIST. (1992) VOL.41, NO. 2
!
!                         -1           -1
! THE HAT MATRIX H = X(X'X) X' = X(R'DR) X' = Z'DZ

!              -1
! WHERE Z = X'R

! HERE WE ONLY CALCULATE THE DIAGONAL ELEMENT HII CORRESPONDING TO ONE
! ROW (XROW).   THE VARIANCE OF THE I-TH LEAST-SQUARES RESIDUAL IS (1 - HII).
!--------------------------------------------------------------------------
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                        :: NREQ
    INTEGER(I4B), INTENT(OUT)                       :: IFAULT
    REAL(WP), DIMENSION(:), INTENT(IN)              :: XROW
    REAL(WP), INTENT(OUT)                           :: HII
!...
!...IDENTIFY SUBROUTINE VARIABLES
    INTEGER(I4B)                                    :: COL, ROW, POS0
    REAL(WP)                                        :: TOTAL
    REAL(WP), DIMENSION(1:NCOL)                     :: WK
!...
!     SOME CHECKS

    IFAULT = 0
    IF (NREQ > NCOL) IFAULT = IFAULT + 4
    IF (IFAULT /= 0) RETURN

!     THE ELEMENTS OF XROW.INV(R).SQRT(D) ARE CALCULATED AND STORED IN WK.

    HII = ZERO_W
    DO COL = 1,NREQ
        IF (SQRT(D(COL)) <= TOL(COL)) THEN
            WK(COL) = ZERO_W
        ELSE
            POS0 = COL - 1
            TOTAL = XROW(COL)
            DO ROW = 1,COL-1
                TOTAL = TOTAL - WK(ROW)*R(POS0)
                POS0 = POS0 + NCOL - ROW - 1
            ENDDO ! ROW = 1, COL-1
            WK(COL) = TOTAL
            HII = HII + TOTAL**2 / D(COL)
        ENDIF
    ENDDO ! COL = 1, NREQ
!...
!...DONE
    RETURN
    END SUBROUTINE HDIAG
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...
    FUNCTION VARPRD(X,NREQ) RESULT(FN_VAL)
!...
!     CALCULATE THE VARIANCE OF X'B WHERE B CONSISTS OF THE FIRST NREQ
!     LEAST-SQUARES REGRESSION COEFFICIENTS.
!
!--------------------------------------------------------------------------
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                        :: NREQ
    REAL(WP), DIMENSION(:), INTENT(IN)              :: X
    REAL(WP)                                        :: FN_VAL
!...
!...IDENTIFY SUBROUTINE VARIABLES
    INTEGER(I4B)                                    :: IFAULT, ROW
    REAL(WP)                                        :: VAR
    REAL(WP), DIMENSION(1:NREQ)                     :: WK
!...
!     CHECK INPUT PARAMETER VALUES

    FN_VAL = ZERO_W
    IFAULT = 0
    IF (NREQ < 1 .OR. NREQ > NCOL) IFAULT = IFAULT+4
    IF (NOBS <= NREQ) IFAULT = IFAULT+8
    IF (IFAULT /= 0) THEN
        WRITE(*, '(1X, A, I4)') 'ERROR IN FUNCTION VARPRD: IFAULT =', IFAULT
        RETURN
    ENDIF

!     CALCULATE THE RESIDUAL VARIANCE ESTIMATE.

    VAR = SSERR/(NOBS - NREQ)

!     VARIANCE OF X'B = VAR.X'(INV R)(INV D)(INV R')X
!     FIRST CALL BKSUB2 TO CALCULATE (INV R')X BY BACK-SUBSTITUTION.

    CALL BKSUB2(X,WK,NREQ)
    DO ROW = 1,NREQ
        IF (D(ROW) > TOL(ROW)) FN_VAL = FN_VAL + WK(ROW)**2/D(ROW)
    ENDDO

    FN_VAL = FN_VAL*VAR
!...
!...DONE
    RETURN
    END FUNCTION VARPRD
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...
    SUBROUTINE BKSUB2(X,B,NREQ)
!...
!     SOLVE X = R'B FOR B GIVEN X, USING ONLY THE FIRST NREQ ROWS AND
!     COLUMNS OF R, AND ONLY THE FIRST NREQ ELEMENTS OF R.
!
!--------------------------------------------------------------------------
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                        :: NREQ
    REAL(WP), DIMENSION(:), INTENT(IN)              :: X
    REAL(WP), DIMENSION(:), INTENT(OUT)             :: B
!...
!...IDENTIFY SUBROUTINE VARIABLES
    INTEGER(I4B)                                    :: POS0, ROW, COL
    REAL(WP)                                        :: TEMP
!...
!...SOLVE BY BACK-SUBSTITUTION, STARTING FROM THE TOP.
    DO ROW = 1,NREQ
        POS0 = ROW - 1
        TEMP = X(ROW)
        DO COL = 1,ROW-1
            TEMP = TEMP - R(POS0)*B(COL)
            POS0 = POS0 + NCOL - COL - 1
        ENDDO
        B(ROW) = TEMP
    ENDDO
!...
!...DONE
    RETURN
    END SUBROUTINE BKSUB2
!...
!...REALLY DONE
END MODULE LSQ
