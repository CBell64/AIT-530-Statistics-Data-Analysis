SUBROUTINE FOURROW_WP(DATA1,ISGN)
!...
!...REPLACES EACH ROW (CONSTANT FIRST INDEX) OF DATA(1:M,1:N) BY ITS DISCRETE FOURIER TRANSFORM
!...(TRANSFORM ON SECOND INDEX), IF ISGN IS INPUT AS 1; OR REPLACES EACH ROW OF DATA
!...BY N TIMES ITS INVERSE DISCRETE FOURIER TRANSFORM, IF ISGN IS INPUT AS −1. N MUST BE AN
!...INTEGER POWER OF 2. PARALLELISM IS M-FOLD ON THE FIRST INDEX OF DATA.
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ASSERT, SWAP
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: CMPLX, IAND, SIN, SIZE
!...
!...DECLARE TRANSFERRED VARIABLES
INTEGER(I4B), INTENT(IN)                            :: ISGN
COMPLEX(WPC), DIMENSION(:,:), INTENT(INOUT)         :: DATA1
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                        :: I, ISTEP, J, MM, MMAX, N2, NN
REAL(WP)                                            :: THETA
COMPLEX(WPC)                                        :: WW, WZ
COMPLEX(WPC)                                        :: WS
COMPLEX(WPC), DIMENSION(SIZE(DATA1,1))              :: TEMP
!...
!...BEGIN EXECUTION
NN = SIZE(DATA1,2)
!...
!...ASSURE ARRAY SIZE
CALL ASSERT(IAND(NN,NN-1)==0, "        N MUST BE A POWER OF 2 IN FOURROW_WP")
!...
!...SET PARAMETER SIZES
N2 = NN/2
 J = N2
!...
!...BEGIN EXECUTION
DO I = 1,NN-2
    IF (J > I) CALL SWAP(DATA1(:,J+1),DATA1(:,I+1))
    MM = N2
    DO
        IF (MM < 2 .OR. J < MM) EXIT
        J  = J-MM
        MM = MM/2
    ENDDO
    J = J+MM
ENDDO
MMAX = 1
!...
!...HERE BEGINS THE DANIELSON-LANCZOS SECTION OF THE ROUTINE
DO
    IF (NN <= MMAX) EXIT
    ISTEP = 2*MMAX
    THETA = PI_W/(ISGN*MMAX)
    WZ = CMPLX(-TWO_W*SIN(HALF_W*THETA)**2,SIN(THETA), KIND=WPC)
    WW = CMPLX(ONE_W,ZERO_W, KIND=WPC)
    DO MM = 1,MMAX
        WS = WW
        DO I = MM,NN,ISTEP
            J = I+MMAX
            TEMP = WS*DATA1(:,J)
            DATA1(:,J) = DATA1(:,I)-TEMP
            DATA1(:,I) = DATA1(:,I)+TEMP
        ENDDO
        WW = WW*WZ+WW
    ENDDO
    MMAX = ISTEP
ENDDO
!...
!...DONE
END SUBROUTINE FOURROW_WP
!...
!...
!...
SUBROUTINE FOURCOL_WP(DATA1,ISGN)

!...REPLACES EACH COLUMN (CONSTANT SECOND INDEX) OF DATA(1:N,1:M) BY ITS DISCRETE FOURIER
!...TRANSFORM (TRANSFORM ON FIRST INDEX), IF ISIGN IS INPUT AS 1; OR REPLACES EACH ROW OF DATA
!...BY N TIMES ITS INVERSE DISCRETE FOURIER TRANSFORM, IF ISIGN IS INPUT AS −1. N MUST BE AN
!...INTEGER POWER OF 2. PARALLELISM IS M-FOLD ON THE SECOND INDEX OF DATA.
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : ASSERT, SWAP
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: CMPLX, IAND, SIN, SIZE
!...
!...DECLARE TRANSFERRED VARIABLES
INTEGER(I4B), INTENT(IN)                            :: ISGN
COMPLEX(WPC), DIMENSION(:,:), INTENT(INOUT)         :: DATA1
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                        :: N, I, ISTEP, J, M, MMAX, N2
REAL(WP)                                            :: THETA
COMPLEX(WPC), DIMENSION(SIZE(DATA1,2))              :: TEMP
COMPLEX(WPC)                                        :: W, WS, WZ        !...DOUBLE PRECISION FOR THE TRIGONOMETRIC RECURRENCES
!...
!...BEGIN EXECUTION
N = SIZE(DATA1,1)
!...
!...ASSURE ARRAY SIZE
CALL ASSERT(IAND(N,N-1)==0, "N MUST BE A POWER OF 2 IN FOURCOL_WP")

N2 = N/2
J = N2
!...
!...THIS IS THE BIT-REVERSAL SECTION OF THE ROUTINE
DO I = 1,N-2
    IF (J > I) CALL SWAP(DATA1(J+1,:),DATA1(I+1,:))
M = N2
    DO
        IF (M < 2 .OR. J < M) EXIT
        J = J-M
        M = M/2
    ENDDO
    J = J+M
ENDDO
!...
MMAX = 1
!...
!...HERE BEGINS THE DANIELSON-LANCZOS SECTION OF THE ROUTINE
DO                                                                  !...OUTER LOOP EXECUTED LOG2 N TIMES.
    IF (N <= MMAX) EXIT
    ISTEP = 2*MMAX
    THETA = PI_W/(ISGN*MMAX)                                        !...INITIALIZE FOR THE TRIGONOMETRIC RECURRENCE.
    WZ = CMPLX(-TWO_W*SIN(HALF_W*THETA)**2,SIN(THETA), KIND=WPC)
    W  = CMPLX(ONE_W,ZERO_W, KIND=WPC)
    DO M = 1,MMAX                                                   !...HERE ARE THE TWO NESTED INNER LOOPS.
        WS = W
        DO I = M,N,ISTEP
            J = I+MMAX
            TEMP = WS*DATA1(J,:)                                    !...THIS IS THE DANIELSON-LANCZOS FORMULA.
            DATA1(J,:) = DATA1(I,:)-TEMP
            DATA1(I,:) = DATA1(I,:)+TEMP
        ENDDO
        W = W*WZ + W                                                !...TRIGONOMETRIC RECURRENCE.
    ENDDO
    MMAX = ISTEP
ENDDO
!...
!...DONE
END SUBROUTINE FOURCOL_WP
