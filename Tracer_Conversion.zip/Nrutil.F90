MODULE NRUTIL
!...
    USE NRTYPE
!...
!...PARAMETERS FOR CROSSOVER FROM SERIAL TO PARALLEL ALGORITHMS (THESE ARE USED ONLY WITHIN THIS NRUTIL MODULE):
    IMPLICIT NONE
    INTEGER(I4B), PARAMETER ::  NPAR_ARTH=16, NPAR2_ARTH=8      !Each NPAR2 must be ≤ the corresponding NPAR
    INTEGER(I4B), PARAMETER ::  NPAR_GEOP=4, NPAR2_GEOP=2
    INTEGER(I4B), PARAMETER ::  NPAR_CUMSUM=16
    INTEGER(I4B), PARAMETER ::  NPAR_CUMPROD=8
    INTEGER(I4B), PARAMETER ::  NPAR_POLY=8
    INTEGER(I4B), PARAMETER ::  NPAR_POLYTERM=8
!...
!...NEXT, GENERIC INTERFACES FOR ROUTINES WITH OVERLOADED VERSIONS.  NAMING CONVENTIONS FOR APPENDED CODES
!...IN THE NAMES OF OVERLOADED ROUTINES AS ARE FOLLOWS: R=REAL, D=DOUBLE PRECISION, I=INTEGER, C=COMPLEX,
!...Z=DOUBLE PRECISION COMPLEX, H=CHARACTER, L=LOGICAL.  ANY OF R, D, I, C, Z, H, L MAY BE FOLLOWED BY
!...V=VECTOR OR M=MATRIX (V, M SUFFIXES ARE USED ONLY WHEN NEEDED TO RESOLVE AMBIGUITIES).
!...
!...ROUTINES THAT MOVE DATA
    INTERFACE ARRAY_COPY
        MODULE PROCEDURE ARRAY_COPY_R, ARRAY_COPY_D, ARRAY_COPY_E, ARRAY_COPY_Q, ARRAY_COPY_I
    END INTERFACE
!
    INTERFACE SWAP
        MODULE PROCEDURE SWAP_I, SWAP_R, SWAP_D, SWAP_E, SWAP_Q, SWAP_RV, SWAP_DV, SWAP_EV, &
                         SWAP_QV, SWAP_C, SWAP_CV, SWAP_CM, SWAP_DC, SWAP_DCV, SWAP_DCM,    &
                         SWAP_EC, SWAP_ECV, SWAP_ECM, SWAP_QC, SWAP_QCV, SWAP_QCM, SWAP_CH, &
                         SWAP_CHV, MASKED_SWAP_RS, MASKED_SWAP_RV, MASKED_SWAP_RM,          &
                         MASKED_SWAP_DS, MASKED_SWAP_DV, MASKED_SWAP_DM,                    &
                         MASKED_SWAP_ES, MASKED_SWAP_EV, MASKED_SWAP_EM,                    &
                         MASKED_SWAP_QS, MASKED_SWAP_QV, MASKED_SWAP_QM
    END INTERFACE
!
    INTERFACE REALLOCATE
        MODULE PROCEDURE REALLOCATE_RV, REALLOCATE_RM,                              &
                         REALLOCATE_DV, REALLOCATE_DM,                              &
                         REALLOCATE_EV, REALLOCATE_EM,                              &
                         REALLOCATE_QV, REALLOCATE_QM,                              &
                         REALLOCATE_IV, REALLOCATE_IM, REALLOCATE_HV
    END INTERFACE
!...
!...ROUTINES RETURNING A LOCATION AS AN INTEGER VALUE (IFIRSTLOC, IMINLOC ARE NOT CURRENTLY OVERLOADED
!...AND SO DO NOT HAVE A GENERIC INTERFACE HERE):
    INTERFACE IMAXLOC
        MODULE PROCEDURE IMAXLOC_R, IMAXLOC_D, IMAXLOC_E, IMAXLOC_Q, IMAXLOC_I
    END INTERFACE
!...
!...ROUTINES FOR ARGUMENT CHECKING AND ERROR HANDLING (NRERROR IS NOT CURRENTLY OVERLOADED):
    INTERFACE ASSERT
        MODULE PROCEDURE ASSERT1, ASSERT2, ASSERT3, ASSERT4, ASSERT_V
    END INTERFACE
!
    INTERFACE ASSERT_EQ
        MODULE PROCEDURE ASSERT_EQ2, ASSERT_EQ3, ASSERT_EQ4, ASSERT_EQN
    END INTERFACE
!...
!...ROUTINES RELATING TO POLYNOMIALS AND RECURRENCES (CUMPROD, ZROOTS_UNITY ARE NOT CURRENTLY OVERLOADED):
    INTERFACE ARTH
        MODULE PROCEDURE ARTH_R, ARTH_D, ARTH_E, ARTH_Q, ARTH_I
    END INTERFACE
!
    INTERFACE GEOP
        MODULE PROCEDURE GEOP_R, GEOP_D, GEOP_E, GEOP_Q, GEOP_I, GEOP_C, GEOP_DV, GEOP_QV
    END INTERFACE
!
    INTERFACE CUMSUM
        MODULE PROCEDURE CUMSUM_R, CUMSUM_D, CUMSUM_E, CUMSUM_Q, CUMSUM_I
    END INTERFACE
!
    INTERFACE POLYY
        MODULE PROCEDURE POLY_RR, POLY_RRV, POLY_DD, POLY_DDV, POLY_EE, POLY_EEV, &
                        POLY_RC, POLY_CC,                   &
                        POLY_MSK_RRV, POLY_MSK_DDV, POLY_MSK_EEV,          &
                        POLY_MSK_QQV, POLY_QQV, POLY_QQ
    END INTERFACE
!
!    INTERFACE POLYW
!        MODULE PROCEDURE POLYW_WW, POLYW_WWV, POLYW_MSK_WWV
!    END INTERFACE
!
    INTERFACE POLY_TERM
        MODULE PROCEDURE POLY_TERM_RR, POLY_TERM_DD, POLY_TERM_EE, POLY_TERM_QQ,      &
                         POLY_TERM_CC, POLY_TERM_DC, POLY_TERM_EC, POLY_TERM_QC
    END INTERFACE

!...ROUTINES RELATING TO POLYNOMIALS AND RECURRENCES (CUMPROD, ZROOTS UNITY ARE NOT CURRENTLY OVERLOADED):
!    INTERFACE ZROOTS_UNITY
!        MODULE PROCEDURE ZROOTS_UNITY_R, ZROOTS_UNITY_D, ZROOTS_UNITY_E, ZROOTS_UNITY_Q
!    END INTERFACE

!    INTERFACE CUMPROD
!        MODULE PROCEDURE CUMPROD_R, CUMPROD_D, CUMPROD_Q
!    END INTERFACE
!...
!...ROUTINES FOR "OUTER" OPERATIONS ON VECTORS (OUTERAND, OUTERSUM, OUTERDIV ARE NOT CURRENTLY OVERLOADED):
    INTERFACE OUTERPROD
        MODULE PROCEDURE OUTERPROD_R, OUTERPROD_D, OUTERPROD_E, OUTERPROD_Q
    END INTERFACE
!
    INTERFACE OUTERDIFF
        MODULE PROCEDURE OUTERDIFF_R, OUTERDIFF_D, OUTERDIFF_E, OUTERDIFF_I
    END INTERFACE
!...
!...ROUTINES FOR SCATTER-WITH-COMBINE, SCATTER_ADD, SCATTER_MAX:
    INTERFACE SCATTER_ADD
        MODULE PROCEDURE SCATTER_ADD_R, SCATTER_ADD_D, SCATTER_ADD_E, SCATTER_ADD_Q
    END INTERFACE
!
    INTERFACE SCATTER_MAX
        MODULE PROCEDURE SCATTER_MAX_R, SCATTER_MAX_D, SCATTER_MAX_E, SCATTER_MAX_Q
    END INTERFACE
!...
!...ROUTINES FOR SKEW OPERATIONS ON MATRICES (UNIT_MATRIX, LOWER_TRIANGLE, UPPER_TRIANGLE NOT CURRENTLY OVERLOADED):
    INTERFACE DIAGADD
        MODULE PROCEDURE DIAGADD_RV, DIAGADD_R, DIAGADD_D, DIAGADD_E, DIAGADD_Q
    END INTERFACE
!
    INTERFACE DIAGMULT
        MODULE PROCEDURE DIAGMULT_RV, DIAGMULT_R, DIAGMULT_DV, DIAGMULT_D,  &
                         DIAGMULT_EV, DIAGMULT_E, DIAGMULT_QV, DIAGMULT_Q
!        END MODULE
    END INTERFACE
!
    INTERFACE GET_DIAG
        MODULE PROCEDURE GET_DIAG_RV, GET_DIAG_DV, GET_DIAG_EV, GET_DIAG_QV
    END INTERFACE
!
    INTERFACE PUT_DIAG
        MODULE PROCEDURE PUT_DIAG_RV, PUT_DIAG_R, PUT_DIAG_DV, PUT_DIAG_D,  &
                         PUT_DIAG_EV, PUT_DIAG_E, PUT_DIAG_QV, PUT_DIAG_Q
!        END MODULE
    END INTERFACE
!...
!...OTHER ROUTINES (VABS IS NOT CURRENTLY OVERLOADED):
!
    INTERFACE VABS
        MODULE PROCEDURE VABS_R, VABS_D, VABS_E, VABS_Q
    END INTERFACE
!...
CONTAINS
!...
!...ROUTINES THAT MOVE DATA:
    SUBROUTINE ARRAY_COPY_R(SRC,DEST,N_COPIED,N_NOT_COPIED)
!...COPY ARRAY WHERE SIZE OF SOURCE NOT KNOWN IN ADVANCE
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  SRC
    REAL(SP), DIMENSION(:), INTENT(OUT)                             ::  DEST
    INTEGER(I4B), INTENT(OUT)                                       ::  N_COPIED, N_NOT_COPIED
!
    N_COPIED = MIN(SIZE(SRC),SIZE(DEST))
    N_NOT_COPIED = SIZE(SRC)-N_COPIED
    DEST(1:N_COPIED) = SRC(1:N_COPIED)
    END SUBROUTINE ARRAY_COPY_R
!
!
    SUBROUTINE ARRAY_COPY_D(SRC,DEST,N_COPIED,N_NOT_COPIED)
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  SRC
    REAL(DP), DIMENSION(:), INTENT(OUT)                             ::  DEST
    INTEGER(I4B), INTENT(OUT)                                       ::  N_COPIED, N_NOT_COPIED
!
    N_COPIED = MIN(SIZE(SRC),SIZE(DEST))
    N_NOT_COPIED = SIZE(SRC)-N_COPIED
    DEST(1:N_COPIED) = SRC(1:N_COPIED)
    END SUBROUTINE ARRAY_COPY_D
!
!
    SUBROUTINE ARRAY_COPY_E(SRC,DEST,N_COPIED,N_NOT_COPIED)
    REAL(EP), DIMENSION(:), INTENT(IN)                              ::  SRC
    REAL(EP), DIMENSION(:), INTENT(OUT)                             ::  DEST
    INTEGER(I4B), INTENT(OUT)                                       ::  N_COPIED, N_NOT_COPIED
!
    N_COPIED = MIN(SIZE(SRC),SIZE(DEST))
    N_NOT_COPIED = SIZE(SRC)-N_COPIED
    DEST(1:N_COPIED) = SRC(1:N_COPIED)
    END SUBROUTINE ARRAY_COPY_E
!
!
    SUBROUTINE ARRAY_COPY_Q(SRC,DEST,N_COPIED,N_NOT_COPIED)
    REAL(QP), DIMENSION(:), INTENT(IN)                              ::  SRC
    REAL(QP), DIMENSION(:), INTENT(OUT)                             ::  DEST
    INTEGER(I4B), INTENT(OUT)                                       ::  N_COPIED, N_NOT_COPIED
!
    N_COPIED = MIN(SIZE(SRC),SIZE(DEST))
    N_NOT_COPIED = SIZE(SRC)-N_COPIED
    DEST(1:N_COPIED) = SRC(1:N_COPIED)
    END SUBROUTINE ARRAY_COPY_Q
!
!
    SUBROUTINE ARRAY_COPY_I(SRC,DEST,N_COPIED,N_NOT_COPIED)
    INTEGER(I4B), DIMENSION(:), INTENT(IN)                          ::  SRC
    INTEGER(I4B), DIMENSION(:), INTENT(OUT)                         ::  DEST
    INTEGER(I4B), INTENT(OUT)                                       ::  N_COPIED, N_NOT_COPIED
!
    N_COPIED = MIN(SIZE(SRC),SIZE(DEST))
    N_NOT_COPIED = SIZE(SRC)-N_COPIED
    DEST(1:N_COPIED) = SRC(1:N_COPIED)
    END SUBROUTINE ARRAY_COPY_I
!
!
    SUBROUTINE SWAP_I(A,B)
!...SWAP THE CONTENTS OF A AND B
    INTEGER(I4B), INTENT(INOUT)                                     ::  A,B
    INTEGER(I4B)                                                    ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_I
!
!
    SUBROUTINE SWAP_R(A,B)
    REAL(SP), INTENT(INOUT)                                         ::  A,B
    REAL(SP)                                                        ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_R
!
!
    SUBROUTINE SWAP_D(A,B)
    REAL(DP), INTENT(INOUT)                                         ::  A,B
    REAL(DP)                                                        ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_D
!
!
    SUBROUTINE SWAP_E(A,B)
    REAL(EP), INTENT(INOUT)                                         ::  A,B
    REAL(EP)                                                        ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_E
!
!
    SUBROUTINE SWAP_Q(A,B)
    REAL(QP), INTENT(INOUT)                                         ::  A,B
    REAL(QP)                                                        ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_Q
!
!
    SUBROUTINE SWAP_RV(A,B)
    REAL(SP), DIMENSION(:), INTENT(INOUT)                           ::  A,B
    REAL(SP), DIMENSION(SIZE(A))                                    ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_RV
!
!
    SUBROUTINE SWAP_DV(A,B)
    REAL(DP), DIMENSION(:), INTENT(INOUT)                           ::  A,B
    REAL(DP), DIMENSION(SIZE(A))                                    ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_DV
!
!
    SUBROUTINE SWAP_EV(A,B)
    REAL(EP), DIMENSION(:), INTENT(INOUT)                           ::  A,B
    REAL(EP), DIMENSION(SIZE(A))                                    ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_EV
!
!
    SUBROUTINE SWAP_QV(A,B)
    REAL(QP), DIMENSION(:), INTENT(INOUT)                           ::  A,B
    REAL(QP), DIMENSION(SIZE(A))                                    ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_QV
!
!
    SUBROUTINE SWAP_C(A,B)
    COMPLEX(SPC), INTENT(INOUT)                                     ::  A,B
    COMPLEX(SPC)                                                    ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_C
!
!
    SUBROUTINE SWAP_CV(A,B)
    COMPLEX(SPC), DIMENSION(:), INTENT(INOUT)                       ::  A,B
    COMPLEX(SPC), DIMENSION(SIZE(A))                                ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_CV
!
!
    SUBROUTINE SWAP_CM(A,B)
    COMPLEX(SPC), DIMENSION(:,:), INTENT(INOUT)                     ::  A,B
    COMPLEX(SPC), DIMENSION(SIZE(A,1),SIZE(A,2))                    ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_CM
!
!
    SUBROUTINE SWAP_DC(A,B)
    COMPLEX(DPC), INTENT(INOUT)                                     ::  A,B
    COMPLEX(DPC)                                                    ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_DC
!
!
    SUBROUTINE SWAP_DCV(A,B)
    COMPLEX(DPC), DIMENSION(:), INTENT(INOUT)                       ::  A,B
    COMPLEX(DPC), DIMENSION(SIZE(A))                                ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_DCV
!
!
    SUBROUTINE SWAP_DCM(A,B)
    COMPLEX(DPC), DIMENSION(:,:), INTENT(INOUT)                     ::  A,B
    COMPLEX(DPC), DIMENSION(SIZE(A,1),SIZE(A,2))                    ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_DCM
!
!
    SUBROUTINE SWAP_EC(A,B)
    COMPLEX(EPC), INTENT(INOUT)                                     ::  A,B
    COMPLEX(EPC)                                                    ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_EC
!
!
    SUBROUTINE SWAP_ECV(A,B)
    COMPLEX(EPC), DIMENSION(:), INTENT(INOUT)                       ::  A,B
    COMPLEX(EPC), DIMENSION(SIZE(A))                                ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_ECV
!
!
    SUBROUTINE SWAP_ECM(A,B)
    COMPLEX(EPC), DIMENSION(:,:), INTENT(INOUT)                     ::  A,B
    COMPLEX(EPC), DIMENSION(SIZE(A,1),SIZE(A,2))                    ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_ECM
!
!
    SUBROUTINE SWAP_QC(A,B)
    COMPLEX(QPC), INTENT(INOUT)                                     ::  A,B
    COMPLEX(QPC)                                                    ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_QC
!
!
    SUBROUTINE SWAP_QCV(A,B)
    COMPLEX(QPC), DIMENSION(:), INTENT(INOUT)                       ::  A,B
    COMPLEX(QPC), DIMENSION(SIZE(A))                                ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_QCV
!
!
    SUBROUTINE SWAP_QCM(A,B)
    COMPLEX(QPC), DIMENSION(:,:), INTENT(INOUT)                     ::  A,B
    COMPLEX(QPC), DIMENSION(SIZE(A,1),SIZE(A,2))                    ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_QCM
!
!
    SUBROUTINE SWAP_CH(A,B)
    CHARACTER(*), INTENT(INOUT)                                     :: A,B
    CHARACTER(LEN(A))                                               :: DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_CH
!
!
    SUBROUTINE SWAP_CHV(A,B)
    CHARACTER(*), DIMENSION(:,:), INTENT(INOUT)                     :: A,B
    CHARACTER(LEN(A)), DIMENSION(SIZE(A,1),SIZE(A,2))               ::  DUM
!
    DUM = A
    A = B
    B = DUM
    END SUBROUTINE SWAP_CHV
!
!
    SUBROUTINE MASKED_SWAP_RS(A,B,MASK)
    REAL(SP), INTENT(INOUT)                                         ::  A,B
    LOGICAL(TLG), INTENT(IN)                                        ::  MASK
    REAL(SP)                                                        ::  SWP
!
    IF (MASK) THEN
        SWP = A
        A = B
        B = SWP
    ENDIF
    END SUBROUTINE MASKED_SWAP_RS
!
!
    SUBROUTINE MASKED_SWAP_RV(A,B,MASK)
    REAL(SP), DIMENSION(:), INTENT(INOUT)                           ::  A,B
    LOGICAL(TLG), DIMENSION(:), INTENT(IN)                          ::  MASK
    REAL(SP), DIMENSION(SIZE(A))                                    ::  SWP
!
    WHERE (MASK)
        SWP = A
        A = B
        B = SWP
    END WHERE
    END SUBROUTINE MASKED_SWAP_RV
!
!
    SUBROUTINE MASKED_SWAP_RM(A,B,MASK)
    REAL(SP), DIMENSION(:,:), INTENT(INOUT)                         ::  A,B
    LOGICAL(TLG), DIMENSION(:,:), INTENT(IN)                        ::  MASK
    REAL(SP), DIMENSION(SIZE(A,1),SIZE(A,2))                        ::  SWP
!
    WHERE (MASK)
        SWP = A
        A = B
        B = SWP
    END WHERE
    END SUBROUTINE  MASKED_SWAP_RM
!
!
    SUBROUTINE MASKED_SWAP_DS(A,B,MASK)
    REAL(DP), INTENT(INOUT)                                         ::  A,B
    LOGICAL(TLG), INTENT(IN)                                        ::  MASK
    REAL(DP)                                                        ::  SWP
!
    IF (MASK) THEN
        SWP = A
        A = B
        B = SWP
    ENDIF
    END SUBROUTINE MASKED_SWAP_DS
!
!
    SUBROUTINE MASKED_SWAP_DV(A,B,MASK)
    REAL(DP), DIMENSION(:), INTENT(INOUT)                           ::  A,B
    LOGICAL(TLG), DIMENSION(:), INTENT(IN)                          ::  MASK
    REAL(DP), DIMENSION(SIZE(A))                                    ::  SWP
!
    WHERE (MASK)
        SWP = A
        A = B
        B = SWP
    END WHERE
    END SUBROUTINE MASKED_SWAP_DV
!
!
    SUBROUTINE MASKED_SWAP_DM(A,B,MASK)
    REAL(DP), DIMENSION(:,:), INTENT(INOUT)                         ::  A,B
    LOGICAL(TLG), DIMENSION(:,:), INTENT(IN)                        ::  MASK
    REAL(DP), DIMENSION(SIZE(A,1),SIZE(A,2))                        ::  SWP
!
    WHERE (MASK)
        SWP = A
        A = B
        B = SWP
    END WHERE
    END SUBROUTINE  MASKED_SWAP_DM
!
!
    SUBROUTINE MASKED_SWAP_ES(A,B,MASK)
    REAL(EP), INTENT(INOUT)                                         ::  A,B
    LOGICAL(TLG), INTENT(IN)                                        ::  MASK
    REAL(EP)                                                        ::  SWP
!
    IF (MASK) THEN
        SWP = A
        A = B
        B = SWP
    ENDIF
    END SUBROUTINE MASKED_SWAP_ES
!
!
    SUBROUTINE MASKED_SWAP_EV(A,B,MASK)
    REAL(EP), DIMENSION(:), INTENT(INOUT)                           ::  A,B
    LOGICAL(TLG), DIMENSION(:), INTENT(IN)                          ::  MASK
    REAL(EP), DIMENSION(SIZE(A))                                    ::  SWP
!
    WHERE (MASK)
        SWP = A
        A = B
        B = SWP
    END WHERE
    END SUBROUTINE MASKED_SWAP_EV
!
!
    SUBROUTINE MASKED_SWAP_EM(A,B,MASK)
    REAL(EP), DIMENSION(:,:), INTENT(INOUT)                         ::  A,B
    LOGICAL(TLG), DIMENSION(:,:), INTENT(IN)                        ::  MASK
    REAL(EP), DIMENSION(SIZE(A,1),SIZE(A,2))                        ::  SWP
!
    WHERE (MASK)
        SWP = A
        A = B
        B = SWP
    END WHERE
    END SUBROUTINE  MASKED_SWAP_EM
!
!
    SUBROUTINE MASKED_SWAP_QS(A,B,MASK)
    REAL(QP), INTENT(INOUT)                                         ::  A,B
    LOGICAL(TLG), INTENT(IN)                                        ::  MASK
    REAL(QP)                                                        ::  SWP
!
    IF (MASK) THEN
        SWP = A
        A = B
        B = SWP
    ENDIF
    END SUBROUTINE MASKED_SWAP_QS
!
!
    SUBROUTINE MASKED_SWAP_QV(A,B,MASK)
    REAL(QP), DIMENSION(:), INTENT(INOUT)                           ::  A,B
    LOGICAL(TLG), DIMENSION(:), INTENT(IN)                          ::  MASK
    REAL(QP), DIMENSION(SIZE(A))                                    ::  SWP
!
    WHERE (MASK)
        SWP = A
        A = B
        B = SWP
    END WHERE
    END SUBROUTINE MASKED_SWAP_QV
!
!
    SUBROUTINE MASKED_SWAP_QM(A,B,MASK)
    REAL(QP), DIMENSION(:,:), INTENT(INOUT)                         ::  A,B
    LOGICAL(TLG), DIMENSION(:,:), INTENT(IN)                        ::  MASK
    REAL(QP), DIMENSION(SIZE(A,1),SIZE(A,2))                        ::  SWP
!
    WHERE (MASK)
        SWP = A
        A = B
        B = SWP
    END WHERE
    END SUBROUTINE  MASKED_SWAP_QM
!
!
    FUNCTION REALLOCATE_RV(P,N)
!...
!...REALLOCATE A POINTER TO A NEW SIZE, PRESERVING ITS PREVIOUS CONTENTS
    REAL(SP), DIMENSION(:), POINTER                                 ::  P, REALLOCATE_RV
    INTEGER(I4B), INTENT(IN)                                        ::  N
    INTEGER(I4B)                                                    ::  NOLD, IERR
!
    ALLOCATE(REALLOCATE_RV(N),STAT=IERR)
    IF (IERR /= 0) CALL NRERROR("REALLOCATE_RV --> PROBLEM IN ATTEMPT TO AALOCATE MEMORY")
    IF (.NOT. ASSOCIATED(P)) RETURN
    NOLD = SIZE(P)
    REALLOCATE_RV(1:MIN(NOLD,N)) = P(1:MIN(NOLD,N))
    DEALLOCATE(P)
    END FUNCTION REALLOCATE_RV
!
!
    FUNCTION REALLOCATE_DV(P,N)
!...
!...REALLOCATE A POINTER TO A NEW SIZE, PRESERVING ITS PREVIOUS CONTENTS
    REAL(DP), DIMENSION(:), POINTER                                 ::  P, REALLOCATE_DV
    INTEGER(I4B), INTENT(IN)                                        ::  N
    INTEGER(I4B)                                                    ::  NOLD, IERR
!
    ALLOCATE(REALLOCATE_DV(N),STAT=IERR)
    IF (IERR /= 0) CALL NRERROR("REALLOCATE_DV --> PROBLEM IN ATTEMPT TO AALOCATE MEMORY")
    IF (.NOT. ASSOCIATED(P)) RETURN
    NOLD = SIZE(P)
    REALLOCATE_DV(1:MIN(NOLD,N)) = P(1:MIN(NOLD,N))
    DEALLOCATE(P)
    END FUNCTION REALLOCATE_DV
!
!
    FUNCTION REALLOCATE_EV(P,N)
!...
!...REALLOCATE A POINTER TO A NEW SIZE, PRESERVING ITS PREVIOUS CONTENTS
    REAL(EP), DIMENSION(:), POINTER                                 ::  P, REALLOCATE_EV
    INTEGER(I4B), INTENT(IN)                                        ::  N
    INTEGER(I4B)                                                    ::  NOLD, IERR
!
    ALLOCATE(REALLOCATE_EV(N),STAT=IERR)
    IF (IERR /= 0) CALL NRERROR("REALLOCATE_EV --> PROBLEM IN ATTEMPT TO AALOCATE MEMORY")
    IF (.NOT. ASSOCIATED(P)) RETURN
    NOLD = SIZE(P)
    REALLOCATE_EV(1:MIN(NOLD,N)) = P(1:MIN(NOLD,N))
    DEALLOCATE(P)
    END FUNCTION REALLOCATE_EV
!
!
    FUNCTION REALLOCATE_QV(P,N)
!...
!...REALLOCATE A POINTER TO A NEW SIZE, PRESERVING ITS PREVIOUS CONTENTS
    REAL(QP), DIMENSION(:), POINTER                                 ::  P, REALLOCATE_QV
    INTEGER(I4B), INTENT(IN)                                        ::  N
    INTEGER(I4B)                                                    ::  NOLD, IERR
!
    ALLOCATE(REALLOCATE_QV(N),STAT=IERR)
    IF (IERR /= 0) CALL NRERROR("REALLOCATE_QV --> PROBLEM IN ATTEMPT TO AALOCATE MEMORY")
    IF (.NOT. ASSOCIATED(P)) RETURN
    NOLD = SIZE(P)
    REALLOCATE_QV(1:MIN(NOLD,N)) = P(1:MIN(NOLD,N))
    DEALLOCATE(P)
    END FUNCTION REALLOCATE_QV
!
!
    FUNCTION REALLOCATE_IV(P,N)
    INTEGER(I4B), DIMENSION(:), POINTER                             ::  P, REALLOCATE_IV
    INTEGER(I4B), INTENT(IN)                                        ::  N
    INTEGER(I4B)                                                    ::  NOLD, IERR
!
    ALLOCATE(REALLOCATE_IV(N), STAT=IERR)
    IF (IERR /= 0) CALL NRERROR("REALLOCATE_IV --> PROBLEM IN ATTEMPT TO ALLOCATE MEMORY")
    IF (.NOT. ASSOCIATED(P)) RETURN
    NOLD = SIZE(P)
    REALLOCATE_IV(1:MIN(NOLD,N)) = P(1:MIN(NOLD,N))
    DEALLOCATE(P)
    END FUNCTION REALLOCATE_IV
!
!
    FUNCTION REALLOCATE_HV(P,N)
    CHARACTER(1), DIMENSION(:), POINTER                             ::  P, REALLOCATE_HV
    INTEGER(I4B), INTENT(IN)                                        ::  N
    INTEGER(I4B)                                                    ::  NOLD, IERR
!
    ALLOCATE(REALLOCATE_HV(N), STAT=IERR)
    IF (IERR /= 0) CALL NRERROR("REALLOCATE_HV --> PROBLEM IN ATTEMPT TO ALLOCATE MEMORY")
    IF (.NOT. ASSOCIATED(P)) RETURN
    NOLD = SIZE(P)
    REALLOCATE_HV(1:MIN(NOLD,N)) = P(1:MIN(NOLD,N))
    DEALLOCATE(P)
    END FUNCTION REALLOCATE_HV
!
!
    FUNCTION REALLOCATE_RM(P,N,M)
    REAL(SP), DIMENSION(:,:), POINTER                               ::  P, REALLOCATE_RM
    INTEGER(I4B), INTENT(IN)                                        ::  N, M
    INTEGER(I4B)                                                    ::  NOLD, MOLD, IERR
!
    ALLOCATE(REALLOCATE_RM(N,M), STAT=IERR)
    IF (IERR /= 0) CALL NRERROR("REALLOCATE_RM --> PROBLEM IN ATTEMPT TO ALLOCATE MEMORY")
    IF (.NOT. ASSOCIATED(P)) RETURN
    NOLD = SIZE(P,1)
    MOLD = SIZE(P,2)
    REALLOCATE_RM(1:MIN(NOLD,N),1:MIN(MOLD,M)) = P(1:MIN(NOLD,N),1:MIN(MOLD,M))
    DEALLOCATE(P)
    END FUNCTION REALLOCATE_RM
!
!
    FUNCTION REALLOCATE_DM(P,N,M)
    REAL(DP), DIMENSION(:,:), POINTER                               ::  P, REALLOCATE_DM
    INTEGER(I4B), INTENT(IN)                                        ::  N, M
    INTEGER(I4B)                                                    ::  NOLD, MOLD, IERR
!
    ALLOCATE(REALLOCATE_DM(N,M), STAT=IERR)
    IF (IERR /= 0) CALL NRERROR("REALLOCATE_DM --> PROBLEM IN ATTEMPT TO ALLOCATE MEMORY")
    IF (.NOT. ASSOCIATED(P)) RETURN
    NOLD = SIZE(P,1)
    MOLD = SIZE(P,2)
    REALLOCATE_DM(1:MIN(NOLD,N),1:MIN(MOLD,M)) = P(1:MIN(NOLD,N),1:MIN(MOLD,M))
    DEALLOCATE(P)
    END FUNCTION REALLOCATE_DM
!
!
    FUNCTION REALLOCATE_EM(P,N,M)
    REAL(EP), DIMENSION(:,:), POINTER                               ::  P, REALLOCATE_EM
    INTEGER(I4B), INTENT(IN)                                        ::  N, M
    INTEGER(I4B)                                                    ::  NOLD, MOLD, IERR
!
    ALLOCATE(REALLOCATE_EM(N,M), STAT=IERR)
    IF (IERR /= 0) CALL NRERROR("REALLOCATE_EM --> PROBLEM IN ATTEMPT TO ALLOCATE MEMORY")
    IF (.NOT. ASSOCIATED(P)) RETURN
    NOLD = SIZE(P,1)
    MOLD = SIZE(P,2)
    REALLOCATE_EM(1:MIN(NOLD,N),1:MIN(MOLD,M)) = P(1:MIN(NOLD,N),1:MIN(MOLD,M))
    DEALLOCATE(P)
    END FUNCTION REALLOCATE_EM
!
!
    FUNCTION REALLOCATE_QM(P,N,M)
    REAL(QP), DIMENSION(:,:), POINTER                               ::  P, REALLOCATE_QM
    INTEGER(I4B), INTENT(IN)                                        ::  N, M
    INTEGER(I4B)                                                    ::  NOLD, MOLD, IERR
!
    ALLOCATE(REALLOCATE_QM(N,M), STAT=IERR)
    IF (IERR /= 0) CALL NRERROR("REALLOCATE_QM --> PROBLEM IN ATTEMPT TO ALLOCATE MEMORY")
    IF (.NOT. ASSOCIATED(P)) RETURN
    NOLD = SIZE(P,1)
    MOLD = SIZE(P,2)
    REALLOCATE_QM(1:MIN(NOLD,N),1:MIN(MOLD,M)) = P(1:MIN(NOLD,N),1:MIN(MOLD,M))
    DEALLOCATE(P)
    END FUNCTION REALLOCATE_QM
!
!
    FUNCTION REALLOCATE_IM(P,N,M)
    INTEGER(I4B), DIMENSION(:,:), POINTER                           ::  P, REALLOCATE_IM
    INTEGER(I4B), INTENT(IN)                                        ::  N, M
    INTEGER(I4B)                                                    ::  NOLD, MOLD, IERR
!
    ALLOCATE(REALLOCATE_IM(N,M), STAT=IERR)
    IF (IERR /= 0) CALL NRERROR("REALLOCATE_IM --> PROBLEM IN ATTEMPT TO ALLOCATE MEMORY")
    IF (.NOT. ASSOCIATED(P)) RETURN
    NOLD = SIZE(P,1)
    MOLD = SIZE(P,2)
    REALLOCATE_IM(1:MIN(NOLD,N),1:MIN(MOLD,M)) = P(1:MIN(NOLD,N),1:MIN(MOLD,M))
    DEALLOCATE(P)
    END FUNCTION REALLOCATE_IM
!...
!...ROUTINES RETURNING A LOCATION AS AN INTEGER VALUE:
    FUNCTION IFIRSTLOC(MASK)
!...INDEX OF FIRST OCCURRENCE OF .TRUE. IN A LOGICAL VECTOR
    LOGICAL(TLG), DIMENSION(:), INTENT(IN)                          ::  MASK
    INTEGER(I4B)                                                    ::  IFIRSTLOC
    INTEGER(I4B), DIMENSION(1)                                      ::  LOC
!
    LOC = MAXLOC(MERGE(1,0,MASK))
    IFIRSTLOC = LOC(1)
    IF (.NOT. MASK(IFIRSTLOC)) IFIRSTLOC=SIZE(MASK)+1
    END FUNCTION IFIRSTLOC
!
!
    FUNCTION IMAXLOC_R(ARR)
!...INDEX OF MAXLOC ON AN ARRAY
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  ARR
    INTEGER(I4B)                                                    ::  IMAXLOC_R
    INTEGER(I4B), DIMENSION(1)                                      ::  IMAX
!
    IMAX = MAXLOC(ARR(:))
    IMAXLOC_R = IMAX(1)
    END FUNCTION IMAXLOC_R
!
!
    FUNCTION IMAXLOC_D(ARR)
!...INDEX OF MAXLOC ON AN ARRAY
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  ARR
    INTEGER(I4B)                                                    ::  IMAXLOC_D
    INTEGER(I4B), DIMENSION(1)                                      ::  IMAX
!
    IMAX = MAXLOC(ARR(:))
    IMAXLOC_D = IMAX(1)
    END FUNCTION IMAXLOC_D
!
!
    FUNCTION IMAXLOC_E(ARR)
!...INDEX OF MAXLOC ON AN ARRAY
    REAL(EP), DIMENSION(:), INTENT(IN)                              ::  ARR
    INTEGER(I4B)                                                    ::  IMAXLOC_E
    INTEGER(I4B), DIMENSION(1)                                      ::  IMAX
!
    IMAX = MAXLOC(ARR(:))
    IMAXLOC_E = IMAX(1)
    END FUNCTION IMAXLOC_E
!
!
    FUNCTION IMAXLOC_Q(ARR)
!...INDEX OF MAXLOC ON AN ARRAY
    REAL(QP), DIMENSION(:), INTENT(IN)                              ::  ARR
    INTEGER(I4B)                                                    ::  IMAXLOC_Q
    INTEGER(I4B), DIMENSION(1)                                      ::  IMAX
!
    IMAX = MAXLOC(ARR(:))
    IMAXLOC_Q = IMAX(1)
    END FUNCTION IMAXLOC_Q
!
!
    FUNCTION IMAXLOC_I(IARR)
    INTEGER(I4B), DIMENSION(:), INTENT(IN)                          ::  IARR
    INTEGER(I4B), DIMENSION(1)                                      ::  IMAX
    INTEGER(I4B)                                                    ::  IMAXLOC_I
!
    IMAX = MAXLOC(IARR(:))
    IMAXLOC_I = IMAX(1)
    END FUNCTION IMAXLOC_I
!
!
    FUNCTION IMINLOC(ARR)
!...INDEX OF MINLOC ON AN ARRAY
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  ARR
    INTEGER(I4B), DIMENSION(1)                                      ::  IMIN
    INTEGER(I4B)                                                    ::  IMINLOC
!
    IMIN = MINLOC(ARR(:))
    IMINLOC = IMIN(1)
    END FUNCTION IMINLOC
!...
!...ROUTINES FOR ARGUMENT CHECKING AND ERROR HANDLING:
    SUBROUTINE ASSERT1(N1,STRING)
!...REPORT AND DIE IF ANY LOGICAL IS FALSE (USED FOR ARG RANGE CHECKING)
    CHARACTER(LEN=*), INTENT(IN)                                    ::  STRING
    LOGICAL, INTENT(IN)                                             ::  N1
!
    IF (.NOT. N1) THEN
        WRITE (*,*) "NRERROR: AN ASSERTION FAILED WITH THIS TAG: ",STRING
        STOP "--> PROGRAM TERMINATED BY ASSERT1"
    ENDIF
    END SUBROUTINE ASSERT1
!
!
    SUBROUTINE ASSERT2(N1,N2,STRING)
    CHARACTER(LEN=*), INTENT(IN)                                    ::  STRING
    LOGICAL, INTENT(IN)                                             ::  N1, N2
!
    IF (.NOT. (N1 .AND. N2)) THEN
        WRITE (*,*) "NRERROR: AN ASSERTION FAILED WITH THIS TAG: ",STRING
        STOP "--> PROGRAM TERMINATED BY ASSERT2"
    ENDIF
    END SUBROUTINE ASSERT2
!
!
    SUBROUTINE ASSERT3(N1,N2,N3,STRING)
    CHARACTER(LEN=*), INTENT(IN)                                    ::  STRING
    LOGICAL, INTENT(IN)                                             ::  N1, N2, N3
!
    IF (.NOT. (N1 .AND. N2 .AND. N3)) THEN
        WRITE (*,*) "NRERROR: AN ASSERTION FAILED WITH THIS TAG: ",STRING
        STOP "--> PROGRAM TERMINATED BY ASSERT3"
    ENDIF
    END SUBROUTINE ASSERT3
!
!
    SUBROUTINE ASSERT4(N1,N2,N3,N4,STRING)
    CHARACTER(LEN=*), INTENT(IN)                                    ::  STRING
    LOGICAL, INTENT(IN)                                             ::  N1, N2, N3,N4
!
    IF (.NOT. (N1 .AND. N2 .AND. N3 .AND. N4)) THEN
        WRITE (*,*) "NRERROR: AN ASSERTION FAILED WITH THIS TAG: ",STRING
        STOP "--> PROGRAM TERMINATED BY ASSERT4"
    ENDIF
    END SUBROUTINE ASSERT4
!
!
    SUBROUTINE ASSERT_V(N,STRING)
    CHARACTER(LEN=*), INTENT(IN)                                    ::  STRING
    LOGICAL, DIMENSION(:), INTENT(IN)                               ::  N
!
    IF (.NOT. ALL(N)) THEN
        WRITE (*,*) "NRERROR: AN ASSERTION FAILED WITH THIS TAG: ",STRING
        STOP "--> PROGRAM TERMINATED BY ASSERT_V"
    ENDIF
    END SUBROUTINE ASSERT_V
!
!
    FUNCTION ASSERT_EQ2(N1,N2,STRING)
!...REPORT AND DIE IF INTEGERS NOT ALL EQUAL (USED FOR SIZE CHECKING)
    CHARACTER(LEN=*), INTENT(IN)                                    ::  STRING
    INTEGER, INTENT(IN)                                             ::  N1, N2
    INTEGER                                                         ::  ASSERT_EQ2
!
    IF (N1 == N2) THEN
    ASSERT_EQ2 = N1
    ELSE
        WRITE (*,*) "NRERROR: AN ASSERT_EQ FAILED WITH THIS TAG: ",STRING
        STOP "--> PROGRAM TERMINATED BY ASSERT_EQ2"
    ENDIF
    END FUNCTION ASSERT_EQ2
!
!
    FUNCTION ASSERT_EQ3(N1,N2,N3,STRING)
    CHARACTER(LEN=*), INTENT(IN)                                    ::  STRING
    INTEGER, INTENT(IN)                                             ::  N1, N2, N3
    INTEGER                                                         ::  ASSERT_EQ3
!
    IF (N1 == N2 .AND. N2 == N3) THEN
        ASSERT_EQ3 = N1
    ELSE
        WRITE (*,*) "NRERROR: AN ASSERT_EQ FAILED WITH THIS TAG: ",STRING
        STOP "--> PROGRAM TERMINATED BY ASSERT_EQ3"
    ENDIF
    END FUNCTION ASSERT_EQ3
!
!
    FUNCTION ASSERT_EQ4(N1,N2,N3,N4,STRING)
    CHARACTER(LEN=*), INTENT(IN)                                    ::  STRING
    INTEGER, INTENT(IN)                                             ::  N1, N2, N3, N4
    INTEGER                                                         ::  ASSERT_EQ4
!
    IF (N1 == N2 .AND. N2 == N3 .AND. N3 == N4) THEN
        ASSERT_EQ4 = N1
    ELSE
        WRITE (*,*) "NRERROR: AN ASSERT_EQ FAILED WITH THIS TAG: ",STRING
        STOP "--> PROGRAM TERMINATED BY ASSERT_EQ4"
    ENDIF
    END FUNCTION ASSERT_EQ4
!
!
    FUNCTION ASSERT_EQN(NN,STRING)
    CHARACTER(LEN=*), INTENT(IN)                                    ::  STRING
    INTEGER, DIMENSION(:), INTENT(IN)                               ::  NN
    INTEGER                                                         ::  ASSERT_EQN
!
    IF (ALL(NN(2:) == NN(1))) THEN
        ASSERT_EQN = NN(1)
    ELSE
        WRITE (*,*) "NRERROR: AN ASSERT_EQ FAILED WITH THIS TAG: ",STRING
        STOP "--> PROGRAM TERMINATED BY ASSERT_EQN"
    ENDIF
    END FUNCTION ASSERT_EQN
!
!
    SUBROUTINE NRERROR(STRING)
!...REPORT A MESSAGE, THEN DIE
    CHARACTER(LEN=*), INTENT(IN)                                    ::  STRING
!
    WRITE (*,*) "NRERROR: ", STRING
    WRITE (*,*)
    STOP "--> PROGRAM TERMINATED BY NRERROR"
    END SUBROUTINE NRERROR
!...
!...ROUTINES RELATING POLYNOMIALS AND RECURRENCES:
    FUNCTION ARTH_R(FIRST,INCREMENT,N)
!...ARRAY FUNCTION RETURNING AND ARITHMETIC PROGRESSION
    REAL(SP), INTENT(IN)                                            ::  FIRST, INCREMENT
    INTEGER(I4B), INTENT(IN)                                        ::  N
    REAL(SP), DIMENSION(N)                                          ::  ARTH_R
    INTEGER(I4B)                                                    ::  K, K2
    REAL(SP)                                                        ::  TEMP
!
    IF (N > 0) ARTH_R(1) = FIRST
    IF (N <= NPAR_ARTH) THEN
    DO K = 2,N
        ARTH_R(K) = ARTH_R(K-1)+INCREMENT
    ENDDO
!        FORALL (K=2:N) ARTH_R(K) = ARTH_R(K-1)+INCREMENT
    ELSE
    DO K = 2,NPAR2_ARTH
        ARTH_R(K) = ARTH_R(K-1)+INCREMENT
    ENDDO
!        FORALL (K=2:NPAR2_ARTH) ARTH_R(K) = ARTH_R(K-1)+INCREMENT
        TEMP = INCREMENT*NPAR2_ARTH
        K = NPAR2_ARTH
        DO
            IF (K >= N) EXIT
            K2 = K+K
            ARTH_R(K+1:MIN(K2,N))=TEMP+ARTH_R(1:MIN(K,N-K))
            TEMP = TEMP+TEMP
            K = K2
        ENDDO
    ENDIF
    END FUNCTION ARTH_R
!
!
    FUNCTION ARTH_D(FIRST,INCREMENT,N)
    REAL(DP), INTENT(IN)                                            ::  FIRST, INCREMENT
    INTEGER(I4B), INTENT(IN)                                        ::  N
    REAL(DP), DIMENSION(N)                                          ::  ARTH_D
    INTEGER(I4B)                                                    ::  K, K2
    REAL(DP)                                                        ::  TEMP
!
    IF (N > 0) ARTH_D(1) = FIRST
    IF (N <= NPAR_ARTH) THEN
    DO K = 2,N
        ARTH_D(K) = ARTH_D(K-1)+INCREMENT
    ENDDO
!        FORALL (K=2:N) ARTH_D(K) = ARTH_D(K-1)+INCREMENT
    ELSE
    DO K = 2,NPAR2_ARTH
        ARTH_D(K) = ARTH_D(K-1)+INCREMENT
    ENDDO
!        FORALL (K=2:NPAR2_ARTH) ARTH_D(K) = ARTH_D(K-1)+INCREMENT
        TEMP = INCREMENT*NPAR2_ARTH
        K = NPAR2_ARTH
        DO
            IF (K >= N) EXIT
            K2 = K+K
            ARTH_D(K+1:MIN(K2,N)) = TEMP+ARTH_D(1:MIN(K,N-K))
            TEMP = TEMP+TEMP
            K = K2
        ENDDO
    ENDIF
    END FUNCTION ARTH_D
!
!
    FUNCTION ARTH_E(FIRST,INCREMENT,N)
    REAL(EP), INTENT(IN)                                            ::  FIRST, INCREMENT
    INTEGER(I4B), INTENT(IN)                                        ::  N
    REAL(EP), DIMENSION(N)                                          ::  ARTH_E
    INTEGER(I4B)                                                    ::  K, K2
    REAL(EP)                                                        ::  TEMP
!
    IF (N > 0) ARTH_E(1) = FIRST
    IF (N <= NPAR_ARTH) THEN
    DO K = 2,N
        ARTH_E(K) = ARTH_E(K-1)+INCREMENT
    ENDDO
!        FORALL (K=2:N) ARTH_E(K) = ARTH_E(K-1)+INCREMENT
    ELSE
    DO K = 2,NPAR2_ARTH
        ARTH_E(K) = ARTH_E(K-1)+INCREMENT
    ENDDO
!        FORALL (K=2:NPAR2_ARTH) ARTH_E(K) = ARTH_E(K-1)+INCREMENT
        TEMP = INCREMENT*NPAR2_ARTH
        K = NPAR2_ARTH
        DO
            IF (K >= N) EXIT
            K2 = K+K
            ARTH_E(K+1:MIN(K2,N)) = TEMP+ARTH_E(1:MIN(K,N-K))
            TEMP = TEMP+TEMP
            K = K2
        ENDDO
    ENDIF
    END FUNCTION ARTH_E
!
!
    FUNCTION ARTH_Q(FIRST,INCREMENT,N)
    REAL(QP), INTENT(IN)                                            ::  FIRST, INCREMENT
    INTEGER(I4B), INTENT(IN)                                        ::  N
    REAL(QP), DIMENSION(N)                                          ::  ARTH_Q
    INTEGER(I4B)                                                    ::  K, K2
    REAL(QP)                                                        ::  TEMP
!
    IF (N > 0) ARTH_Q(1) = FIRST
    IF (N <= NPAR_ARTH) THEN
    DO K = 2,N
        ARTH_Q(K) = ARTH_Q(K-1)+INCREMENT
    ENDDO
!        FORALL (K=2:N) ARTH_Q(K) = ARTH_Q(K-1)+INCREMENT
    ELSE
    DO K = 2,NPAR2_ARTH
        ARTH_Q(K) = ARTH_Q(K-1)+INCREMENT
    ENDDO
!        FORALL (K=2:NPAR2_ARTH) ARTH_D(K) = ARTH_D(K-1)+INCREMENT
        TEMP = INCREMENT*NPAR2_ARTH
        K = NPAR2_ARTH
        DO
            IF (K >= N) EXIT
            K2 = K+K
            ARTH_Q(K+1:MIN(K2,N)) = TEMP+ARTH_Q(1:MIN(K,N-K))
            TEMP = TEMP+TEMP
            K = K2
        ENDDO
    ENDIF
    END FUNCTION ARTH_Q
!
!
    FUNCTION ARTH_I(FIRST,INCREMENT,N)
    INTEGER(I4B), INTENT(IN)                                        ::  FIRST, INCREMENT, N
    INTEGER(I4B), DIMENSION(N)                                      ::  ARTH_I
    INTEGER(I4B)                                                    ::  K, K2, TEMP
!
    IF (N > 0) ARTH_I(1) = FIRST
    IF (N <= NPAR_ARTH) THEN
    DO K = 2,N
        ARTH_I(K) = ARTH_I(K-1)+INCREMENT
    ENDDO
!        FORALL (K=2:N) ARTH_I(K) = ARTH_I(K-1)+INCREMENT
    ELSE
    DO K = 2,NPAR2_ARTH
        ARTH_I(K) = ARTH_I(K-1)+INCREMENT
    ENDDO
!        FORALL (K=2:NPAR2_ARTH) ARTH_I(K) = ARTH_I(K-1)+INCREMENT
        TEMP = INCREMENT*NPAR2_ARTH
        K = NPAR2_ARTH
        DO
            IF (K >= N) EXIT
            K2 = K+K
            ARTH_I(K+1:MIN(K2,N)) = TEMP+ARTH_I(1:MIN(K,N-K))
            TEMP = TEMP+TEMP
            K = K2
        ENDDO
    ENDIF
    END FUNCTION ARTH_I
!
!
    FUNCTION GEOP_R(FIRST,FACTOR,N)
!...ARRAY FUNCTION RETURNING A GEOMETRIC PROGRESSION
    REAL(SP), INTENT(IN)                                            ::  FIRST, FACTOR
    INTEGER(I4B), INTENT(IN)                                        ::  N
    REAL(SP), DIMENSION(N)                                          ::  GEOP_R
    INTEGER(I4B)                                                    ::  K, K2
    REAL(SP)                                                        ::  TEMP
!
    IF (N > 0) GEOP_R(1) = FIRST
    IF (N <= NPAR_GEOP) THEN
    DO K = 2,N
        GEOP_R(K) = GEOP_R(K-1)*FACTOR
    ENDDO
!        FORALL (K=2:N) GEOP_R(K) = GEOP_R(K-1)*FACTOR
    ELSE
    DO K = 2,NPAR2_GEOP
        GEOP_R(K) = GEOP_R(K-1)*FACTOR
    ENDDO
!        FORALL (K=2:NPAR2_GEOP) GEOP_R(K) = GEOP_R(K-1)*FACTOR
        TEMP = FACTOR**NPAR2_GEOP
        K = NPAR2_GEOP
        DO
            IF (K >= N) EXIT
            K2 = K+K
            GEOP_R(K+1:MIN(K2,N)) = TEMP*GEOP_R(1:MIN(K,N-K))
            TEMP = TEMP*TEMP
            K = K2
        ENDDO
    ENDIF
    END FUNCTION GEOP_R
!
!
    FUNCTION GEOP_D(FIRST,FACTOR,N)
    REAL(DP), INTENT(IN)                                            ::  FIRST, FACTOR
    INTEGER(I4B), INTENT(IN)                                        ::  N
    REAL(DP), DIMENSION(N)                                          ::  GEOP_D
    INTEGER(I4B)                                                    ::  K, K2
    REAL(DP)                                                        ::  TEMP
!
    IF (N > 0) GEOP_D(1) = FIRST
    IF (N <= NPAR_GEOP) THEN
    DO K = 2,N
        GEOP_D(K) = GEOP_D(K-1)*FACTOR
    ENDDO
!        FORALL (K=2:N) GEOP_D(K) = GEOP_D(K-1)*FACTOR
    ELSE
    DO K = 2,NPAR2_GEOP
        GEOP_D(K) = GEOP_D(K-1)*FACTOR
    ENDDO
!        FORALL (K=2:NPAR2_GEOP) GEOP_D(K) = GEOP_D(K-1)*FACTOR
        TEMP = FACTOR**NPAR2_GEOP
        K = NPAR2_GEOP
        DO
            IF (K >= N) EXIT
            K2 = K+K
            GEOP_D(K+1:MIN(K2,N)) = TEMP*GEOP_D(1:MIN(K,N-K))
            TEMP = TEMP*TEMP
            K = K2
        ENDDO
    ENDIF
    END FUNCTION GEOP_D
!
!
    FUNCTION GEOP_E(FIRST,FACTOR,N)
    REAL(EP), INTENT(IN)                                            ::  FIRST, FACTOR
    INTEGER(I4B), INTENT(IN)                                        ::  N
    REAL(EP), DIMENSION(N)                                          ::  GEOP_E
    INTEGER(I4B)                                                    ::  K, K2
    REAL(EP)                                                        ::  TEMP
!
    IF (N > 0) GEOP_E(1) = FIRST
    IF (N <= NPAR_GEOP) THEN
    DO K = 2,N
        GEOP_E(K) = GEOP_E(K-1)*FACTOR
    ENDDO
!        FORALL (K=2:N) GEOP_E(K) = GEOP_E(K-1)*FACTOR
    ELSE
    DO K = 2,NPAR2_GEOP
        GEOP_E(K) = GEOP_E(K-1)*FACTOR
    ENDDO
!        FORALL (K=2:NPAR2_GEOP) GEOP_E(K) = GEOP_E(K-1)*FACTOR
        TEMP = FACTOR**NPAR2_GEOP
        K = NPAR2_GEOP
        DO
            IF (K >= N) EXIT
            K2 = K+K
            GEOP_E(K+1:MIN(K2,N)) = TEMP*GEOP_E(1:MIN(K,N-K))
            TEMP = TEMP*TEMP
            K = K2
        ENDDO
    ENDIF
    END FUNCTION GEOP_E
!
!
    FUNCTION GEOP_Q(FIRST,FACTOR,N)
    REAL(QP), INTENT(IN)                                            ::  FIRST, FACTOR
    INTEGER(I4B), INTENT(IN)                                        ::  N
    REAL(QP), DIMENSION(N)                                          ::  GEOP_Q
    INTEGER(I4B)                                                    ::  K, K2
    REAL(QP)                                                        ::  TEMP
!
    IF (N > 0) GEOP_Q(1) = FIRST
    IF (N <= NPAR_GEOP) THEN
    DO K = 2,N
        GEOP_Q(K) = GEOP_Q(K-1)*FACTOR
    ENDDO
!        FORALL (K=2:N) GEOP_Q(K) = GEOP_Q(K-1)*FACTOR
    ELSE
    DO K = 2,NPAR2_GEOP
        GEOP_Q(K) = GEOP_Q(K-1)*FACTOR
    ENDDO
!        FORALL (K=2:NPAR2_GEOP) GEOP_Q(K) = GEOP_Q(K-1)*FACTOR
        TEMP = FACTOR**NPAR2_GEOP
        K = NPAR2_GEOP
        DO
            IF (K >= N) EXIT
            K2 = K+K
            GEOP_Q(K+1:MIN(K2,N)) = TEMP*GEOP_Q(1:MIN(K,N-K))
            TEMP = TEMP*TEMP
            K = K2
        ENDDO
    ENDIF
    END FUNCTION GEOP_Q
!
!
    FUNCTION GEOP_I(FIRST,FACTOR,N)
    INTEGER(I4B), INTENT(IN)                                        ::  FIRST, FACTOR, N
    INTEGER(I4B), DIMENSION(N)                                      ::  GEOP_I
    INTEGER(I4B)                                                    ::  K, K2, TEMP
!
    IF (N > 0) GEOP_I(1) = FIRST
    IF (N <= NPAR_GEOP) THEN
    DO K = 2,N
        GEOP_I(K) = GEOP_I(K-1)*FACTOR
    ENDDO
!        FORALL (K=2:N) GEOP_I(K) = GEOP_I(K-1)*FACTOR
    ELSE
    DO K = 2,NPAR2_GEOP
        GEOP_I(K) = GEOP_I(K-1)*FACTOR
    ENDDO
!        FORALL (K=2:NPAR2_GEOP) GEOP_I(K) = GEOP_I(K-1)*FACTOR
        TEMP = FACTOR**NPAR2_GEOP
        K = NPAR2_GEOP
        DO
            IF (K >= N) EXIT
            K2 = K+K
            GEOP_I(K+1:MIN(K2,N)) = TEMP*GEOP_I(1:MIN(K,N-K))
            TEMP = TEMP*TEMP
            K = K2
        ENDDO
    ENDIF
    END FUNCTION GEOP_I
!
!
    FUNCTION GEOP_C(FIRST,FACTOR,N)
    COMPLEX(SPC), INTENT(IN)                                        ::  FIRST, FACTOR
    INTEGER(I4B), INTENT(IN)                                        ::  N
    COMPLEX(SPC), DIMENSION(N)                                      ::  GEOP_C
    INTEGER(I4B)                                                    ::  K, K2
    COMPLEX(SPC)                                                    ::  TEMP
!
    IF (N > 0) GEOP_C(1) = FIRST
    IF (N <= NPAR_GEOP) THEN
    DO K = 2,N
        GEOP_C(K) = GEOP_C(K-1)*FACTOR
    ENDDO
!        FORALL (K=2:N) GEOP_C(K) = GEOP_C(K-1)*FACTOR
    ELSE
    DO K = 2,NPAR2_GEOP
        GEOP_C(K)=GEOP_C(K-1)*FACTOR
    ENDDO
!        FORALL (K=2:NPAR2_GEOP) GEOP_C(K)=GEOP_C(K-1)*FACTOR
        TEMP = FACTOR**NPAR2_GEOP
        K = NPAR2_GEOP
        DO
            IF (K >= N) EXIT
            K2 = K+K
            GEOP_C(K+1:MIN(K2,N)) = TEMP*GEOP_C(1:MIN(K,N-K))
            TEMP = TEMP*TEMP
            K = K2
        ENDDO
    ENDIF
    END FUNCTION GEOP_C
!
!
    FUNCTION GEOP_DV(FIRST,FACTOR,N)
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  FIRST, FACTOR
    INTEGER(I4B), INTENT(IN)                                        ::  N
    REAL(DP), DIMENSION(SIZE(FIRST),N)                              ::  GEOP_DV
    INTEGER(I4B)                                                    ::  K, K2
    REAL(DP), DIMENSION(SIZE(FIRST))                                ::  TEMP
!
    IF (N > 0) GEOP_DV(:,1) = FIRST(:)
    IF (N <= NPAR_GEOP) THEN
    DO K = 2,N
        GEOP_DV(:,K) = GEOP_DV(:,K-1)*FACTOR(:)
    ENDDO
!        FORALL (K=2:N) GEOP_DV(:,K) = GEOP_DV(:,K-1)*FACTOR(:)
    ELSE
    DO K = 2,NPAR2_GEOP
        GEOP_DV(:,K) = GEOP_DV(:,K-1)*FACTOR(:)
    ENDDO
!        FORALL (K=2:NPAR2_GEOP) GEOP_DV(:,K) = GEOP_DV(:,K-1)*FACTOR(:)
        TEMP = FACTOR**NPAR2_GEOP
        K = NPAR2_GEOP
        DO
            IF (K >= N) EXIT
            K2 = K+K
            GEOP_DV(:,K+1:MIN(K2,N)) = GEOP_DV(:,1:MIN(K,N-K)) * SPREAD(TEMP,2,SIZE(GEOP_DV(:,1:MIN(K,N-K)),2))
            TEMP = TEMP*TEMP
            K = K2
        ENDDO
    ENDIF
    END FUNCTION GEOP_DV
!
!
    FUNCTION GEOP_EV(FIRST,FACTOR,N)
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  FIRST, FACTOR
    INTEGER(I4B), INTENT(IN)                                        ::  N
    REAL(EP), DIMENSION(SIZE(FIRST),N)                              ::  GEOP_EV
    INTEGER(I4B)                                                    ::  K, K2
    REAL(EP), DIMENSION(SIZE(FIRST))                                ::  TEMP
!
    IF (N > 0) GEOP_EV(:,1) = FIRST(:)
    IF (N <= NPAR_GEOP) THEN
    DO K = 2,N
        GEOP_EV(:,K) = GEOP_EV(:,K-1)*FACTOR(:)
    ENDDO
!        FORALL (K=2:N) GEOP_EV(:,K) = GEOP_EV(:,K-1)*FACTOR(:)
    ELSE
    DO K = 2,NPAR2_GEOP
        GEOP_EV(:,K) = GEOP_EV(:,K-1)*FACTOR(:)
    ENDDO
!        FORALL (K=2:NPAR2_GEOP) GEOP_EV(:,K) = GEOP_EV(:,K-1)*FACTOR(:)
        TEMP = FACTOR**NPAR2_GEOP
        K = NPAR2_GEOP
        DO
            IF (K >= N) EXIT
            K2 = K+K
            GEOP_EV(:,K+1:MIN(K2,N)) = GEOP_EV(:,1:MIN(K,N-K)) * SPREAD(TEMP,2,SIZE(GEOP_EV(:,1:MIN(K,N-K)),2))
            TEMP = TEMP*TEMP
            K = K2
        ENDDO
    ENDIF
    END FUNCTION GEOP_EV
!
!
    FUNCTION GEOP_QV(FIRST,FACTOR,N)
    REAL(QP), DIMENSION(:), INTENT(IN)                              ::  FIRST, FACTOR
    INTEGER(I4B), INTENT(IN)                                        ::  N
    REAL(QP), DIMENSION(SIZE(FIRST),N)                              ::  GEOP_QV
    INTEGER(I4B)                                                    ::  K, K2
    REAL(QP), DIMENSION(SIZE(FIRST))                                ::  TEMP
!
    IF (N > 0) GEOP_QV(:,1) = FIRST(:)
    IF (N <= NPAR_GEOP) THEN
    DO K = 2,N
        GEOP_QV(:,K) = GEOP_QV(:,K-1)*FACTOR(:)
    ENDDO
!        FORALL (K=2:N) GEOP_QV(:,K) = GEOP_QV(:,K-1)*FACTOR(:)
    ELSE
    DO K = 2,NPAR2_GEOP
        GEOP_QV(:,K) = GEOP_QV(:,K-1)*FACTOR(:)
    ENDDO
!        FORALL (K=2:NPAR2_GEOP) GEOP_QV(:,K) = GEOP_QV(:,K-1)*FACTOR(:)
        TEMP = FACTOR**NPAR2_GEOP
        K = NPAR2_GEOP
        DO
            IF (K >= N) EXIT
            K2 = K+K
            GEOP_QV(:,K+1:MIN(K2,N)) = GEOP_QV(:,1:MIN(K,N-K)) * SPREAD(TEMP,2,SIZE(GEOP_QV(:,1:MIN(K,N-K)),2))
            TEMP = TEMP*TEMP
            K = K2
        ENDDO
    ENDIF
    END FUNCTION GEOP_QV
!
!
    RECURSIVE FUNCTION CUMSUM_R(ARR,SEED) RESULT(ANS)
!...CUMMULATIVE SUM ON AN ARRAY WITH OPTIONAL ADDITIVE SEED
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  ARR
    REAL(SP), OPTIONAL, INTENT(IN)                                  ::  SEED
    REAL(SP), DIMENSION(SIZE(ARR))                                  ::  ANS
    INTEGER(I4B)                                                    ::  N, J
    REAL(SP)                                                        ::  SD
!
    N = SIZE(ARR)
    IF (N == 0_I4B) RETURN
    SD = ZERO_S
    IF (PRESENT(SEED)) SD=SEED
    ANS(1) = ARR(1)+SD
    IF (N < NPAR_CUMSUM) THEN
    DO J = 2,N
        ANS(J) = ANS(J-1)+ARR(J)
    ENDDO
!        FORALL (J=2:N) ANS(J) = ANS(J-1)+ARR(J)
    ELSE
        ANS(2:N:2) = CUMSUM_R(ARR(2:N:2)+ARR(1:N-1:2),SD)
        ANS(3:N:2) = ANS(2:N-1:2)+ARR(3:N:2)
    ENDIF
    END FUNCTION CUMSUM_R
!
!
    RECURSIVE FUNCTION CUMSUM_D(ARR,SEED) RESULT(ANS)
!...CUMMULATIVE SUM ON AN ARRAY WITH OPTIONAL ADDITIVE SEED
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  ARR
    REAL(DP), OPTIONAL, INTENT(IN)                                  ::  SEED
    REAL(DP), DIMENSION(SIZE(ARR))                                  ::  ANS
    INTEGER(I4B)                                                    ::  N, J
    REAL(DP)                                                        ::  SD
!
    N = SIZE(ARR)
    IF (N == 0_I4B) RETURN
    SD = ZERO_S
    IF (PRESENT(SEED)) SD=SEED
    ANS(1) = ARR(1)+SD
    IF (N < NPAR_CUMSUM) THEN
    DO J = 2,N
        ANS(J) = ANS(J-1)+ARR(J)
    ENDDO
!        FORALL (J=2:N) ANS(J) = ANS(J-1)+ARR(J)
    ELSE
        ANS(2:N:2) = CUMSUM_D(ARR(2:N:2)+ARR(1:N-1:2),SD)
        ANS(3:N:2) = ANS(2:N-1:2)+ARR(3:N:2)
    ENDIF
    END FUNCTION CUMSUM_D
!
!
    RECURSIVE FUNCTION CUMSUM_E(ARR,SEED) RESULT(ANS)
!...CUMMULATIVE SUM ON AN ARRAY WITH OPTIONAL ADDITIVE SEED
    REAL(EP), DIMENSION(:), INTENT(IN)                              ::  ARR
    REAL(EP), OPTIONAL, INTENT(IN)                                  ::  SEED
    REAL(EP), DIMENSION(SIZE(ARR))                                  ::  ANS
    INTEGER(I4B)                                                    ::  N, J
    REAL(EP)                                                        ::  SD
!
    N = SIZE(ARR)
    IF (N == 0_I4B) RETURN
    SD = ZERO_S
    IF (PRESENT(SEED)) SD=SEED
    ANS(1) = ARR(1)+SD
    IF (N < NPAR_CUMSUM) THEN
    DO J = 2,N
        ANS(J) = ANS(J-1)+ARR(J)
    ENDDO
!        FORALL (J=2:N) ANS(J) = ANS(J-1)+ARR(J)
    ELSE
        ANS(2:N:2) = CUMSUM_E(ARR(2:N:2)+ARR(1:N-1:2),SD)
        ANS(3:N:2) = ANS(2:N-1:2)+ARR(3:N:2)
    ENDIF
    END FUNCTION CUMSUM_E
!
!
    RECURSIVE FUNCTION CUMSUM_Q(ARR,SEED) RESULT(ANS)
!...CUMMULATIVE SUM ON AN ARRAY WITH OPTIONAL ADDITIVE SEED
    REAL(QP), DIMENSION(:), INTENT(IN)                              ::  ARR
    REAL(QP), OPTIONAL, INTENT(IN)                                  ::  SEED
    REAL(QP), DIMENSION(SIZE(ARR))                                  ::  ANS
    INTEGER(I4B)                                                    ::  N, J
    REAL(QP)                                                        ::  SD
!
    N = SIZE(ARR)
    IF (N == 0_I4B) RETURN
    SD = ZERO_S
    IF (PRESENT(SEED)) SD=SEED
    ANS(1) = ARR(1)+SD
    IF (N < NPAR_CUMSUM) THEN
    DO J = 2,N
        ANS(J) = ANS(J-1)+ARR(J)
    ENDDO
!        FORALL (J=2:N) ANS(J) = ANS(J-1)+ARR(J)
    ELSE
        ANS(2:N:2) = CUMSUM_Q(ARR(2:N:2)+ARR(1:N-1:2),SD)
        ANS(3:N:2) = ANS(2:N-1:2)+ARR(3:N:2)
    ENDIF
    END FUNCTION CUMSUM_Q
!
!
    RECURSIVE FUNCTION CUMSUM_I(ARR,SEED) RESULT(ANS)
    INTEGER(I4B), DIMENSION(:), INTENT(IN)                          ::  ARR
    INTEGER(I4B), OPTIONAL, INTENT(IN)                              ::  SEED
    INTEGER(I4B), DIMENSION(SIZE(ARR))                              ::  ANS
    INTEGER(I4B)                                                    ::  N, J, SD
!
    N = SIZE(ARR)
    IF (N == 0_I4B) RETURN
    SD = 0_I4B
    IF (PRESENT(SEED)) SD=SEED
    ANS(1) = ARR(1)+SD
    IF (N < NPAR_CUMSUM) THEN
    DO J = 2,N
        ANS(J) = ANS(J-1)+ARR(J)
    ENDDO
!        FORALL (J=2:N) ANS(J) = ANS(J-1)+ARR(J)
    ELSE
        ANS(2:N:2) = CUMSUM_I(ARR(2:N:2)+ARR(1:N-1:2),SD)
        ANS(3:N:2) = ANS(2:N-1:2)+ARR(3:N:2)
    ENDIF
    END FUNCTION CUMSUM_I
!
!
    RECURSIVE FUNCTION CUMPROD_R(ARR,SEED) RESULT(ANS)
!...CUMMULATIVE PRODUCT ON AN ARRAY WITH OPTIONAL MULITPLICATIVE SEED
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  ARR
    REAL(SP), OPTIONAL, INTENT(IN)                                  ::  SEED
    REAL(SP), DIMENSION(SIZE(ARR))                                  ::  ANS
    INTEGER(I4B)                                                    ::  N, J
    REAL(SP)                                                        ::  SD
!
    N = SIZE(ARR)
    IF (N == 0_I4B) RETURN
    SD = ONE_S
    IF (PRESENT(SEED)) SD=SEED
    ANS(1) = ARR(1)*SD
    IF (N < NPAR_CUMPROD) THEN
    DO J = 2,N
        ANS(J) = ANS(J-1)*ARR(J)
    ENDDO
!        FORALL (J=2:N) ANS(J) = ANS(J-1)*ARR(J)
    ELSE
        ANS(2:N:2) = CUMPROD_R(ARR(2:N:2)*ARR(1:N-1:2),SD)
        ANS(3:N:2) = ANS(2:N-1:2)*ARR(3:N:2)
    ENDIF
    END FUNCTION CUMPROD_R
!
!
    RECURSIVE FUNCTION CUMPROD_D(ARR,SEED) RESULT(ANS)
!...CUMMULATIVE PRODUCT ON AN ARRAY WITH OPTIONAL MULITPLICATIVE SEED
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  ARR
    REAL(DP), OPTIONAL, INTENT(IN)                                  ::  SEED
    REAL(DP), DIMENSION(SIZE(ARR))                                  ::  ANS
    INTEGER(I4B)                                                    ::  N, J
    REAL(DP)                                                        ::  SD
!
    N = SIZE(ARR)
    IF (N == 0_I4B) RETURN
    SD = ONE_D
    IF (PRESENT(SEED)) SD=SEED
    ANS(1) = ARR(1)*SD
    IF (N < NPAR_CUMPROD) THEN
    DO J = 2,N
        ANS(J) = ANS(J-1)*ARR(J)
    ENDDO
!        FORALL (J=2:N) ANS(J) = ANS(J-1)*ARR(J)
    ELSE
        ANS(2:N:2) = CUMPROD_D(ARR(2:N:2)*ARR(1:N-1:2),SD)
        ANS(3:N:2) = ANS(2:N-1:2)*ARR(3:N:2)
    ENDIF
    END FUNCTION CUMPROD_D
!
!
    RECURSIVE FUNCTION CUMPROD_E(ARR,SEED) RESULT(ANS)
!...CUMMULATIVE PRODUCT ON AN ARRAY WITH OPTIONAL MULITPLICATIVE SEED
    REAL(EP), DIMENSION(:), INTENT(IN)                              ::  ARR
    REAL(EP), OPTIONAL, INTENT(IN)                                  ::  SEED
    REAL(EP), DIMENSION(SIZE(ARR))                                  ::  ANS
    INTEGER(I4B)                                                    ::  N, J
    REAL(EP)                                                        ::  SD
!
    N = SIZE(ARR)
    IF (N == 0_I4B) RETURN
    SD = ONE_E
    IF (PRESENT(SEED)) SD=SEED
    ANS(1) = ARR(1)*SD
    IF (N < NPAR_CUMPROD) THEN
    DO J = 2,N
        ANS(J) = ANS(J-1)*ARR(J)
    ENDDO
!        FORALL (J=2:N) ANS(J) = ANS(J-1)*ARR(J)
    ELSE
        ANS(2:N:2) = CUMPROD_E(ARR(2:N:2)*ARR(1:N-1:2),SD)
        ANS(3:N:2) = ANS(2:N-1:2)*ARR(3:N:2)
    ENDIF
    END FUNCTION CUMPROD_E
!
!
    RECURSIVE FUNCTION CUMPROD_Q(ARR,SEED) RESULT(ANS)
!...CUMMULATIVE PRODUCT ON AN ARRAY WITH OPTIONAL MULITPLICATIVE SEED
    REAL(QP), DIMENSION(:), INTENT(IN)                              ::  ARR
    REAL(QP), OPTIONAL, INTENT(IN)                                  ::  SEED
    REAL(QP), DIMENSION(SIZE(ARR))                                  ::  ANS
    INTEGER(I4B)                                                    ::  N, J
    REAL(QP)                                                        ::  SD
!
    N = SIZE(ARR)
    IF (N == 0_I4B) RETURN
    SD = ONE_Q
    IF (PRESENT(SEED)) SD=SEED
    ANS(1) = ARR(1)*SD
    IF (N < NPAR_CUMPROD) THEN
    DO J = 2,N
        ANS(J) = ANS(J-1)*ARR(J)
    ENDDO
!        FORALL (J=2:N) ANS(J) = ANS(J-1)*ARR(J)
    ELSE
        ANS(2:N:2) = CUMPROD_Q(ARR(2:N:2)*ARR(1:N-1:2),SD)
        ANS(3:N:2) = ANS(2:N-1:2)*ARR(3:N:2)
    ENDIF
    END FUNCTION CUMPROD_Q
!
!
    PURE FUNCTION POLY_RR(X,COEFFS)
!...POLYNOMIAL EVALUATION
    REAL(SP), INTENT(IN)                                            ::  X
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  COEFFS
    REAL(SP)                                                        ::  POLY_RR
    REAL(SP)                                                        ::  POW
    REAL(SP), DIMENSION(:), ALLOCATABLE                             ::  VEC
    INTEGER(I4B)                                                    ::  I, N, NN
!
    N = SIZE(COEFFS)
    IF (N <= 0) THEN
        POLY_RR = ZERO_S
    ELSEIF (N < NPAR_POLY) THEN
        POLY_RR = COEFFS(N)
        DO I = N-1,1,-1
            POLY_RR = X*POLY_RR+COEFFS(I)
        ENDDO
    ELSE
        ALLOCATE(VEC(N+1))
        POW = X
        VEC(1:N) = COEFFS
        DO
            VEC(N+1) = ZERO_S
            NN = ISHFT(N+1,-1)
            VEC(1:NN) = VEC(1:N:2)+POW*VEC(2:N+1:2)
            IF (NN == 1) EXIT
            POW = POW*POW
            N = NN
        ENDDO
        POLY_RR = VEC(1)
        DEALLOCATE(VEC)
    ENDIF
    END FUNCTION POLY_RR
!
!
    PURE FUNCTION POLY_DD(X,COEFFS)
!...POLYNOMIAL EVALUATION
    REAL(DP), INTENT(IN)                                            ::  X
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  COEFFS
    REAL(DP)                                                        ::  POLY_DD
    REAL(DP)                                                        ::  POW
    REAL(DP), DIMENSION(:), ALLOCATABLE                             ::  VEC
    INTEGER(I4B)                                                    ::  I, N, NN
!
    N = SIZE(COEFFS)
    IF (N <= 0) THEN
        POLY_DD = ZERO_D
    ELSEIF (N < NPAR_POLY) THEN
        POLY_DD = COEFFS(N)
        DO I = N-1,1,-1
            POLY_DD = X*POLY_DD+COEFFS(I)
        ENDDO
    ELSE
        ALLOCATE(VEC(N+1))
        POW = X
        VEC(1:N) = COEFFS
        DO
            VEC(N+1) = ZERO_D
            NN = ISHFT(N+1,-1)
            VEC(1:NN) = VEC(1:N:2)+POW*VEC(2:N+1:2)
            IF (NN == 1) EXIT
            POW = POW*POW
            N = NN
        ENDDO
        POLY_DD = VEC(1)
        DEALLOCATE(VEC)
    ENDIF
    END FUNCTION POLY_DD
!
!
    PURE FUNCTION POLY_EE(X,COEFFS)
!...POLYNOMIAL EVALUATION
    REAL(EP), INTENT(IN)                                            ::  X
    REAL(EP), DIMENSION(:), INTENT(IN)                              ::  COEFFS
    REAL(EP)                                                        ::  POLY_EE
    REAL(EP)                                                        ::  POW
    REAL(EP), DIMENSION(:), ALLOCATABLE                             ::  VEC
    INTEGER(I4B)                                                    ::  I, N, NN
!
    N = SIZE(COEFFS)
    IF (N <= 0) THEN
        POLY_EE = ZERO_E
    ELSEIF (N < NPAR_POLY) THEN
        POLY_EE = COEFFS(N)
        DO I = N-1,1,-1
            POLY_EE = X*POLY_EE+COEFFS(I)
        ENDDO
    ELSE
        ALLOCATE(VEC(N+1))
        POW = X
        VEC(1:N) = COEFFS
        DO
            VEC(N+1) = ZERO_E
            NN = ISHFT(N+1,-1)
            VEC(1:NN) = VEC(1:N:2)+POW*VEC(2:N+1:2)
            IF (NN == 1) EXIT
            POW = POW*POW
            N = NN
        ENDDO
        POLY_EE = VEC(1)
        DEALLOCATE(VEC)
    ENDIF
    END FUNCTION POLY_EE
!
!
    PURE FUNCTION POLY_QQ(X,COEFFS)
!...POLYNOMIAL EVALUATION
    REAL(QP), INTENT(IN)                                            ::  X
    REAL(QP), DIMENSION(:), INTENT(IN)                              ::  COEFFS
    REAL(QP)                                                        ::  POLY_QQ
    REAL(QP)                                                        ::  POW
    REAL(QP), DIMENSION(:), ALLOCATABLE                             ::  VEC
    INTEGER(I4B)                                                    ::  I, N, NN
!
    N = SIZE(COEFFS)
    IF (N <= 0) THEN
        POLY_QQ = ZERO_Q
    ELSEIF (N < NPAR_POLY) THEN
        POLY_QQ = COEFFS(N)
        DO I = N-1,1,-1
            POLY_QQ = X*POLY_QQ+COEFFS(I)
        ENDDO
    ELSE
        ALLOCATE(VEC(N+1))
        POW = X
        VEC(1:N) = COEFFS
        DO
            VEC(N+1) = ZERO_Q
            NN = ISHFT(N+1,-1)
            VEC(1:NN) = VEC(1:N:2)+POW*VEC(2:N+1:2)
            IF (NN == 1) EXIT
            POW = POW*POW
            N = NN
        ENDDO
        POLY_QQ = VEC(1)
        DEALLOCATE(VEC)
    ENDIF
    END FUNCTION POLY_QQ
!
!
    FUNCTION POLY_RC(X,COEFFS)
!...POLYNOMIAL EVALUATION
    COMPLEX(SPC), INTENT(IN)                                        ::  X
    REAL(SPC), DIMENSION(:), INTENT(IN)                             ::  COEFFS
    COMPLEX(SPC)                                                    ::  POLY_RC
    COMPLEX(SPC)                                                    ::  POW
    COMPLEX(SPC), DIMENSION(:), ALLOCATABLE                         ::  VEC
    INTEGER(I4B)                                                    ::  I, N, NN
!
    N = SIZE(COEFFS)
    IF (N <= 0) THEN
        POLY_RC = ZERO_S
    ELSEIF (N < NPAR_POLY) THEN
        POLY_RC = COEFFS(N)
        DO I = N-1,1,-1
            POLY_RC = X*POLY_RC+COEFFS(I)
        ENDDO
    ELSE
        ALLOCATE(VEC(N+1))
        POW = X
        VEC(1:N) = COEFFS
        DO
            VEC(N+1) = ZERO_S
            NN = ISHFT(N+1,-1)
            VEC(1:NN) = VEC(1:N:2)+POW*VEC(2:N+1:2)
            IF (NN == 1) EXIT
            POW = POW*POW
            N = NN
        ENDDO
        POLY_RC = VEC(1)
        DEALLOCATE(VEC)
    ENDIF
    END FUNCTION POLY_RC
!
!
    FUNCTION POLY_CC(X,COEFFS)
    COMPLEX(SPC), INTENT(IN)                                        ::  X
    COMPLEX(SPC), DIMENSION(:), INTENT(IN)                          ::  COEFFS
    COMPLEX(SPC)                                                    ::  POLY_CC
    COMPLEX(SPC)                                                    ::  POW
    COMPLEX(SPC), DIMENSION(:), ALLOCATABLE                         ::  VEC
    INTEGER(I4B)                                                    ::  I, N, NN
!
    N = SIZE(COEFFS)
    IF (N <= 0) THEN
        POLY_CC = ZERO_S
    ELSEIF (N < NPAR_POLY) THEN
        POLY_CC = COEFFS(N)
        DO I = N-1,1,-1
            POLY_CC = X*POLY_CC+COEFFS(I)
        ENDDO
    ELSE
        ALLOCATE(VEC(N+1))
        POW = X
        VEC(1:N) = COEFFS
        DO
            VEC(N+1) = ZERO_S
            NN = ISHFT(N+1,-1)
            VEC(1:NN) = VEC(1:N:2)+POW*VEC(2:N+1:2)
            IF (NN == 1) EXIT
            POW = POW*POW
            N = NN
        ENDDO
        POLY_CC = VEC(1)
        DEALLOCATE(VEC)
    ENDIF
    END FUNCTION POLY_CC
!
!
    FUNCTION POLY_RRV(X,COEFFS)
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  COEFFS, X
    REAL(SP), DIMENSION(SIZE(X))                                    ::  POLY_RRV
    INTEGER(I4B)                                                    ::  I, N, M
!
    M = SIZE(COEFFS)
    N = SIZE(X)
    IF (M <= 0) THEN
        POLY_RRV = ZERO_S
    ELSEIF (M < N .OR. M < NPAR_POLY) THEN
        POLY_RRV = COEFFS(M)
    DO I = M-1,1,-1
        POLY_RRV = X*POLY_RRV+COEFFS(I)
    ENDDO
!        FORALL (I=M-1:1:-1) POLY_RRV =X *POLY_RRV+COEFFS(I)
    ELSE
    DO I = 1,N
        POLY_RRV(I) = POLY_RR(X(I),COEFFS)
    ENDDO
!        FORALL (I=1:N) POLY_RRV(I) = POLY_RR(X(I),COEFFS)
    ENDIF
    END FUNCTION POLY_RRV
!
!
    FUNCTION POLY_DDV(X,COEFFS)
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  COEFFS, X
    REAL(DP), DIMENSION(SIZE(X))                                    ::  POLY_DDV
    INTEGER(I4B)                                                    ::  I, N, M
!
    M = SIZE(COEFFS)
    N = SIZE(X)
    IF (M <= 0) THEN
        POLY_DDV = ZERO_D
    ELSEIF (M < N .OR. M < NPAR_POLY) THEN
        POLY_DDV = COEFFS(M)
    DO I = M-1,1,-1
        POLY_DDV = X*POLY_DDV+COEFFS(I)
    ENDDO
!        FORALL (I=M-1:1:-1) POLY_DDV = X*POLY_DDV+COEFFS(I)
    ELSE
    DO I = 1,N
        POLY_DDV(I) = POLY_DD(X(I),COEFFS)
    ENDDO
!        FORALL (I=1:N) POLY_DDV(I) = POLY_DD(X(I),COEFFS)
    ENDIF
    END FUNCTION POLY_DDV
!
!
    FUNCTION POLY_EEV(X,COEFFS)
    REAL(EP), DIMENSION(:), INTENT(IN)                              ::  COEFFS, X
    REAL(EP), DIMENSION(SIZE(X))                                    ::  POLY_EEV
    INTEGER(I4B)                                                    ::  I, N, M
!
    M = SIZE(COEFFS)
    N = SIZE(X)
    IF (M <= 0) THEN
        POLY_EEV = ZERO_E
    ELSEIF (M < N .OR. M < NPAR_POLY) THEN
        POLY_EEV = COEFFS(M)
    DO I = M-1,1,-1
        POLY_EEV = X*POLY_EEV+COEFFS(I)
    ENDDO
!        FORALL (I=M-1:1:-1) POLY_EEV = X*POLY_EEV+COEFFS(I)
    ELSE
    DO I = 1,N
        POLY_EEV(I) = POLY_EE(X(I),COEFFS)
    ENDDO
!        FORALL (I=1:N) POLY_EEV(I) = POLY_EE(X(I),COEFFS)
    ENDIF
    END FUNCTION POLY_EEV
!
!
    FUNCTION POLY_QQV(X,COEFFS)
    REAL(QP), DIMENSION(:), INTENT(IN)                              ::  COEFFS, X
    REAL(QP), DIMENSION(SIZE(X))                                    ::  POLY_QQV
    INTEGER(I4B)                                                    ::  I, N, M
!
    M = SIZE(COEFFS)
    N = SIZE(X)
    IF (M <= 0) THEN
        POLY_QQV = ZERO_Q
    ELSEIF (M < N .OR. M < NPAR_POLY) THEN
        POLY_QQV = COEFFS(M)
    DO I = M-1,1,-1
        POLY_QQV = X*POLY_QQV+COEFFS(I)
    ENDDO
!        FORALL (I=M-1:1:-1) POLY_QQV = X*POLY_QQV+COEFFS(I)
    ELSE
    DO I = 1,N
        POLY_QQV(I) = POLY_QQ(X(I),COEFFS)
    ENDDO
!        FORALL (I=1:N) POLY_QQV(I) = POLY_QQ(X(I),COEFFS)
    ENDIF
    END FUNCTION POLY_QQV
!
!
    FUNCTION POLY_MSK_RRV(X,COEFFS,MASK)
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  COEFFS, X
    LOGICAL(TLG), DIMENSION(:), INTENT(IN)                          ::  MASK
    REAL(SP), DIMENSION(SIZE(X))                                    ::  POLY_MSK_RRV
!
    POLY_MSK_RRV = UNPACK(POLY_RRV(PACK(X,MASK),COEFFS),MASK,ZERO_S)
    END FUNCTION POLY_MSK_RRV
!
!
    FUNCTION POLY_MSK_DDV(X,COEFFS,MASK)
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  COEFFS, X
    LOGICAL(TLG), DIMENSION(:), INTENT(IN)                          ::  MASK
    REAL(DP), DIMENSION(SIZE(X))                                    ::  POLY_MSK_DDV
!
    POLY_MSK_DDV = UNPACK(POLY_DDV(PACK(X,MASK),COEFFS),MASK,ZERO_D)
    END FUNCTION POLY_MSK_DDV
!
!
    FUNCTION POLY_MSK_EEV(X,COEFFS,MASK)
    REAL(EP), DIMENSION(:), INTENT(IN)                              ::  COEFFS, X
    LOGICAL(TLG), DIMENSION(:), INTENT(IN)                          ::  MASK
    REAL(EP), DIMENSION(SIZE(X))                                    ::  POLY_MSK_EEV
!
    POLY_MSK_EEV = UNPACK(POLY_EEV(PACK(X,MASK),COEFFS),MASK,ZERO_E)
    END FUNCTION POLY_MSK_EEV
!
!
    FUNCTION POLY_MSK_QQV(X,COEFFS,MASK)
    REAL(QP), DIMENSION(:), INTENT(IN)                              ::  COEFFS, X
    LOGICAL(TLG), DIMENSION(:), INTENT(IN)                          ::  MASK
    REAL(QP), DIMENSION(SIZE(X))                                    ::  POLY_MSK_QQV
!
    POLY_MSK_QQV = UNPACK(POLY_QQV(PACK(X,MASK),COEFFS),MASK,ZERO_Q)
    END FUNCTION POLY_MSK_QQV
!
!
    PURE FUNCTION POLYW_WW(X,COEFFS)
!...POLYNOMIAL EVALUATION
    REAL(WP), INTENT(IN)                                            ::  X
    REAL(WP), DIMENSION(:), INTENT(IN)                              ::  COEFFS
    REAL(WP)                                                        ::  POLYW_WW
    REAL(WP)                                                        ::  POW
    REAL(WP), DIMENSION(:), ALLOCATABLE                             ::  VEC
    INTEGER(I4B)                                                    ::  I, N, NN
!
    N = SIZE(COEFFS)
    IF (N <= 0) THEN
        POLYW_WW = ZERO_W
    ELSEIF (N < NPAR_POLY) THEN
        POLYW_WW = COEFFS(N)
        DO I = N-1,1,-1
            POLYW_WW = X*POLYW_WW+COEFFS(I)
        ENDDO
    ELSE
        ALLOCATE(VEC(N+1))
        POW = X
        VEC(1:N) = COEFFS
        DO
            VEC(N+1) = ZERO_W
            NN = ISHFT(N+1,-1)
            VEC(1:NN) = VEC(1:N:2)+POW*VEC(2:N+1:2)
            IF (NN == 1) EXIT
            POW = POW*POW
            N = NN
        ENDDO
        POLYW_WW = VEC(1)
        DEALLOCATE(VEC)
    ENDIF
    END FUNCTION POLYW_WW
!
!
    FUNCTION POLYW_WWV(X,COEFFS)
    REAL(WP), DIMENSION(:), INTENT(IN)                              ::  COEFFS, X
    REAL(WP), DIMENSION(SIZE(X))                                    ::  POLYW_WWV
    INTEGER(I4B)                                                    ::  I, N, M
!
    M = SIZE(COEFFS)
    N = SIZE(X)
    IF (M <= 0) THEN
        POLYW_WWV = ZERO_W
    ELSEIF (M < N .OR. M < NPAR_POLY) THEN
        POLYW_WWV = COEFFS(M)
    DO I = M-1,1,-1
        POLYW_WWV = X*POLYW_WWV+COEFFS(I)
    ENDDO
!        FORALL (I=M-1:1:-1) POLY_WWV = X*POLY_WWV+COEFFS(I)
    ELSE
    DO I = 1,N
        POLYW_WWV(I) = POLYW_WW(X(I),COEFFS)
    ENDDO
!        FORALL (I=1:N) POLY_WWV(I) = POLY_WW(X(I),COEFFS)
    ENDIF
    END FUNCTION POLYW_WWV
!
!
    FUNCTION POLYW_MSK_WWV(X,COEFFS,MASK)
    REAL(WP), DIMENSION(:), INTENT(IN)                              ::  COEFFS, X
    LOGICAL(TLG), DIMENSION(:), INTENT(IN)                          ::  MASK
    REAL(WP), DIMENSION(SIZE(X))                                    ::  POLYW_MSK_WWV

    POLYW_MSK_WWV = UNPACK(POLYW_WWV(PACK(X,MASK),COEFFS),MASK,ZERO_W)
    END FUNCTION POLYW_MSK_WWV
!
!
    RECURSIVE FUNCTION POLY_TERM_RR(A,B) RESULT(U)
!...TABULATE CUMULANTS OF A POLYNOMIAL
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  A
    REAL(SP), INTENT(IN)                                            ::  B
    REAL(SP), DIMENSION(SIZE(A))                                    ::  U
    INTEGER(I4B)                                                    ::  N, J
!
    N = SIZE(A)
    IF (N <= 0) RETURN
    U(1) = A(1)
    IF (N < NPAR_POLYTERM) THEN
    DO J = 2,N
        U(J) = A(J)+B*U(J-1)
   ENDDO
!        FORALL (J=2:N) U(J) = A(J)+B*U(J-1)
    ELSE
        U(2:N:2) = POLY_TERM_RR(A(2:N:2) + A(1:N-1:2)*B,B*B)
        U(3:N:2) = A(3:N:2) + B*U(2:N-1:2)
    ENDIF
    END FUNCTION POLY_TERM_RR
!
!
    RECURSIVE FUNCTION POLY_TERM_DD(A,B) RESULT(U)
!...TABULATE CUMULANTS OF A POLYNOMIAL
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  A
    REAL(DP), INTENT(IN)                                            ::  B
    REAL(DP), DIMENSION(SIZE(A))                                    ::  U
    INTEGER(I4B)                                                    ::  N, J
!
    N = SIZE(A)
    IF (N <= 0) RETURN
    U(1) = A(1)
    IF (N < NPAR_POLYTERM) THEN
    DO J = 2,N
        U(J) = A(J)+B*U(J-1)
   ENDDO
!        FORALL (J=2:N) U(J) = A(J)+B*U(J-1)
    ELSE
        U(2:N:2) = POLY_TERM_DD(A(2:N:2) + A(1:N-1:2)*B,B*B)
        U(3:N:2) = A(3:N:2) + B*U(2:N-1:2)
    ENDIF
    END FUNCTION POLY_TERM_DD
!
!
    RECURSIVE FUNCTION POLY_TERM_EE(A,B) RESULT(U)
!...TABULATE CUMULANTS OF A POLYNOMIAL
    REAL(EP), DIMENSION(:), INTENT(IN)                              ::  A
    REAL(EP), INTENT(IN)                                            ::  B
    REAL(EP), DIMENSION(SIZE(A))                                    ::  U
    INTEGER(I4B)                                                    ::  N, J
!
    N = SIZE(A)
    IF (N <= 0) RETURN
    U(1) = A(1)
    IF (N < NPAR_POLYTERM) THEN
    DO J = 2,N
        U(J) = A(J)+B*U(J-1)
   ENDDO
!        FORALL (J=2:N) U(J) = A(J)+B*U(J-1)
    ELSE
        U(2:N:2) = POLY_TERM_EE(A(2:N:2) + A(1:N-1:2)*B,B*B)
        U(3:N:2) = A(3:N:2) + B*U(2:N-1:2)
    ENDIF
    END FUNCTION POLY_TERM_EE
!
!
    RECURSIVE FUNCTION POLY_TERM_QQ(A,B) RESULT(U)
!...TABULATE CUMULANTS OF A POLYNOMIAL
    REAL(QP), DIMENSION(:), INTENT(IN)                              ::  A
    REAL(QP), INTENT(IN)                                            ::  B
    REAL(QP), DIMENSION(SIZE(A))                                    ::  U
    INTEGER(I4B)                                                    ::  N, J
!
    N = SIZE(A)
    IF (N <= 0) RETURN
    U(1) = A(1)
    IF (N < NPAR_POLYTERM) THEN
    DO J = 2,N
        U(J) = A(J)+B*U(J-1)
   ENDDO
!        FORALL (J=2:N) U(J) = A(J)+B*U(J-1)
    ELSE
        U(2:N:2) = POLY_TERM_QQ(A(2:N:2) + A(1:N-1:2)*B,B*B)
        U(3:N:2) = A(3:N:2) + B*U(2:N-1:2)
    ENDIF
    END FUNCTION POLY_TERM_QQ
!
!
    RECURSIVE FUNCTION POLY_TERM_CC(A,B) RESULT(U)
    COMPLEX(SPC), DIMENSION(:), INTENT(IN)                          ::  A
    COMPLEX(SPC), INTENT(IN)                                        ::  B
    COMPLEX(SPC), DIMENSION(SIZE(A))                                ::  U
    INTEGER(I4B)                                                    ::  N, J
!
    N = SIZE(A)
    IF (N <= 0) RETURN
    U(1) = A(1)
    IF (N < NPAR_POLYTERM) THEN
    DO J = 2,N
        U(J) = A(J)+B*U(J-1)
    ENDDO
!        FORALL (J=2:N) U(J) = A(J)+B*U(J-1)
    ELSE
    U(2:N:2) = POLY_TERM_CC(A(2:N:2) + A(1:N-1:2)*B,B*B)
    U(3:N:2) = A(3:N:2) + B*U(2:N-1:2)
    ENDIF
    END FUNCTION POLY_TERM_CC
!
!
    RECURSIVE FUNCTION POLY_TERM_DC(A,B) RESULT(U)
    COMPLEX(DPC), DIMENSION(:), INTENT(IN)                          ::  A
    COMPLEX(DPC), INTENT(IN)                                        ::  B
    COMPLEX(DPC), DIMENSION(SIZE(A))                                ::  U
    INTEGER(I4B)                                                    ::  N, J
!
    N = SIZE(A)
    IF (N <= 0) RETURN
    U(1) = A(1)
    IF (N < NPAR_POLYTERM) THEN
    DO J = 2,N
        U(J) = A(J)+B*U(J-1)
    ENDDO
!        FORALL (J=2:N) U(J) = A(J)+B*U(J-1)
    ELSE
    U(2:N:2) = POLY_TERM_DC(A(2:N:2) + A(1:N-1:2)*B,B*B)
    U(3:N:2) = A(3:N:2) + B*U(2:N-1:2)
    ENDIF
    END FUNCTION POLY_TERM_DC
!
!
    RECURSIVE FUNCTION POLY_TERM_EC(A,B) RESULT(U)
    COMPLEX(EPC), DIMENSION(:), INTENT(IN)                          ::  A
    COMPLEX(EPC), INTENT(IN)                                        ::  B
    COMPLEX(EPC), DIMENSION(SIZE(A))                                ::  U
    INTEGER(I4B)                                                    ::  N, J
!
    N = SIZE(A)
    IF (N <= 0) RETURN
    U(1) = A(1)
    IF (N < NPAR_POLYTERM) THEN
    DO J = 2,N
        U(J) = A(J)+B*U(J-1)
    ENDDO
!        FORALL (J=2:N) U(J) = A(J)+B*U(J-1)
    ELSE
    U(2:N:2) = POLY_TERM_EC(A(2:N:2) + A(1:N-1:2)*B,B*B)
    U(3:N:2) = A(3:N:2) + B*U(2:N-1:2)
    ENDIF
    END FUNCTION POLY_TERM_EC
!
!
    RECURSIVE FUNCTION POLY_TERM_QC(A,B) RESULT(U)
    COMPLEX(QPC), DIMENSION(:), INTENT(IN)                          ::  A
    COMPLEX(QPC), INTENT(IN)                                        ::  B
    COMPLEX(QPC), DIMENSION(SIZE(A))                                ::  U
    INTEGER(I4B)                                                    ::  N, J
!
    N = SIZE(A)
    IF (N <= 0) RETURN
    U(1) = A(1)
    IF (N < NPAR_POLYTERM) THEN
    DO J = 2,N
        U(J) = A(J)+B*U(J-1)
    ENDDO
!        FORALL (J=2:N) U(J) = A(J)+B*U(J-1)
    ELSE
    U(2:N:2) = POLY_TERM_QC(A(2:N:2) + A(1:N-1:2)*B,B*B)
    U(3:N:2) = A(3:N:2) + B*U(2:N-1:2)
    ENDIF
    END FUNCTION POLY_TERM_QC
!
!
    FUNCTION ZROOTS_UNITY_R(N,NN)
!...COMPLEX FUNCTION RETURNING NN POWERS OF THE NTH ROOT OF UNITY
    INTEGER(I4B), INTENT(IN)                                        ::  N, NN
    COMPLEX(SPC), DIMENSION(NN)                                     ::  ZROOTS_UNITY_R
    INTEGER(I4B)                                                    ::  K
    REAL(SP)                                                        ::  THETA
!
    ZROOTS_UNITY_R(1) = ONE_S
    THETA = TWOPI_S/N
    K = 1_I4B
    DO
        IF (K >= NN) EXIT
        ZROOTS_UNITY_R(K+1) = CMPLX(COS(K*THETA),SIN(K*THETA),SPC)
        ZROOTS_UNITY_R(K+2:MIN(2*K,NN)) = ZROOTS_UNITY_R(K+1) * ZROOTS_UNITY_R(2:MIN(K,NN-K))
        K = 2*K
    ENDDO
    END FUNCTION ZROOTS_UNITY_R
!
!
    FUNCTION ZROOTS_UNITY_D(N,NN)
!...COMPLEX FUNCTION RETURNING NN POWERS OF THE NTH ROOT OF UNITY
    INTEGER(I4B), INTENT(IN)                                        ::  N, NN
    COMPLEX(DPC), DIMENSION(NN)                                     ::  ZROOTS_UNITY_D
    INTEGER(I4B)                                                    ::  K
    REAL(DP)                                                        ::  THETA
!
    ZROOTS_UNITY_D(1) = ONE_D
    THETA = TWOPI_D/N
    K = 1_I4B
    DO
        IF (K >= NN) EXIT
        ZROOTS_UNITY_D(K+1) = CMPLX(COS(K*THETA),SIN(K*THETA),DPC)
        ZROOTS_UNITY_D(K+2:MIN(2*K,NN)) = ZROOTS_UNITY_D(K+1) * ZROOTS_UNITY_D(2:MIN(K,NN-K))
        K = 2*K
    ENDDO
    END FUNCTION ZROOTS_UNITY_D
!
!
!    FUNCTION ZROOTS_UNITY_E(N,NN)
!!...COMPLEX FUNCTION RETURNING NN POWERS OF THE NTH ROOT OF UNITY
!    INTEGER(I4B), INTENT(IN)                                        ::  N, NN
!    COMPLEX(EPC), DIMENSION(NN)                                     ::  ZROOTS_UNITY_E
!    INTEGER(I4B)                                                    ::  K
!    REAL(EP)                                                        ::  THETA
!!
!    ZROOTS_UNITY_E(1) = ONE_E
!    THETA = TWOPI_E/N
!    K = 1_I4B
!    DO
!        IF (K >= NN) EXIT
!        ZROOTS_UNITY_E(K+1) = CMPLX(COS(K*THETA),SIN(K*THETA),EPC)
!        ZROOTS_UNITY_E(K+2:MIN(2*K,NN)) = ZROOTS_UNITY_E(K+1) * ZROOTS_UNITY_E(2:MIN(K,NN-K))
!        K = 2*K
!    ENDDO
!    END FUNCTION ZROOTS_UNITY_E
!!
!!
!    FUNCTION ZROOTS_UNITY_Q(N,NN)
!!...COMPLEX FUNCTION RETURNING NN POWERS OF THE NTH ROOT OF UNITY
!    INTEGER(I4B), INTENT(IN)                                        ::  N, NN
!    COMPLEX(QPC), DIMENSION(NN)                                     ::  ZROOTS_UNITY_Q
!    INTEGER(I4B)                                                    ::  K
!    REAL(QP)                                                        ::  THETA
!!
!    ZROOTS_UNITY_Q(1) = ONE_Q
!    THETA = TWOPI_Q/N
!    K = 1_I4B
!    DO
!        IF (K >= NN) EXIT
!        ZROOTS_UNITY_Q(K+1) = CMPLX(COS(K*THETA),SIN(K*THETA),QPC)
!        ZROOTS_UNITY_Q(K+2:MIN(2*K,NN)) = ZROOTS_UNITY_Q(K+1) * ZROOTS_UNITY_Q(2:MIN(K,NN-K))
!        K = 2*K
!    ENDDO
!    END FUNCTION ZROOTS_UNITY_Q
!
!
!...
!...ROUTINES FOR "OUTER" OPERATIONS ON VECTORS.  THE ORDER CONVENTION IS: RESULT(I,J)=FIRST_OPERAND(I)
!...(OP) SECOND_OPERAND(J)
    FUNCTION OUTERPROD_R(A,B)
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  A,B
    REAL(SP), DIMENSION(SIZE(A),SIZE(B))                            ::  OUTERPROD_R
!
    OUTERPROD_R = SPREAD(A,DIM=2,NCOPIES=SIZE(B)) * SPREAD(B,DIM=1,NCOPIES=SIZE(A))
    END FUNCTION OUTERPROD_R
!
!
    FUNCTION OUTERPROD_D(A,B)
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  A,B
    REAL(DP), DIMENSION(SIZE(A),SIZE(B))                            ::  OUTERPROD_D
!
    OUTERPROD_D = SPREAD(A,DIM=2,NCOPIES=SIZE(B)) * SPREAD(B,DIM=1,NCOPIES=SIZE(A))
    END FUNCTION OUTERPROD_D
!
!
    FUNCTION OUTERPROD_E(A,B)
    REAL(EP), DIMENSION(:), INTENT(IN)                              ::  A,B
    REAL(EP), DIMENSION(SIZE(A),SIZE(B))                            ::  OUTERPROD_E
!
    OUTERPROD_E = SPREAD(A,DIM=2,NCOPIES=SIZE(B)) * SPREAD(B,DIM=1,NCOPIES=SIZE(A))
    END FUNCTION OUTERPROD_E
!
!
    FUNCTION OUTERPROD_Q(A,B)
    REAL(QP), DIMENSION(:), INTENT(IN)                              ::  A,B
    REAL(QP), DIMENSION(SIZE(A),SIZE(B))                            ::  OUTERPROD_Q
!
    OUTERPROD_Q = SPREAD(A,DIM=2,NCOPIES=SIZE(B)) * SPREAD(B,DIM=1,NCOPIES=SIZE(A))
    END FUNCTION OUTERPROD_Q
!
!
    FUNCTION OUTERDIV(A,B)
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  A,B
    REAL(SP), DIMENSION(SIZE(A),SIZE(B))                            ::  OUTERDIV
!
OUTERDIV = SPREAD(A,DIM=2,NCOPIES=SIZE(B)) / SPREAD(B,DIM=1,NCOPIES=SIZE(A))
END FUNCTION OUTERDIV
!
!
    FUNCTION OUTERSUM(A,B)
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  A, B
    REAL(SP), DIMENSION(SIZE(A),SIZE(B))                            ::  OUTERSUM
!
    OUTERSUM = SPREAD(A,DIM=2,NCOPIES=SIZE(B)) + SPREAD(B,DIM=1,NCOPIES=SIZE(A))
    END FUNCTION OUTERSUM
!
!
    FUNCTION OUTERDIFF_R(A,B)
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  A, B
    REAL(SP), DIMENSION(SIZE(A),SIZE(B))                            ::  OUTERDIFF_R
!
    OUTERDIFF_R = SPREAD(A,DIM=2,NCOPIES=SIZE(B)) - SPREAD(B,DIM=1,NCOPIES=SIZE(A))
    END FUNCTION OUTERDIFF_R
!
!
    FUNCTION OUTERDIFF_D(A,B)
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  A, B
    REAL(DP), DIMENSION(SIZE(A),SIZE(B))                            ::  OUTERDIFF_D
!
    OUTERDIFF_D = SPREAD(A,DIM=2,NCOPIES=SIZE(B)) - SPREAD(B,DIM=1,NCOPIES=SIZE(A))
    END FUNCTION OUTERDIFF_D
!
!
    FUNCTION OUTERDIFF_E(A,B)
    REAL(EP), DIMENSION(:), INTENT(IN)                              ::  A, B
    REAL(EP), DIMENSION(SIZE(A),SIZE(B))                            ::  OUTERDIFF_E
!
    OUTERDIFF_E = SPREAD(A,DIM=2,NCOPIES=SIZE(B)) - SPREAD(B,DIM=1,NCOPIES=SIZE(A))
    END FUNCTION OUTERDIFF_E
!
!
    FUNCTION OUTERDIFF_Q(A,B)
    REAL(QP), DIMENSION(:), INTENT(IN)                              ::  A, B
    REAL(QP), DIMENSION(SIZE(A),SIZE(B))                            ::  OUTERDIFF_Q
!
    OUTERDIFF_Q = SPREAD(A,DIM=2,NCOPIES=SIZE(B)) - SPREAD(B,DIM=1,NCOPIES=SIZE(A))
    END FUNCTION OUTERDIFF_Q
!
!
    FUNCTION OUTERDIFF_I(A,B)
    INTEGER(I4B), DIMENSION(:), INTENT(IN)                          ::  A, B
    INTEGER(I4B), DIMENSION(SIZE(A),SIZE(B))                        ::  OUTERDIFF_I
!
    OUTERDIFF_I = SPREAD(A,DIM=2,NCOPIES=SIZE(B)) - SPREAD(B,DIM=1,NCOPIES=SIZE(A))
    END FUNCTION OUTERDIFF_I
!
!
    FUNCTION OUTERAND(A,B)
    LOGICAL(TLG), DIMENSION(:), INTENT(IN)                          ::  A, B
    LOGICAL(TLG), DIMENSION(SIZE(A),SIZE(B))                        ::  OUTERAND
!
    OUTERAND = SPREAD(A,DIM=2,NCOPIES=SIZE(B)) .AND. SPREAD(B,DIM=1,NCOPIES=SIZE(A))
    END FUNCTION OUTERAND
!...
!...ROUTINES FOR SCATTER-WITH-COMBINE
    SUBROUTINE SCATTER_ADD_R(DEST,SOURCE,DEST_INDEX)
    REAL(SP), DIMENSION(:), INTENT(OUT)                             ::  DEST
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  SOURCE
    INTEGER(I4B), DIMENSION(:), INTENT(IN)                          ::  DEST_INDEX
    INTEGER(I4B)                                                    ::  M, N, J, I
!
    N = ASSERT_EQ2(SIZE(SOURCE),SIZE(DEST_INDEX),"SCATTER_ADD_R")
    M = SIZE(DEST)
    DO J = 1,N
        I = DEST_INDEX(J)
        IF (I > 0 .AND. I <= M) DEST(I) = DEST(I)+SOURCE(J)
    ENDDO
    END SUBROUTINE SCATTER_ADD_R
!
!
    SUBROUTINE SCATTER_ADD_D(DEST,SOURCE,DEST_INDEX)
    REAL(DP), DIMENSION(:), INTENT(OUT)                             ::  DEST
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  SOURCE
    INTEGER(I4B), DIMENSION(:), INTENT(IN)                          ::  DEST_INDEX
    INTEGER(I4B)                                                    ::  M, N, J, I
!
    N = ASSERT_EQ2(SIZE(SOURCE),SIZE(DEST_INDEX),"SCATTER_ADD_D")
    M = SIZE(DEST)
    DO J = 1,N
        I = DEST_INDEX(J)
        IF (I > 0 .AND. I <= M) DEST(I) = DEST(I)+SOURCE(J)
    ENDDO
    END SUBROUTINE SCATTER_ADD_D
!
!
    SUBROUTINE SCATTER_ADD_E(DEST,SOURCE,DEST_INDEX)
    REAL(EP), DIMENSION(:), INTENT(OUT)                             ::  DEST
    REAL(EP), DIMENSION(:), INTENT(IN)                              ::  SOURCE
    INTEGER(I4B), DIMENSION(:), INTENT(IN)                          ::  DEST_INDEX
    INTEGER(I4B)                                                    ::  M, N, J, I
!
    N = ASSERT_EQ2(SIZE(SOURCE),SIZE(DEST_INDEX),"SCATTER_ADD_E")
    M = SIZE(DEST)
    DO J = 1,N
        I = DEST_INDEX(J)
        IF (I > 0 .AND. I <= M) DEST(I) = DEST(I)+SOURCE(J)
    ENDDO
    END SUBROUTINE SCATTER_ADD_E
!
!
    SUBROUTINE SCATTER_ADD_Q(DEST,SOURCE,DEST_INDEX)
    REAL(QP), DIMENSION(:), INTENT(OUT)                             ::  DEST
    REAL(QP), DIMENSION(:), INTENT(IN)                              ::  SOURCE
    INTEGER(I4B), DIMENSION(:), INTENT(IN)                          ::  DEST_INDEX
    INTEGER(I4B)                                                    ::  M, N, J, I
!
    N = ASSERT_EQ2(SIZE(SOURCE),SIZE(DEST_INDEX),"SCATTER_ADD_Q")
    M = SIZE(DEST)
    DO J = 1,N
        I = DEST_INDEX(J)
        IF (I > 0 .AND. I <= M) DEST(I) = DEST(I)+SOURCE(J)
    ENDDO
    END SUBROUTINE SCATTER_ADD_Q
!
!
    SUBROUTINE SCATTER_MAX_R(DEST,SOURCE,DEST_INDEX)
    REAL(SP), DIMENSION(:), INTENT(OUT)                             ::  DEST
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  SOURCE
    INTEGER(I4B), DIMENSION(:), INTENT(IN)                          ::  DEST_INDEX
    INTEGER(I4B)                                                    ::  M, N, J, I
!
    N = ASSERT_EQ2(SIZE(SOURCE),SIZE(DEST_INDEX),"SCATTER_MAX_R")
    M = SIZE(DEST)
    DO J = 1,N
        I = DEST_INDEX(J)
        IF (I > 0 .AND. I <= M) DEST(I) = MAX(DEST(I),SOURCE(J))
    ENDDO
    END SUBROUTINE SCATTER_MAX_R
!
!
    SUBROUTINE SCATTER_MAX_D(DEST,SOURCE,DEST_INDEX)
    REAL(DP), DIMENSION(:), INTENT(OUT)                             ::  DEST
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  SOURCE
    INTEGER(I4B), DIMENSION(:), INTENT(IN)                          ::  DEST_INDEX
    INTEGER(I4B)                                                    ::  M, N, J, I
!
    N = ASSERT_EQ2(SIZE(SOURCE),SIZE(DEST_INDEX),"SCATTER_MAX_D")
    M = SIZE(DEST)
    DO J = 1,N
        I = DEST_INDEX(J)
        IF (I > 0 .AND. I <= M) DEST(I) = MAX(DEST(I),SOURCE(J))
    ENDDO
    END SUBROUTINE SCATTER_MAX_D
!
!
    SUBROUTINE SCATTER_MAX_E(DEST,SOURCE,DEST_INDEX)
    REAL(EP), DIMENSION(:), INTENT(OUT)                             ::  DEST
    REAL(EP), DIMENSION(:), INTENT(IN)                              ::  SOURCE
    INTEGER(I4B), DIMENSION(:), INTENT(IN)                          ::  DEST_INDEX
    INTEGER(I4B)                                                    ::  M, N, J, I
!
    N = ASSERT_EQ2(SIZE(SOURCE),SIZE(DEST_INDEX),"SCATTER_MAX_E")
    M = SIZE(DEST)
    DO J = 1,N
        I = DEST_INDEX(J)
        IF (I > 0 .AND. I <= M) DEST(I) = MAX(DEST(I),SOURCE(J))
    ENDDO
    END SUBROUTINE SCATTER_MAX_E
!
!
    SUBROUTINE SCATTER_MAX_Q(DEST,SOURCE,DEST_INDEX)
    REAL(QP), DIMENSION(:), INTENT(OUT)                             ::  DEST
    REAL(QP), DIMENSION(:), INTENT(IN)                              ::  SOURCE
    INTEGER(I4B), DIMENSION(:), INTENT(IN)                          ::  DEST_INDEX
    INTEGER(I4B)                                                    ::  M, N, J, I
!
    N = ASSERT_EQ2(SIZE(SOURCE),SIZE(DEST_INDEX),"SCATTER_MAX_Q")
    M = SIZE(DEST)
    DO J = 1,N
        I = DEST_INDEX(J)
        IF (I > 0 .AND. I <= M) DEST(I) = MAX(DEST(I),SOURCE(J))
    ENDDO
    END SUBROUTINE SCATTER_MAX_Q
!...
!...ROUTINES FOR SKEW OPERATIONS ON MATRICES:
    SUBROUTINE DIAGADD_RV(MAT,DIAG)
!...ADDS VECTOR OR SCALAR DIAG TO THE DIAGONAL OF MATRIX MAT
    REAL(SP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  DIAG
    INTEGER(I4B)                                                    ::  J, N
!
    N = ASSERT_EQ2(SIZE(DIAG),MIN(SIZE(MAT,1),SIZE(MAT,2)),"DIAGADD_RV")
    DO J = 1,N
        MAT(J,J) = MAT(J,J)+DIAG(J)
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = MAT(J,J)+DIAG(J)
    END SUBROUTINE DIAGADD_RV
!
!
    SUBROUTINE DIAGADD_R(MAT,DIAG)
    REAL(SP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    REAL(SP), INTENT(IN)                                            ::  DIAG
    INTEGER(I4B)                                                    ::  J, N
!
    N = MIN(SIZE(MAT,1),SIZE(MAT,2))
    DO J = 1,N
        MAT(J,J) = MAT(J,J)+DIAG
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = MAT(J,J)+DIAG
    END SUBROUTINE DIAGADD_R
!...
!...ROUTINES FOR SKEW OPERATIONS ON MATRICES:
    SUBROUTINE DIAGADD_DV(MAT,DIAG)
!...ADDS VECTOR OR SCALAR DIAG TO THE DIAGONAL OF MATRIX MAT
    REAL(DP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  DIAG
    INTEGER(I4B)                                                    ::  J, N
!
    N = ASSERT_EQ2(SIZE(DIAG),MIN(SIZE(MAT,1),SIZE(MAT,2)),"DIAGADD_DV")
    DO J = 1,N
        MAT(J,J) = MAT(J,J)+DIAG(J)
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = MAT(J,J)+DIAG(J)
    END SUBROUTINE DIAGADD_DV
!
!
    SUBROUTINE DIAGADD_D(MAT,DIAG)
    REAL(DP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    REAL(DP), INTENT(IN)                                            ::  DIAG
    INTEGER(I4B)                                                    ::  J, N
!
    N = MIN(SIZE(MAT,1),SIZE(MAT,2))
    DO J = 1,N
        MAT(J,J) = MAT(J,J)+DIAG
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = MAT(J,J)+DIAG
    END SUBROUTINE DIAGADD_D
!...
!...ROUTINES FOR SKEW OPERATIONS ON MATRICES:
    SUBROUTINE DIAGADD_EV(MAT,DIAG)
!...ADDS VECTOR OR SCALAR DIAG TO THE DIAGONAL OF MATRIX MAT
    REAL(EP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    REAL(EP), DIMENSION(:), INTENT(IN)                              ::  DIAG
    INTEGER(I4B)                                                    ::  J, N
!
    N = ASSERT_EQ2(SIZE(DIAG),MIN(SIZE(MAT,1),SIZE(MAT,2)),"DIAGADD_EV")
    DO J = 1,N
        MAT(J,J) = MAT(J,J)+DIAG(J)
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = MAT(J,J)+DIAG(J)
    END SUBROUTINE DIAGADD_EV
!
!
    SUBROUTINE DIAGADD_E(MAT,DIAG)
    REAL(EP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    REAL(EP), INTENT(IN)                                            ::  DIAG
    INTEGER(I4B)                                                    ::  J, N
!
    N = MIN(SIZE(MAT,1),SIZE(MAT,2))
    DO J = 1,N
        MAT(J,J) = MAT(J,J)+DIAG
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = MAT(J,J)+DIAG
    END SUBROUTINE DIAGADD_E
!...
!...ROUTINES FOR SKEW OPERATIONS ON MATRICES:
    SUBROUTINE DIAGADD_QV(MAT,DIAG)
!...ADDS VECTOR OR SCALAR DIAG TO THE DIAGONAL OF MATRIX MAT
    REAL(QP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    REAL(QP), DIMENSION(:), INTENT(IN)                              ::  DIAG
    INTEGER(I4B)                                                    ::  J, N
!
    N = ASSERT_EQ2(SIZE(DIAG),MIN(SIZE(MAT,1),SIZE(MAT,2)),"DIAGADD_QV")
    DO J = 1,N
        MAT(J,J) = MAT(J,J)+DIAG(J)
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = MAT(J,J)+DIAG(J)
    END SUBROUTINE DIAGADD_QV
!
!
    SUBROUTINE DIAGADD_Q(MAT,DIAG)
    REAL(QP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    REAL(QP), INTENT(IN)                                            ::  DIAG
    INTEGER(I4B)                                                    ::  J, N
!
    N = MIN(SIZE(MAT,1),SIZE(MAT,2))
    DO J = 1,N
        MAT(J,J) = MAT(J,J)+DIAG
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = MAT(J,J)+DIAG
    END SUBROUTINE DIAGADD_Q
!
!
    SUBROUTINE DIAGMULT_RV(MAT,DIAG)
!...MULTIPLIES VECTOR OR SCALAR DIAG TO THE DIAGONAL OF MATRIX MAT
    REAL(SP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  DIAG
    INTEGER(I4B)                                                    ::  J, N
!
    N = ASSERT_EQ2(SIZE(DIAG),MIN(SIZE(MAT,1),SIZE(MAT,2)),"DIAGMULT_RV")
    DO J = 1,N
        MAT(J,J) = MAT(J,J)*DIAG(J)
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = MAT(J,J)+DIAG(J)
    END SUBROUTINE DIAGMULT_RV
!
!
    SUBROUTINE DIAGMULT_R(MAT,DIAG)
    REAL(SP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    REAL(SP), INTENT(IN)                                            ::  DIAG
    INTEGER(I4B)                                                    ::  J, N
!
    N = MIN(SIZE(MAT,1),SIZE(MAT,2))
    DO J = 1,N
        MAT(J,J) = MAT(J,J)*DIAG
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = MAT(J,J)+DIAG
    END SUBROUTINE DIAGMULT_R
!
!
    SUBROUTINE DIAGMULT_DV(MAT,DIAG)
!...MULTIPLIES VECTOR OR SCALAR DIAG TO THE DIAGONAL OF MATRIX MAT
    REAL(DP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  DIAG
    INTEGER(I4B)                                                    ::  J, N
!
    N = ASSERT_EQ2(SIZE(DIAG),MIN(SIZE(MAT,1),SIZE(MAT,2)),"DIAGMULT_DV")
    DO J = 1,N
        MAT(J,J) = MAT(J,J)*DIAG(J)
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = MAT(J,J)+DIAG(J)
    END SUBROUTINE DIAGMULT_DV
!
!
    SUBROUTINE DIAGMULT_D(MAT,DIAG)
    REAL(DP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    REAL(DP), INTENT(IN)                                            ::  DIAG
    INTEGER(I4B)                                                    ::  J, N
!
    N = MIN(SIZE(MAT,1),SIZE(MAT,2))
    DO J = 1,N
        MAT(J,J) = MAT(J,J)*DIAG
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = MAT(J,J)+DIAG
    END SUBROUTINE DIAGMULT_D
!
!
    SUBROUTINE DIAGMULT_EV(MAT,DIAG)
!...MULTIPLIES VECTOR OR SCALAR DIAG TO THE DIAGONAL OF MATRIX MAT
    REAL(EP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    REAL(EP), DIMENSION(:), INTENT(IN)                              ::  DIAG
    INTEGER(I4B)                                                    ::  J, N
!
    N = ASSERT_EQ2(SIZE(DIAG),MIN(SIZE(MAT,1),SIZE(MAT,2)),"DIAGMULT_EV")
    DO J = 1,N
        MAT(J,J) = MAT(J,J)*DIAG(J)
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = MAT(J,J)+DIAG(J)
    END SUBROUTINE DIAGMULT_EV
!
!
    SUBROUTINE DIAGMULT_E(MAT,DIAG)
    REAL(EP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    REAL(EP), INTENT(IN)                                            ::  DIAG
    INTEGER(I4B)                                                    ::  J, N
!
    N = MIN(SIZE(MAT,1),SIZE(MAT,2))
    DO J = 1,N
        MAT(J,J) = MAT(J,J)*DIAG
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = MAT(J,J)+DIAG
    END SUBROUTINE DIAGMULT_E
!
!
    SUBROUTINE DIAGMULT_QV(MAT,DIAG)
!...MULTIPLIES VECTOR OR SCALAR DIAG TO THE DIAGONAL OF MATRIX MAT
    REAL(QP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    REAL(QP), DIMENSION(:), INTENT(IN)                              ::  DIAG
    INTEGER(I4B)                                                    ::  J, N
!
    N = ASSERT_EQ2(SIZE(DIAG),MIN(SIZE(MAT,1),SIZE(MAT,2)),"DIAGMULT_QV")
    DO J = 1,N
        MAT(J,J) = MAT(J,J)*DIAG(J)
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = MAT(J,J)+DIAG(J)
    END SUBROUTINE DIAGMULT_QV
!
!
    SUBROUTINE DIAGMULT_Q(MAT,DIAG)
    REAL(QP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    REAL(QP), INTENT(IN)                                            ::  DIAG
    INTEGER(I4B)                                                    ::  J, N
!
    N = MIN(SIZE(MAT,1),SIZE(MAT,2))
    DO J = 1,N
        MAT(J,J) = MAT(J,J)*DIAG
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = MAT(J,J)+DIAG
    END SUBROUTINE DIAGMULT_Q
!
!
    FUNCTION GET_DIAG_RV(MAT)
!...RETURN AS A VECTOR THE DIAGONAL OF MATRIX MAT
    REAL(SP), DIMENSION(:,:), INTENT(IN)                            ::  MAT
    REAL(SP), DIMENSION(SIZE(MAT,1))                                ::  GET_DIAG_RV
    INTEGER(I4B)                                                    ::  J
!
    J = ASSERT_EQ2(SIZE(MAT,1),SIZE(MAT,2),"GET_DIAG_RV")
    DO J = 1,SIZE(MAT,1)
        GET_DIAG_RV(J) = MAT(J,J)
    ENDDO
!    FORALL (J=1:SIZE(MAT,1)) GET_DIAG_RV(J) = MAT(J,J)
    END FUNCTION GET_DIAG_RV
!
!
    FUNCTION GET_DIAG_DV(MAT)
    REAL(DP), DIMENSION(:,:), INTENT(IN)                            ::  MAT
    REAL(DP), DIMENSION(SIZE(MAT,1))                                ::  GET_DIAG_DV
    INTEGER(I4B)                                                    ::  J
!
J = ASSERT_EQ2(SIZE(MAT,1),SIZE(MAT,2),"GET_DIAG_DV")
    DO J = 1,SIZE(MAT,1)
        GET_DIAG_DV(J) = MAT(J,J)
    ENDDO
!    FORALL (J=1:SIZE(MAT,1)) GET_DIAG_DV(J) = MAT(J,J)
    END FUNCTION GET_DIAG_DV
!
!
    FUNCTION GET_DIAG_EV(MAT)
    REAL(EP), DIMENSION(:,:), INTENT(IN)                            ::  MAT
    REAL(EP), DIMENSION(SIZE(MAT,1))                                ::  GET_DIAG_EV
    INTEGER(I4B)                                                    ::  J
!
J = ASSERT_EQ2(SIZE(MAT,1),SIZE(MAT,2),"GET_DIAG_EV")
    DO J = 1,SIZE(MAT,1)
        GET_DIAG_EV(J) = MAT(J,J)
    ENDDO
!    FORALL (J=1:SIZE(MAT,1)) GET_DIAG_EV(J) = MAT(J,J)
    END FUNCTION GET_DIAG_EV
!
!
    FUNCTION GET_DIAG_QV(MAT)
    REAL(QP), DIMENSION(:,:), INTENT(IN)                            ::  MAT
    REAL(QP), DIMENSION(SIZE(MAT,1))                                ::  GET_DIAG_QV
    INTEGER(I4B)                                                    ::  J
!
J = ASSERT_EQ2(SIZE(MAT,1),SIZE(MAT,2),"GET_DIAG_QV")
    DO J = 1,SIZE(MAT,1)
        GET_DIAG_QV(J) = MAT(J,J)
    ENDDO
!    FORALL (J=1:SIZE(MAT,1)) GET_QIAG_QV(J) = MAT(J,J)
    END FUNCTION GET_DIAG_QV
!
!
    SUBROUTINE PUT_DIAG_RV(DIAGV,MAT)
!...SET THE DIAGONAL OF MATRIX MAT TO THE VALUES OF A VECTOR OR SCALAR
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  DIAGV
    REAL(SP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    INTEGER(I4B)                                                    ::  J, N
!
    N = ASSERT_EQ2(SIZE(DIAGV),MIN(SIZE(MAT,1),SIZE(MAT,2)),"PUT_DIAG_RV")
    DO J = 1,N
        MAT(J,J) = DIAGV(J)
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = DIAGV(J)
    END SUBROUTINE PUT_DIAG_RV
!
!
    SUBROUTINE PUT_DIAG_R(SCAL,MAT)
    REAL(SP), INTENT(IN)                                            ::  SCAL
    REAL(SP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    INTEGER(I4B)                                                    ::  J, N
!
    N = MIN(SIZE(MAT,1),SIZE(MAT,2))
    DO J = 1,N
        MAT(J,J) = SCAL
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = SCAL
    END SUBROUTINE PUT_DIAG_R
!
!
    SUBROUTINE PUT_DIAG_DV(DIAGV,MAT)
!...SET THE DIAGONAL OF MATRIX MAT TO THE VALUES OF A VECTOR OR SCALAR
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  DIAGV
    REAL(DP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    INTEGER(I4B)                                                    ::  J, N
!
    N = ASSERT_EQ2(SIZE(DIAGV),MIN(SIZE(MAT,1),SIZE(MAT,2)),"PUT_DIAG_DV")
    DO J = 1,N
        MAT(J,J) = DIAGV(J)
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = DIAGV(J)
    END SUBROUTINE PUT_DIAG_DV
!
!
    SUBROUTINE PUT_DIAG_D(SCAL,MAT)
    REAL(DP), INTENT(IN)                                            ::  SCAL
    REAL(DP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    INTEGER(I4B)                                                    ::  J, N
!
    N = MIN(SIZE(MAT,1),SIZE(MAT,2))
    DO J = 1,N
        MAT(J,J) = SCAL
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = SCAL
    END SUBROUTINE PUT_DIAG_D
!
!
    SUBROUTINE PUT_DIAG_EV(DIAGV,MAT)
!...SET THE DIAGONAL OF MATRIX MAT TO THE VALUES OF A VECTOR OR SCALAR
    REAL(EP), DIMENSION(:), INTENT(IN)                              ::  DIAGV
    REAL(EP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    INTEGER(I4B)                                                    ::  J, N
!
    N = ASSERT_EQ2(SIZE(DIAGV),MIN(SIZE(MAT,1),SIZE(MAT,2)),"PUT_DIAG_EV")
    DO J = 1,N
        MAT(J,J) = DIAGV(J)
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = DIAGV(J)
    END SUBROUTINE PUT_DIAG_EV
!
!
    SUBROUTINE PUT_DIAG_E(SCAL,MAT)
    REAL(EP), INTENT(IN)                                            ::  SCAL
    REAL(EP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    INTEGER(I4B)                                                    ::  J, N
!
    N = MIN(SIZE(MAT,1),SIZE(MAT,2))
    DO J = 1,N
        MAT(J,J) = SCAL
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = SCAL
    END SUBROUTINE PUT_DIAG_E
!
!
    SUBROUTINE PUT_DIAG_QV(DIAGV,MAT)
!...SET THE DIAGONAL OF MATRIX MAT TO THE VALUES OF A VECTOR OR SCALAR
    REAL(QP), DIMENSION(:), INTENT(IN)                              ::  DIAGV
    REAL(QP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    INTEGER(I4B)                                                    ::  J, N
!
    N = ASSERT_EQ2(SIZE(DIAGV),MIN(SIZE(MAT,1),SIZE(MAT,2)),"PUT_DIAG_QV")
    DO J = 1,N
        MAT(J,J) = DIAGV(J)
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = DIAGV(J)
    END SUBROUTINE PUT_DIAG_QV
!
!
    SUBROUTINE PUT_DIAG_Q(SCAL,MAT)
    REAL(QP), INTENT(IN)                                            ::  SCAL
    REAL(QP), DIMENSION(:,:), INTENT(INOUT)                         ::  MAT
    INTEGER(I4B)                                                    ::  J, N
!
    N = MIN(SIZE(MAT,1),SIZE(MAT,2))
    DO J = 1,N
        MAT(J,J) = SCAL
    ENDDO
!    FORALL (J=1:N) MAT(J,J) = SCAL
    END SUBROUTINE PUT_DIAG_Q
!
!
    SUBROUTINE UNIT_MATRIX(MAT)
!...SET THE MATRIX MAT TO BE A UNIT MATRIX (IF IT IS AQUARE)
    REAL(SP), DIMENSION(:,:), INTENT(OUT)                           ::  MAT
    INTEGER(I4B)                                                    ::  I, N
!
    N = MIN(SIZE(MAT,1),SIZE(MAT,2))
    MAT(:,:) = ZERO_S
    DO I = 1,N
        MAT(I,I) = ONE_S
    ENDDO
!    FORALL (I=1:N) MAT(I,I) = ONE_S
    END SUBROUTINE UNIT_MATRIX
!
!
    FUNCTION UPPER_TRIANGLE(J,K,EXTRA)
!...RETURN AN UPPER TRIANGULAR LOGICAL MASK
    INTEGER(I4B), INTENT(IN)                                        ::  J, K
    INTEGER(I4B), OPTIONAL, INTENT(IN)                              ::  EXTRA
    LOGICAL(TLG), DIMENSION(J,K)                                    ::  UPPER_TRIANGLE
    INTEGER(I4B)                                                    ::  N
!
    N = 0_I4B
    IF (PRESENT(EXTRA)) N = EXTRA
    UPPER_TRIANGLE = (OUTERDIFF(ARTH_I(1,1,J),ARTH_I(1,1,K)) < N)
    END FUNCTION UPPER_TRIANGLE
!
!
    FUNCTION LOWER_TRIANGLE(J,K,EXTRA)
!...RETURN A LOWER TRIANGULAR LOGICAL MASK
    INTEGER(I4B), INTENT(IN)                                        ::  J, K
    INTEGER(I4B), OPTIONAL, INTENT(IN)                              ::  EXTRA
    LOGICAL(TLG), DIMENSION(J,K)                                    ::  LOWER_TRIANGLE
    INTEGER(I4B)                                                    ::  N
!
    N = 0_I4B
    IF (PRESENT(EXTRA)) N = EXTRA
    LOWER_TRIANGLE = (OUTERDIFF(ARTH_I(1,1,J),ARTH_I(1,1,K)) > -N)
    END FUNCTION LOWER_TRIANGLE
!...
!...OTHER ROUTINES:
    FUNCTION VABS_R(V)
!...RETURN THE LENGTH (ORDINARY L2 NORM) OF A VECTOR
    REAL(SP), DIMENSION(:), INTENT(IN)                              ::  V
    REAL(SP)                                                        ::  VABS_R
!
    VABS_R = SQRT(DOT_PRODUCT(V,V))
    END FUNCTION VABS_R
!
!
    FUNCTION VABS_D(V)
!...RETURN THE LENGTH (ORDINARY L2 NORM) OF A VECTOR
    REAL(DP), DIMENSION(:), INTENT(IN)                              ::  V
    REAL(DP)                                                        ::  VABS_D
!
    VABS_D = SQRT(DOT_PRODUCT(V,V))
    END FUNCTION VABS_D
!
!
    FUNCTION VABS_E(V)
!...RETURN THE LENGTH (ORDINARY L2 NORM) OF A VECTOR
    REAL(EP), DIMENSION(:), INTENT(IN)                              ::  V
    REAL(EP)                                                        ::  VABS_E
!
    VABS_E = SQRT(DOT_PRODUCT(V,V))
    END FUNCTION VABS_E
!
!
    FUNCTION VABS_Q(V)
!...RETURN THE LENGTH (ORDINARY L2 NORM) OF A VECTOR
    REAL(QP), DIMENSION(:), INTENT(IN)                              ::  V
    REAL(QP)                                                        ::  VABS_Q
!
    VABS_Q = SQRT(DOT_PRODUCT(V,V))
    END FUNCTION VABS_Q
!...
!...DONE
END MODULE NRUTIL
