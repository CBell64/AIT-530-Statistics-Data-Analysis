!...
!...LIST OF SUBROUTINES AND ARGUMENTS
! SUBROUTINE CONTROL (IPREPOST,BCKGRD,METHOD,MORDER,LD,SMOOTHING,IZERO,DL,ITM,ICN,PLINE,PL)
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                   SUBROUTINE CONTROL                 *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 03/18/15          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...SUBROUTINE TO READ A PROCESS CONTROL FILE
SUBROUTINE CONTROL (IPREPOST,BCKGRD,METHOD,MORDER,LD,SMOOTHING,IZERO,DL,ITM,ICN,PLINE,PL,DPMARK,DNPLOT)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL,  ONLY : NRERROR
USE AA_SIZE, ONLY : IREDUCE, NREDUCE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: EXECUTE_COMMAND_LINE
!...
!...IDENTIFY TRANSFERED VALIABLES
CHARACTER(LEN=*), INTENT(INOUT)                     :: METHOD, SMOOTHING, PLINE, PL, DPMARK, DNPLOT
INTEGER(I4B), INTENT(INOUT)                         :: IPREPOST, IZERO, ITM, ICN, MORDER, LD
REAL(WP), INTENT(INOUT)                             :: BCKGRD, DL
!...
!...IDENTIFY SUBROUTINE VALIABLES
CHARACTER(LEN=80)                                   :: JUNK
CHARACTER(LEN=3)                                    :: ZERO
INTEGER(I4B)                                        :: I, IUN
!...
!===================================================================================
!...
!...READ DATA FILE
!REWIND(13)
OPEN (NEWUNIT=IUN, FILE = "CTRL.DAT", ACCESS = "SEQUENTIAL", STATUS = "OLD", POSITION = "REWIND")
!...
!...READ DATA ANALYSIS TYPE --> PRE- OR POST-INJECTION
DO I = 1,3
    READ (IUN,*) JUNK
ENDDO
READ (IUN,*) IPREPOST
IF ((IPREPOST < 1) .OR. (IPREPOST > 2)) THEN
    CALL EXECUTE_COMMAND_LINE("CLS")
    CALL EXECUTE_COMMAND_LINE("COLOR 0D")
    DO I = 1,3
        WRITE (*,*)
    ENDDO
    CALL NRERROR("FATAL ERROR --> PRE- OR POST-INJECTION SELECTION LESS THAN 1 OR SELECTION GREATER THAN 2")
ENDIF
!...
!...READ BACKGROUND DETERMINATION (SUBTRACT? AND VALUE TO SUBTRACT)
DO I = 1,2
    READ (IUN,*) JUNK
ENDDO
READ (IUN,*) BCKGRD
IF (BCKGRD < ZERO_W) THEN
    CALL EXECUTE_COMMAND_LINE("CLS")
    CALL EXECUTE_COMMAND_LINE("COLOR 0D")
    DO I = 1,3
        WRITE (*,*)
    ENDDO
    CALL NRERROR("FATAL ERROR --> BACKGROUND VALUE LESS THAN ZERO")
ENDIF
IF (IPREPOST == 1) BCKGRD = ZERO_W
!...
!...READ CONTROL FOR DETERMINING THE SMOOTHING ROUTINE TO BE USED
DO I = 1,2
    READ (IUN,*) JUNK
ENDDO
READ (IUN,*) SMOOTHING
SELECT CASE (SMOOTHING)
    CASE ("Y","y")
        DO I = 1,21
            READ (IUN,*) JUNK
        ENDDO
        READ (IUN,*) METHOD, IREDUCE
        IF (IREDUCE == 1) THEN                              !...CHECK VALUE TO BE USED TO REDUCE THE SIZE OF THE DATA SET
            IF ((METHOD == "C" .OR. METHOD == "c") .OR.                                         &
                (METHOD == "L" .OR. METHOD == "l") .OR.                                         &
                (METHOD == "U" .OR. METHOD == "u")) THEN
                SMOOTHING = "Y"
            ELSE
                SMOOTHING = "N"
                WRITE (*,500)
                WRITE (*,100)
            ENDIF
        ELSEIF ((IREDUCE < 1) .OR. (IREDUCE > 1000)) THEN   !...IDENTIFY DATA REDUCTION ERRORS AND CEASE PROGRAM OPERATION
            CALL EXECUTE_COMMAND_LINE("CLS")
            CALL EXECUTE_COMMAND_LINE("COLOR 0D")
            DO I = 1,3
                WRITE (*,*)
            ENDDO
            CALL NRERROR("FATAL ERROR --> SMOOTHING AVERAGE SELECTION LESS THAN 1 OR SELECTION GREATER THAN 1000")
        ENDIF
        SELECT CASE (METHOD)
            CASE ("A":"C","a":"c","E":"G","e":"g","K":"M","k":"m","P":"Q","p":"q","S","s","U","u","W","w")
                IF (METHOD == "B" .OR. METHOD == "b") THEN
                    IF (IPREPOST == 1) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> CANNOT REQUEST B-SPLINE SMOOTHING FOR PRE-INJECTION DATA")
                    ENDIF
                    READ (IUN,*) MORDER
                    IF ((MORDER < 1) .OR. (MORDER > 4)) THEN
                        MORDER = 4
                        WRITE (*,500)
                        WRITE (*,150)
                    ENDIF
                    WRITE (*,500)
                ELSEIF (METHOD == "U" .OR. METHOD == "u") THEN
                    IF (IPREPOST == 1) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> CANNOT REQUEST CURVE-FIT SMOOTHING FOR PRE-INJECTION DATA")
                    ENDIF
                    IREDUCE = 1
                    READ (IUN,*) JUNK
                    WRITE (*,500)
                    WRITE (*,300)
                ELSEIF ((METHOD == "C" .OR. METHOD == "c") .OR.                                         &
                        (METHOD == "L" .OR. METHOD == "l")) THEN
                    IREDUCE = 1
                    READ (IUN,*) JUNK
                    WRITE (*,500)
                    WRITE (*,300)
                ELSEIF (METHOD == "G" .OR. METHOD == "g") THEN
                    READ (IUN,*) MORDER, LD
                    IF ((MORDER < 2) .OR. (MORDER == 3) .OR. (MORDER > 6)) THEN
                        MORDER = 2
                        WRITE (*,500)
                        WRITE (*,200)
                    ENDIF
                    WRITE (*,500)
                ELSEIF (METHOD == "K" .OR. METHOD == "k") THEN
                    READ (IUN,*) MORDER, LD
                    WRITE (*,500)
                    IF ((MORDER < 1) .OR. (MORDER > 2)) THEN
                        MORDER = 2
                        WRITE (*,500)
                        WRITE (*,350)
                        WRITE (*,400)
                    ENDIF
                ELSEIF (METHOD == "P" .OR. METHOD == "p") THEN
                    IREDUCE = 1
                    READ (IUN,*) MORDER
                    IF ((MORDER < 0) .OR. (MORDER > 100)) THEN
                        MORDER = 20
                        WRITE (*,500)
                        WRITE (*,420)
                        WRITE (*,500)
                        WRITE (*,300)
                    ENDIF
                    WRITE (*,500)
                ELSE
                    READ (IUN,*) JUNK
                ENDIF
            CASE ("N","n")
                SMOOTHING = "N"
                READ (IUN,*) JUNK
                IREDUCE = 1
                WRITE (*,500)
                WRITE (*,450)
                WRITE (*,100)
            CASE DEFAULT
                CALL EXECUTE_COMMAND_LINE("CLS")
                CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                DO I = 1,3
                    WRITE (*,*)
                ENDDO
                WRITE (*,*) "'A' OR 'B' OR 'C' OR 'E' OR 'F' OR 'G' OR 'K' OR 'L' OR ",         &
                            "'M' OR 'P' OR 'Q' OR 'S' OR 'U' OR 'W' MUST BE SELECTED"
                CALL NRERROR("FATAL ERROR")
        END SELECT
    CASE ("N","n")
        DO I = 1,21
            READ (IUN,*) JUNK
        ENDDO
        READ (IUN,*) METHOD, IREDUCE
        READ (IUN,*) JUNK
    CASE DEFAULT
        CALL EXECUTE_COMMAND_LINE("CLS")
        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
        DO I = 1,3
            WRITE (*,*)
        ENDDO
        CALL NRERROR("FATAL ERROR --> A 'Y' OR 'N' MUST BE LISTED FOR DATA SMOOTHING OR FOR NO DATA SMOOTHING")
END SELECT
!...
!...COPY VALUE TO BE USED TO REDUCE THE SIZE OF THE DATA SET FOR LATER USE
NREDUCE = IREDUCE
!...
!...READ IN CONTROL TO DETERMINE IF NEGATIVE VALUES TO BE CONVERTED TO ZERO
DO I = 1,2
    READ (IUN,*) JUNK
ENDDO
READ (IUN,*) ZERO
IF ((ZERO == "Y") .OR. (ZERO == "y")) THEN
    IZERO = 1
ELSE
    IZERO = 2
ENDIF
IF ((IZERO < 1) .OR. (IZERO > 2)) THEN
    CALL EXECUTE_COMMAND_LINE("CLS")
    CALL EXECUTE_COMMAND_LINE("COLOR 0D")
    DO I = 1,3
        WRITE (*,*)
    ENDDO
    CALL NRERROR("FATAL ERROR --> FATAL ERROR: NEGATIVE VALUE CORRECTION -- SELECTION LESS THAN 1 OR SELECTION GREATER THAN 2")
ENDIF
!...
!...READ A BACKGROUND CONTROL VALUE
DO I = 1,2
    READ (IUN,*) JUNK
ENDDO
READ (IUN,*) DL
!...
!...READ A CONTROL PARAMETER FOR TIME DISPLAY
DO I = 1,2
    READ (IUN,*) JUNK
ENDDO
READ (IUN,*) ITM
IF ((ITM < 1) .OR. (ITM > 4)) THEN
    CALL EXECUTE_COMMAND_LINE("CLS")
    CALL EXECUTE_COMMAND_LINE("COLOR 0D")
    DO I = 1,3
        WRITE (*,*)
    ENDDO
    CALL NRERROR("FATAL ERROR --> FATAL ERROR: TIME LISTING SELECTION LESS THAN 1 OR SELECTION GREATER THAN 4")
ENDIF
!...
!...READ A CONTROL PARAMETER FOR CONCENTRATION DISPLAY
DO I = 1,2
    READ (IUN,*) JUNK
ENDDO
READ (IUN,*) ICN
IF ((ICN < 1) .OR. (ICN > 6)) THEN
    CALL EXECUTE_COMMAND_LINE("CLS")
    CALL EXECUTE_COMMAND_LINE("COLOR 0D")
    DO I = 1,3
        WRITE (*,*)
    ENDDO
    CALL NRERROR("FATAL ERROR --> FATAL ERROR: CONCENTRATION LISTING SELECTION LESS THAN 1 OR SELECTION GREATER THAN 6")
ENDIF
!...
!...DETERMINE IF ORIGINAL DATA SHOULD BE PLOTTED AS POINTS OR A CONNECTED LINE
DO I = 1,2
    READ (IUN,*) JUNK
ENDDO
READ (IUN,*) PL
SELECT CASE (PL)
    CASE ("P","p","L","l")
        CONTINUE
    CASE DEFAULT
        CALL EXECUTE_COMMAND_LINE("CLS")
        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
        DO I = 1,3
            WRITE (*,*)
        ENDDO
        CALL NRERROR("FATAL ERROR --> A 'P' OR 'L' MUST BE SELECTED")
END SELECT
!...
!...DETERMINE IF PLOTTED DATA POINTS SHOULD BE CONNECTED WITH A SMOOTH LINE
DO I = 1,2
    READ (IUN,*) JUNK
ENDDO
READ (IUN,*) PLINE
SELECT CASE (PLINE(1:1))
    CASE ("Y","y","N","n")
        CONTINUE
    CASE DEFAULT
        CALL EXECUTE_COMMAND_LINE("CLS")
        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
        DO I = 1,3
            WRITE (*,*)
        ENDDO
        CALL NRERROR("FATAL ERROR --> FATAL ERROR: ONLY A 'Y' OR AN 'N' ARE ACCEPTABLE ENTRIES FOR JOINING DATA WITH A LINE")
END SELECT
!...
!...DETERMINE IF DOWNLOADED DATA POINTS SHOULD BE PLOTTED
DO I = 1,2
    READ (IUN,*) JUNK
ENDDO
READ (IUN,*) DNPLOT
SELECT CASE (DNPLOT(1:1))
    CASE ("Y","y","N","n")
        CONTINUE
    CASE DEFAULT
        CALL EXECUTE_COMMAND_LINE("CLS")
        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
        DO I = 1,3
            WRITE (*,*)
        ENDDO
        CALL NRERROR("FATAL ERROR --> FATAL ERROR: ONLY A 'Y' OR AN 'N' ARE ACCEPTABLE ENTRIES FOR JOINING DATA WITH A LINE")
END SELECT
!...
!...DETERMINE IF DOWNLOADED DATA POINTS SHOULD BE MARKED ON THE PLOTS
DO I = 1,2
    READ (IUN,*) JUNK
ENDDO
READ (IUN,*) DPMARK
SELECT CASE (DPMARK(1:1))
    CASE ("Y","y","N","n")
        CONTINUE
    CASE DEFAULT
        CALL EXECUTE_COMMAND_LINE("CLS")
        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
        DO I = 1,3
            WRITE (*,*)
        ENDDO
        CALL NRERROR("FATAL ERROR --> FATAL ERROR: ONLY A 'Y' OR AN 'N' ARE ACCEPTABLE ENTRIES FOR JOINING DATA WITH A LINE")
END SELECT
!...
!...CLOSE AND SAVE INPUT FILE CONTROL
CLOSE (UNIT=IUN, STATUS = "KEEP")
!...
!...FORMAT ROUTINES
100 FORMAT (16X,"*** SMOOTHING NOT CALCULATED BECAUSE '1' SELECTED FOR DATA REDUCTION ***")
150 FORMAT (16X,"*** VALUES = 1 -- 4 MUST BE ENTERED ***",5X,"VALUE AUTOMATICALLY SET TO 4")
200 FORMAT (16X,"*** VALUES = 2, 4, OR 6 MUST BE ENTERED ***",5X,"VALUE AUTOMATICALLY SET TO 2")
300 FORMAT (16X,"*** NO DATA REDUCTION FOR THE SMOOTHING METHOD SELECTED ***",/)
350 FORMAT (16X,"*** VALUE = 1 (GLKERN), OR (LOKERN) 2 MUST BE ENTERED ***")
400 FORMAT (16X,"*** LOKERN AUTOMATICALLY IMPLEMENTED ***",//)
420 FORMAT (16X,"*** VALUES = 0 -- 100 MUST BE ENTERED ***",5X,"VALUE AUTOMATICALLY SET TO 20")
450 FORMAT (16X,"*** SMOOTHING REPLACED WITH NO SMOOTHING BECAUSE 'N' SELECTED FOR METHOD ***")
500 FORMAT (//)
!...
!...DONE WITH SUBROUTINE CONTROL
RETURN
END SUBROUTINE CONTROL
