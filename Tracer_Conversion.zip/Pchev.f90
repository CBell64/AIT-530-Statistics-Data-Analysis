!...
!...LIST OF SUBROUTINES, FUNCTIONS, AND ARGUMENTS
! SUBROUTINE PCHEV (N,X,F,D,NVAL,XVAL,FVAL,DVAL,IERR)
!     SUBROUTINE PCHFD (N,X,F,D,INCFD,SKIP,NE,XE,FE,DE,IERR)
!     SUBROUTINE CHFDV (X1,X2,F1,F2,D1,D2,NE,XE,FE,DE,NEXT,IERR)
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                  SUBROUTINE PCHEV                    *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 09/12/07          *
!...   *                                                      *
!...    ******************************************************
!...
!...
SUBROUTINE PCHEV (N,X,F,D,NVAL,XVAL,FVAL,DVAL,IERR)
!
!***BEGIN PROLOGUE  PCHEV
!***DATE WRITTEN   870828   (YYMMDD)
!***REVISION DATE  870828   (YYMMDD)
!***CATEGORY NO.  E3,H1
!***KEYWORDS  CUBIC HERMITE OR SPLINE DIFFERENTIATION,CUBIC HERMITE
!             EVALUATION,EASY TO USE SPLINE OR CUBIC HERMITE EVALUATOR
!***AUTHOR  KAHANER, D.K., (NBS)
!             SCIENTIFIC COMPUTING DIVISION
!             NATIONAL BUREAU OF STANDARDS
!             ROOM A161, TECHNOLOGY BUILDING
!             GAITHERSBURG, MARYLAND 20899
!             (301) 975-3808
!***PURPOSE  EVALUATES THE FUNCTION AND FIRST DERIVATIVE OF A PIECEWISE
!            CUBIC HERMITE OR SPLINE FUNCTION AT AN ARRAY OF POINTS XVAL,
!            EASY TO USE.
!***DESCRIPTION

!          PCHEV:  PIECEWISE CUBIC HERMITE OR SPLINE DERIVATIVE EVALUATOR,
!                  EASY TO USE.

!     FROM THE BOOK "NUMERICAL METHODS AND SOFTWARE"
!          BY  D. KAHANER, C. MOLER, S. NASH
!                 PRENTICE HALL 1988

!     EVALUATES THE FUNCTION AND FIRST DERIVATIVE OF THE CUBIC HERMITE
!     OR SPLINE FUNCTION DEFINED BY  N, X, F, D, AT THE ARRAY OF POINTS XVAL.

!     THIS IS AN EASY TO USE DRIVER FOR THE ROUTINES BY F.N. FRITSCH
!     DESCRIBED IN REFERENCE (2) BELOW. THOSE ALSO HAVE OTHER CAPABILITIES.

! ----------------------------------------------------------------------

!  CALLING SEQUENCE: CALL  PCHEV (N, X, F, D, NVAL, XVAL, FVAL, DVAL, IERR)

!     INTEGER  N, NVAL, IERR
!     REAL  X(N), F(N), D(N), XVAL(NVAL), FVAL(NVAL), DVAL(NVAL)

!   PARAMETERS:

!     N -- (INPUT) NUMBER OF DATA POINTS.  (ERROR RETURN IF N.LT.2 .)

!     X -- (INPUT) REAL ARRAY OF INDEPENDENT VARIABLE VALUES.  THE
!           ELEMENTS OF X MUST BE STRICTLY INCREASING:
!             X(I-1) .LT. X(I),  I = 2(1)N. (ERROR RETURN IF NOT.)

!     F -- (INPUT) REAL ARRAY OF FUNCTION VALUES.  F(I) IS
!           THE VALUE CORRESPONDING TO X(I).

!     D -- (INPUT) REAL ARRAY OF DERIVATIVE VALUES.  D(I) IS
!           THE VALUE CORRESPONDING TO X(I).

!  NVAL -- (INPUT) NUMBER OF POINTS AT WHICH THE FUNCTIONS ARE TO BE
!           EVALUATED. ( ERROR RETURN IF NVAL.LT.1 )

!  XVAL -- (INPUT) REAL ARRAY OF POINTS AT WHICH THE FUNCTIONS ARE TO
!           BE EVALUATED.

!          NOTES:
!           1. THE EVALUATION WILL BE MOST EFFICIENT IF THE ELEMENTS
!              OF XVAL ARE INCREASING RELATIVE TO X;
!              THAT IS,   XVAL(J) .GE. X(I)
!              IMPLIES    XVAL(K) .GE. X(I),  ALL K.GE.J .
!           2. IF ANY OF THE XVAL ARE OUTSIDE THE INTERVAL [X(1),X(N)],
!              VALUES ARE EXTRAPOLATED FROM THE NEAREST EXTREME CUBIC,
!              AND A WARNING ERROR IS RETURNED.

!  FVAL -- (OUTPUT) REAL ARRAY OF VALUES OF THE CUBIC HERMITE FUNCTION
!           DEFINED BY  N, X, F, D  AT THE POINTS  XVAL.

!  DVAL -- (OUTPUT) REAL ARRAY OF VALUES OF THE FIRST DERIVATIVE OF
!           THE SAME FUNCTION AT THE POINTS  XVAL.

!  IERR -- (OUTPUT) ERROR FLAG.
!           NORMAL RETURN:
!              IERR = 0  (NO ERRORS).
!           WARNING ERROR:
!              IERR.GT.0  MEANS THAT EXTRAPOLATION WAS PERFORMED AT
!                 IERR POINTS.
!           "RECOVERABLE" ERRORS:
!              IERR = -1  IF N.LT.2 .
!              IERR = -3  IF THE X-ARRAY IS NOT STRICTLY INCREASING.
!              IERR = -4  IF NVAL.LT.1 .
!           (OUTPUT ARRAYS HAVE NOT BEEN CHANGED IN ANY OF THESE CASES.)
!               NOTE:  THE ABOVE ERRORS ARE CHECKED IN THE ORDER LISTED,
!                   AND FOLLOWING ARGUMENTS HAVE **NOT** BEEN VALIDATED.
!              IERR = -5  IF AN ERROR HAS OCCURRED IN THE LOWER-LEVEL
!                         ROUTINE CHFDV.  NB: THIS SHOULD NEVER HAPPEN.
!                         NOTIFY THE AUTHOR **IMMEDIATELY** IF IT DOES.

! ----------------------------------------------------------------------
!***REFERENCES  1. F.N.FRITSCH AND R.E.CARLSON, 'MONOTONE PIECEWISE
!                 CUBIC INTERPOLATION,' SIAM J.NUMER.ANAL. 17, 2 (APRIL
!                 1980), 238-246.
!               2. F.N.FRITSCH, 'PIECEWISE CUBIC HERMITE INTERPOLATION
!                 PACKAGE, FINAL SPECIFICATIONS', LAWRENCE LIVERMORE
!                 NATIONAL LABORATORY, COMPUTER DOCUMENTATION UCID-30194,
!                 AUGUST 1982.
!***ROUTINES CALLED  PCHFD
!***END PROLOGUE  PCHEV
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B),  INTENT(INOUT)                    :: N
REAL(SP),      INTENT(INOUT)                    :: X(N)
REAL(SP),      INTENT(INOUT)                    :: F(N)
REAL(SP),      INTENT(INOUT)                    :: D(N)
INTEGER(I4B),  INTENT(INOUT)                    :: NVAL
REAL(SP),      INTENT(INOUT)                    :: XVAL(NVAL)
REAL(SP),      INTENT(INOUT)                    :: FVAL(NVAL)
REAL(SP),      INTENT(INOUT)                    :: DVAL(NVAL)
INTEGER(I4B),  INTENT(INOUT)                    :: IERR
!
!  DECLARE LOCAL VARIABLES.
INTEGER                                         :: INCFD
LOGICAL                                         :: SKIP
DATA SKIP /.TRUE./
DATA INCFD /1/
!SKIP = .TRUE.
!INCFD = 1

!***FIRST EXECUTABLE STATEMENT  PCHEV

CALL PCHFD(N,X,F,D,INCFD,SKIP,NVAL,XVAL,FVAL,DVAL,IERR)


CONTINUE
RETURN

!------------- LAST LINE OF PCHEV FOLLOWS ------------------------------
!...
!... ADD CONTAINS STATEMENTS
CONTAINS
!...
! -------------------------------------------------------------------
!...
!...
!...    ******************************************************
!...   *                                                      *
!...   *                   SUBROUTINE PCHFD                   *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 08/28/87          *
!...   *                                                      *
!...    ******************************************************
!...
!...

SUBROUTINE PCHFD (N,X,F,D,INCFD,SKIP,NE,XE,FE,DE,IERR)
!
!***BEGIN PROLOGUE  PCHFD
!     THIS PROLOGUE HAS BEEN REMOVED FOR REASONS OF SPACE
!     FOR A COMPLETE COPY OF THIS ROUTINE CONTACT THE AUTHORS
!     FROM THE BOOK "NUMERICAL METHODS AND SOFTWARE"
!          BY  D. KAHANER, C. MOLER, S. NASH
!               PRENTICE HALL 1988
!***END PROLOGUE  PCHFD

!  DECLARE ARGUMENTS.
!
INTEGER(I4B),  INTENT(IN)                       :: N, INCFD
REAL(SP),      INTENT(IN)                       :: X(N)
REAL(SP),      INTENT(INOUT)                    :: F(INCFD,N)
REAL(SP),      INTENT(INOUT)                    :: D(INCFD,N)
!
INTEGER(I4B),  INTENT(IN)                       :: NE
REAL(SP),      INTENT(INOUT)                    :: XE(NE)
REAL(SP),      INTENT(INOUT)                    :: FE(NE)
REAL(SP),      INTENT(INOUT)                    :: DE(NE)
INTEGER(I4B),  INTENT(OUT)                      :: IERR
!
LOGICAL, INTENT(INOUT)                          :: SKIP
!...
!...LOCAL VARIABLES FOR XERROR REPORTING
CHARACTER(LEN=50)                               :: MESSG
INTEGER(I4B)                                    :: NMESSG
INTEGER(I4B)                                    :: NERR
INTEGER(I4B)                                    :: LEVEL
!
!  DECLARE LOCAL VARIABLES.
!
INTEGER(I4B)                                    :: I, IERC, IR, J, JFIRST, NEXT(2), NJ

!  VALIDITY-CHECK ARGUMENTS.

!***FIRST EXECUTABLE STATEMENT  PCHFD
IF (SKIP)  GO TO 5

IF ( N < 2 )  GO TO 5001
IF ( INCFD < 1 )  GO TO 5002
DO   I = 2, N
  IF ( X(I) <= X(I-1) )  GO TO 5003
END DO

!  FUNCTION DEFINITION IS OK, GO ON.

5 CONTINUE
IF ( NE < 1 )  GO TO 5004
IERR = 0
SKIP = .TRUE.

!  LOOP OVER INTERVALS.        (   INTERVAL INDEX IS  IL = IR-1  . )
!                              ( INTERVAL IS X(IL).LE.X.LT.X(IR) . )
JFIRST = 1
IR = 2
10 CONTINUE

!     SKIP OUT OF LOOP IF HAVE PROCESSED ALL EVALUATION POINTS.

IF (JFIRST > NE)  GO TO 5000

!     LOCATE ALL POINTS IN INTERVAL.

DO   J = JFIRST, NE
  IF (XE(J) >= X(IR))  GO TO 30
END DO
J = NE + 1
GO TO 40

!     HAVE LOCATED FIRST POINT BEYOND INTERVAL.

30    CONTINUE
IF (IR == N)  J = NE + 1

40    CONTINUE
NJ = J - JFIRST

!     SKIP EVALUATION IF NO POINTS IN INTERVAL.

IF (NJ == 0)  GO TO 50

!     EVALUATE CUBIC AT XE(I),  I = JFIRST (1) J-1 .

!       ----------------------------------------------------------------
CALL CHFDV (X(IR-1),X(IR), F(1,IR-1),F(1,IR), D(1,IR-1),D(1,IR),  &
    NJ, XE(JFIRST), FE(JFIRST), DE(JFIRST), NEXT, IERC)
!       ----------------------------------------------------------------
IF (IERC < 0)  GO TO 5005

IF (NEXT(2) == 0)  GO TO 42
!        IF (NEXT(2) .GT. 0)  THEN
!           IN THE CURRENT SET OF XE-POINTS, THERE ARE NEXT(2) TO THE
!           RIGHT OF X(IR).

IF (IR < N)  GO TO 41
!           IF (IR .EQ. N)  THEN
!              THESE ARE ACTUALLY EXTRAPOLATION POINTS.
IERR = IERR + NEXT(2)
GO TO 42
41       CONTINUE
!           ELSE
!              WE SHOULD NEVER HAVE GOTTEN HERE.
GO TO 5005
!           ENDIF
!        ENDIF
42    CONTINUE

IF (NEXT(1) == 0)  GO TO 49
!        IF (NEXT(1) .GT. 0)  THEN
!           IN THE CURRENT SET OF XE-POINTS, THERE ARE NEXT(1) TO THE
!           LEFT OF X(IR-1).

IF (IR > 2)  GO TO 43
!           IF (IR .EQ. 2)  THEN
!              THESE ARE ACTUALLY EXTRAPOLATION POINTS.
IERR = IERR + NEXT(1)
GO TO 49
43       CONTINUE
!           ELSE
!              XE IS NOT ORDERED RELATIVE TO X, SO MUST ADJUST
!              EVALUATION INTERVAL.

!              FIRST, LOCATE FIRST POINT TO LEFT OF X(IR-1).
DO   I = JFIRST, J-1
  IF (XE(I) < X(IR-1))  GO TO 45
END DO
!              NOTE-- CANNOT DROP THROUGH HERE UNLESS THERE IS AN ERROR
!                     IN CHFDV.
GO TO 5005

45          CONTINUE
!              RESET J.  (THIS WILL BE THE NEW JFIRST.)
J = I

!              NOW FIND OUT HOW FAR TO BACK UP IN THE X-ARRAY.
DO   I = 1, IR-1
  IF (XE(J) < X(I)) GO TO 47
END DO
!              NB-- CAN NEVER DROP THROUGH HERE, SINCE XE(J).LT.X(IR-1).

47          CONTINUE
!              AT THIS POINT, EITHER  XE(J) .LT. X(1)
!                 OR      X(I-1) .LE. XE(J) .LT. X(I) .
!              RESET IR, RECOGNIZING THAT IT WILL BE INCREMENTED BEFORE
!              CYCLING.
IR = MAX0(1, I-1)
!           ENDIF
!        ENDIF
49    CONTINUE

JFIRST = J

!     END OF IR-LOOP.

50 CONTINUE
IR = IR + 1
IF (IR <= N)  GO TO 10

!  NORMAL RETURN.

5000 CONTINUE
RETURN

!  ERROR RETURNS.

5001 CONTINUE
!     N.LT.2 RETURN.
IERR = -1
MESSG  = 'PCHFD -- NUMBER OF DATA POINTS LESS THAN TWO'
NMESSG = 44
NERR   = IERR
LEVEL  = 1
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
RETURN

5002 CONTINUE
!     INCFD.LT.1 RETURN.
IERR = -2
MESSG  = 'PCHFD -- INCREMENT LESS THAN ONE'
NMESSG = 32
NERR   = IERR
LEVEL  = 1
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
RETURN

5003 CONTINUE
!     X-ARRAY NOT STRICTLY INCREASING.
IERR = -3
MESSG  = 'PCHFD -- X-ARRAY NOT STRICTLY INCREASING'
NMESSG = 40
NERR   = IERR
LEVEL  = 1
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
RETURN

5004 CONTINUE
!     NE.LT.1 RETURN.
IERR = -4
MESSG  = 'PCHFD -- NUMBER OF EVALUATION POINTS LESS THAN ONE'
NMESSG = 50
NERR   = IERR
LEVEL  = 1
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
RETURN

5005 CONTINUE
!     ERROR RETURN FROM CHFDV.
!   *** THIS CASE SHOULD NEVER OCCUR ***
IERR = -5
MESSG  = 'PCHFD -- ERROR RETURN FROM CHFDV -- FATAL'
NMESSG = 41
NERR   = IERR
LEVEL  = 2
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
RETURN
!------------- LAST LINE OF PCHFD FOLLOWS ------------------------------
END SUBROUTINE PCHFD
!...
! -------------------------------------------------------------------
!...
!...
!...    ******************************************************
!...   *                                                      *
!...   *                   SUBROUTINE CHFDV                   *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 08/28/87          *
!...   *                                                      *
!...    ******************************************************
!...
!...

SUBROUTINE CHFDV (X1,X2,F1,F2,D1,D2,NE,XE,FE,DE,NEXT,IERR)
!
!***BEGIN PROLOGUE  CHFDV
!     THIS PROLOGUE HAS BEEN REMOVED FOR REASONS OF SPACE
!     FOR A COMPLETE COPY OF THIS ROUTINE CONTACT THE AUTHORS
!     FROM THE BOOK "NUMERICAL METHODS AND SOFTWARE"
!          BY  D. KAHANER, C. MOLER, S. NASH
!               PRENTICE HALL 1988
!***END PROLOGUE  CHFDV

!  DECLARE ARGUMENTS.
!
REAL(SP),      INTENT(IN)                       :: X1
REAL(SP),      INTENT(IN)                       :: X2
REAL(SP),      INTENT(IN)                       :: F1
REAL(SP),      INTENT(INOUT)                    :: F2
REAL(SP),      INTENT(IN)                       :: D1
REAL(SP),      INTENT(INOUT)                    :: D2
INTEGER(I4B),  INTENT(IN)                       :: NE
REAL(SP),      INTENT(IN)                       :: XE(NE)
REAL(SP),      INTENT(OUT)                      :: FE(NE)
REAL(SP),      INTENT(OUT)                      :: DE(NE)
INTEGER(I4B),  INTENT(OUT)                      :: NEXT(2)
INTEGER(I4B),  INTENT(OUT)                      :: IERR
!...
!...LOCAL VARIABLES FOR XERROR REPORTING
CHARACTER(LEN=50)                               :: MESSG
INTEGER(I4B)                                    :: NMESSG
INTEGER(I4B)                                    :: NERR
INTEGER(I4B)                                    :: LEVEL
!
!  DECLARE LOCAL VARIABLES.
!
INTEGER(I4B)                                    :: I
REAL(SP)                                        :: C2, C2T2, C3, C3T3, DEL1, DEL2, DELTA, H, X, XMI, XMA

!  VALIDITY-CHECK ARGUMENTS.

!***FIRST EXECUTABLE STATEMENT  CHFDV
IF (NE < 1)  GO TO 5001
H = X2 - X1
IF (H == ZERO_S)  GO TO 5002

!  INITIALIZE.

IERR = 0
NEXT(1) = 0
NEXT(2) = 0
XMI = AMIN1(ZERO_S, H)
XMA = AMAX1(ZERO_S, H)

!  COMPUTE CUBIC COEFFICIENTS (EXPANDED ABOUT X1).

DELTA = (F2 - F1)/H
DEL1 = (D1 - DELTA)/H
DEL2 = (D2 - DELTA)/H
!                                           (DELTA IS NO LONGER NEEDED.)
C2 = -(DEL1+DEL1 + DEL2)
C2T2 = C2 + C2
C3 = (DEL1 + DEL2)/H
!                               (H, DEL1 AND DEL2 ARE NO LONGER NEEDED.)
C3T3 = C3+C3+C3

!  EVALUATION LOOP.

DO   I = 1, NE
  X = XE(I) - X1
  FE(I) = F1 + X*(D1 + X*(C2 + X*C3))
  DE(I) = D1 + X*(C2T2 + X*C3T3)
!          COUNT EXTRAPOLATION POINTS.
  IF ( X < XMI )  NEXT(1) = NEXT(1) + 1
  IF ( X > XMA )  NEXT(2) = NEXT(2) + 1
!        (NOTE REDUNDANCY--IF EITHER CONDITION IS TRUE, OTHER IS FALSE.)
END DO

!  NORMAL RETURN.

RETURN

!  ERROR RETURNS.

5001 CONTINUE
!     NE.LT.1 RETURN.
IERR = -1
MESSG  = 'CHFDV -- NUMBER OF EVALUATION POINTS LESS THAN ONE'
NMESSG = 50
NERR   = IERR
LEVEL  = 1
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
RETURN

5002 CONTINUE
!     X1.EQ.X2 RETURN.
IERR = -2
MESSG  = 'CHFDV -- INTERVAL ENDPOINTS EQUAL'
NMESSG = 33
NERR   = IERR
LEVEL  = 1
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
RETURN
!------------- LAST LINE OF CHFDV FOLLOWS ------------------------------
END SUBROUTINE CHFDV
!...
!...END FULL PCHEV SUBROUTINE
END SUBROUTINE PCHEV
