!...
!...SUBROUTINE MOMENT TO CALCULATE BASIC STATISTICS
SUBROUTINE MOMENTS (NN,DATA1,AMEAN,ADEV,SDEV,VAR,SKEW,CURT,RMS,XMED,XMAD,PRNT)
!...
!...GIVEN AN ARRAY OF DATA1, THIS ROUTINE RETURNS ITS MEAN AVE, AVERAGE DEVIATION ADEV, STANDARD
!...DEVIATION SDEV, VARIANCE VAR, SKEWNESS SKEW, AND KURTOSIS CURT.
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE; USE NRUTIL, ONLY : ARRAY_COPY, NRERROR
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                               :: ABS, LOG, MAXVAL, MINVAL, MOD, NINT, SIZE, SUM
!...
!...DECLARE TRANSFERRED VARIABLES
CHARACTER(LEN=*)                                        :: PRNT
INTEGER(I4B), INTENT(IN)                                :: NN
REAL(WP), INTENT(OUT)                                   :: AMEAN, ADEV, SDEV, VAR, SKEW, CURT, RMS, XMED, XMAD
REAL(WP), DIMENSION(1:NN), INTENT(IN)                   :: DATA1
!...
!...IDENTIFY LOCAL VARIABLES
CHARACTER(LEN=80)                                       :: USTATOUT
INTEGER(I4B)                                            :: NN_COPIED, NN_NOT_COPIED, V1, STATFILE, MM, I!, N1
INTEGER(I4B)                                            :: K, K1, K2, K3, K4, K5, N_COPIED, N_NOT_COPIED, INDICATE=0
!INTEGER(I4B), PARAMETER                                 :: N2 = 2
REAL(WP)                                                :: ES, CV, RNGE, ZW, STMEAN
REAL(WP)                                                :: ALPHA, ALPHA1, ALPHA2, ALPHA3, ALPHA4, ALPHA5
REAL(WP)                                                :: TRIM0, TRIM1, TRIM2, TRIM3, TRIM4, TRIM5!, ZW1
REAL(WP)                                                :: XTSIG0, XTSIG1, XTSIG2, XTSIG3, XTSIG4, XTSIG5
REAL(WP)                                                :: WINS0, WINS1, WINS2, WINS3, WINS4, WINS5!, ZW1
REAL(WP)                                                :: XWSIG0, XWSIG1, XWSIG2, XWSIG3, XWSIG4, XWSIG5
REAL(WP)                                                :: CLML999, CLMU999, CLML950, CLMU950, CLML900, CLMU900
REAL(WP)                                                :: CLML800, CLMU800, CLML500, CLMU500
REAL(DP)                                                :: VARG, SDEVG, GMEAN, CVG, COEF, PMEAN, QMEAN, CMEAN
REAL(DP)                                                :: HMEAN, VARH, SDEVH, CVH, CHMEAN, ZD, ZN
REAL(DP), DIMENSION(SIZE(DATA1))                        :: DATA2, DATA2A
!REAL(WP)                                                :: ALPHAD2, OMAD2, BOUND, TLIM, DF, RATIO
!REAL(WP), PARAMETER                                     :: CONFLEV = 0.95_WP
REAL(WP), DIMENSION(SIZE(DATA1))                        :: MED, PP, SS, RR
!...
!...CHECK FOR SERIOUS ERROR
!N = SIZE(DATA1)
!IF (NN <= 1) CALL NRERROR("             MOMENT: NUMBER OF VALUES MUST BE AT LEAST 2")
V1 = 1
!...
!...CALCULATE BASIC ARITHMETIC STATISTICS
ZN      = REAL(NN, KIND=DP)
ZD      = ONE_D/ZN
ZW      = REAL(NN, KIND=WP)
AMEAN   = SUM(DATA1(:))/ZW                                  ! FIRST PASS TO GET THE MEAN.
SS(:)   = DATA1(:)-AMEAN                                    ! SECOND PASS TO GET THE FIRST (ABSOLUTE), SECOND, THIRD, AND
ES      = SUM(SS(:))                                        ! FOURTH MOMENTS OF THE DEVIATION FROM THE MEAN.
ADEV    = SUM(ABS(SS(:)))/ZW
PP(:)   = SS(:)*SS(:)
VAR     = SUM(PP(:))
PP(:)   = PP(:)*SS(:)
SKEW    = SUM(PP(:))
PP(:)   = PP(:)*SS(:)
CURT    = SUM(PP(:))
VAR     = (VAR-ES**2/ZW)/(ZW-ONE_W)                          ! CORRECTED TWO-PASS FORMULA.
!VAR     = DOT_PRODUCT(SS,SS)
!VAR     = (VAR-SUM(SS)**2/NN)/(NN-1)
SDEV    = SQRT(VAR)
STMEAN  = SDEV/SQRT(ZW)
!...
!...CALCULATE THE COEFFICIENT OF VARIATION
IF (AMEAN /= ZERO_W) THEN
    CV = SDEV/AMEAN
ELSE
    CV = ZERO_W
ENDIF
!...
!...CALCULATE THE DATA RANGE
RNGE  = MAXVAL(DATA1)-MINVAL(DATA1)
!...
!...CALCULATE CONFIDENCE LIMITS ON THE MEAN
!...
!...USE 3.34138 FOR A 99.9% CONFIDENCE LEVEL
CLML999 = AMEAN - 3.34138_WP*SDEV/SQRT(ZW)
CLMU999 = AMEAN + 3.34138_WP*SDEV/SQRT(ZW)
!...
!...USE 1.97226 FOR A 95.0% CONFIDENCE LEVEL  <--PRINT THIS ONE
CLML950 = AMEAN - 1.97226_WP*SDEV/SQRT(ZW)
CLMU950 = AMEAN + 1.97226_WP*SDEV/SQRT(ZW)
!...
!...USE 1.65274 FOR A 90.0% CONFIDENCE LEVEL
CLML900 = AMEAN - 1.65274_WP*SDEV/SQRT(ZW)
CLMU900 = AMEAN + 1.65274_WP*SDEV/SQRT(ZW)
!...
!...USE 1.28593 FOR A 80.0% CONFIDENCE LEVEL
CLML800 = AMEAN - 1.28593_WP*SDEV/SQRT(ZW)
CLMU800 = AMEAN + 1.28593_WP*SDEV/SQRT(ZW)
!...
!...USE 0.67575 FOR A 50.0% CONFIDENCE LEVEL
CLML500 = AMEAN - 0.67575_WP*SDEV/SQRT(ZW)
CLMU500 = AMEAN + 0.67575_WP*SDEV/SQRT(ZW)

!
!DF    = ZW - ONE_W
!RATIO = SQRT(ZW)/CV
!ALPHAD2 = (ONE_W - CONFLEV)/TWO_W
!OMAD2 = 1.0D0 - ALPHAD2
!CALL CDFT(N2,OMAD2,ALPHAD2,TLIM,DF,IER,BOUND)
!...
!...CALCULATE SKEWNESS AND KURTOSIS AS APPROPRIATE
IF (VAR /= ZERO_W) THEN
    SKEW = SKEW/(ZW*SDEV**3)
    CURT = CURT/(ZW*VAR**2)-THREE_W
ELSE
    IF (NN <= 1) WRITE (*,*) "             MOMENT ERROR: NO SKEW OR KURTOSIS WHEN ZERO VARIANCE"
ENDIF
!...
!...CALCULATE BASIC GEOMETRIC STATISTICS
!GMEAN = PRODUCT(DATA1(:))**(ONE_W/ZW)
DATA2 = REAL(DATA1, KIND=DP)
!...
!...FIRST TRANSLATE DATA VALUES IF ANY DATA VALUES <= ZERO
DO I = 1,NN
    IF (DATA2(I) <= ZERO_D) THEN
        INDICATE = 1
        EXIT
    ENDIF
ENDDO
IF (INDICATE == 1) THEN
    COEF = ONE_D
    10  CONTINUE
    IF (MINVAL(DATA2) <= ZERO_D) THEN
        DATA2A(:) = LOG10(COEF+DATA2(:)-MINVAL(DATA2))
        IF ((MINVAL(DATA2A) <= ZERO_D)) THEN
            COEF = COEF*TEN_D
            GOTO 10
        ENDIF
    ENDIF
    CALL ARRAY_COPY (DATA2A,DATA2,N_COPIED,N_NOT_COPIED)
ENDIF
!...
!...CONTINUE WITH GEOMETRIC MEAN CALCULATIONS
MM = 0
DO I = 1,NN
    IF (LOG(DATA2(I)) < ZERO_D) MM = MM+1
ENDDO
!GMEAN = ((-ONE_D)**ZM)*(EXP((ZZ)*SUM(LOG(ABS(DATA2(:))))))  ! https://en.wikipedia.org/wiki/Geometric_mean
GMEAN =  EXP((ZD)*SUM(LOG(DATA2(:))))
SDEVG =  EXP(SQRT(SUM(LOG(DATA2(:)/GMEAN)**2)*ZD))
VARG  =  SDEVG*SDEVG
CVG   = (SDEVG-ONE_D)*HUND_D                                ! http://lexjansen.com/nesug/nesug11/ph/ph10.pdfz
!...
!...CALCULATE BASIC HARMONIC STATISTICS
HMEAN =  ZN/SUM(ONE_D/DATA2(:))
!HMEAN =  EXP(AMEAN - HALF_W*VAR) - ONE_W                    ! The harmonic mean ( H ) of a lognormal distribution, [SEE https://en.wikipedia.org/wiki/Harmonic_mean]
VARH  =  ZD*SUM((DATA2(:)-HMEAN)**2)
SDEVH =  SQRT(VARH/ZN*HMEAN**4)
CVH   = (SDEVH-ONE_D)*HUND_D
!...
!...CALCULATE BASIC POWER STATISTICS
PMEAN = ZN/SUM(ONE_D/SQRT(DATA2(:)))
!...
!...CALCULATE BASIC CONTRAHARMONIC STATISTICS
CHMEAN = SUM((DATA2(:))**2)/SUM(DATA2(:))
!...
!...CALCULATE QUADRATIC MEAN
QMEAN = SQRT(SUM((DATA2(:))**2)/ZN)
!...
!...CALCULATE CUBIC MEAN
CMEAN = SQRT(SUM((DATA2(:))**3)/ZN)
!...
!...CALCULATE ROOT (QUADRATIC) MEAN SQUARE
RMS = SQRT(SUM(DATA1(:)**2)/ZW)
!...
!...COPY ALL OF ARRAY DATA1 INTO LOW END OF ARRAY MED
CALL ARRAY_COPY (DATA1,MED,NN_COPIED,NN_NOT_COPIED)
!...
!...SORT DATA1
CALL SORT_PICKED(NN,MED)
!...
!...SOLVE FOR MEDIAN
IF (NN_NOT_COPIED == 0) THEN
    IF (MOD(NN,2) == 0) THEN
        XMED = (MED(NN/2) + MED((NN/2)+1))/2
    ELSE
        XMED = MED((NN/2)+1)
    ENDIF
ENDIF
!...
!...SOLVE FOR THE MEDIAN ABSOLUTE DEVIATIONS
RR(:) = ABS(DATA1(:)-XMED)
CALL SORT_PICKED(NN,RR)
IF (MOD(NN,2) == 0) THEN
    XMAD = (RR(NN/2) + RR((NN/2)+1))/2
ELSE
    XMAD = RR((NN/2)+1)
ENDIF
!...
!...SOLVE FOR TRIMMED MEAN AFTER REMOVAL OF SELECTED END PERCENTAGES
DO I = 1,5
    IF (I == 1) ALPHA = 0.05_WP
    IF (I == 2) ALPHA = TENTH_W
    IF (I == 3) ALPHA = FIFTH_W
    IF (I == 4) ALPHA = 0.3_WP
    IF (I == 5) ALPHA = 0.4_WP
    CALL TRIMM (MED,NN,ALPHA,TRIM0,XTSIG0,K)
    CALL WINSR (MED,NN,ALPHA,WINS0,XWSIG0)
    IF (I == 1) THEN
        ALPHA1 = ALPHA
        TRIM1  = TRIM0
        XTSIG1 = XTSIG0
        WINS1  = WINS0
        XWSIG1 = XWSIG0
            K1 = K
    ELSEIF (I == 2) THEN
        ALPHA2 = ALPHA
        TRIM2  = TRIM0
        XTSIG2 = XTSIG0
        WINS2  = WINS0
        XWSIG2 = XWSIG0
            K2 = K
    ELSEIF (I == 3) THEN
        ALPHA3 = ALPHA
        TRIM3  = TRIM0
        XTSIG3 = XTSIG0
        WINS3  = WINS0
        XWSIG3 = XWSIG0
            K3 = K
    ELSEIF (I == 4) THEN
        ALPHA4 = ALPHA
        TRIM4  = TRIM0
        XTSIG4 = XTSIG0
        WINS4  = WINS0
        XWSIG4 = XWSIG0
            K4 = K
    ELSEIF (I == 5) THEN
        ALPHA5 = ALPHA
        TRIM5  = TRIM0
        XTSIG5 = XTSIG0
        WINS5  = WINS0
        XWSIG5 = XWSIG0
            K5 = K
    ENDIF
ENDDO
!...
!...SOLVE FOR THE MID-MEAN (Mid-Mean - computes a mean using the data between the 25th and 75th percentiles.)
CALL TRIMM (MED,NN,QUART_W,TRIM0,XTSIG0,K)
!...
!...PRINT FULL SET OF RESULTS
SELECT CASE (PRNT)
    CASE ("Y","y")
        USTATOUT = "STAT_DATA.OUT"
        OPEN (NEWUNIT=STATFILE, FILE = USTATOUT, STATUS = "UNKNOWN", POSITION = "REWIND")
        WRITE (STATFILE,100) V1, AMEAN, VAR, SDEV, SKEW, CURT, V1, MINVAL(DATA1), MAXVAL(DATA1), RNGE, CV, NN,                 &
                             V1, CLML950, CLMU950, STMEAN
        WRITE (STATFILE,110) GMEAN, VARG, SDEVG, CVG, XMED, XMAD
        WRITE (STATFILE,120) HMEAN, VARH, SDEVH!, CVH
        WRITE (STATFILE,125) PMEAN
        WRITE (STATFILE,130) CHMEAN
        WRITE (STATFILE,132) QMEAN
        WRITE (STATFILE,134) CMEAN
        WRITE (STATFILE,140)
        WRITE (STATFILE,150) NINT(ALPHA1*HUND_W),TRIM1,XTSIG1,WINS1,XWSIG1,K1
        WRITE (STATFILE,150) NINT(ALPHA2*HUND_W),TRIM2,XTSIG2,WINS2,XWSIG2,K2
        WRITE (STATFILE,150) NINT(ALPHA3*HUND_W),TRIM3,XTSIG3,WINS3,XWSIG3,K3
        WRITE (STATFILE,150) NINT(ALPHA4*HUND_W),TRIM4,XTSIG4,WINS4,XWSIG4,K4
        WRITE (STATFILE,150) NINT(ALPHA5*HUND_W),TRIM5,XTSIG5,WINS5,XWSIG5,K5
        WRITE (STATFILE,160)
        WRITE (STATFILE,170) TRIM0,XTSIG0
        CLOSE (STATFILE, STATUS = "KEEP")
    CASE DEFAULT
END SELECT
!...
!...FORMAT STATEMENTS
100 FORMAT (////,91("="),/,91("="),/,30X,"Univariate Statistics",//,1X,"Variable",12X,"Mean",8X,"Variance",                     &
                                      7X,"Std. Dev.",8X,"Skewness",8X,"Kurtosis",/,                                             &
                                      5X,I1,7X,F12.6,4X,F12.6,4X,F12.6,4X,F12.6,4X,F12.6,//,                                    &
                                      1X,"Variable",9X,"Minimum",9X,"Maximum",11X,"Range",6X,"Coef. Var.",11X,"Count",/,        &
                                      5X,I1,7X,F12.6,4X,F12.6,4X,F12.6,4X,F12.6,6X,I10,//,                                      &
                                      1X,"Variable",7X,"Lower CLM",7X,"Upper CLM",7X,"Std. Err.",                               &
                                      7X,"Lower CLV",7X,"Upper CLV",/,                                                          &
                                      5X,I1,7X,F12.6,4X,F12.6,4X,F12.6,//,                                                      &
                 91("="),/,91("="))
110 FORMAT (//,1X,"Geometric Mean =",F12.6,6X,"VARG =",F12.6,6X,"SDEVG =",F12.6,6X,"CVG =",F12.6,/,                             &
            //,1X,"Median =",F12.6,6X,"Median Std. Dev. =",F12.6)
120 FORMAT (//,1X,"Harmonic Mean =",F12.6,6X,"VARH =",F12.6,6X,"SDEVH =",F12.6,6X,"CVH =",F12.6)
125 FORMAT (//,1X,"Power Mean =",F12.6)
130 FORMAT (//,1X,"Contraharmonic Mean =",F12.6)
132 FORMAT (//,1X,"Quadratic Mean =",F12.6)
134 FORMAT (//,1X,"Cubic Mean =",F12.6,//)
140 FORMAT (  19X,"Trimmed Statistics",25X,"Winsorized Statistics",15X,"No. of Trimmed and",/,                                  &
               1X,"Alpha",11X,"Mean",10X,"Std. Dev.",21X,"Mean",10X,"Std. Dev.",16X,"Winsorized Obs.",/,117("-"))
150 FORMAT (   3X,I2,"%",5X,F12.6,5X,F12.6,15X,F12.6,5X,F12.6,20X,I5)
160 FORMAT (117("-"))
170 FORMAT (//,1X,"Mid-Mean =",F12.6,5X,"Mid-Mean Std. Dev. =",F12.6)
!...
!...INCLUDE SORT ROUTINE
CONTAINS
!...
!**********************************************************************************************
!...
!...
!...SUBROUTINE TO SORT DATA1 IN ASCENDING ORDER
    SUBROUTINE SORT_PICKED(NN,ARR)
!...
!...SORTS AN ARRAY ARR INTO ASCENDING NUMERICAL ORDER, BY STRAIGHT INSERTION.  ARR IS REPLACED
!...ON OUTPUT BY ITS SORTED REARRANGEMENT.
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                            :: NN
    REAL(WP), DIMENSION(1:NN), INTENT(INOUT)            :: ARR
!...
!...IDENTIFY LOCAL VARIABLES
    INTEGER(I4B)                                        :: I, J
    REAL(WP)                                            :: AA
!...
!...BEGIN SORTING
    DO J = 2,NN
        AA = ARR(J)
        DO I = J-1,1,-1
            IF (ARR(I) <= AA) EXIT
            ARR(I+1) = ARR(I)
        ENDDO
        ARR(I+1) = AA
    ENDDO
!...
!...DONE WITH SORT ROUTINE
    END SUBROUTINE SORT_PICKED
!...
!**********************************************************************************************
!...
!...
!...SUBROUTINE TO CALCULATE TRIMMED MEAN
    SUBROUTINE TRIMM (XDATA,NN,ALPHA,TRIMMED,XTSIG,K)
!...
!...THE TRIMMED MEAN FINDS THE MEAN OF THE SET OF N ORDERED STATISTICS AFTER TRIMMING THE PERCENTAGE ALPHA FROM BOTH ENDS OF THE SET.
!...THE VALUE TRIMMED IS RETURNED AS THE MEAN OF THE TRIMMED SET OF ORDERED STATISTICS.  THE WEIGHTS GIVEN TO THE ORDERED STATS
!...AND THE FORMULA FOR COMPUTATION OF THE TRIMMED MEAN CAN BE FOUND ON PAGE 311 OF UREDA.
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                       :: NINT
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                        :: NN
    INTEGER(I4B), INTENT(OUT)                       :: K
    REAL(WP), INTENT(IN)                            :: ALPHA
    REAL(WP), INTENT(OUT)                           :: TRIMMED, XTSIG
    REAL(WP), DIMENSION(1:NN), INTENT(IN)           :: XDATA
!...
!...IDENTIFY LOCAL VARIABLES
    INTEGER(I4B)                                    :: I, IG, N1=1, N2=2
    REAL(WP)                                        :: D1=ONE_W, D2=TWO_W, RR, SUM1, SUM2, AK, AN
!...
!...BEGIN CALCULATIONS
    IG = NINT(ALPHA*NN)
    AN = REAL(NN, KIND=WP)
    RR = (ALPHA*NN) - REAL(IG, KIND=WP)
    SUM1 = ZERO_W
    K = 0
    DO I = IG+N2,NN-IG-N1
        K = K+1
        SUM1 = SUM1+XDATA(I)
    ENDDO
    SUM2 = (D1-RR)*(XDATA(IG+N1) + XDATA(NN-IG))
    TRIMMED = (D1/(AN*(D1 -(D2*ALPHA))))*(SUM2+SUM1)
    AK = REAL(K, KIND=WP)
!...
!...CALCULATE TRIMMED STANDARD DEVIATION
    SUM1 = ZERO_W
    DO I = IG+N2,NN-IG-N1
        SUM1 = SUM1+(XDATA(I) - TRIMMED)**2
    ENDDO
    XTSIG = SQRT(SUM1/(AK-ONE_W))
!...
!...DONE WITH TRIMMED ROUTINE
    RETURN
    END SUBROUTINE TRIMM
!...
!**********************************************************************************************
!...
!...
!...SUBROUTINE TO CALCULATE WINSORIZED MEAN
    SUBROUTINE WINSR (XDATA,NN,ALPHA,WINSOR,XWSIG)
!...
!...THE WINSORIZED MEAN FINDS THE MEAN OF THE SET OF N ORDERED STATISTICS AFTER TRIMMING THE PERCENTAGE ALPHA FROM BOTH ENDS OF THE SET.
!...THE VALUE WINSORIZED IS RETURNED AS THE MEAN OF THE WINSORIZED SET OF ORDERED STATISTICS.  THE WEIGHTS GIVEN TO THE ORDERED STATS
!...AND THE FORMULA FOR COMPUTATION OF THE WINSORIZED MEAN CAN BE FOUND ON PAGE 311 OF UREDA.
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                       :: NINT
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                        :: NN
    REAL(WP), INTENT(IN)                            :: ALPHA
    REAL(WP), INTENT(OUT)                           :: WINSOR, XWSIG
    REAL(WP), DIMENSION(1:NN), INTENT(IN)           :: XDATA
!...
!...IDENTIFY LOCAL VARIABLES
    INTEGER(I4B)                                    :: I, IG, K, N1=1, N2=2
    REAL(WP)                                        :: SUM1, AIG, AN
!...
!...BEGIN CALCULATIONS
    IG = NINT(ALPHA*NN)
    AN = REAL(NN, KIND=WP)
    SUM1 = ZERO_W
    IF (IG < N2) RETURN
    K = 0
    DO I = IG+N2,NN-IG-N1
        K = K+1
        SUM1 = SUM1+XDATA(I)
    ENDDO
    AIG  = REAL(IG, KIND=WP)
    SUM1 = SUM1 + AIG*XDATA(IG+N2)
    SUM1 = SUM1 + AIG*XDATA(NN-IG-N1)
    WINSOR = SUM1/AN
!...
!...CALCULATE WINSOR STANDARD DEVIATION
    SUM1 = ZERO_W
    DO I = IG+N2,NN-IG-N1
        SUM1 = SUM1+(XDATA(I) - WINSOR)**2
    ENDDO
    XWSIG = SQRT(SUM1/(AN-ONE_W))
!...
!...DONE WITH WINSOR ROUTINE
    RETURN
    END SUBROUTINE WINSR
!...
!...DONE WITH FULL MOMENTS ROUTINE
END SUBROUTINE MOMENTS
