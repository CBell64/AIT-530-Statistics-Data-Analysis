!...
!...LIST OF SUBROUTINES AND ARGUMENTS
! SUBROUTINE PLOT (N1,X1,Y1,DLL,AVEE,IMK,XM,YM,IPLT,IFPLT,FILEOUTT,IEP)
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                     SUBROUTINE PLOT                  *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 03/18/15          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...SUBROUTINE TO PLOT POSSIBLE BREAKTHROUGH CURVE
SUBROUTINE PLOT (N1,X1,Y1,DLL,AVEE,IMK,XM,YM,IPLT,IFPLT,FILEOUTT,IEP)
!...
!...INCLUDE PLOT CONTROL MODULE (COLOR, LINE STYLE, ETC.)
USE DISLIN
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE AA_SIZE, ONLY : NREDUCE
!...
!...ADD PLOT CONTROL MODULE
USE PLOT_CNTL
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ABS, MAXVAL, MINVAL, TRIM
!...
!...IDENTIFY TRANSFERED VALIABLES
CHARACTER(LEN=*), INTENT(IN)                        :: FILEOUTT
INTEGER(I4B), INTENT(IN)                            :: N1, IMK, IPLT, IFPLT, IEP
REAL(WP), INTENT(IN), DIMENSION(1:N1)               :: X1, Y1
REAL(WP), INTENT(IN), DIMENSION(1:IMK)              :: XM, YM
REAL(WP), INTENT(IN)                                :: DLL, AVEE
!...
!...IDENTIFY SUBROUTINE VALIABLES
CHARACTER(LEN=4)                                    :: CDEV
CHARACTER(LEN=6)                                    :: CPOL
CHARACTER(LEN=14)                                   :: CSTR1
CHARACTER(LEN=30)                                   :: CSTR2
INTEGER(I4B)                                        :: NDIGX, NDIGY, I, ND, NN
INTEGER(I4B), PARAMETER                             :: IOPT=3, IDIR=0
REAL(SP), DIMENSION(1:N1)                           :: XX, YY, XD, YD
REAL(SP), DIMENSION(1:IMK)                          :: XM1, YM1
REAL(WP), DIMENSION(1:N1)                           :: YW
REAL(SP)                                            :: XL, XH, YL, YH, XSTEP, YSTEP, AX, BX, AY, BY, D1, A1, EN, XHADJ, YHADJ
!...
!===================================================================================
!...
!...CONVERT QUAD-PRECISION ARRAYS TO SINGLE-PRECISION ARRAYS
XX  = REAL(X1, KIND=SP)
YY  = REAL(Y1, KIND=SP)
!
XM1 = REAL(XM, KIND=SP)
YM1 = REAL(YM, KIND=SP)
!...
!...REDUCE DATA FILES AS APPROPRIATE
NN = 0
DO I = 1,N1,NREDUCE
    NN = NN+1
    XX(NN) = XX(I)
    YY(NN) = YY(I)
ENDDO
YW = REAL(YY, KIND=WP)
!...
!...CONVERT QUAD-PRECISION DETECTION LIMIT TO SINGLE-PRECISION
D1 = REAL(DLL, KIND=SP)
!...
!...CONVERT QUAD-PRECISION AVERAGE CONCENTRATION TO SINGLE-PRECISION
A1 = REAL(AVEE, KIND=SP)
!...
!...SET MINIMUM PLOT DIMENSIONS
XL = MINVAL(XX)
YL = MINVAL(YY)
!YL = ZERO_S
!...
!...SET MAXIMUM PLOT DIMENSIONS
XH = MAXVAL(XX)
YH = MAXVAL(YY)
!WRITE(*,*) XH,YH
!XH = REAL(NINT(XH,KIND=I4B),KIND=SP)
!YH = REAL(NINT(YH,KIND=I4B),KIND=SP)
!WRITE(*,*) XH,YH
!...
!...DEVELOP ARRAYS FOR DATA LESS THAN DETECTION LIMIT
ND = 0
IF (IPREPOST == 1) THEN
    DO I = 1,NN
        IF (YY(I) < D1) THEN
            ND = ND+1
            XD(ND) = XX(I)
            YD(ND) = YY(I)
        ENDIF
    ENDDO
ENDIF
!...
!...SET DISPLAY TYPE FOR SCREEN OR OUTPUT
IF (IPLT < 1) THEN
    CDEV = "XWIN"
ELSE
    IF (IEP == 1) THEN
        CDEV = "EPS"
    ELSE
        CDEV = "PDF"
    ENDIF
ENDIF
!...
!...PREVENT DISLIN PLOTTING ERROR MESSAGES FROM BEING WRITTEN TO SCREEN BY WRITING TO A FILE
CALL ERRDEV ("APPEND")
!CALL ERRMOD ("ALL","OFF")
!...
!...
!...START A NEW PAGE
!...
!...CALL DISLIN TO INITIATE PGPLOT AND OPEN THE OUTPUT DEVICES (VIDEO SCREEN AND/OR POSTSCRIPT PLOT FILE)
CALL METAFL (CDEV)
CALL SETPAG ("USAL")
CALL DISINI
!...
!...SET BACKGROUND COLOR
IF (IPLT == 0) THEN
    CALL SETVLT ("RAIN")                                !SELECTS COLOR TABLE (p. 53)
ELSE
    CALL SETVLT ("GREY")                                !SELECTS GREY TABLE (p. 53)
ENDIF
CALL PAGFLL (0)                                         !DEFAULT BLACK PAGE
IF ((IPLT > 0) .AND. (IFPLT == 3)) CALL PAGFLL (0)
!IF ((IPLT > 0) .AND. (IFPLT == 3)) CALL AXSBGD (255)
!IF ((IPLT > 0) .AND. (IFPLT == 2)) CALL AXSBGD (100)
IF (IPLT < 1) THEN
    CALL AXCLRS (190,"LABELS","XYZ")                    !COLORS FOR AXES PARTS (p. 50)
    CALL AXCLRS (230,"NAME","XYZ")                      !COLORS FOR AXES PARTS (p. 50)
ELSE
    CALL AXCLRS (255,"LABELS","XYZ")                    !COLORS FOR AXES PARTS (p. 50)
    CALL AXCLRS (255,"NAME","XYZ")                      !COLORS FOR AXES PARTS (p. 50)
ENDIF
IF ((IPLT > 0) .AND. (IFPLT == 3)) THEN
    CALL AXCLRS (190,"LABELS","XYZ")                    !COLORS FOR AXES PARTS (p. 50)
    CALL AXCLRS (230,"NAME","XYZ")                      !COLORS FOR AXES PARTS (p. 50)
ENDIF
!...
!..ADD BORDER IF NOT HARDCOPY
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!IF (IPLT < 1) CALL PAGERA
!...
!...CHOOSE A FONT
CALL COMPLX                     !...CALL WINFNT ("ARIAL BOLD") !...CALL PSFONT("HELVETICA-BOLD")
CALL TEXMOD ("ON")
!...
!...SETUP PLOT FORM
CALL SETGRF ("NAME","NAME","TICKS","TICKS")
!...
!...SET LABELS SIZE
CALL HNAME (44)
!...
!...SET LINE WIDTH
CALL LINWID (5)
!...
!...SET PROPER TIME UNITS FOR X-AXIS FOR PRE-TRACER INJECTION
IF (IPREPOST == 1) THEN
    SELECT CASE (ITM)
        CASE (1)
            CALL NAME ("Time prior to injection (d)","X")
        CASE (2)
            CALL NAME ("Time prior to injection (h)","X")
        CASE (3)
            CALL NAME ("Time prior to injection (min)","X")
        CASE (4)
            CALL NAME ("Time prior to injection (s)","X")
        CASE DEFAULT
            CALL NAME ("Time prior to injection (s)","X")
    END SELECT
ELSE
!...
!...SET PROPER TIME UNITS FOR X-AXIS FOR POST-TRACER INJECTION
    SELECT CASE (ITM)
        CASE (1)
            CALL NAME ("Time since injection (d)","X")
        CASE (2)
            CALL NAME ("Time since injection (h)","X")
        CASE (3)
            CALL NAME ("Time since injection (min)","X")
        CASE (4)
            CALL NAME ("Time since injection (s)","X")
        CASE DEFAULT
            CALL NAME ("Time since injection (s)","X")
    END SELECT
ENDIF
!...
!...SET PROPER CONCENTRATION UNITS FOR Y-AXIS
SELECT CASE (ICN)
    CASE (1)
        CALL NAME ("Concentration (kg L$^{-1}$)","Y")
    CASE (2)
        CALL NAME ("Concentration (g L$^{-1}$)","Y")
    CASE (3)
        CALL NAME ("Concentration (mg L$^{-1}$)","Y")
    CASE (4)
        CALL NAME ("Concentration ($\mu$g L$^{-1}$)","Y")
    CASE (5)
        CALL NAME ("Concentration (ng L$^{-1}$)","Y")
    CASE (6)
        CALL NAME ("Concentration (pg L$^{-1}$)","Y")
    CASE DEFAULT
        CALL NAME ("Concentration ($\mu$g L$^{-1}$)","Y")
END SELECT
!...
!...SETS AXES VALUE DISPLAY TYPE
IF (XH-XL <= ONE_S) THEN
    CALL LABDIG (2,"X")
ELSE
    CALL LABDIG (1,"X")
ENDIF
!...
IF ((ICN < 4) .OR. (ICN > 4)) THEN
    CALL LABDIG ( 1,"Y")
ELSE
    CALL LABDIG (-2,"Y")
ENDIF
!...
!...ADJUST LABELS DISPLAY
IF ((ABS(XX(1)) > ZERO_S .AND. ABS(XX(1)) <= TMIL_S) .OR. (ABS(XX(N1)) >= THOU_S)) CALL LABELS ("XEXP","X")
IF ((ICN < 4) .OR. (ICN > 4)) CALL LABELS ("XEXP","Y")
!...
!...DEFINE TICK POSITIONS
CALL TICPOS ("REVERS","XY")
!...
!...SETUP GRAPH TICK MARKS
CALL TICKS  (4,"XY")
!...
!...AUTOMATICALLY DETERMINE AXIS LIMITS
CALL SETSCL (XX,NN,"XRESET")
CALL SETSCL (YY,NN,"YRESET")
!....
!...PREPARE TITLE
IF (IPREPOST == 1) THEN
    CALL TITLIN ("TRACER RELEASE PRIOR TO INJECTION, FILE NAME:",1)
ELSE
    CALL TITLIN ("TRACER RELEASE AFTER INJECTION, FILE NAME:",1)
ENDIF
CALL TITLIN (FILEOUTT,3)
!...
!...SET FRAME WIDTH
IF ((IPLT > 0) .AND. (IFPLT == 3)) CALL COLOR ("ORANGE")
CALL FRAME (4)
!...
!...DETERMINE LABEL STEPS (NOT CURRENTLY CORRECT -- JUST TEMPORARY FOR PLACE HOLDING)
XSTEP = ABS(XH-XL)*QUART_S
YSTEP = ABS(YH-YL)*QUART_S
!...
!...DETERMINE AXIS PARAMETERS
IF ((IPLT == 1) .AND. (IFPLT == 3)) CALL COLOR ("WHITE")
CALL GAXPAR (XL,XH,"EXTEND","X",AX,BX,XL,XSTEP,NDIGX)
CALL GAXPAR (YL,YH,"EXTEND","Y",AY,BY,YL,YSTEP,NDIGY)
!...
!...ADJUST X-AXIS LENGTH
IF (XH >= TEN_S) THEN
    XHADJ = REAL(INT(XH,KIND=I4B),KIND=SP)
ELSE
    XHADJ = REAL(INT(XH*TEN_S,KIND=I4B),KIND=SP)*TENTH_S
ENDIF
IF (XHADJ < XH) THEN
    XH = XHADJ + XSTEP*HALF_S
ELSE
    XH = XHADJ
ENDIF
!...
!...ADJUST Y-AXIS LENGTH
IF (YH >= TEN_S) THEN
    YHADJ = REAL(INT(YH,KIND=I4B),KIND=SP)
ELSEIF ((YH < TEN_S) .AND. (YH >= TENTH_S)) THEN
    YHADJ = YH+HUNDTH_S*FIVE_S
    !REAL(INT(YH*TEN_S,KIND=I4B),KIND=SP)*TENTH_S
ELSE
    YHADJ = YH+THOUTH_S*FIVE_S
ENDIF
IF (YHADJ < YH) THEN
    YH = YHADJ + YSTEP*HALF_S!FIVE_S
ELSE
    YH = YHADJ
ENDIF
!...
!...PLOT GRAPH
CALL GRAF (XL,XH,XL,XSTEP,YL,YH,YL,YSTEP)
!...
!...WRITE TITLE
CALL TITLE
!...
!...ENSURE THAT PLOTTED CURVES HAVE NO SPECIAL ATTRIBUTES
CALL CHNCRV ("NONE")
!...
!...SET LINE TYPE TO SOLID AND SHADING COLOR
CALL LINTYP (0)
CALL SETVLT ("RAIN")
!...
!...SET LINE WIDTH
CALL LINWID (7)
!...
!...DETERMINE INTERPOLATION METHOD
CPOL = "LINEAR"
CALL POLCRV (CPOL)
!...
!...SET MARKER SIZE AND SHAPE
CALL HSYMBL (30)
CALL MARKER (15)
!...
!...SET LINE WIDTH
CALL LINWID (7)
!...
!...DRAW CURVE IF INITIAL DATA FILE
SELECT CASE (PLINE)
    CASE ("N","n")
        CALL INCMRK (-1)
    CASE DEFAULT                ! PLINE = YES
        CALL INCMRK (0)
END SELECT
SELECT CASE (PL)
    CASE ("L","l")
        CALL CHNCRV ("NONE")
        CALL SOLID
        IF (IPLT /= 1) CALL COLOR ("RED")
        IF ((IPLT > 0) .AND. (IFPLT == 2 .OR. IFPLT == 3)) CALL COLOR ("RED")
        CPOL = "LINEAR"
        CALL POLCRV (CPOL)
        CALL CURVE  (XX,YY,NN)
    CASE DEFAULT
        CALL CHNCRV ("NONE")
        CALL SOLID
        SELECT CASE (PLINE)
            CASE ("Y","y")
                IF (IPLT /= 1) CALL COLOR ("RED")
                IF ((IPLT > 0) .AND. (IFPLT == 2 .OR. IFPLT == 3)) CALL COLOR ("RED")
            CASE DEFAULT
                CONTINUE
        END SELECT
        CPOL = "LINEAR"
        CALL POLCRV (CPOL)
        CALL CURVE  (XX,YY,NN)
!...
!...PLOT DATA POINTS
        IF (IPLT <= 0) THEN
            IF (IPLT == 0) THEN
                CALL COLOR ("GREEN")
            ELSE
!                CALL SETCLR (200)                  !FILLS PLOT SYMBOLS WITH LIGHT GREY BACKGROUND
                CALL SETRGB (1., 1., 1.)            !FILLS PLOT SYMBOLS WITH WHITE BACKGROUND
                CALL HSYMBL (20)
            ENDIF
            CALL INCMRK (-1)
            CALL MARKER (21)
            CALL CURVE (XX,YY,NN)
        ENDIF
!
        IF (IPLT == 0) THEN
            CALL COLOR ("BLUE")
        ELSEIF  ((IPLT > 0) .AND. (IFPLT == 3)) THEN
            CALL SETRGB(0., 1., 0.)                 !PLOT SYMBOL DISPLAYED AS GREEN
        ELSE
            CALL SETRGB (0., 0., 0.)                !PLOT SYMBOL DISPLAYED AS BLACK
            IF (IFPLT == 2) THEN
                CALL COLOR ("BLUE")
            ELSEIF (IFPLT == 1) THEN
                CALL SETVLT("GREY")
                CALL SETCLR(130)
            ENDIF
        ENDIF
!
        CALL INCMRK (-1)
        IF (IPLT == 0) THEN
            CALL HSYMBL (40)
        ELSE
            IF ((IFPLT == 2) .OR. (IFPLT == 3)) CALL HSYMBL (40)
            CALL HSYMBL (25)
        ENDIF
        IF (IPREPOST == 1) THEN
            CALL COLOR ("GREEN")
            CALL MARKER (21)
            CALL CURVE (XD,YD,ND)
        ENDIF
        CALL COLOR ("BLUE")
        CALL MARKER (15)
        CALL CURVE (XX,YY,NN)
        CALL SETRGB (0., 0., 0.)
END SELECT
!...
!...MARK DOWNLOAD VALUES (POSSIBLE ERRONEOUS DATA)
SELECT CASE (DNPLOT)
    CASE ("Y","y")
        SELECT CASE (DPMARK)
            CASE ("Y","y")
                IF (IPLT == 0) THEN
                    CALL HSYMBL (50)
                ELSE
                    IF ((IFPLT == 2) .OR. (IFPLT == 3)) CALL HSYMBL (50)
                ENDIF
                CALL COLOR ("ORANGE")
                CALL MARKER (0)
                CALL CURVE (XM1,YM1,IMK)
                IF (IPLT == 0) THEN
                    CALL HSYMBL (25)
                    CALL COLOR ("WHITE")
                ELSE
                    IF ((IFPLT == 2) .OR. (IFPLT == 3)) CALL HSYMBL (25)
                    CALL HSYMBL (15)
                    CALL COLOR ("GREEN")
                ENDIF
                CALL MARKER (21)
                CALL CURVE (XM1,YM1,IMK)
            CASE ("N","n")
                CONTINUE
            CASE DEFAULT
                CONTINUE
        END SELECT
    CASE ("N","n")
        CONTINUE
    CASE DEFAULT
        SELECT CASE (DPMARK)
            CASE ("Y","y")
                IF (IPLT == 0) THEN
                    CALL HSYMBL (50)
                ELSE
                    IF ((IFPLT == 2) .OR. (IFPLT == 3)) CALL HSYMBL (50)
                ENDIF
                CALL COLOR ("ORANGE")
                CALL MARKER (0)
                CALL CURVE (XM1,YM1,IMK)
                IF (IPLT == 0) THEN
                    CALL HSYMBL (25)
                    CALL COLOR ("WHITE")
                ELSE
                    IF ((IFPLT == 2) .OR. (IFPLT == 3)) CALL HSYMBL (25)
                    CALL HSYMBL (15)
                    CALL COLOR ("GREEN")
                ENDIF
                CALL MARKER (21)
                CALL CURVE (XM1,YM1,IMK)
            CASE ("N","n")
                CONTINUE
            CASE DEFAULT
                CONTINUE
        END SELECT
END SELECT
!...
!...SET LINE WIDTH
CALL LINWID (5)
!...
!...DRAW HORIZONTAL DETECTION LIMIT DOTTED LINE
CALL COLOR ("WHITE")
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CALL RLMESS ("Detection Limit",HUND_S,0.03_SP)
CALL LINWID (4)
CALL DASHL
CALL RLINE (XL,D1,XH,D1)
!...
!...SET LINE WIDTH
CALL LINWID (5)
!...
!...DRAW HORIZONTAL AVERAGE CONCENTRATION DASHED LINE
!!!CALL RLMESS ("Mean Concentration",132.0_SP,FIFTH_S)
!!!CALL LINWID (4)
!!!CALL DASH
!!!CALL RLINE (XL,A1,XH,A1)
!...
!...SET LINE WIDTH
CALL LINWID (5)
!...
!...REPORT NUMBER OF DATA POINTS PLOTTED
EN = REAL(NN, KIND=SP)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CALL RLMESS ("Num of data = ",125.5_SP,0.475_SP)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CALL RLNUMB (EN,-1,150.0_SP,0.475_SP)
!...
!...SET LINE WIDTH
CALL LINWID (3)
!...
!...PRINT PAGE HEADER INFORMATION
IF (IMETHOD == 0) THEN
    CSTR2 = TRIM("ALL MEASURED DATA")
ELSEIF (IMETHOD == 4) THEN
    CSTR2 = TRIM("SUBSET OF MEASURED DATA")
ENDIF
CSTR1 = "PLOTTING FILE:"
CALL COLOR ("CYAN")
IF ((CDEV == "EPS") .OR. (CDEV == "PDF")) CALL COLOR ("WHITE")
CALL PAGHDR (CSTR1,CSTR2,IOPT,IDIR)
!...
!...DISLIN PLOTTING
CALL DISFIN
OPEN  (21, FILE = "dislin.err", STATUS = "UNKNOWN")
CLOSE (21, STATUS = "DELETE")
RETURN
!...
!...DONE WITH SUBROUTINE PLOT
END SUBROUTINE PLOT



!...
!...LIST OF SUBROUTINES AND ARGUMENTS
! SUBROUTINE PLOT_DISTRIBUTION (N1,X1,Y1,IPLT,IFPLT,FILERSD,NPLT)
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *             SUBROUTINE PLOT_DISTRIBUTION             *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 04/08/19          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...SUBROUTINE TO PLOT POSSIBLE BREAKTHROUGH CURVE
SUBROUTINE PLOT_DISTRIBUTION (N1,X1,Y1,IPLT,IFPLT,FILERSD,ILABEL,IGMIN,IPP)
!...
!...INCLUDE PLOT CONTROL MODULE (COLOR, LINE STYLE, ETC.)
USE DISLIN
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ADD PLOT CONTROL MODULE
USE PLOT_CNTL,  ONLY : ICN, IMETHOD
!...
!...ADD INTERPOLATION ROUTINE
USE INTERPOLATION
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ABS, MAXVAL, MINVAL, TRIM
!...
!...DECLARE TRANSFERRED VARIABLES
CHARACTER(LEN=*), INTENT(IN)                        :: FILERSD
INTEGER(I4B), INTENT(IN)                            :: N1, IPLT, IFPLT, ILABEL, IGMIN, IPP
REAL(WP), INTENT(IN), DIMENSION(1:N1)               :: X1, Y1
!...
!...IDENTIFY SUBROUTINE VALIABLES
CHARACTER(LEN=4)                                    :: CDEV
CHARACTER(LEN=6)                                    :: CPOL
CHARACTER(LEN=18)                                   :: CSTR1
CHARACTER(LEN=30)                                   :: CSTR2
INTEGER(I4B)                                        :: ID2, NDIGX, NDIGY, MZ, ISMTH, I
INTEGER(I4B), PARAMETER                             :: IOPT=3, IDIR=0, NZ=100
REAL(SP)                                            :: XL, XH, XM, YL, YH, XSTEP, YSTEP, AX, BX, AY, BY, A, B, D, R, PROB, Z
REAL(SP), DIMENSION(1:N1)                           :: XX, YY
REAL(SP), DIMENSION(N1*NZ)                          :: XZ, YZ
!...
!===================================================================================
!...
!...CONVERT SMOOTHING AGVERAGE QUAD-PRECISION ARRAYS TO SINGLE-PRECISION ARRAYS
XX = REAL(X1,  KIND=SP)
YY = REAL(Y1,  KIND=SP)
!...
!...SET MINIMUM PLOT DIMENSIONS
XL = MINVAL(XX)
YL = MINVAL(YY)
!...
!...SET MAXIMUM PLOT DIMENSIONS
XH = MAXVAL(XX)
XM = XH/TEN_S
XH = XH+XM
IF (IPP == 1) XH = 1.05_SP
IF (IGMIN == 2) THEN
    YH = ABS(YY(2))
ELSE
    YH = MAXVAL(YY)
    YH = YH + YH/FOUR_S
ENDIF
!...
!...SET DISPLAY TYPE FOR SCREEN OR OUTPUT
IF (IPLT < 1) THEN
    CDEV = "XWIN"
ELSE
    CDEV = "PDF"
ENDIF
!...
!...PREVENT DISLIN PLOTTING ERROR MESSAGES FROM BEING WRITTEN TO SCREEN BY WRITING TO A FILE
CALL ERRDEV ("APPEND")
!CALL ERRMOD ("ALL","OFF")
!...
!...
!...START A NEW PAGE
!...
!...CALL DISLIN TO INITIATE PGPLOT AND OPEN THE OUTPUT DEVICES (VIDEO SCREEN AND/OR POSTSCRIPT PLOT FILE)
CALL METAFL (CDEV)
CALL SETPAG ("USAL")
CALL DISINI
!...
!...SET BACKGROUND COLOR
IF (IPLT == 0) THEN
    CALL SETVLT ("RAIN")                                !SELECTS COLOR TABLE (p. 53)
ELSE
    CALL SETVLT ("GREY")                                !SELECTS GREY TABLE (p. 53)
ENDIF
CALL PAGFLL (0)                                         !DEFAULT BLACK PAGE
IF ((IPLT > 0) .AND. (IFPLT == 3)) CALL PAGFLL (0)
IF (IPLT < 1) THEN
    CALL AXCLRS (190,"LABELS","XYZ")                    !COLORS FOR AXES PARTS (p. 50)
    CALL AXCLRS (230,"NAME","XYZ")                      !COLORS FOR AXES PARTS (p. 50)
ELSE
    CALL AXCLRS (255,"LABELS","XYZ")                    !COLORS FOR AXES PARTS (p. 50)
    CALL AXCLRS (255,"NAME","XYZ")                      !COLORS FOR AXES PARTS (p. 50)
ENDIF
IF ((IPLT > 0) .AND. (IFPLT == 3)) THEN
    CALL AXCLRS (190,"LABELS","XYZ")                    !COLORS FOR AXES PARTS (p. 50)
    CALL AXCLRS (230,"NAME","XYZ")                      !COLORS FOR AXES PARTS (p. 50)
ENDIF
!...
!..ADD BORDER IF NOT HARDCOPY
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!IF (IPLT < 1) CALL PAGERA
!...
!...CHOOSE A FONT
CALL COMPLX
!CALL WINFNT ("ARIAL BOLD")
!CALL PSFONT("HELVETICA-BOLD")
CALL TEXMOD ("ON")
!...
!...SETUP PLOT FORM
CALL SETGRF ("NAME","NAME","TICKS","TICKS")
!...
!...SET LABELS SIZE
CALL HNAME (44)
!...
!...SET LINE WIDTH
CALL LINWID (5)
!...
!...SET AXIS LABELS
SELECT CASE (ILABEL)
    CASE (1)
        CALL NAME ("Theoretical Quantile","X")
        SELECT CASE (ICN)
            CASE (1)
                CALL NAME ("Concentration (kg L$^{-1}$)","Y")
            CASE (2)
                CALL NAME ("Concentration (g L$^{-1}$)","Y")
            CASE (3)
                CALL NAME ("Concentration (mg L$^{-1}$)","Y")
            CASE (4)
                CALL NAME ("Concentration ($\mu$g L$^{-1}$)","Y")
            CASE (5)
                CALL NAME ("Concentration (ng L$^{-1}$)","Y")
            CASE (6)
                CALL NAME ("Concentration (pg L$^{-1}$)","Y")
            CASE DEFAULT
                CALL NAME ("Concentration ($\mu$g L$^{-1}$)","Y")
        END SELECT
    CASE (2)
        CALL NAME ("Probability","X")
        CALL NAME ("Percent Point Function","Y")
END SELECT
!...
!...SETS AXES VALUE DISPLAY TYPE
CALL LABDIG (1,"X")
IF (XH-XL <= ONE_S) CALL LABDIG (2,"X")
CALL LABDIG (2,"Y")
!...
!...ADJUST LABELS DISPLAY
IF ((ABS(XX(1)) > ZERO_S .AND. ABS(XX(1)) <= TNAN_S) .OR. (ABS(XX(N1)) >= THOU_S)) CALL LABELS ("XEXP","X")
!...
!...DEFINE TICK POSITIONS
CALL TICPOS ("REVERS","XY")
!...
!...SETUP GRAPH TICK MARKS
CALL TICKS  (4,"XY")
!...
!...AUTOMATICALLY DETERMINE AXIS LIMITS
CALL SETSCL (XX,N1,"XRESET")
CALL SETSCL (YY,N1,"YRESET")
!....
!...PREPARE TITLE
CALL TITLIN (FILERSD,3)
!...
!...SET FRAME WIDTH
IF ((IPLT > 0) .AND. (IFPLT == 3)) CALL COLOR ("ORANGE")
CALL FRAME (4)
!...
!...DETERMINE LABEL STEPS (NOT CURRENTLY CORRECT -- JUST TEMPORARY FOR PLACE HOLDING)
XSTEP = ABS(XH-XL)*QUART_S
YSTEP = ABS(YH-YL)*QUART_S
!...
!...PLOT GRAPH
IF ((IPLT == 1) .AND. (IFPLT == 3)) CALL COLOR ("WHITE")
CALL GAXPAR (XL,XH,"EXTEND","X",AX,BX,XL,XSTEP,NDIGX)
CALL GAXPAR (YL,YH,"EXTEND","Y",AY,BY,YL,YSTEP,NDIGY)
CALL GRAF   (XL,XH,XL,XSTEP,YL,YH,YL,YSTEP)
!...
!...WRITE TITLE
CALL TITLE
!...
!...ENSURE THAT PLOTTED CURVES HAVE NO SPECIAL ATTRIBUTES
CALL CHNCRV ("NONE")
!...
!...SET LINE TYPE TO SOLID AND SHADING COLOR
CALL LINTYP (0)
CALL SETVLT ("RAIN")
!...
!...SET LINE WIDTH
CALL LINWID (7)
!...
!...DETERMINE INTERPOLATION METHOD
CPOL = "LINEAR"
CALL POLCRV (CPOL)
!...
!...SET NUMBER OF POINTS AT WHICH THE FUNCTIONS ARE TO BE EVALUATED
MZ = N1*NZ
!...
!...SET MARKER SIZE AND SHAPE
CALL HSYMBL (30)
CALL MARKER (15)
!...
!...PLOT ORIGINAL DATA POINTS
CALL SETVLT ("RAIN")
IF (IPLT <= 0) THEN
    IF (IPLT == 0) THEN
        CALL COLOR ("GREEN")
    ELSE
!        CALL SETCLR (200)                  !FILLS PLOT SYMBOLS WITH LIGHT GREY BACKGROUND
        CALL SETRGB (1., 1., 1.)            !FILLS PLOT SYMBOLS WITH WHITE BACKGROUND
        CALL HSYMBL (20)
    ENDIF
    CALL INCMRK (-1)
    CALL MARKER (21)
    CALL CURVE (XX,YY,N1)
ENDIF
!
IF (IPLT == 0) THEN
    CALL COLOR ("BLUE")
ELSEIF  ((IPLT > 0) .AND. (IFPLT == 3)) THEN
    CALL SETRGB(0., 1., 0.)                 !PLOT SYMBOL DISPLAYED AS GREEN
ELSE
    CALL SETRGB (0., 0., 0.)                !PLOT SYMBOL DISPLAYED AS BLACK
    IF (IFPLT == 2) THEN
        CALL COLOR ("BLUE")
    ELSEIF (IFPLT == 1) THEN
        CALL SETVLT("GREY")
        CALL SETCLR(130)
    ENDIF
ENDIF
!
CALL INCMRK (-1)
IF (IPLT == 0) THEN
    CALL HSYMBL (40)
ELSE
    IF ((IFPLT == 2) .OR. (IFPLT == 3)) CALL HSYMBL (40)
    CALL HSYMBL (25)
ENDIF
CALL MARKER (15)
CALL CURVE (XX,YY,N1)
CALL SETRGB (0., 0., 0.)
CALL SETVLT ("RAIN")
!...
!...PLOT A SMOOTH INTERPOLATED LINE TO THE PPI DATA
CALL INCMRK (0)
CALL COLOR  ("RED")
IF ((IPLT == 1) .AND. (IFPLT == 1)) CALL COLOR ("WHITE")
IF (IPP == 1) THEN
!...
!...SET LINE WIDTH
    CALL LINWID (7)
!...
!...SET SPLINE CONTROL TO TRUE (ISMTH = 1)
    ISMTH = 0
!...
!...SOLVE FOR PIECEWISE CUBIC INTERPOLATION FOR CTDAT AND PLOT DATA CURVE
    CALL STEPIN (N1,XX,YY,MZ,XZ,YZ,ISMTH)
    CALL CURVE  (XZ,YZ,MZ)
ELSE
!...
!...PLOT A STRAIGHT LINE THROUGH THE DATA
    CALL LEAST_SQUARE (N1,XX,YY,A,B,D)
    DO I = 1,N1
        YZ(I) = B*XX(I) + A
    ENDDO
    CALL CURVE  (XX,YZ,N1)
    CALL PEARSN (YY,YZ,N1,R,PROB,Z)
    WRITE (*,100) R
    WRITE (*,110) SUPERSC2_C,R*R
ENDIF
CALL COLOR ("WHITE")
!...
!...SET LINE WIDTH
CALL LINWID (3)
!...
!...PRINT PAGE HEADER INFORMATION
IF (IMETHOD == 0) THEN
    CSTR2 = TRIM("ALL MEASURED DATA")
ELSEIF (IMETHOD == 1) THEN
    CSTR2 = TRIM("MOVING-AVERAGE SMOOTHING")
ELSEIF (IMETHOD == 2) THEN
    CSTR2 = TRIM("MOVING-MEDIAN SMOOTHING")
ELSEIF (IMETHOD == 3) THEN
    CSTR2 = TRIM("SAVITZKY-GOLAY SMOOTHING")
ELSEIF (IMETHOD == 4) THEN
    CSTR2 = TRIM("SUBSET OF MEASURED DATA")
ELSEIF (IMETHOD == 5) THEN
    CSTR2 = TRIM("GLKERN SMOOTHING")
ELSEIF (IMETHOD == 6) THEN
    CSTR2 = TRIM("LOKERN SMOOTHING")
ELSEIF (IMETHOD == 7) THEN
    CSTR2 = TRIM("FFT SMOOTHING")
ELSEIF (IMETHOD == 8) THEN
    CSTR2 = TRIM("EXPON. AVERAGE SMOOTHING")
ELSEIF (IMETHOD == 9) THEN
    CSTR2 = TRIM("QUINTIC-SPLINE SMOOTHING")
ELSEIF (IMETHOD == 10) THEN
    CSTR2 = TRIM("LOCAL REGRESS. SMOOTHING")
ELSEIF (IMETHOD == 11) THEN
    CSTR2 = TRIM("CUBIC-SPLINE SMOOTHING")
ELSEIF (IMETHOD == 12) THEN
    CSTR2 = TRIM("BUTTERWORTH FILTER")
ELSEIF (IMETHOD == 13) THEN
    CSTR2 = TRIM("WEIGHTED-QUINTIC-SPLINE")
ELSEIF (IMETHOD == 14) THEN
    CSTR2 = TRIM("B-SPLINE SMOOTHING")
ELSEIF (IMETHOD == 15) THEN
    CSTR2 = TRIM("POLYNOMIAL FIT")
ELSEIF (IMETHOD == 16) THEN
    CSTR2 = TRIM("CURVE FIT")
ENDIF
CSTR1 = "DISTRIBUTION FILE:"
CALL COLOR ("CYAN")
IF (CDEV == "PDF") CALL COLOR ("WHITE")
CALL PAGHDR (CSTR1,CSTR2,IOPT,IDIR)
!...
!...FORMAT STATEMENTS
100 FORMAT (//,10X,"R  =",F10.6)
110 FORMAT (10X,"R",A1, " =",F10.6)
!...
!...DONE
CALL DISFIN
OPEN  (NEWUNIT=ID2, FILE = "dislin.err", STATUS = "UNKNOWN")
CLOSE (ID2, STATUS = "DELETE")
!...
!****************************************************************
!...
CONTAINS
!...
!***************************************************
!*        LINEAR LEAST SQUARES SUBROUTINE          *
!* ----------------------------------------------- *
!* THE INPUT DATA SET IS X(N), Y(N). THE NUMBER OF *
!* DATA POINTS IS N (N MUST BE > 2). THE RETURNED  *
!* PARAMETERS ARE: A,B, COEFFICIENTS OF EQUATION   *
!* Y = A + B X, AND D, STANDARD DEVIATION OF FIT.  *
!***************************************************
    SUBROUTINE LEAST_SQUARE (N,X,Y,A,B,D)
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                       :: SQRT, SUM
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                        :: N
    REAL(SP), INTENT(OUT)                           :: A, B, D
    REAL(SP), DIMENSION(1:N), INTENT(IN)            :: X, Y
!...
!...IDENTIFY SUBROUTINE VALIABLES
    REAL(WP)                                        :: A1, A2, B0, B1, AA, BB, DD
    REAL(WP), DIMENSION(0:N-1)                      :: XW, YW
!...
!===================================================================================
!...
!...CONVERT SINGLE PRECISION ARRAYS TO DOUBLE PRECISION ARRAYS
    XW = REAL(X, KIND=WP)
    YW = REAL(Y, KIND=WP)
!...
!...CALCULATE ARITHMETIC MEANS
    A1 = SUM(XW)   /REAL(N, KIND=WP)
    A2 = SUM(XW*XW)/REAL(N, KIND=WP)
    B0 = SUM(YW)   /REAL(N, KIND=WP)
    B1 = SUM(YW*XW)/REAL(N, KIND=WP)
!...
!...CALCULATE ADDITIONAL PARAMETERS
    DD = A1*A1 - A2
    AA = A1*B1 - A2*B0
    AA = AA/DD
    BB = A1*B0 - B1
    BB = BB/DD
!...
!...CALCULATE STANDARD DEVIATION DD (UNBIASED ESTIMATE)
    DD = SQRT(SUM((YW - AA - BB*XW)**2)/(REAL(N-2, KIND=WP)))
!...
!...CONVERT CALCULATED PARAMETERS TO SINGLE PRECISION
    A = REAL(AA, KIND=SP)
    B = REAL(BB, KIND=SP)
    D = REAL(DD, KIND=SP)
!...
!...DONE WITH SUBROUTINE LEAST_SQUARE
    RETURN
    END SUBROUTINE LEAST_SQUARE
!...
!...DONE WITH SUBROUTINE PLOT
END SUBROUTINE PLOT_DISTRIBUTION
