! WSC@RESEARCH.BELL-LABS.COM MON DEC 30 16:55 EST 1985
! W. S. CLEVELAND
! BELL LABORATORIES
! MURRAY HILL NJ 07974
!
! OUTLINE OF THIS FILE:
!    LINES 1-72   INTRODUCTION
!        73-177   DOCUMENTATION FOR LOWESS
!       178-238   RATFOR VERSION OF LOWESS
!       239-301   DOCUMENTATION FOR LOWEST
!       302-350   RATFOR VERSION OF LOWEST
!       351-END   TEST DRIVER AND FORTRAN VERSION OF LOWESS AND LOWEST
!
!   A MULTIVARIATE VERSION IS AVAILABLE BY "SEND DLOESS FROM A"
!
!              COMPUTER PROGRAMS FOR LOCALLY WEIGHTED REGRESSION
!
!             THIS PACKAGE CONSISTS  OF  TWO  FORTRAN  PROGRAMS  FOR
!        SMOOTHING    SCATTERPLOTS   BY   ROBUST   LOCALLY   WEIGHTED
!        REGRESSION, OR LOWESS.   THE  PRINCIPAL  ROUTINE  IS  LOWESS
!        WHICH   COMPUTES   THE  SMOOTHED  VALUES  USING  THE  METHOD
!        DESCRIBED IN THE ELEMENTS OF GRAPHING DATA, BY WILLIAM S.
!        CLEVELAND    (WADSWORTH,    555 MOREGO   STREET,   MONTEREY,
!        CALIFORNIA 93940).
!
!             LOWESS CALLS A SUPPORT ROUTINE, LOWEST, THE CODE FOR
!        WHICH IS INCLUDED. LOWESS ALSO CALLS A ROUTINE  SORT,  WHICH
!        THE USER MUST PROVIDE.
!
!             TO REDUCE THE COMPUTATIONS, LOWESS  REQUIRES  THAT  THE
!        ARRAYS  X  AND  Y,  WHICH  ARE  THE  HORIZONTAL AND VERTICAL
!        COORDINATES, RESPECTIVELY, OF THE SCATTERPLOT, BE SUCH  THAT
!        X  IS  SORTED  FROM  SMALLEST  TO  LARGEST.   THE  USER MUST
!        THEREFORE USE ANOTHER SORT ROUTINE WHICH WILL SORT X  AND  Y
!        ACCORDING  TO X.
!             TO SUMMARIZE THE SCATTERPLOT, YS,  THE  FITTED  VALUES,
!        SHOULD  BE  PLOTTED  AGAINST X.   NO  GRAPHICS  ROUTINES ARE
!        AVAILABLE IN THE PACKAGE AND MUST BE SUPPLIED BY THE USER.
!
!             THE FORTRAN CODE FOR THE ROUTINES LOWESS AND LOWEST HAS
!        BEEN   GENERATED   FROM   HIGHER   LEVEL   RATFOR   PROGRAMS
!        (B. W. KERNIGHAN, ``RATFOR:  A PREPROCESSOR FOR  A  RATIONAL
!        FORTRAN,''  SOFTWARE PRACTICE AND EXPERIENCE, VOL. 5 (1975),
!        WHICH ARE ALSO INCLUDED.
!
!             THE FOLLOWING ARE DATA AND OUTPUT FROM LOWESS THAT  CAN
!        BE  USED  TO CHECK YOUR IMPLEMENTATION OF THE ROUTINES.  THE
!        NOTATION (10)V MEANS 10 VALUES OF V.
!
!
!
!
!        X VALUES:
!          1  2  3  4  5  (10)6  8  10  12  14  50
!
!        Y VALUES:
!           18  2  15  6  10  4  16  11  7  3  14  17  20  12  9  13  1  8  5  19
!
!
!        YS VALUES WITH F = .25, NSTEPS = 0, DELTA = 0.0
!         13.659  11.145  8.701  9.722  10.000  (10)11.300  13.000  6.440  5.596
!           5.456  18.998
!
!        YS VALUES WITH F = .25, NSTEPS = 0 ,  DELTA = 3.0
!          13.659  12.347  11.034  9.722  10.511  (10)11.300  13.000  6.440  5.596
!            5.456  18.998
!
!        YS VALUES WITH F = .25, NSTEPS = 2, DELTA = 0.0
!          14.811  12.115  8.984  9.676  10.000  (10)11.346  13.000  6.734  5.744
!            5.415  18.998
!
!
!
!
!                                   LOWESS
!
!
!
!        CALLING SEQUENCE
!
!        CALL LOWESS(X,Y,N,F,NSTEPS,DELTA,YS,RW,RES)
!
!        PURPOSE
!
!        LOWESS COMPUTES THE SMOOTH OF A SCATTERPLOT OF Y  AGAINST  X
!        USING  ROBUST  LOCALLY  WEIGHTED REGRESSION.  FITTED VALUES,
!        YS, ARE COMPUTED AT EACH OF THE  VALUES  OF  THE  HORIZONTAL
!        AXIS IN X.
!
!        ARGUMENT DESCRIPTION
!
!              X = INPUT; ABSCISSAS OF THE POINTS ON THE
!                  SCATTERPLOT; THE VALUES IN X MUST BE ORDERED
!                  FROM SMALLEST TO LARGEST.
!              Y = INPUT; ORDINATES OF THE POINTS ON THE
!                  SCATTERPLOT.
!              N = INPUT; DIMENSION OF X,Y,YS,RW, AND RES.
!              F = INPUT; SPECIFIES THE AMOUNT OF SMOOTHING; F IS
!                  THE FRACTION OF POINTS USED TO COMPUTE EACH
!                  FITTED VALUE; AS F INCREASES THE SMOOTHED VALUES
!                  BECOME SMOOTHER; CHOOSING F IN THE RANGE .2 TO
!                  .8 USUALLY RESULTS IN A GOOD FIT; IF YOU HAVE NO
!                  IDEA WHICH VALUE TO USE, TRY F = .5.
!         NSTEPS = INPUT; THE NUMBER OF ITERATIONS IN THE ROBUST
!                  FIT; IF NSTEPS = 0, THE NONROBUST FIT IS
!                  RETURNED; SETTING NSTEPS EQUAL TO 2 SHOULD SERVE
!                  MOST PURPOSES.
!          DELTA = INPUT; NONNEGATIVE PARAMETER WHICH MAY BE USED
!                  TO SAVE COMPUTATIONS; IF N IS LESS THAN 100, SET
!                  DELTA EQUAL TO 0.0; IF N IS GREATER THAN 100 YOU
!                  SHOULD FIND OUT HOW DELTA WORKS BY READING THE
!                  ADDITIONAL INSTRUCTIONS SECTION.
!             YS = OUTPUT; FITTED VALUES; YS(I) IS THE FITTED VALUE
!                  AT X(I); TO SUMMARIZE THE SCATTERPLOT, YS(I)
!                  SHOULD BE PLOTTED AGAINST X(I).
!             RW = OUTPUT; ROBUSTNESS WEIGHTS; RW(I) IS THE WEIGHT
!                  GIVEN TO THE POINT (X(I),Y(I)); IF NSTEPS = 0,
!                  RW IS NOT USED.
!            RES = OUTPUT; RESIDUALS; RES(I) = Y(I)-YS(I).
!
!
!        OTHER PROGRAMS CALLED
!
!               LOWEST
!               SSORT
!
!        ADDITIONAL INSTRUCTIONS
!
!        DELTA CAN BE USED TO SAVE COMPUTATIONS.   VERY  ROUGHLY  THE
!        ALGORITHM  IS  THIS:   ON THE INITIAL FIT AND ON EACH OF THE
!        NSTEPS ITERATIONS LOCALLY WEIGHTED REGRESSION FITTED  VALUES
!        ARE COMPUTED AT POINTS IN X WHICH ARE SPACED, ROUGHLY, DELTA
!        APART; THEN THE FITTED VALUES AT THE  REMAINING  POINTS  ARE
!        COMPUTED  USING  LINEAR  INTERPOLATION.   THE  FIRST LOCALLY
!        WEIGHTED REGRESSION (L.W.R.) COMPUTATION IS CARRIED  OUT  AT
!        X(1)  AND  THE  LAST  IS  CARRIED  OUT AT X(N).  SUPPOSE THE
!        L.W.R. COMPUTATION IS CARRIED OUT AT  X(I).   IF  X(I+1)  IS
!        GREATER  THAN  OR  EQUAL  TO  X(I)+DELTA,  THE  NEXT  L.W.R.
!        COMPUTATION IS CARRIED OUT AT X(I+1).   IF  X(I+1)  IS  LESS
!        THAN X(I)+DELTA, THE NEXT L.W.R.  COMPUTATION IS CARRIED OUT
!        AT THE LARGEST X(J) WHICH IS GREATER THAN OR EQUAL  TO  X(I)
!        BUT  IS NOT GREATER THAN X(I)+DELTA.  THEN THE FITTED VALUES
!        FOR X(K) BETWEEN X(I)  AND  X(J),  IF  THERE  ARE  ANY,  ARE
!        COMPUTED  BY  LINEAR  INTERPOLATION  OF THE FITTED VALUES AT
!        X(I) AND X(J).  IF N IS LESS THAN 100 THEN DELTA CAN BE  SET
!        TO  0.0  SINCE  THE  COMPUTATION TIME WILL NOT BE TOO GREAT.
!        FOR LARGER N IT IS TYPICALLY NOT NECESSARY TO CARRY OUT  THE
!        L.W.R.  COMPUTATION FOR ALL POINTS, SO THAT MUCH COMPUTATION
!        TIME CAN BE SAVED BY TAKING DELTA TO BE  GREATER  THAN  0.0.
!        IF  DELTA =  RANGE  (X)/K  THEN,  IF  THE  VALUES  IN X WERE
!        UNIFORMLY  SCATTERED  OVER  THE  RANGE,  THE   FULL   L.W.R.
!        COMPUTATION  WOULD BE CARRIED OUT AT APPROXIMATELY K POINTS.
!        TAKING K TO BE 50 OFTEN WORKS WELL.
!
!        METHOD
!
!        THE FITTED VALUES ARE COMPUTED BY USING THE NEAREST NEIGHBOR
!        ROUTINE  AND  ROBUST LOCALLY WEIGHTED REGRESSION OF DEGREE 1
!        WITH THE TRICUBE WEIGHT FUNCTION.  A FEW ADDITIONAL FEATURES
!        HAVE  BEEN  ADDED.  SUPPOSE R IS FN TRUNCATED TO AN INTEGER.
!        LET  H  BE  THE  DISTANCE  TO  THE  R-TH  NEAREST   NEIGHBOR
!        FROM X(I).   ALL  POINTS WITHIN H OF X(I) ARE USED.  THUS IF
!        THE R-TH NEAREST NEIGHBOR IS EXACTLY THE  SAME  DISTANCE  AS
!        OTHER  POINTS,  MORE  THAN R POINTS CAN POSSIBLY BE USED FOR
!        THE SMOOTH AT  X(I).   THERE  ARE  TWO  CASES  WHERE  ROBUST
!        LOCALLY  WEIGHTED REGRESSION OF DEGREE 0 IS ACTUALLY USED AT
!        X(I).  ONE CASE OCCURS WHEN  H  IS  0.0.   THE  SECOND  CASE
!        OCCURS  WHEN  THE  WEIGHTED  STANDARD ERROR OF THE X(I) WITH
!        RESPECT TO THE WEIGHTS W(J) IS  LESS  THAN  .001  TIMES  THE
!        RANGE  OF THE X(I), WHERE W(J) IS THE WEIGHT ASSIGNED TO THE
!        J-TH POINT OF X (THE TRICUBE  WEIGHT  TIMES  THE  ROBUSTNESS
!        WEIGHT)  DIVIDED BY THE SUM OF ALL OF THE WEIGHTS.  FINALLY,
!        IF THE W(J) ARE ALL ZERO FOR THE SMOOTH AT X(I), THE  FITTED
!        VALUE IS TAKEN TO BE Y(I).
!
!
!
!
!  SUBROUTINE LOWESS(X,Y,N,F,NSTEPS,DELTA,YS,RW,RES)
!  REAL X(N),Y(N),YS(N),RW(N),RES(N)
!  LOGICAL OK
!  IF (N<2){ YS(1) = Y(1); RETURN }
!  NS = MAX0(MIN0(IFIX(FCFLOAT(N)),N),2)  # AT LEAST TWO, AT MOST N POINTS
!  FOR(ITER=1; ITER<=NSTEPS+1; ITER=ITER+1){      # ROBUSTNESS ITERATIONS
!         NLEFT = 1; NRIGHT = NS
!         LAST = 0        # INDEX OF PREV ESTIMATED POINT
!         I = 1   # INDEX OF CURRENT POINT
!         REPEAT{
!                 WHILE(NRIGHT<N){
!  # MOVE NLEFT, NRIGHT TO RIGHT IF RADIUS DECREASES
!                         D1 = X(I)-X(NLEFT)
!                         D2 = X(NRIGHT+1)-X(I)
!  # IF D1<=D2 WITH X(NRIGHT+1)==X(NRIGHT), LOWEST FIXES
!                         IF (D1<=D2) BREAK
!  # RADIUS WILL NOT DECREASE BY MOVE RIGHT
!                         NLEFT = NLEFT+1
!                         NRIGHT = NRIGHT+1
!                         }
!                 CALL LOWEST(X,Y,N,X(I),YS(I),NLEFT,NRIGHT,RES,ITER>1,RW,OK)
!  # FITTED VALUE AT X(I)
!                 IF (!OK) YS(I) = Y(I)
!  # ALL WEIGHTS ZERO - COPY OVER VALUE (ALL RW==0)
!                 IF (LAST<I-1) { # SKIPPED POINTS -- INTERPOLATE
!                         DENOM = X(I)-X(LAST)    # NON-ZERO - PROOF?
!                         FOR(J=LAST+1; J<I; J=J+1){
!                                 ALPHA = (X(J)-X(LAST))/DENOM
!                                 YS(J) = ALPHACYS(I)+(1.0-ALPHA)CYS(LAST)
!                                 }
!                         }
!                 LAST = I        # LAST POINT ACTUALLY ESTIMATED
!                 CUT = X(LAST)+DELTA     # X COORD OF CLOSE POINTS
!                 FOR(I=LAST+1; I<=N; I=I+1){     # FIND CLOSE POINTS
!                         IF (X(I)>CUT) BREAK     # I ONE BEYOND LAST PT WITHIN CUT
!                         IF(X(I)==X(LAST)){      # EXACT MATCH IN X
!                                 YS(I) = YS(LAST)
!                                 LAST = I
!                                 }
!                         }
!                 I=MAX0(LAST+1,I-1)
!  # BACK 1 POINT SO INTERPOLATION WITHIN DELTA, BUT ALWAYS GO FORWARD
!                 } UNTIL(LAST>=N)
!         DO I = 1,N      # RESIDUALS
!                 RES(I) = Y(I)-YS(I)
!         IF (ITER>NSTEPS) BREAK  # COMPUTE ROBUSTNESS WEIGHTS EXCEPT LAST TIME
!         DO I = 1,N
!                 RW(I) = ABS(RES(I))
!         CALL SORT(RW,N)
!         M1 = 1+N/2; M2 = N-M1+1
!         CMAD = 3.0C(RW(M1)+RW(M2))      # 6 MEDIAN ABS RESID
!         C9 = .999CCMAD; C1 = .001CCMAD
!         DO I = 1,N {
!                 R = ABS(RES(I))
!                 IF(R<=C1) RW(I)=1.      # NEAR 0, AVOID UNDERFLOW
!                 ELSE IF(R>C9) RW(I)=0.  # NEAR 1, AVOID UNDERFLOW
!                 ELSE RW(I) = (1.0-(R/CMAD)CC2)CC2
!                 }
!         }
!  RETURN
!  END
!
!
!
!
!                                   LOWEST
!
!
!
!        CALLING SEQUENCE
!
!        CALL LOWEST(X,Y,N,XS,YS,NLEFT,NRIGHT,W,USERW,RW,OK)
!
!        PURPOSE
!
!        LOWEST IS A SUPPORT ROUTINE FOR LOWESS AND  ORDINARILY  WILL
!        NOT  BE  CALLED  BY  THE  USER.   THE  FITTED  VALUE, YS, IS
!        COMPUTED  AT  THE  VALUE,  XS,  OF  THE   HORIZONTAL   AXIS.
!        ROBUSTNESS  WEIGHTS,  RW,  CAN  BE EMPLOYED IN COMPUTING THE
!        FIT.
!
!        ARGUMENT DESCRIPTION
!
!
!              X = INPUT; ABSCISSAS OF THE POINTS ON THE
!                  SCATTERPLOT; THE VALUES IN X MUST BE ORDERED
!                  FROM SMALLEST TO LARGEST.
!              Y = INPUT; ORDINATES OF THE POINTS ON THE
!                  SCATTERPLOT.
!              N = INPUT; DIMENSION OF X,Y,W, AND RW.
!             XS = INPUT; VALUE OF THE HORIZONTAL AXIS AT WHICH THE
!                  SMOOTH IS COMPUTED.
!             YS = OUTPUT; FITTED VALUE AT XS.
!          NLEFT = INPUT; INDEX OF THE FIRST POINT WHICH SHOULD BE
!                  CONSIDERED IN COMPUTING THE FITTED VALUE.
!         NRIGHT = INPUT; INDEX OF THE LAST POINT WHICH SHOULD BE
!                  CONSIDERED IN COMPUTING THE FITTED VALUE.
!              W = OUTPUT; W(I) IS THE WEIGHT FOR Y(I) USED IN THE
!                  EXPRESSION FOR YS, WHICH IS THE SUM FROM
!                  I = NLEFT TO NRIGHT OF W(I)CY(I); W(I) IS
!                  DEFINED ONLY AT LOCATIONS NLEFT TO NRIGHT.
!          USERW = INPUT; LOGICAL VARIABLE; IF USERW IS .TRUE., A
!                  ROBUST FIT IS CARRIED OUT USING THE WEIGHTS IN
!                  RW; IF USERW IS .FALSE., THE VALUES IN RW ARE
!                  NOT USED.
!             RW = INPUT; ROBUSTNESS WEIGHTS.
!             OK = OUTPUT; LOGICAL VARIABLE; IF THE WEIGHTS FOR THE
!                  SMOOTH ARE ALL 0.0, THE FITTED VALUE, YS, IS NOT
!                  COMPUTED AND OK IS SET EQUAL TO .FALSE.; IF THE
!                  FITTED VALUE IS COMPUTED OK IS SET EQUAL TO
!
!
!        METHOD
!
!        THE SMOOTH AT XS IS COMPUTED USING (ROBUST) LOCALLY WEIGHTED
!        REGRESSION OF DEGREE 1.  THE TRICUBE WEIGHT FUNCTION IS USED
!        WITH H EQUAL TO THE MAXIMUM OF XS-X(NLEFT) AND X(NRIGHT)-XS.
!        TWO  CASES  WHERE  THE  PROGRAM  REVERTS TO LOCALLY WEIGHTED
!        REGRESSION OF DEGREE 0 ARE DESCRIBED  IN  THE  DOCUMENTATION
!        FOR LOWESS.
!
!
!
!
!  SUBROUTINE LOWEST(X,Y,N,XS,YS,NLEFT,NRIGHT,W,USERW,RW,OK)
!  REAL X(N),Y(N),W(N),RW(N)
!  LOGICAL USERW,OK
!  RANGE = X(N)-X(1)
!  H = AMAX1(XS-X(NLEFT),X(NRIGHT)-XS)
!  H9 = .999CH
!  H1 = .001CH
!  A = 0.0        # SUM OF WEIGHTS
!  FOR(J=NLEFT; J<=N; J=J+1){     # COMPUTE WEIGHTS (PICK UP ALL TIES ON RIGHT)
!         W(J)=0.
!         R = ABS(X(J)-XS)
!         IF (R<=H9) {    # SMALL ENOUGH FOR NON-ZERO WEIGHT
!                 IF (R>H1) W(J) = (1.0-(R/H)CC3)CC3
!                 ELSE      W(J) = 1.
!                 IF (USERW) W(J) = RW(J)CW(J)
!                 A = A+W(J)
!                 }
!         ELSE IF(X(J)>XS)BREAK   # GET OUT AT FIRST ZERO WT ON RIGHT
!         }
!  NRT=J-1        # RIGHTMOST PT (MAY BE GREATER THAN NRIGHT BECAUSE OF TIES)
!  IF (A<=0.0) OK = FALSE
!  ELSE { # WEIGHTED LEAST SQUARES
!         OK = TRUE
!         DO J = NLEFT,NRT
!                 W(J) = W(J)/A   # MAKE SUM OF W(J) == 1
!         IF (H>0.) {     # USE LINEAR FIT
!                 A = 0.0
!                 DO J = NLEFT,NRT
!                         A = A+W(J)CX(J) # WEIGHTED CENTER OF X VALUES
!                 B = XS-A
!                 C = 0.0
!                 DO J = NLEFT,NRT
!                         C = C+W(J)C(X(J)-A)CC2
!                 IF(SQRT(C)>.001CRANGE) {
!  # POINTS ARE SPREAD OUT ENOUGH TO COMPUTE SLOPE
!                         B = B/C
!                         DO J = NLEFT,NRT
!                                 W(J) = W(J)C(1.0+BC(X(J)-A))
!                         }
!                 }
!         YS = 0.0
!         DO J = NLEFT,NRT
!                 YS = YS+W(J)CY(J)
!         }
!  RETURN
!  END
!
!
!C
!**************************************************************
!  FORTRAN OUTPUT FROM RATFOR
!
SUBROUTINE LOWESS (X,Y,N,F,NSTEPS,DELTA,YS,RW,RES)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ABS, INT, MAX0, MIN0
!...
!...DECLARE TRANSFERRED VARIABLES
INTEGER(I4B), INTENT(IN)                            :: N, NSTEPS
REAL(WP), INTENT(IN)                                :: DELTA, F
REAL(WP), INTENT(IN), DIMENSION(1:N)                :: X, Y
REAL(WP), INTENT(OUT), DIMENSION(1:N)               :: YS, RES, RW
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                        :: NRIGHT, I, J
INTEGER(I4B)                                        :: ITER, LAST, M1, M2, NS, NLEFT
REAL(WP)                                            :: CUT, CMAD, R, D1, D2, C1, C9, ALPHA, DENOM
REAL(WP), PARAMETER                                 :: ALMOST_ONE=0.999_WP
REAL(DP)                                            :: FF
LOGICAL(FLG)                                        :: OK
!...
!...
IF (N < 2) THEN
    YS(1) = Y(1)
    RETURN
ENDIF
!...
!...AT LEAST TWO, AT MOST N POINTS
FF = REAL(F, KIND=DP)
NS = MAX0(MIN0(INT(FF*REAL(N), KIND=DP),N),2)
ITER = 1
GOTO 3
2 ITER = ITER+1
3 IF (ITER > NSTEPS+1) RETURN
!...
!...ROBUSTNESS ITERATIONS
NLEFT  = 1
NRIGHT = NS
!...
!...INDEX OF PREV ESTIMATED POINT
LAST = 0
!...
!...INDEX OF CURRENT POINT
I = 1
4 CONTINUE
IF (NRIGHT < N) THEN
!...
!...MOVE NLEFT, NRIGHT TO RIGHT IF RADIUS DECREASES
    D1 = X(I)-X(NLEFT)
!...
! IF D1<=D2 WITH X(NRIGHT+1)==X(NRIGHT), LOWEST FIXES
    D2 = X(NRIGHT+1)-X(I)
    IF (D1 > D2) THEN
!...
!...RADIUS WILL NOT DECREASE BY MOVE RIGHT
        NLEFT  = NLEFT+1
        NRIGHT = NRIGHT+1
        GOTO 4
    ENDIF
ENDIF
!...
!...FITTED VALUE AT X(I)
CALL LOWEST (X,Y,N,X(I),YS(I),NLEFT,NRIGHT,RES,ITER>1,RW,OK)
IF (.NOT. OK) YS(I) = Y(I)
!...
!...ALL WEIGHTS ZERO - COPY OVER VALUE (ALL RW==0)
IF (LAST < I-1) THEN
    DENOM = X(I)-X(LAST)
!...
!...SKIPPED POINTS -- INTERPOLATE
!...NON-ZERO - PROOF?
    J = LAST+1
    GOTO 7
6   J = J+1
7   CONTINUE
    IF (J < I) THEN
        ALPHA = (X(J)-X(LAST))/DENOM
        YS(J) = ALPHA*YS(I)+(ONE_W-ALPHA)*YS(LAST)
        GOTO 6
    ENDIF
!...
!...LAST POINT ACTUALLY ESTIMATED
ENDIF
LAST = I
!...
!...X COORD OF CLOSE POINTS
CUT = X(LAST)+DELTA
I = LAST+1
GOTO 11
10 I = I+1
11 CONTINUE
IF (I <= N) THEN
!...
!...FIND CLOSE POINTS
    IF (X(I) <= CUT) THEN
!...
!...I ONE BEYOND LAST PT WITHIN CUT
        IF (X(I) == X(LAST)) THEN
            YS(I) = YS(LAST)
!...
!...EXACT MATCH IN X
            LAST = I
        ENDIF
        GOTO 10
    ENDIF
ENDIF
!...
!...BACK 1 POINT SO INTERPOLATION WITHIN DELTA, BUT ALWAYS GO FORWARD
I = MAX0(LAST+1, I-1)
IF (LAST < N) GOTO 4
!...
!...RESIDUALS
DO I = 1,N
    RES(I) = Y(I)-YS(I)
ENDDO
IF (ITER > NSTEPS) RETURN
!...
!...COMPUTE ROBUSTNESS WEIGHTS EXCEPT LAST TIME
DO I = 1,N
    RW(I) = ABS(RES(I))
ENDDO
CALL SORT(RW,N)
M1 = N/2+1
M2 = N-M1+1
!...
!...MEDIAN ABS RESID
CMAD = THREE_W*(RW(M1)+RW(M2))
  C9 = ALMOST_ONE*CMAD
  C1 = THOUTH_W*CMAD
DO I = 1,N
    R = ABS(RES(I))
    IF (R <= C1) THEN
        RW(I) = ONE_W
!...
!...NEAR 0, AVOID UNDERFLOW
        CYCLE
    ENDIF
    IF (R > C9) THEN
        RW(I) = ZERO_W
!...
!...NEAR 1, AVOID UNDERFLOW
        CYCLE
    ENDIF
    RW(I) = (ONE_W-(R/CMAD)**2)**2
ENDDO
GOTO 2
CONTAINS
!...
!*************************************************************************
!...
    SUBROUTINE LOWEST (X,Y,N,XS,YS,NLEFT,NRIGHT,W,USERW,RW,OK)
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                       :: ABS, AMAX1
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                        :: N, NLEFT, NRIGHT
    REAL(WP), INTENT(IN)                            :: XS
    REAL(WP), INTENT(INOUT)                         :: YS
    REAL(WP), INTENT(IN), DIMENSION(1:N)            :: X, Y, RW
    REAL(WP), INTENT(INOUT), DIMENSION(1:N)         :: W
    LOGICAL(TLG), INTENT(IN)                        :: USERW
    LOGICAL(TLG), INTENT(OUT)                       :: OK
!...
!...SUBROUTINE VARIABLES
    INTEGER(I4B)                                    :: NRT, J
    REAL(WP)                                        :: A, B, C, H, R, H1, H9, RANGE1
!,,,
!,,,BEGIN SUBROUTINE
    RANGE1 = X(N)-X(1)
     H = AMAX1(XS-X(NLEFT), X(NRIGHT)-XS)
    H9 = ALMOST_ONE*H
    H1 = THOUTH_W*H
!...
!...SUM OF WEIGHTS
    A = ZERO_W
    J = NLEFT
    GOTO 2
1   J = J+1
2   CONTINUE
    IF (J <= N) THEN
!...
!...COMPUTE WEIGHTS (PICK UP ALL TIES ON RIGHT)
        W(J) = ZERO_W
        R = ABS(X(J)-XS)
        IF (R <= H9) THEN
            IF (R > H1) THEN
                W(J) = (ONE_W-(R/H)**3)**3
!...
!...SMALL ENOUGH FOR NON-ZERO WEIGHT
                GOTO 4
            ENDIF
            W(J) = ONE_W
4           IF (USERW) W(J) = RW(J)*W(J)
            A = A+W(J)
            GOTO 1
        ENDIF
        IF (X(J) <= XS) GOTO 1
!...
!...GET OUT AT FIRST ZERO WT ON RIGHT
        GOTO 1
!...
!...RIGHTMOST PT (MAY BE GREATER THAN NRIGHT BECAUSE OF TIES)
    ENDIF
    NRT = J-1
    IF (A <= ZERO_W) THEN
        OK = .FALSE.
        RETURN
    ENDIF
    OK = .TRUE.
!...
!...WEIGHTED LEAST SQUARES
    DO J = NLEFT,NRT
!...
!...MAKE SUM OF W(J) == 1
        W(J) = W(J)/A
    ENDDO
    IF (H > ZERO_W) THEN
        A = ZERO_W
!...
!...USE LINEAR FIT
        DO J = NLEFT,NRT
!...
!...WEIGHTED CENTER OF X VALUES
            A = A+W(J)*X(J)
        ENDDO
        B = XS-A
        C = ZERO_W
        DO J = NLEFT,NRT
            C = C+W(J)*(X(J)-A)**2
        ENDDO
        IF (SQRT(C) > THOUTH_W*RANGE1) THEN
            B = B/C
!...
!...POINTS ARE SPREAD OUT ENOUGH TO COMPUTE SLOPE
            DO J = NLEFT,NRT
                W(J) = W(J)*(B*(X(J)-A)+ONE_W)
            ENDDO
        ENDIF
    ENDIF
    YS = ZERO_W
    DO J = NLEFT,NRT
        YS = YS+W(J)*Y(J)
    ENDDO
!...
!...DONE
    RETURN
    END SUBROUTINE LOWEST
    !...
!*************************************************************************
!...
    SUBROUTINE SORT(ARR,N)
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                        :: N
    REAL(WP), INTENT(INOUT), DIMENSION(1:N)         :: ARR
!...
!...SUBROUTINE VARIABLES
    INTEGER(I4B)                                    :: I, J
    REAL(WP)                                        :: A
!
    DO J = 2,N
        A = ARR(J)
        DO I = J-1,1,-1
            IF (ARR(I) <= A) GOTO 10
            ARR(I+1) = ARR(I)
        ENDDO
        I = 0
10      ARR(I+1) = A
    ENDDO
!...
!...DONE
    RETURN
    END SUBROUTINE SORT
!...
!...DONE
END SUBROUTINE LOWESS
