!**************************************************************************************
!...
!... PROGRAM MTVOUT
!...
!**************************************************************************************
!...
!... MTVOUT
!...
!... PURPOSE
!...  IDENTIFY OUTLIERS IN MULTIVARIATE DATA
!...
!... METHOD
!...  LET VECTORS X(I) THRU X(N) BE OBSERVATIONS FROM AN NP-VARIATE
!...   NORMAL DISTRIBUTION
!...
!...  THEN
!...   XBAR AND COVARIANCE MATRIX S ARE OBTAINED BY EQUATIONS
!...     XBAR = (1/N) * SUM X(J)
!...   S * (N-1) = SUM(X(J)-XBAR) * (X(J)-XBAR)TRANSPOSE
!...
!...  WHERE
!...       N = SAMPLE SIZE
!...      NP = NUMBER OF VARIABLES (NP .LE. 10)
!...       ALPH = SIGNIFICANCE LEVEL
!...      FALPH = F-VALUE FOR ALPHA AT NP AND N-NP-1
!...        DEGREES OF FREEDOM
!...     X(J,I) = THE 'I'TH ELEMENT OF THE 'J'TH VECTOR,
!...        WHERE I = 1,2,...,NP AND J = 1,2,...,N
!...
!...  CALCULATE
!...   DELSTAR = ((N-1)**2*NP*FALPH) / (N*((N-NP-1)+NP*FALPH))
!...
!...  CALCULATE FOR EACH OBSERVATION VECTOR X(J)
!...      RR = (X(J)-XBAR)TRANSPOSE * (S)INVERSE * (X(J)-XBAR)
!...
!... REFERENCES
!...
!...  1.  AN INTRODUCTION TO MULTIVARIATE STATISTICAL ANAYLSIS,
!...      ANDERSON, 1965
!...  2.  A SIMPLE TECHNIQUE FOR AUTOMATIC COMPUTER EDITING
!...      OF BIODATA, NASA TN D-5275
!...  3.  SYS360 SCIENTIFIC SUBROUTINE PACKAGE (360A-CM-03X)
!...      PROGRAMMERS MANUAL, IBM INC., 1968
!...
!... SUBROUTINES
!...      FTABLE
!...      MPRD  (IBM SSP)
!...      LOC      "   "
!...      DSINV    "   "
!...      DMFSD    "   "
!...
!... INPUT
!...
!...  CARD 1  FORMAT OF X-ARRAY CARDS TO BE READ IN     (20A4)
!...  CARD 2
!...   COL  1- 2      NP   (NUMBER OF VARIABLES)  NP <= 10) (I2)
!...   COL  3  BLANK2
!...   COL  4- 6  ALPH (SIGNIFICANCE LEVEL) 0.1, 0.05, 0.025, 0.01, OR 0.001 (F3.2)
!...   COL  7- 9 BLANK2
!...   COL 10  VARIABLE NAME CARD INDICATOR
!...      1 - NAME CARD FOLLOWS
!...     BLANK2 - NO NAME CARD
!...  CARD 3 (OPTIONAL)
!...   TEN FIELDS OF EIGHT CHARACTERS EACH (10A8), WHICH MAY
!...   BE USED TO ASSIGN MEANINGFUL NAMES TO THE NP VARIABLES.
!...   IF COL 10 OF THE PREVIOUS CARD IS PUNCHED, NAMES MUST
!...   BE ASSIGNED FOR ALL NP VARIABLES.  DEFAULT NAMES ARE
!...   "X1", "X2", ... , "X(NP)".
!...  CARDS 4- DATA FORMATTED AS PRESCRIBED IN CARD 1
!...
!...  MULTIPLE RUNS ARE PERMITTED, AS LONG AS EACH DATA DECK IS
!...  PRECEDED BY APPROPRIATE CONTROL CARDS (CARDS 1, 2, AND
!...  3 ABOVE), AND IS FOLLOWED BY A CARD WITH   ****   PUNCHED
!...  IN COLUMNS 1 THRU 4.
!...
!... OUTPUT
!...  1 LIST OF VECTORS WITH OUTLIERS IDENTIFIED BY ARROWS
!...  2 MEAN (ORIGINAL DATA)
!...  3 STANDARD DEVIATION (ORIGINAL DATA)
!...  4 MEAN (OUTLIERS DELETED)
!...  5 STANDARD DEVIATION (OUTLIERS DELETED)
!...
!**************************************************************************************
!...
!...
SUBROUTINE MTVOUT (NOBS,ALPHA,XX,YY,PW,OUTL,XMEAN,XSIGMA)
!...
!...ADD MODULE DATA TYPE DEFINITION
USE NRTYPE
USE NRUTIL,  ONLY : NRERROR, ASSERT_EQ, ARRAY_COPY
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: LOG
!...
!...IDENTIFY TRANSFERED VALIABLES
INTEGER(I4B), INTENT(INOUT)                         :: NOBS
REAL(WP), INTENT(IN)                                :: PW, ALPHA
REAL(WP), INTENT(OUT)                               :: XMEAN, XSIGMA
REAL(WP), DIMENSION(1:*), INTENT(INOUT)             :: XX, YY, OUTL
!...
!...IDENTIFY SUBROUTINE VALIABLES
CHARACTER(LEN=1)                                    :: DELETE
CHARACTER(LEN=8)                                    :: BLANK1 = "        "
CHARACTER(LEN=4)                                    :: BLANK2 = "    ", FLAG
CHARACTER(LEN=3)                                    :: STAR = "<--"
CHARACTER(LEN=8), DIMENSION(1:10)                   :: DAS, VAR, FMTT
CHARACTER(LEN=4), DIMENSION(1:2), PARAMETER         :: OPT = (/ " YES","  NO" /)
CHARACTER(LEN=8), DIMENSION(1:10), PARAMETER        :: DEF = (/ "    X1  ","    X2  ","    X3  ",              &
                                                                "    X4  ","    X5  ","    X6  ",              &
                                                                "    X7  ","    X8  ","    X9  ",              &
                                                                "    X10 " /)
CHARACTER(LEN=8), DIMENSION(1:10), PARAMETER        :: DAF = (/ "--------","--------","--------",              &
                                                                "--------","--------","--------",              &
                                                                "--------","--------","--------","--------" /)
INTEGER(I4B)                                        :: I, LINES, NSWI, IO, IZ, MM, J, JJ, K, IER, FLGTOT, DSWI
INTEGER(I4B)                                        :: LL, IOUT, N_COPIED, N_NOT_COPIED, NOUTL, NSAVE
INTEGER(I4B), PARAMETER                             :: NP=1, ISWI=0
INTEGER(I4B), DIMENSION(1:NOBS)                     :: IFLAG, NCOUNT, FCOUNT
REAL(WP)                                            :: DELSTR, DH, FALPH, OH, ALPH
REAL(WP), DIMENSION(1:10)                           :: SUMX, XBAR, SD, XBAR1, SD1, B, R
REAL(WP), DIMENSION(1:55)                           :: A
REAL(WP), DIMENSION(1:1)                            :: RR
REAL(WP), DIMENSION(1:10,1:10)                      :: S
REAL(WP), DIMENSION(1:NOBS,1:10)                    :: X1, Y1
LOGICAL(FLG)                                        :: OK
!***
!*******END DECLARATIONS*******
!***
!...
!...OPEN MTVOUT RESULTS FOR OUTPUT WRITING
OPEN (NEWUNIT=IOUT, FILE = "MTVOUT_OUTLIER.OUT", STATUS = "UNKNOWN", POSITION = "REWIND")
INQUIRE(IOUT, OPENED = OK)
IF (.NOT. OK) OPEN(IOUT, FILE = "MTVOUT_OUTLIER.OUT", STATUS = "UNKNOWN")
!...
!...CLEAR SOME ARRAYS
DO I = 1,10
    DAS(I)  = DAF(I)
    VAR(I)  = DEF(I)
    FMTT(I) = BLANK1
ENDDO
DO I = 1,NOBS
    IFLAG(I) = 0
ENDDO
!...
!...SET SOME CONTROL PARAMETERS
FLGTOT = 0
LINES  = 1
NSWI   = 0
DSWI   = 0
DH     = HUNDTH_W
IO     = 1
IZ     = 0
MM     = 1
OH     = ZERO_W
LL     = 0
ALPH   = ALPHA
NOUTL  = 0
NSAVE  = 0
!...
!...COPY DATA IN LOGARITHM FORM INTO THE X-ARRAY TO APPROXIMATE A NORMAL DISTRIBUTION AS NECESSARY
DO I = 1,NOBS
    IF (PW < ALPHA) THEN
        LL = 1
        X1(I,1) = LOG(YY(I)+ONE_W)
    ELSE
        X1(I,1) = YY(I)
    ENDIF
ENDDO
NSWI = 1
!...
!...SELECT APPROPRIATE F-VALUE
CALL FTABLE (NOBS,NP,ALPH,FALPH,IOUT)
!...
!...WRITE THE INPUT CONTROL INFORMATION
WRITE (IOUT,5002) NP, ALPH, FALPH, OPT(MM)
!...
!...CALCULATE THE VALUE THAT WILL MARK OUTLIERS
DELSTR = ((NOBS-1)**2 * NP*FALPH)/(NOBS*((NOBS-NP-1) + NP*FALPH))
!...
!...IDENTIFY OUTLIERS
DO
    DO I = 1,10
        SUMX(I) = ZERO_W
        DO J = 1,10
            S(I,J) = ZERO_W
        ENDDO
    ENDDO
    DO J = 1,NOBS
!...
!...TEST FOR FLAGGED VECTORS IDENTIFIED AS OUTLIERS
        IF (IFLAG(J) > 0) THEN
            OUTL(J) = X1(J,1)
            CYCLE
        ENDIF
        DO I = 1,NP
            IF (LL == 0) THEN
                SUMX(I) = SUMX(I) + X1(J,I)
            ELSE
                SUMX(I) = SUMX(I) + EXP(X1(J,I))
            ENDIF
        ENDDO
    ENDDO
!...
!...FIND MEAN OF EACH VARIABLE
    DO I = 1,NP
        IF (LL == 0) THEN
            XBAR(I) =  SUMX(I)/(NOBS-FLGTOT)
        ELSE
            XBAR(I) = (SUMX(I)/(NOBS-FLGTOT))-ONE_W
        ENDIF
        DO J = 1,NOBS
            IF (LL == 0) THEN
                Y1(J,I) = X1(J,I) - XBAR(I)
            ELSE
                Y1(J,I) = (EXP(X1(J,I)) - XBAR(I))-ONE_W
            ENDIF
            IF (IFLAG(J) > 0) Y1(J,I) = ZERO_W
        ENDDO
    ENDDO
    JJ = 0
    DO I = 1,NP
        DO K = 1,I
            DO J = 1,NOBS
                S(I,K) = Y1(J,I)*Y1(J,K) + S(I,K)
            ENDDO
!...
!...FIND STANDARD DEVIATION OF EACH VARIABLE
            SD(I) = SQRT(S(I,I)/(NOBS-1-FLGTOT))
            JJ = JJ+1
            A(JJ) = S(I,K)
        ENDDO
    ENDDO
!...
!...IF COMPUTATIONS ARE COMPLETE, BRANCH TO PRINT TABLE OF MEANS AND S.D.'S
    IF (DSWI > 0) EXIT
    CALL DSINV (A,NP,OH,IER)
!...
!...STOP PROGRAM IF ERRORS DETECTED
    IF (IER /= 0) THEN
        WRITE (IOUT,5001)
        GOTO 9999
    ENDIF
!...
!...WRITE THE LIST HEADING
    WRITE (IOUT,1015) (VAR(I), I = 1,NP)
    WRITE (IOUT,1018) (DAS(I), I = 1,NP)
    WRITE (*,1022)
    DO J = 1,NOBS
        FCOUNT(J) = J
        DO K = 1,NP
            B(K) = Y1(J,K)
        ENDDO
        CALL MPRD(B,A, R)
        CALL MPRD(R,B,RR)
        RR(1) = RR(1)*(NOBS-1)
        FLAG = BLANK2
!...
!...FLAG THIS VECTOR WITH AN ARROW, DELSTR, IF IT IS IDENTIFIED AS AN OUTLIER
        IF (RR(1) > DELSTR) THEN
            FLAG = STAR
            IF (LL == 0) THEN
                WRITE (*,1023) (X1(J,K), K = 1,NP)
                DO K = I,NP
                    NOUTL = NOUTL+1
                    NCOUNT(NOUTL) = J
                    OUTL(NOUTL) = EXP(X1(J,K))-ONE_W
                ENDDO
            ELSE
                DO I = 1,NP
                    WRITE (*,1023) (EXP(X1(J,K))-ONE_W, K = I,NP)
                    DO K = I,NP
                        NOUTL = NOUTL+1
                        NCOUNT(NOUTL) = J
                        OUTL(NOUTL) = EXP(X1(J,K))-ONE_W
                    ENDDO
                ENDDO
            ENDIF
        ENDIF
        IF (FLAG /= STAR) GOTO 95
        IFLAG(J) = 1
        FLGTOT = FLGTOT+1
!...
!...WRITE THE DATA VECTOR AND IF IDENTIFIED AS AN OUTLIER, LABEL WITH AN ARROW
95      CONTINUE
        IF (LL == 0) THEN
            WRITE (IOUT,1020) J, RR(1), FLAG, (X1(J,K), K = 1,NP)
        ELSE
            DO I = 1,NP
                WRITE (IOUT,1020) J, RR(1), FLAG, (EXP(X1(J,K))-ONE_W, K = I,NP)
            ENDDO
        ENDIF
        LINES = LINES+1
        IF (LINES <= 80) CYCLE
        WRITE (IOUT,1015) (VAR(I), I = 1,NP)
        WRITE (IOUT,1018) (DAS(I), I = 1,NP)
        LINES = 1
    ENDDO
    WRITE (IOUT,1025) ALPH
    WRITE (IOUT,1030) NOBS
    WRITE (IOUT,1035) FLGTOT
    WRITE (IOUT,1040) DELSTR
!...
!...SAVE MEANS AND S.D.'S, THEN LOOP BACK AND COMPUTE NEW MEANS AND S.D.'S AFTER DELETING OUTLIERS
    CALL ARRAY_COPY(XBAR,XBAR1,N_COPIED,N_NOT_COPIED)
    CALL ARRAY_COPY(  SD,  SD1,N_COPIED,N_NOT_COPIED)
    IF (N_NOT_COPIED > 0) THEN
        CALL EXECUTE_COMMAND_LINE("CLS")
        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
        DO I = 1,3
            WRITE (*,*)
        ENDDO
        CALL NRERROR("FATAL ERROR --> MEAN AND SD ARRAYS NOT PROPERLY COPIED IN MTVOUT")
    ENDIF
    DSWI = 1
ENDDO
!...
!...DETERMINE IF OUTLIERS SHOULD BE DELETED FROM THE TIME-CONCENTRATION DATASET
WRITE (*,5005, ADVANCE="NO")
READ  (*,5007) DELETE
!...
!...DELETE OUTLIERS FROM THE TIME-CONCENTRATION DATASET AND RESET THE NUMBER DATA
SELECT CASE (DELETE)
    CASE ("Y","y")
        DO I = 1,NOBS
            DO J = 1,NOUTL
                IF (FCOUNT(I) == NCOUNT(J)) THEN
                    GOTO 10
                ELSE
                    CYCLE
                ENDIF
            ENDDO
            NSAVE = NSAVE+1
            XX(NSAVE) = XX(I)
            YY(NSAVE) = YY(I)
10      ENDDO
        NOBS = NSAVE
    CASE ("N","n")
        CONTINUE
    CASE DEFAULT
        CONTINUE
END SELECT
!...
!...WRITE TABLE OF MEANS AND S.D.'s BEFORE AND AFTER DELETION OF OUTLIERS
WRITE (IOUT,2000)
WRITE (IOUT,2005)
WRITE (IOUT,2010)
DO I = 1,NP
    WRITE (IOUT,2015) VAR(I),XBAR1(I),SD1(I),XBAR(I),SD(I)
ENDDO
XMEAN  = XBAR(1)
XSIGMA = SD(1)
9999 CONTINUE
WRITE (*,5010)
!...
!...FORMAT STATEMENTS
1015 FORMAT (/,1X,"LIST OF VECTORS WITH OUTLIERS IDENTIFIED BY ARROWS",/,53("="),/,3X,"J",14X,"DELTA",7X,10(2X,A8),/)
1018 FORMAT (1X,6("-"),9X,8("-"),7X,10(2X,A8))
1020 FORMAT (1X,I6,5X,F12.4,2X,A3,2X,10F10.6)
1022 FORMAT (////,33X,"POSSIBLE OUTLIERS",/,32X,19("-"))
1023 FORMAT (40X,10F10.5)
1025 FORMAT (80("="),//,9X,"--> OUTLIER IDENTIFIED AT ",F4.2," SIGNIFICANCE LEVEL")
1030 FORMAT (13X,"SAMPLE SIZE IS ",I6)
1035 FORMAT (13X,"NUMBER OF OUTLIERS IS ",I6)
1040 FORMAT (13X,"DELSTAR = ",F10.4)
2000 FORMAT (/,21X,"MEAN AND STANDARD DEVIATION OF THE VARIABLES")
2005 FORMAT (17X,"DATA FOR IDENTIFICATION",11X,"DATA AFTER DELETION",/,23X,"OF OUTLIERS",21X,"OF OUTLIERS")
2010 FORMAT (1X,"VARIABLES",8X,"MEAN",13X,"S.D.",11X,"MEAN",14X,"S.D.")
2015 FORMAT (1X,A8,F15.4,F17.4,F15.4,F18.4,//,80("="),//)
5001 FORMAT (1X,"ERROR IN THE MATRIX INVERSION PROCESS - PROGRAM TERMINATED")
5002 FORMAT (//,1X,"**INPUT CONTROL INFORMATION",//,1X,"**NUMBER OF VARIABLES IS",I4/1X,                    &
                   "**SIGNIFICANCE LEVEL IS",F5.2/1X,"**F-VALUE IS",F16.4//1X,"**VARIABLE NAME CARD: ",A4)
5005 FORMAT (//,16X,"DO YOU WANT TO DETELE THE OUTLIERS (Y=YES, N=NO [DEFAULT=NO])",6X,"")
5007 FORMAT (A1)
5010 FORMAT (//,20X,"MTVOUT FINISHED --- CHECK MTVOUT_OUTLIER.OUT FILE FOR RESULTS")
!...
!...DONE
RETURN
!...
!...ADD REQUIRED SUBROUTINES
CONTAINS
!...
!-----------------------------------------------------------------------------------------------------
!...
!... SUBROUTINE FTABLE (NN,MM,SL,FF,IOUT)
!...
!***************************************************************************
!                                                                          *
! FTABLE                                                                   *
!                                                                          *
! SUBROUTINE FTABLE SELECTS THE PROPER VALUE OF F AT M AND N-M-1           *
! DEGREES OF FREEDOM FOR SIGNIFICANCE LEVELS OF 10%, 5%, 2.5%, 1%, OR 0.1% *
!                                                                          *
! CALLING PARAMETERS                                                       *
!                                                                          *
! NN = SAMPLE SIZE        INTEGER                                          *
! MM = NUMBER OF VARIABLES  M <= 10  INTEGER                               *
! SL = SIGNIFICANCE LEVEL  0.1, 0.05 0.025, 0.01, OR 0.001 REAL            *
! FF = SELECTED F-VALUE      REAL                                          *
!                                                                          *
!                                                                          *
!   SUBROUTINE UPDATED BY MALCOLM FIELD                                    *
!                                                                          *
!***************************************************************************
!...
    SUBROUTINE FTABLE (NN,MM,SL,FF,IOUT)
!...
!...IDENTIFY TRANSFERED VALIABLES
    INTEGER(I4B), INTENT(IN)                            :: NN, MM, IOUT
    REAL(WP), INTENT(OUT)                               :: SL, FF
!...
!...DECLARE LOCAL VARIABLES
    INTEGER(I4B)                                        :: DF, L, I
    INTEGER(I4B), DIMENSION(1:7), PARAMETER             :: XDF = (/ 30, 40, 60, 120, 200, 400, 1000 /)
    REAL(WP), DIMENSION(1:5,1:10,1:34)                  :: TABLE
    REAL(WP), DIMENSION(1:5), PARAMETER                 :: SLT = (/ TENTH_W, 0.05_WP, 0.025_WP, HUNDTH_W, THOUTH_W /)
    REAL(WP), DIMENSION(1:500)                          :: TABL1, TABL2, TABL3
    REAL(WP), DIMENSION(1:200)                          :: TABL4
!...
!...DATA STATEMENTS
!...                 0.1             0.05            0.025            0.01               0.001
!--------------------------------------------------------------------------------------------------------
    DATA  TABL1/ 39.86346_WP,    161.4476_WP,    647.7890_WP,    4052.181_WP,    405284.067900000_WP,   &
                 49.50000_WP,    199.5000_WP,    799.5000_WP,    4999.500_WP,    499999.500000000_WP,   &
                 53.59324_WP,    215.7073_WP,    864.1630_WP,    5403.352_WP,    540379.201600000_WP,   &
                 55.83296_WP,    224.5832_WP,    899.5833_WP,    5624.583_WP,    562499.583300000_WP,   &
                 57.24008_WP,    230.1619_WP,    921.8479_WP,    5763.650_WP,    576404.555800000_WP,   &
                 58.20442_WP,    233.9860_WP,    937.1111_WP,    5858.986_WP,    585937.111100000_WP,   &
                 58.90595_WP,    236.7684_WP,    948.2169_WP,    5928.356_WP,    592873.287900000_WP,   &
                 59.43898_WP,    238.8827_WP,    956.6562_WP,    5981.070_WP,    598144.156200000_WP,   &
                 59.85759_WP,    240.5433_WP,    963.2846_WP,    6022.473_WP,    602283.991600000_WP,   &
                 60.19498_WP,    241.8817_WP,    968.6274_WP,    6055.847_WP,    605620.971200000_WP,   &
                  8.52632_WP,     18.5128_WP,     38.5063_WP,      98.503_WP,       998.500250100_WP,   &
                  9.00000_WP,     19.0000_WP,     39.0000_WP,      99.000_WP,       999.000000000_WP,   &
                  9.16179_WP,     19.1643_WP,     39.1655_WP,      99.166_WP,       999.166620300_WP,   &
                  9.24342_WP,     19.2468_WP,     39.2484_WP,      99.249_WP,       999.249937500_WP,   &
                  9.29263_WP,     19.2964_WP,     39.2982_WP,      99.299_WP,       999.299930000_WP,   &
                  9.32553_WP,     19.3295_WP,     39.3315_WP,      99.333_WP,       999.333259200_WP,   &
                  9.34908_WP,     19.3532_WP,     39.3552_WP,      99.356_WP,       999.357066300_WP,   &
                  9.36677_WP,     19.3710_WP,     39.3730_WP,      99.374_WP,       999.374921800_WP,   &
                  9.38054_WP,     19.3848_WP,     39.3869_WP,      99.388_WP,       999.388809600_WP,   &
                  9.39157_WP,     19.3959_WP,     39.3980_WP,      99.399_WP,       999.399920000_WP,   &
                  5.53832_WP,     10.1280_WP,     17.4434_WP,      34.116_WP,       167.029223800_WP,   &
                  5.46238_WP,      9.5521_WP,     16.0441_WP,      30.817_WP,       148.500000000_WP,   &
                  5.39077_WP,      9.2766_WP,     15.4392_WP,      29.457_WP,       141.108461200_WP,   &
                  5.34264_WP,      9.1172_WP,     15.1010_WP,      28.710_WP,       137.100362700_WP,   &
                  5.30916_WP,      9.0135_WP,     14.8848_WP,      28.237_WP,       134.580022000_WP,   &
                  5.28473_WP,      8.9406_WP,     14.7347_WP,      27.911_WP,       132.847468900_WP,   &
                  5.26619_WP,      8.8867_WP,     14.6244_WP,      27.672_WP,       131.582857200_WP,   &
                  5.25167_WP,      8.8452_WP,     14.5399_WP,      27.489_WP,       130.619008800_WP,   &
                  5.24000_WP,      8.8123_WP,     14.4731_WP,      27.345_WP,       129.859963300_WP,   &
                  5.23041_WP,      8.7855_WP,     14.4189_WP,      27.229_WP,       129.246681600_WP,   &
                  4.54477_WP,      7.7086_WP,     12.2179_WP,      21.198_WP,        74.137293320_WP,   &
                  4.32456_WP,      6.9443_WP,     10.6491_WP,      18.000_WP,        61.245553200_WP,   &
                  4.19086_WP,      6.5914_WP,      9.9792_WP,      16.694_WP,        56.177188490_WP,   &
                  4.10725_WP,      6.3882_WP,      9.6045_WP,      15.977_WP,        53.435829120_WP,   &
                  4.05058_WP,      6.2561_WP,      9.3645_WP,      15.522_WP,        51.711568560_WP,   &
                  4.00975_WP,      6.1631_WP,      9.1973_WP,      15.207_WP,        50.525021950_WP,   &
                  3.97897_WP,      6.0942_WP,      9.0741_WP,      14.976_WP,        49.657886730_WP,   &
                  3.95494_WP,      6.0410_WP,      8.9796_WP,      14.799_WP,        48.996188770_WP,   &
                  3.93567_WP,      5.9988_WP,      8.9047_WP,      14.659_WP,        48.474511350_WP,   &
                  3.91988_WP,      5.9644_WP,      8.8439_WP,      14.546_WP,        48.052589120_WP,   &
                  4.06042_WP,      6.6079_WP,     10.0070_WP,      16.258_WP,        47.180779220_WP,   &
                  3.77972_WP,      5.7861_WP,      8.4336_WP,      13.274_WP,        37.122329810_WP,   &
                  3.61948_WP,      5.4095_WP,      7.7636_WP,      12.060_WP,        33.202463180_WP,   &
                  3.52020_WP,      5.1922_WP,      7.3879_WP,      11.392_WP,        31.085005570_WP,   &
                  3.45298_WP,      5.0503_WP,      7.1464_WP,      10.967_WP,        29.752398580_WP,   &
                  3.40451_WP,      4.9503_WP,      6.9777_WP,      10.672_WP,        28.834360980_WP,   &
                  3.36790_WP,      4.8759_WP,      6.8531_WP,      10.456_WP,        28.162647020_WP,   &
                  3.33928_WP,      4.8183_WP,      6.7572_WP,      10.289_WP,        27.649475370_WP,   &
                  3.31628_WP,      4.7725_WP,      6.6811_WP,      10.158_WP,        27.244458580_WP,   &
                  3.29740_WP,      4.7351_WP,      6.6192_WP,      10.051_WP,        26.916567590_WP,   &
                  3.77595_WP,      5.9874_WP,      8.8131_WP,      13.745_WP,        35.507490250_WP,   &
                  3.46330_WP,      5.1433_WP,      7.2599_WP,      10.925_WP,        27.000000000_WP,   &
                  3.28876_WP,      4.7571_WP,      6.5988_WP,       9.780_WP,        23.703308650_WP,   &
                  3.18076_WP,      4.5337_WP,      6.2272_WP,       9.148_WP,        21.923541360_WP,   &
                  3.10751_WP,      4.3874_WP,      5.9876_WP,       8.746_WP,        20.802663960_WP,   &
                  3.05455_WP,      4.2839_WP,      5.8198_WP,       8.466_WP,        20.029654720_WP,   &
                  3.01446_WP,      4.2067_WP,      5.6955_WP,       8.260_WP,        19.463408040_WP,   &
                  2.98304_WP,      4.1468_WP,      5.5996_WP,       8.102_WP,        19.030333120_WP,   &
                  2.95774_WP,      4.0990_WP,      5.5234_WP,       7.976_WP,        18.688181570_WP,   &
                  2.93693_WP,      4.0600_WP,      5.4613_WP,       7.874_WP,        18.410924800_WP,   &
                  3.58943_WP,      5.5914_WP,      8.0727_WP,      12.246_WP,        29.245193360_WP,   &
                  3.25744_WP,      4.7374_WP,      6.5415_WP,       9.547_WP,        21.688998560_WP,   &
                  3.07407_WP,      4.3468_WP,      5.8898_WP,       8.451_WP,        18.772269820_WP,   &
                  2.96053_WP,      4.1203_WP,      5.5226_WP,       7.847_WP,        17.197993780_WP,   &
                  2.88334_WP,      3.9715_WP,      5.2852_WP,       7.460_WP,        16.205800320_WP,   &
                  2.82739_WP,      3.8660_WP,      5.1186_WP,       7.191_WP,        15.520840440_WP,   &
                  2.78493_WP,      3.7870_WP,      4.9949_WP,       6.993_WP,        15.018556750_WP,   &
                  2.75158_WP,      3.7257_WP,      4.8993_WP,       6.840_WP,        14.634006630_WP,   &
                  2.72468_WP,      3.6767_WP,      4.8232_WP,       6.719_WP,        14.329900470_WP,   &
                  2.70251_WP,      3.6365_WP,      4.7611_WP,       6.620_WP,        14.083255380_WP,   &
                  3.45792_WP,      5.3177_WP,      7.5709_WP,      11.259_WP,        25.414760470_WP,   &
                  3.11312_WP,      4.4590_WP,      6.0595_WP,       8.649_WP,        18.493653010_WP,   &
                  2.92380_WP,      4.0662_WP,      5.4160_WP,       7.591_WP,        15.829489580_WP,   &
                  2.80643_WP,      3.8379_WP,      5.0526_WP,       7.006_WP,        14.391584510_WP,   &
                  2.72645_WP,      3.6875_WP,      4.8173_WP,       6.632_WP,        13.484689450_WP,   &
                  2.66833_WP,      3.5806_WP,      4.6517_WP,       6.371_WP,        12.858026140_WP,   &
                  2.62413_WP,      3.5005_WP,      4.5286_WP,       6.178_WP,        12.398041230_WP,   &
                  2.58935_WP,      3.4381_WP,      4.4333_WP,       6.029_WP,        12.045541240_WP,   &
                  2.56124_WP,      3.3881_WP,      4.3572_WP,       5.911_WP,        11.766532490_WP,   &
                  2.53804_WP,      3.3472_WP,      4.2951_WP,       5.814_WP,        11.540056110_WP,   &
                  3.36030_WP,      5.1174_WP,      7.2093_WP,      10.561_WP,        22.857125150_WP,   &
                  3.00645_WP,      4.2565_WP,      5.7147_WP,       8.022_WP,        16.387149750_WP,   &
                  2.81286_WP,      3.8625_WP,      5.0781_WP,       6.992_WP,        13.901803190_WP,   &
                  2.69268_WP,      3.6331_WP,      4.7181_WP,       6.422_WP,        12.560318740_WP,   &
                  2.61061_WP,      3.4817_WP,      4.4844_WP,       6.057_WP,        11.713667310_WP,   &
                  2.55086_WP,      3.3738_WP,      4.3197_WP,       5.802_WP,        11.128129780_WP,   &
                  2.50531_WP,      3.2927_WP,      4.1970_WP,       5.613_WP,        10.697947910_WP,   &
                  2.46941_WP,      3.2296_WP,      4.1020_WP,       5.467_WP,        10.368000370_WP,   &
                  2.44034_WP,      3.1789_WP,      4.0260_WP,       5.351_WP,        10.106627880_WP,   &
                  2.41632_WP,      3.1373_WP,      3.9639_WP,       5.257_WP,         9.894304921_WP,   &
                  3.28502_WP,      4.9646_WP,      6.9367_WP,      10.044_WP,        21.039595270_WP,   &
                  2.92447_WP,      4.1028_WP,      5.4564_WP,       7.559_WP,        14.905358530_WP,   &
                  2.72767_WP,      3.7083_WP,      4.8256_WP,       6.552_WP,        12.552745390_WP,   &
                  2.60534_WP,      3.4780_WP,      4.4683_WP,       5.994_WP,        11.282751510_WP,   &
                  2.52164_WP,      3.3258_WP,      4.2361_WP,       5.636_WP,        10.480722470_WP,   &
                  2.46058_WP,      3.2172_WP,      4.0721_WP,       5.386_WP,         9.925612909_WP,   &
                  2.41397_WP,      3.1355_WP,      3.9498_WP,       5.200_WP,         9.517454314_WP,   &
                  2.37715_WP,      3.0717_WP,      3.8549_WP,       5.057_WP,         9.204149865_WP,   &
                  2.34731_WP,      3.0204_WP,      3.7790_WP,       4.942_WP,         8.955774135_WP,   &
                  2.32260_WP,      2.9782_WP,      3.7168_WP,       4.849_WP,         8.753866275_WP /
!...=====================================================================================================
!...
!...                 0.1             0.05            0.025            0.01               0.001
!--------------------------------------------------------------------------------------------------------
    DATA  TABL2/  3.22520_WP,      4.8443_WP,      6.7241_WP,       9.646_WP,        19.686785650_WP,   &
                  2.85951_WP,      3.9823_WP,      5.2559_WP,       7.206_WP,        13.811554540_WP,   &
                  2.66023_WP,      3.5874_WP,      4.6300_WP,       6.217_WP,        11.561125850_WP,   &
                  2.53619_WP,      3.3567_WP,      4.2751_WP,       5.668_WP,        10.346115970_WP,   &
                  2.45118_WP,      3.2039_WP,      4.0440_WP,       5.316_WP,         9.578375041_WP,   &
                  2.38907_WP,      3.0946_WP,      3.8807_WP,       5.069_WP,         9.046621909_WP,   &
                  2.34157_WP,      3.0123_WP,      3.7586_WP,       4.886_WP,         8.655347931_WP,   &
                  2.30400_WP,      2.9480_WP,      3.6638_WP,       4.744_WP,         8.354786262_WP,   &
                  2.27350_WP,      2.8962_WP,      3.5879_WP,       4.632_WP,         8.116347343_WP,   &
                  2.24823_WP,      2.8536_WP,      3.5257_WP,       4.539_WP,         7.922390621_WP,   &
                  3.17655_WP,      4.7472_WP,      6.5538_WP,       9.330_WP,        18.643321570_WP,   &
                  2.80680_WP,      3.8853_WP,      5.0959_WP,       6.927_WP,        12.973665960_WP,   &
                  2.60552_WP,      3.4903_WP,      4.4742_WP,       5.953_WP,        10.804204380_WP,   &
                  2.48010_WP,      3.2592_WP,      4.1212_WP,       5.412_WP,         9.632726103_WP,   &
                  2.39402_WP,      3.1059_WP,      3.8911_WP,       5.064_WP,         8.892109207_WP,   &
                  2.33102_WP,      2.9961_WP,      3.7283_WP,       4.821_WP,         8.378814227_WP,   &
                  2.28278_WP,      2.9134_WP,      3.6065_WP,       4.640_WP,         8.000868384_WP,   &
                  2.24457_WP,      2.8486_WP,      3.5118_WP,       4.499_WP,         7.710352309_WP,   &
                  2.21352_WP,      2.7964_WP,      3.4358_WP,       4.388_WP,         7.479735839_WP,   &
                  2.18776_WP,      2.7534_WP,      3.3736_WP,       4.296_WP,         7.292029030_WP,   &
                  3.13621_WP,      4.6672_WP,      6.4143_WP,       9.074_WP,        17.815420470_WP,   &
                  2.76317_WP,      3.8056_WP,      4.9653_WP,       6.701_WP,        12.312729810_WP,   &
                  2.56027_WP,      3.4105_WP,      4.3472_WP,       5.739_WP,        10.208935590_WP,   &
                  2.43371_WP,      3.1791_WP,      3.9959_WP,       5.205_WP,         9.072738309_WP,   &
                  2.34672_WP,      3.0254_WP,      3.7667_WP,       4.862_WP,         8.354088263_WP,   &
                  2.28298_WP,      2.9153_WP,      3.6043_WP,       4.620_WP,         7.855728193_WP,   &
                  2.23410_WP,      2.8321_WP,      3.4827_WP,       4.441_WP,         7.488554553_WP,   &
                  2.19535_WP,      2.7669_WP,      3.3880_WP,       4.302_WP,         7.206147377_WP,   &
                  2.16382_WP,      2.7144_WP,      3.3120_WP,       4.191_WP,         6.981836475_WP,   &
                  2.13763_WP,      2.6710_WP,      3.2497_WP,       4.100_WP,         6.799160117_WP,   &
                  3.10221_WP,      4.6001_WP,      6.2979_WP,       8.862_WP,        17.143360260_WP,   &
                  2.72647_WP,      3.7389_WP,      4.8567_WP,       6.515_WP,        11.778870570_WP,   &
                  2.52222_WP,      3.3439_WP,      4.2417_WP,       5.564_WP,         9.729366315_WP,   &
                  2.39469_WP,      3.1122_WP,      3.8919_WP,       5.035_WP,         8.622319637_WP,   &
                  2.30694_WP,      2.9582_WP,      3.6634_WP,       4.695_WP,         7.921807358_WP,   &
                  2.24256_WP,      2.8477_WP,      3.5014_WP,       4.456_WP,         7.435768361_WP,   &
                  2.19313_WP,      2.7642_WP,      3.3799_WP,       4.278_WP,         7.077472347_WP,   &
                  2.15390_WP,      2.6987_WP,      3.2853_WP,       4.140_WP,         6.801739796_WP,   &
                  2.12195_WP,      2.6458_WP,      3.2093_WP,       4.030_WP,         6.582612114_WP,   &
                  2.09540_WP,      2.6022_WP,      3.1469_WP,       3.939_WP,         6.404064741_WP,   &
                  3.07319_WP,      4.5431_WP,      6.1995_WP,       8.683_WP,        16.587416340_WP,   &
                  2.69517_WP,      3.6823_WP,      4.7650_WP,       6.359_WP,        11.339148240_WP,   &
                  2.48979_WP,      3.2874_WP,      4.1528_WP,       5.417_WP,         9.335253585_WP,   &
                  2.36143_WP,      3.0556_WP,      3.8043_WP,       4.893_WP,         8.252683745_WP,   &
                  2.27302_WP,      2.9013_WP,      3.5764_WP,       4.556_WP,         7.567391978_WP,   &
                  2.20808_WP,      2.7905_WP,      3.4147_WP,       4.318_WP,         7.091684190_WP,   &
                  2.15818_WP,      2.7066_WP,      3.2934_WP,       4.142_WP,         6.740824738_WP,   &
                  2.11853_WP,      2.6408_WP,      3.1987_WP,       4.004_WP,         6.470676858_WP,   &
                  2.08621_WP,      2.5876_WP,      3.1227_WP,       3.895_WP,         6.255880292_WP,   &
                  2.05932_WP,      2.5437_WP,      3.0602_WP,       3.805_WP,         6.080778142_WP,   &
                  3.04811_WP,      4.4940_WP,      6.1151_WP,       8.531_WP,        16.120195510_WP,   &
                  2.66817_WP,      3.6337_WP,      4.6867_WP,       6.226_WP,        10.970989650_WP,   &
                  2.46181_WP,      3.2389_WP,      4.0768_WP,       5.292_WP,         9.005936856_WP,   &
                  2.33274_WP,      3.0069_WP,      3.7294_WP,       4.773_WP,         7.944202271_WP,   &
                  2.24376_WP,      2.8524_WP,      3.5021_WP,       4.437_WP,         7.271859486_WP,   &
                  2.17833_WP,      2.7413_WP,      3.3406_WP,       4.202_WP,         6.804934648_WP,   &
                  2.12800_WP,      2.6572_WP,      3.2194_WP,       4.026_WP,         6.460391446_WP,   &
                  2.08798_WP,      2.5911_WP,      3.1248_WP,       3.890_WP,         6.194981663_WP,   &
                  2.05533_WP,      2.5377_WP,      3.0488_WP,       3.780_WP,         5.983855012_WP,   &
                  2.02815_WP,      2.4935_WP,      2.9862_WP,       3.691_WP,         5.811668029_WP,   &
                  3.02623_WP,      4.4513_WP,      6.0420_WP,       8.400_WP,        15.722226350_WP,   &
                  2.64464_WP,      3.5915_WP,      4.6189_WP,       6.112_WP,        10.658438190_WP,   &
                  2.43743_WP,      3.1968_WP,      4.0112_WP,       5.185_WP,         8.726852036_WP,   &
                  2.30775_WP,      2.9647_WP,      3.6648_WP,       4.669_WP,         7.683062089_WP,   &
                  2.21825_WP,      2.8100_WP,      3.4379_WP,       4.336_WP,         7.021866266_WP,   &
                  2.15239_WP,      2.6987_WP,      3.2767_WP,       4.102_WP,         6.562497005_WP,   &
                  2.10169_WP,      2.6143_WP,      3.1556_WP,       3.927_WP,         6.223382666_WP,   &
                  2.06134_WP,      2.5480_WP,      3.0610_WP,       3.791_WP,         5.962041028_WP,   &
                  2.02839_WP,      2.4943_WP,      2.9849_WP,       3.682_WP,         5.754061542_WP,   &
                  2.00094_WP,      2.4499_WP,      2.9222_WP,       3.593_WP,         5.584371076_WP,   &
                  3.00698_WP,      4.4139_WP,      5.9781_WP,       8.285_WP,        15.379305980_WP,   &
                  2.62395_WP,      3.5546_WP,      4.5597_WP,       6.013_WP,        10.389912210_WP,   &
                  2.41601_WP,      3.1599_WP,      3.9539_WP,       5.092_WP,         8.487454528_WP,   &
                  2.28577_WP,      2.9277_WP,      3.6083_WP,       4.579_WP,         7.459277515_WP,   &
                  2.19583_WP,      2.7729_WP,      3.3820_WP,       4.248_WP,         6.807775867_WP,   &
                  2.12958_WP,      2.6613_WP,      3.2209_WP,       4.015_WP,         6.354973351_WP,   &
                  2.07854_WP,      2.5767_WP,      3.0999_WP,       3.841_WP,         6.020573523_WP,   &
                  2.03789_WP,      2.5102_WP,      3.0053_WP,       3.705_WP,         5.762761197_WP,   &
                  2.00467_WP,      2.4563_WP,      2.9291_WP,       3.597_WP,         5.557508841_WP,   &
                  1.97698_WP,      2.4117_WP,      2.8664_WP,       3.508_WP,         5.389978842_WP,   &
                  2.98990_WP,      4.3807_WP,      5.9216_WP,       8.185_WP,        15.080841020_WP,   &
                  2.60561_WP,      3.5219_WP,      4.5075_WP,       5.926_WP,        10.156811770_WP,   &
                  2.39702_WP,      3.1274_WP,      3.9034_WP,       5.010_WP,         8.279932106_WP,   &
                  2.26630_WP,      2.8951_WP,      3.5587_WP,       4.500_WP,         7.265460600_WP,   &
                  2.17596_WP,      2.7401_WP,      3.3327_WP,       4.171_WP,         6.622465306_WP,   &
                  2.10936_WP,      2.6283_WP,      3.1718_WP,       3.939_WP,         6.175421571_WP,   &
                  2.05802_WP,      2.5435_WP,      3.0509_WP,       3.765_WP,         5.845153016_WP,   &
                  2.01710_WP,      2.4768_WP,      2.9563_WP,       3.631_WP,         5.590430454_WP,   &
                  1.98364_WP,      2.4227_WP,      2.8801_WP,       3.523_WP,         5.387562915_WP,   &
                  1.95573_WP,      2.3779_WP,      2.8172_WP,       3.434_WP,         5.221919789_WP,   &
                  2.97465_WP,      4.3512_WP,      5.8715_WP,       8.096_WP,        14.818775550_WP,   &
                  2.58925_WP,      3.4928_WP,      4.4613_WP,       5.849_WP,         9.952623150_WP,   &
                  2.38009_WP,      3.0984_WP,      3.8587_WP,       4.938_WP,         8.098379787_WP,   &
                  2.24893_WP,      2.8661_WP,      3.5147_WP,       4.431_WP,         7.096034067_WP,   &
                  2.15823_WP,      2.7109_WP,      3.2891_WP,       4.103_WP,         6.460561850_WP,   &
                  2.09132_WP,      2.5990_WP,      3.1283_WP,       3.871_WP,         6.018608472_WP,   &
                  2.03970_WP,      2.5140_WP,      3.0074_WP,       3.699_WP,         5.691989043_WP,   &
                  1.99853_WP,      2.4471_WP,      2.9128_WP,       3.564_WP,         5.439993193_WP,   &
                  1.96485_WP,      2.3928_WP,      2.8365_WP,       3.457_WP,         5.239228000_WP,   &
                  1.93674_WP,      2.3479_WP,      2.7737_WP,       3.368_WP,         5.075246211_WP /
!...=====================================================================================================
!...
!...                 0.1             0.05            0.025            0.01               0.001
!--------------------------------------------------------------------------------------------------------
    DATA  TABL3/  2.96096_WP,      4.3248_WP,      5.8266_WP,       8.017_WP,        14.586878060_WP,   &
                  2.57457_WP,      3.4668_WP,      4.4199_WP,       5.780_WP,         9.772326153_WP,   &
                  2.36489_WP,      3.0725_WP,      3.8188_WP,       4.874_WP,         7.938255045_WP,   &
                  2.23334_WP,      2.8401_WP,      3.4754_WP,       4.369_WP,         6.946712411_WP,   &
                  2.14231_WP,      2.6848_WP,      3.2501_WP,       4.042_WP,         6.317940339_WP,   &
                  2.07512_WP,      2.5727_WP,      3.0895_WP,       3.812_WP,         5.880518225_WP,   &
                  2.02325_WP,      2.4876_WP,      2.9686_WP,       3.640_WP,         5.557144922_WP,   &
                  1.98186_WP,      2.4205_WP,      2.8740_WP,       3.506_WP,         5.307572584_WP,   &
                  1.94797_WP,      2.3660_WP,      2.7977_WP,       3.398_WP,         5.108674052_WP,   &
                  1.91967_WP,      2.3210_WP,      2.7348_WP,       3.310_WP,         4.946165606_WP,   &
                  2.94858_WP,      4.3009_WP,      5.7863_WP,       7.945_WP,        14.380255030_WP,   &
                  2.56131_WP,      3.4434_WP,      4.3828_WP,       5.719_WP,         9.611991651_WP,   &
                  2.35117_WP,      3.0491_WP,      3.7829_WP,       4.817_WP,         7.796008703_WP,   &
                  2.21927_WP,      2.8167_WP,      3.4401_WP,       4.313_WP,         6.814150802_WP,   &
                  2.12794_WP,      2.6613_WP,      3.2151_WP,       3.988_WP,         6.191383370_WP,   &
                  2.06050_WP,      2.5491_WP,      3.0546_WP,       3.758_WP,         5.758020256_WP,   &
                  2.00840_WP,      2.4638_WP,      2.9338_WP,       3.587_WP,         5.437552906_WP,   &
                  1.96680_WP,      2.3965_WP,      2.8392_WP,       3.453_WP,         5.190148353_WP,   &
                  1.93273_WP,      2.3419_WP,      2.7628_WP,       3.346_WP,         4.992917879_WP,   &
                  1.90425_WP,      2.2967_WP,      2.6998_WP,       3.258_WP,         4.831724520_WP,   &
                  2.93736_WP,      4.2793_WP,      5.7498_WP,       7.881_WP,        14.195011740_WP,   &
                  2.54929_WP,      3.4221_WP,      4.3492_WP,       5.664_WP,         9.468502010_WP,   &
                  2.33873_WP,      3.0280_WP,      3.7505_WP,       4.765_WP,         7.668829050_WP,   &
                  2.20651_WP,      2.7955_WP,      3.4083_WP,       4.264_WP,         6.695701994_WP,   &
                  2.11491_WP,      2.6400_WP,      3.1835_WP,       3.939_WP,         6.078346209_WP,   &
                  2.04723_WP,      2.5277_WP,      3.0232_WP,       3.710_WP,         5.648639651_WP,   &
                  1.99492_WP,      2.4422_WP,      2.9023_WP,       3.539_WP,         5.330788559_WP,   &
                  1.95312_WP,      2.3748_WP,      2.8077_WP,       3.406_WP,         5.085334185_WP,   &
                  1.91888_WP,      2.3201_WP,      2.7313_WP,       3.299_WP,         4.889602925_WP,   &
                  1.89025_WP,      2.2747_WP,      2.6682_WP,       3.211_WP,         4.729590237_WP,   &
                  2.92712_WP,      4.2597_WP,      5.7166_WP,       7.823_WP,        14.028010820_WP,   &
                  2.53833_WP,      3.4028_WP,      4.3187_WP,       5.614_WP,         9.339352920_WP,   &
                  2.32739_WP,      3.0088_WP,      3.7211_WP,       4.718_WP,         7.554460810_WP,   &
                  2.19488_WP,      2.7763_WP,      3.3794_WP,       4.218_WP,         6.589244543_WP,   &
                  2.10303_WP,      2.6207_WP,      3.1548_WP,       3.895_WP,         5.976790793_WP,   &
                  2.03513_WP,      2.5082_WP,      2.9946_WP,       3.667_WP,         5.550395104_WP,   &
                  1.98263_WP,      2.4226_WP,      2.8738_WP,       3.496_WP,         5.234911592_WP,   &
                  1.94066_WP,      2.3551_WP,      2.7791_WP,       3.363_WP,         4.991220743_WP,   &
                  1.90625_WP,      2.3002_WP,      2.7027_WP,       3.256_WP,         4.796843990_WP,   &
                  1.87748_WP,      2.2547_WP,      2.6396_WP,       3.168_WP,         4.637896886_WP,   &
                  2.91774_WP,      4.2417_WP,      5.6864_WP,       7.770_WP,        13.876697450_WP,   &
                  2.52831_WP,      3.3852_WP,      4.2909_WP,       5.568_WP,         9.222510359_WP,   &
                  2.31702_WP,      2.9912_WP,      3.6943_WP,       4.675_WP,         7.451074703_WP,   &
                  2.18424_WP,      2.7587_WP,      3.3530_WP,       4.177_WP,         6.493059157_WP,   &
                  2.09216_WP,      2.6030_WP,      3.1287_WP,       3.855_WP,         5.885066330_WP,   &
                  2.02406_WP,      2.4904_WP,      2.9685_WP,       3.627_WP,         5.461682430_WP,   &
                  1.97138_WP,      2.4047_WP,      2.8478_WP,       3.457_WP,         5.148351478_WP,   &
                  1.92925_WP,      2.3371_WP,      2.7531_WP,       3.324_WP,         4.906262879_WP,   &
                  1.89469_WP,      2.2821_WP,      2.6766_WP,       3.217_WP,         4.713115713_WP,   &
                  1.86578_WP,      2.2365_WP,      2.6135_WP,       3.129_WP,         4.555134934_WP,   &
                  2.90913_WP,      4.2252_WP,      5.6586_WP,       7.721_WP,        13.738970620_WP,   &
                  2.51910_WP,      3.3690_WP,      4.2655_WP,       5.526_WP,         9.116305638_WP,   &
                  2.30749_WP,      2.9752_WP,      3.6697_WP,       4.637_WP,         7.357171892_WP,   &
                  2.17447_WP,      2.7426_WP,      3.3289_WP,       4.140_WP,         6.405738218_WP,   &
                  2.08218_WP,      2.5868_WP,      3.1048_WP,       3.818_WP,         5.801821989_WP,   &
                  2.01389_WP,      2.4741_WP,      2.9447_WP,       3.591_WP,         5.381189419_WP,   &
                  1.96104_WP,      2.3883_WP,      2.8240_WP,       3.421_WP,         5.069823880_WP,   &
                  1.91876_WP,      2.3205_WP,      2.7293_WP,       3.288_WP,         4.829197263_WP,   &
                  1.88407_WP,      2.2655_WP,      2.6528_WP,       3.182_WP,         4.637171121_WP,   &
                  1.85503_WP,      2.2197_WP,      2.5896_WP,       3.094_WP,         4.480070488_WP,   &
                  2.90119_WP,      4.2100_WP,      5.6331_WP,       7.677_WP,        13.613087010_WP,   &
                  2.51061_WP,      3.3541_WP,      4.2421_WP,       5.488_WP,         9.019357252_WP,   &
                  2.29871_WP,      2.9604_WP,      3.6472_WP,       4.601_WP,         7.271512947_WP,   &
                  2.16546_WP,      2.7278_WP,      3.3067_WP,       4.106_WP,         6.326118571_WP,   &
                  2.07298_WP,      2.5719_WP,      3.0828_WP,       3.785_WP,         5.725942086_WP,   &
                  2.00452_WP,      2.4591_WP,      2.9228_WP,       3.558_WP,         5.307832651_WP,   &
                  1.95151_WP,      2.3732_WP,      2.8021_WP,       3.388_WP,         4.998268652_WP,   &
                  1.90909_WP,      2.3053_WP,      2.7074_WP,       3.256_WP,         4.758981281_WP,   &
                  1.87427_WP,      2.2501_WP,      2.6309_WP,       3.149_WP,         4.567981245_WP,   &
                  1.84511_WP,      2.2043_WP,      2.5676_WP,       3.062_WP,         4.411685477_WP,   &
                  2.89385_WP,      4.1960_WP,      5.6096_WP,       7.636_WP,        13.497588240_WP,   &
                  2.50276_WP,      3.3404_WP,      4.2205_WP,       5.453_WP,         8.930511897_WP,   &
                  2.29060_WP,      2.9467_WP,      3.6264_WP,       4.568_WP,         7.193064301_WP,   &
                  2.15714_WP,      2.7141_WP,      3.2863_WP,       4.074_WP,         6.253230915_WP,   &
                  2.06447_WP,      2.5581_WP,      3.0626_WP,       3.754_WP,         5.656497301_WP,   &
                  1.99585_WP,      2.4453_WP,      2.9027_WP,       3.528_WP,         5.240709971_WP,   &
                  1.94270_WP,      2.3593_WP,      2.7820_WP,       3.358_WP,         4.932803227_WP,   &
                  1.90014_WP,      2.2913_WP,      2.6872_WP,       3.226_WP,         4.694747102_WP,   &
                  1.86520_WP,      2.2360_WP,      2.6106_WP,       3.120_WP,         4.504689719_WP,   &
                  1.83593_WP,      2.1900_WP,      2.5473_WP,       3.032_WP,         4.349132686_WP,   &
                  2.88703_WP,      4.1830_WP,      5.5878_WP,       7.598_WP,        13.391245100_WP,   &
                  2.49548_WP,      3.3277_WP,      4.2006_WP,       5.420_WP,         8.848799400_WP,   &
                  2.28307_WP,      2.9340_WP,      3.6072_WP,       4.538_WP,         7.120957395_WP,   &
                  2.14941_WP,      2.7014_WP,      3.2674_WP,       4.045_WP,         6.186261216_WP,   &
                  2.05658_WP,      2.5454_WP,      3.0438_WP,       3.725_WP,         5.592707510_WP,   &
                  1.98781_WP,      2.4324_WP,      2.8840_WP,       3.499_WP,         5.179064288_WP,   &
                  1.93452_WP,      2.3463_WP,      2.7633_WP,       3.330_WP,         4.872687108_WP,   &
                  1.89184_WP,      2.2783_WP,      2.6686_WP,       3.198_WP,         4.635766714_WP,   &
                  1.85679_WP,      2.2229_WP,      2.5919_WP,       3.092_WP,         4.446578231_WP,   &
                  1.82741_WP,      2.1768_WP,      2.5286_WP,       3.005_WP,         4.291701540_WP,   &
                  2.88069_WP,      4.1709_WP,      5.5675_WP,       7.562_WP,        13.293014370_WP,   &
                  2.48872_WP,      3.3158_WP,      4.1821_WP,       5.390_WP,         8.773397887_WP,   &
                  2.27607_WP,      2.9223_WP,      3.5894_WP,       4.510_WP,         7.054457147_WP,   &
                  2.14223_WP,      2.6896_WP,      3.2499_WP,       4.018_WP,         6.124520950_WP,   &
                  2.04925_WP,      2.5336_WP,      3.0265_WP,       3.699_WP,         5.533913138_WP,   &
                  1.98033_WP,      2.4205_WP,      2.8667_WP,       3.473_WP,         5.122255677_WP,   &
                  1.92692_WP,      2.3343_WP,      2.7460_WP,       3.304_WP,         4.817294523_WP,   &
                  1.88412_WP,      2.2662_WP,      2.6513_WP,       3.173_WP,         4.581424983_WP,   &
                  1.84896_WP,      2.2107_WP,      2.5746_WP,       3.067_WP,         4.393039913_WP,   &
                  1.81949_WP,      2.1646_WP,      2.5112_WP,       2.979_WP,         4.238791759_WP /
!...=====================================================================================================
!...
!...                 0.1             0.05            0.025            0.01               0.001
!--------------------------------------------------------------------------------------------------------
    DATA  TABL4/  2.83535_WP,      4.0847_WP,      5.4239_WP,       7.314_WP,        12.609357830_WP,   &
                  2.44037_WP,      3.2317_WP,      4.0510_WP,       5.179_WP,         8.250750892_WP,   &
                  2.22609_WP,      2.8387_WP,      3.4633_WP,       4.313_WP,         6.594539978_WP,   &
                  2.09095_WP,      2.6060_WP,      3.1261_WP,       3.828_WP,         5.698134144_WP,   &
                  1.99682_WP,      2.4495_WP,      2.9037_WP,       3.514_WP,         5.128263425_WP,   &
                  1.92688_WP,      2.3359_WP,      2.7444_WP,       3.291_WP,         4.730568331_WP,   &
                  1.87252_WP,      2.2490_WP,      2.6238_WP,       3.124_WP,         4.435546744_WP,   &
                  1.82886_WP,      2.1802_WP,      2.5289_WP,       2.993_WP,         4.207036577_WP,   &
                  1.79290_WP,      2.1240_WP,      2.4519_WP,       2.888_WP,         4.024261400_WP,   &
                  1.76269_WP,      2.0772_WP,      2.3882_WP,       2.801_WP,         3.874386084_WP,   &
                  2.79107_WP,      4.0012_WP,      5.2856_WP,       7.077_WP,        11.972987290_WP,   &
                  2.39325_WP,      3.1504_WP,      3.9253_WP,       4.977_WP,         7.767762354_WP,   &
                  2.17741_WP,      2.7581_WP,      3.3425_WP,       4.126_WP,         6.171230784_WP,   &
                  2.04099_WP,      2.5252_WP,      3.0077_WP,       3.649_WP,         5.306701558_WP,   &
                  1.94571_WP,      2.3683_WP,      2.7863_WP,       3.339_WP,         4.756520750_WP,   &
                  1.87472_WP,      2.2541_WP,      2.6274_WP,       3.119_WP,         4.372054609_WP,   &
                  1.81939_WP,      2.1665_WP,      2.5068_WP,       2.953_WP,         4.086419814_WP,   &
                  1.77483_WP,      2.0970_WP,      2.4117_WP,       2.823_WP,         3.864828170_WP,   &
                  1.73802_WP,      2.0401_WP,      2.3344_WP,       2.718_WP,         3.687295280_WP,   &
                  1.70701_WP,      1.9926_WP,      2.2702_WP,       2.632_WP,         3.541475241_WP,   &
                  2.74781_WP,      3.9201_WP,      5.1523_WP,       6.851_WP,        11.380190330_WP,   &
                  2.34734_WP,      3.0718_WP,      3.8046_WP,       4.787_WP,         7.321107258_WP,   &
                  2.12999_WP,      2.6802_WP,      3.2269_WP,       3.949_WP,         5.781368317_WP,   &
                  1.99230_WP,      2.4472_WP,      2.8943_WP,       3.480_WP,         4.947154185_WP,   &
                  1.89587_WP,      2.2899_WP,      2.6740_WP,       3.174_WP,         4.415675807_WP,   &
                  1.82381_WP,      2.1750_WP,      2.5154_WP,       2.956_WP,         4.043746615_WP,   &
                  1.76748_WP,      2.0868_WP,      2.3948_WP,       2.792_WP,         3.766975258_WP,   &
                  1.72196_WP,      2.0164_WP,      2.2994_WP,       2.663_WP,         3.551881884_WP,   &
                  1.68425_WP,      1.9588_WP,      2.2217_WP,       2.559_WP,         3.379237205_WP,   &
                  1.65238_WP,      1.9105_WP,      2.1570_WP,       2.472_WP,         3.237162411_WP,   &
                  2.70554_WP,      3.8415_WP,      5.0239_WP,       6.635_WP,        10.827566170_WP,   &
                  2.30259_WP,      2.9957_WP,      3.6889_WP,       4.605_WP,         6.907755279_WP,   &
                  2.08380_WP,      2.6049_WP,      3.1161_WP,       3.782_WP,         5.422078732_WP,   &
                  1.94486_WP,      2.3719_WP,      2.7858_WP,       3.319_WP,         4.616706738_WP,   &
                  1.84727_WP,      2.2141_WP,      2.5665_WP,       3.017_WP,         4.103001130_WP,   &
                  1.77411_WP,      2.0986_WP,      2.4082_WP,       2.802_WP,         3.742957414_WP,   &
                  1.71672_WP,      2.0096_WP,      2.2875_WP,       2.639_WP,         3.474555193_WP,   &
                  1.67020_WP,      1.9384_WP,      2.1918_WP,       2.511_WP,         3.265560195_WP,   &
                  1.63152_WP,      1.8799_WP,      2.1136_WP,       2.407_WP,         3.097462763_WP,   &
                  1.59872_WP,      1.8307_WP,      2.0483_WP,       2.321_WP,         2.958829845_WP /
!...=====================================================================================================
!...
    EQUIVALENCE  (TABLE(1,1,1),  TABL1(1))
    EQUIVALENCE  (TABLE(1,1,11), TABL2(1))
    EQUIVALENCE  (TABLE(1,1,21), TABL3(1))
    EQUIVALENCE  (TABLE(1,1,31), TABL4(1))
!...
!...DETERMINE IF TOO MANY VARIATES LISTED
    IF (MM > 10) THEN
        WRITE (3,990)
        FF = 2.32_WP
        RETURN
    ENDIF
!...
!...DETERMINE CORRECT NUMBER OF DEGREES OF FREEDOM
    DF = NN-MM-1
!...
!...SELECT SIGNIFICANCE LEVEL
    IF (SL == SLT(1)) THEN
        L = 1
    ELSEIF (SL == SLT(2)) THEN
        L = 2
    ELSEIF (SL == SLT(3)) THEN
        L = 3
    ELSEIF (SL == SLT(4)) THEN
        L = 4
    ELSEIF (SL == SLT(5)) THEN
        L = 5
    ELSE
        WRITE (IOUT,991) SL
        SL = HUNDTH_W
        L = 2
    ENDIF
!...
!...CALCULATE F FOR SMALL DEGREES OF FREEDOM
    IF (DF <= XDF(1)) THEN
        FF = TABLE(L,MM,DF)
        RETURN
    ENDIF
!...
!...CALCULATE F FOR LARGE DEGREES OF FREEDOM
    DO I = 2,7
        IF (DF-XDF(I) < ZERO_W) THEN
            FF = TABLE(L,MM,I+26) + ((ONE_W/DF - ONE_W/XDF(I))/(ONE_W/XDF(I-1) -                            &
                                      ONE_W/XDF(I)))*(TABLE(L,MM,I+25) - TABLE(L,MM,I+26))
            RETURN
        ENDIF
    ENDDO
    DO I = 2,7
        IF (DF-XDF(I) == ZERO_W) THEN
            DF = I+26
            FF = TABLE(L,MM,DF)
            RETURN
        ENDIF
    ENDDO
    DO I = 2,7
        IF (DF-XDF(I) > ZERO_W) THEN
            FF = TABLE(L,MM,33) + ((ONE_W/NN)/THOUTH_W)*(TABLE(L,MM,33) - TABLE(L,MM,34))
            RETURN
        ENDIF
    ENDDO
!...
!...FORMAT STATEMENTS
990 FORMAT (/,1X,"**NUMBER OF VARIABLES > 10.  F HAS BEEN SET TO A DUMMY VALUE OF 2.32",//)
991 FORMAT (/,1X,"**SIGNIFICANCE LEVEL",F6.3," IS NOT ACCEPTABLE.  LEVEL IS SET TO 0.01",//)
!...
!...DONE
    END SUBROUTINE FTABLE
!...
!...-----------------------------------------------------------------------------------------------------
!...
!... SUBROUTINE DSINV (AA,NN,EPS,IER)
!...
!...**************************************************************************************
!...
!... SUBROUTINE DSINV
!...
!... PURPOSE
!...  INVERT A GIVEN SYMMETRIC POSITIVE DEFINITE MATRIX
!...
!... USAGE
!...  CALL DSINV (A,N,EPS,IER)
!...
!... DESCRIPTION OF PARAMETERS
!...  AA  - DOUBLE PRECISION UPPER TRIANGULAR PART OF GIVEN SYMMETRIC
!...      POSITIVE DEFINITE N BY N COEFFICIENT MATRIX.
!...      ON RETURN A CONTAINS THE RESULTANT UPPER TRIANGULAR
!...      MATRIX IN DOUBLE PRECISION.
!...  NN  - THE NUMBER OF ROWS (COLUMNS) IN GIVEN MATRIX.
!...  EPS  - SINGLE PRECISION INPUT CONSTANT WHICH IS USED AS RELATIVE
!...      TOLERANCE FOR TEST ON LOSS OF SIGNIFICANCE.
!...  IER  - RESULTING ERROR PARAMETER CODED AS FOLLOWS
!...      IER =  0 - NO ERROR
!...      IER = -1 - NO RESULT BECAUSE OF WRONG INPUT PARAMETER
!...        N OR BECAUSE SOME RADICAND IS NONPOSITIVE
!...        (MATRIX A IS NOT POSITIVE DEFINITE, POSSIBLY
!...        DUE TO LOSS OF SIGNIFICANCE)
!...      IER = K  - WARNING WHICH INDICATES LOSS OF SIGNIFICANCE.
!...        THE RADICAND FORMED AT FACTORIZATION STEP K+1
!...        WAS STILL POSITIVE BUT NO LONGER GREATER THAN
!...        ABS(EPS*A(K+1,K+1)).
!...
!... REMARKS
!...  THE UPPER TRIANGULAR PART OF GIVEN MATRIX IS ASSUMED TO BE STORED
!...  COLUMNWISE IN N*(N+1)/2 SUCCESSIVE STORAGE LOCATIONS.  IN THE SAME
!...  STORAGE LOCATIONS THE RESULTING UPPER TRIANGULAR MATRIX IS STORED
!...  COLUMNWISE TOO.
!...  THE PROCEDURE GIVES RESULTS IF N IS GREATER THAN 0 AND ALL CALCULATED
!...  RADICANDS ARE POSITIVE.
!...
!... SUBROUTINES AND FUNCTION SUBPROGRAMS REQUIRED
!...  DMFSD
!...
!... METHOD
!...  SOLUTION IS DONE_W USING FACTORIZATION BY SUBROUTINE DMFSD
!...
!...
!...     SUBROUTINE UPDATE BY MALCOLM FIELD
!...
!**************************************************************************************
!...
    SUBROUTINE DSINV (AA,NN,EPS,IER)
!...
!...IDENTIFY TRANSFERED VALIABLES
    INTEGER(I4B), INTENT(IN)                            :: NN
    INTEGER(I4B), INTENT(INOUT)                         :: IER
    REAL(WP), INTENT(INOUT)                             :: EPS
    REAL(WP), DIMENSION(1:1), INTENT(INOUT)             :: AA
!...
!...DECLARE LOCAL VARIABLES
    INTEGER(I4B)                                        :: IND, IPIV, I, MINN, J, KEND, LANF, LHOR, LVER, K, L
    REAL(WP)                                            :: DIN, WORK
!...
!...FACTORIZE GIVEN MATRIX BY MEANS OF SUBROUTINE DMFSD -- A = TRANSPOSE(T) * T
    CALL DMFSD(AA,NN,EPS,IER)
!...
!...CHECK FOR ERRORS --- RETURN IF NEGATIVE VALUE
    IF (IER < 0) RETURN
!...
!...INVERT UPPER TRIANGULAR MATRIX T, PREPARE INVERSION-LOOP
    IPIV = NN*(NN+1)/2
    IND  = IPIV
!...
!...INITIALIZE INVERSION-LOOP
    DO I = 1,NN
        DIN = ONE_W/A(IPIV)
        AA(IPIV) = DIN
        MINN  = NN
        KEND = I-1
        LANF = NN-KEND
        IF (KEND <= 0) GOTO 5
        J = IND
        DO K = 1,KEND
            WORK = ZERO_W
            MINN  = MINN-1
            LHOR = IPIV
            LVER = J
            DO L = LANF,MINN
                LVER = LVER+1
                LHOR = LHOR+L
                WORK = WORK+A(LVER)*A(LHOR)
            ENDDO
            AA(J) = -WORK*DIN
            J = J-MINN
        ENDDO
5       IPIV = IPIV-MINN
        IND  = IND-1
    ENDDO                   !...END OF INVERSION LOOP
!...
!...CALCULATE INVERSE(A) BY MEANS OF INVERSE(T)
!...INVERSE(A) = INVERSE(T) * TRANSPOSE(INVERSE(T))
!...
!...INITIALIZE MULTIPLICATION-LOOP
    DO I = 1,NN
        IPIV = IPIV+I
        J = IPIV
        DO K = I,NN
            WORK = ZERO_W
            LHOR = J
            DO L = K,NN
                LVER = LHOR+K-I
                WORK = WORK+AA(LHOR)*AA(LVER)
                LHOR = LHOR+L
            ENDDO
            AA(J) = WORK
            J = J+K
        ENDDO
    ENDDO               !...END OF ROW- AND MULTIPLICATION-LOOP
!...
!...DONE
    RETURN
    END SUBROUTINE DSINV
!...
!-----------------------------------------------------------------------------------------------------
!...
!... SUBROUTINE DMFSD
!...
!... PURPOSE
!...  FACTOR A GIVEN SYMMETRIC POSITIVE DEFINITE MATRIX
!...
!... USAGE
!...  CALL DMFSDV (AA,NN,EPS,IER)
!...
!... DESCRIPTION OF PARAMETERS
!...  A  - DOUBLE PRECISION UPPER TRIANGULAR PART OF GIVEN SYMMETRIC
!...      POSITIVE DEFINITE N BY N COEFFICIENT MATRIX.
!...      ON RETURN A CONTAINS THE RESULTANT UPPER TRIANGULAR
!...      MATRIX IN DOUBLE PRECISION.
!...  N  - THE NUMBER OF ROWS (COLUMNS) IN GIVEN MATRIX.
!...  EPS  - SINGLE PRECISION INPUT CONSTANT WHICH IS USED AS RELATIVE
!...      TOLERANCE FOR TEST ON LOSS OF SIGNIFICANCE.
!...  IER  - RESULTING ERROR PARAMETER CODED AS FOLLOWS
!...      IER =  0 - NO ERROR
!...      IER = -1 - NO RESULT BECAUSE OF WRONG INPUT PARAMETER
!...        N OR BECAUSE SOME RADICAND IS NONPOSITIVE
!...        (MATRIX A IS NOT POSITIVE DEFINITE, POSSIBLY
!...        DUE TO LOSS OF SIGNIFICANCE)
!...      IER = K  - WARNING WHICH INDICATES LOSS OF SIGNIFICANCE.
!...        THE RADICAND FORMED AT FACTORIZATION STEP K+1
!...        WAS STILL POSITIVE BUT NO LONGER GREATER THAN
!...        ABS(EPS*A(K+1,K+1)).
!...
!... REMARKS
!...  THE UPPER TRIANGULAR PART OF GIVEN MATRIX IS ASSUMED TO BE STORED
!...  COLUMNWISE IN N*(N+1)/2 SUCCESSIVE STORAGE LOCATIONS.  IN THE SAME
!...  STORAGE LOCATIONS THE RESULTING UPPER TRIANGULAR MATRIX IS STORED
!...  COLUMNWISE TOO.
!...  THE PROCEDURE GIVES RESULTS IF N IS GREATER THAN 0 AND ALL CALCULATED
!...  RADICANDS ARE POSITIVE.
!...  THE PRODUCT OF RETURNED DIAGONAL TERMS IS EQUAL TO THE SQUARE-ROOT
!...  OF THE DETERMINANT OF THE GIVEN MATRIX.
!...
!... SUBROUTINES AND FUNCTION SUBPROGRAMS REQUIRED
!...  NONE
!...
!... METHOD
!...  SOLUTION IS DONE_W USING THE SQUARE-ROOT METHOD OF CHOLESKY.  THE GIVEN
!...  MATRIX IS REPRESENTED AS PRODUCT OF TWO TRIANGULAR MATRICES, WHERE
!...  THE LEFT HAND FACTOR IS THE TRANSPOSE OF THE RETURNED RIGHT HAND FACTOR.
!...
!...
!...       SUBROUTINE UPDATE BY MALCOLM FIELD
!...
!...
!**************************************************************************************
!...
    SUBROUTINE DMFSD (AA,N1,EPS,IER)
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                           :: ABS
!...
!...IDENTIFY TRANSFERED VALIABLES
    INTEGER(I4B), INTENT(IN)                            :: N1
    INTEGER(I4B), INTENT(OUT)                           :: IER
    REAL(WP), INTENT(INOUT)                             :: EPS
    REAL(WP), DIMENSION(1:1), INTENT(INOUT)             :: AA
!...
!...DECLARE LOCAL VARIABLES
    INTEGER(I4B)                                        :: KPIV, K, IND, LEND, LANF, LIND, L, I
    REAL(WP)                                            :: TOL, WPIV, DSUM
!...
!...TEST ON WRONG INPUT PARAMETER N
    IF (N1-1 < 0) THEN
        IER = -1
        RETURN
    ELSE
        IER = 0
    ENDIF
!...
!...INITIALIZE DIAGONAL-LOOP
    KPIV = 0
    DO K = 1,N1
        KPIV = KPIV+K
        IND  = KPIV
        LEND = K-1
!...
!...CALCULATE TOLERANCE
        TOL = ABS(EPS*(AA(KPIV)))
!...
!...START FACTORIZATION-LOOP OVER K-TH ROW
        DO I = K,N1
            DSUM = ZERO_W
            IF (LEND /= 0) THEN
                DO L = 1,LEND
                    LANF = KPIV-L
                    LIND = IND-L
                    DSUM = DSUM + AA(LANF)*AA(LIND)
                ENDDO
            ENDIF
            DSUM = AA(IND)-DSUM
            IF (I-K /= 0) GOTO 10
            IF ((DSUM)-TOL <= ZERO_W) THEN
                IER = -1
                RETURN
            ELSE
                GOTO 9
            ENDIF
            IF (DSUM > ZERO_W) GOTO 9
            IF (IER > 0) GOTO 9
            IER = K-1
9           WPIV = SQRT(DSUM)
            AA(KPIV) = WPIV
            WPIV = ONE_W/WPIV
            GOTO 11
10          AA(IND) = DSUM*WPIV
11          IND = IND+I
        ENDDO
    ENDDO               !...END OF DIAGONAL ELEMENT
!...
!...DONE
    RETURN
    END SUBROUTINE DMFSD
!...
!-----------------------------------------------------------------------------------------------------
!...
!... SUBROUTINE MPRD (AA,BB,RR)
!...
!**************************************************************************************
!...
!... SUBROUTINE MPRD
!...
!... PURPOSE
!...  MULTIPLY TWO VECTORS TO FORM A RESULTANT VECTOR
!...
!... USAGE
!...  CALL MPRD (AA,BB,RR)
!...
!... DESCRIPTION OF PARAMETERS
!...  AA - NAME OF FIRST INPUT MATRIX
!...  BB - NAME OF SECOND INPUT MATRIX
!...  RR - NAME OF OUTPUT MATRIX
!...
!...     SUBROUTINE UPDATED BY MALCOLM FIELD
!...
!**************************************************************************************
!...
    SUBROUTINE MPRD (AA,BB,RR)
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                           :: DOT_PRODUCT
!...
!...IDENTIFY TRANSFERED VALIABLES
    REAL(WP), DIMENSION(1:1), INTENT(IN)                :: AA, BB
    REAL(WP), DIMENSION(1:1), INTENT(INOUT)             :: RR
!...
!...MULTIPLY TWO VECTORS
    RR = DOT_PRODUCT(AA,BB)
!...
!...DONE
    RETURN
    END SUBROUTINE MPRD
!...
!...REALLY DONE
END SUBROUTINE MTVOUT
