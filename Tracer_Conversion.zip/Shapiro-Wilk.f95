!...
!...LIST OF SUBROUTINES AND ARGUMENTS
! SWILK (INIT,X,N,N1,N2,A,W,PW,IFAULT)
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                    SUBROUTINE SWILK                  *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 09/10/19          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...SUBROUTINE TO TO DETERMINE IF THE MEASURED DATA CONFORMS TO A NORMAL DISTRIBUTION
!...
SUBROUTINE SWILK (INIT,X,N,N1,N2,A,W,PW,IFAULT)
!...
!...ALGORITHM AS R94 APPL. STATIST. (1995) VOL.44, NO.4
!...
!...CALCULATES THE SHAPIRO-WILK W TEST AND ITS SIGNIFICANCE LEVEL
!...
! ARGUMENTS:
!...INIT     SET TO .FALSE. ON THE FIRST CALL SO THAT WEIGHTS A(N2) CAN BE
!...         CALCULATED.   SET TO .TRUE. ON EXIT UNLESS IFAULT = 1 OR 3.
!   X(N1)    SAMPLE VALUES IN ASCENDING ORDER.
!   N        THE TOTAL SAMPLE SIZE (INCLUDING ANY RIGHT-CENSORED VALUES).
!   N1       THE NUMBER OF UNCENSORED CASES (N1 <= N).
!   N2       INTEGER PART OF N/2.
!   A(N2)    THE CALCULATED WEIGHTS.
!   W        THE SHAPIRO-WILKS W-STATISTIC.
!   PW       THE P-VALUE FOR W.
!   IFAULT   ERROR INDICATOR:
!            = 0 FOR NO ERROR
!            = 1 IF N1 < 3
!            = 2 IF N > 5000 (A NON-FATAL ERROR)
!            = 3 IF N2 < N/2
!            = 4 IF N1 > N OR (N1 < N AND N < 20).
!            = 5 IF THE PROPORTION CENSORED (N - N1)/N > 0.8.
!            = 6 IF THE DATA HAVE ZERO RANGE.
!            = 7 IF THE X'S ARE NOT SORTED IN INCREASING ORDER
!...
!...AUXILIARY FUNCTIONS
!...
!...REAL(WP) :: PPND, ALNORM, POLY
!...
!...FORTRAN 90 VERSION BY ALAN.MILLER @ VIC.CMIS.CSIRO.AU
!...LATEST REVISION - 4 DECEMBER 1998
!...
!...CORRECTED BY MALCOLM FIELD 10 SEPTEMBER 2019
!...
!...ADD MODULE DATA TYPE DEFINITION
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ASIN, LOG, MIN, SIGN
!...
!...IDENTIFY TRANSFERED VALIABLES
INTEGER(I4B), INTENT(IN)                            :: N, N1, N2
INTEGER(I4B), INTENT(OUT)                           :: IFAULT
REAL(WP), INTENT(OUT)                               :: PW, W
REAL(WP), DIMENSION(1:N), INTENT(IN)                :: X
REAL(WP), DIMENSION(1:N2), INTENT(OUT)              :: A
LOGICAL, INTENT(INOUT)                              :: INIT
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                        :: NCENS, NN2, I, I1, J
REAL(WP)                                            :: SUMM2, SSUMM2, FAC, RSN, AN, AN25, A1, A2, DELTA, RNGE
REAL(WP)                                            :: SA, SX, SSX, SSA, SAX, ASA, XSX, SSASSX, W1, Y, XX, XI
REAL(WP)                                            :: GMMA, M, S, LD, BF, Z90F, Z95F, Z99F, ZFM, ZSD, ZBAR
!...
REAL(WP), PARAMETER                                 :: Z90   =     1.281600_WP,  Z95 = 1.644900_WP, &
                                                       Z99   =     2.326300_WP
REAL(WP), PARAMETER                                 :: ZM    =     1.750900_WP,  ZSS = 0.562680_WP
REAL(WP), PARAMETER                                 :: BF1   =     0.837800_WP, XX90 = 0.556000_WP, &
                                                       XX95  =     0.622000_WP
REAL(WP), PARAMETER                                 :: SQRTH =     0.707110_WP,   TH = 0.375000_WP
REAL(WP), PARAMETER                                 :: PI6   =     1.909859_WP, STQR = 1.047198_WP
!...
REAL(WP), DIMENSION(1:6), PARAMETER                 :: C1 = (/ ZERO_W, 0.2211570_WP,                &
                                                                      -0.1479810_WP,                &
                                                                      -2.0711900_WP,                &
                                                                       4.4346850_WP,                &
                                                                      -2.7060560_WP /)
!...
REAL(WP), DIMENSION(1:6), PARAMETER                 :: C2 = (/ ZERO_W, 0.042981_WP,                 &
                                                                      -0.293762_WP,                 &
                                                                      -1.752461_WP,                 &
                                                                       5.682633_WP,                 &
                                                                      -3.582633_WP /)
!...
REAL(WP), DIMENSION(1:4), PARAMETER                 :: C3 = (/ 0.5440000_WP, -0.3997800_WP,         &
                                                               0.0250540_WP, -0.6714E-3_WP /)
!...
REAL(WP), DIMENSION(1:4), PARAMETER                 :: C4 = (/ 1.3822000_WP, -0.7785700_WP,         &
                                                               0.0627670_WP, -0.0020322_WP /)
!...
REAL(WP), DIMENSION(1:4), PARAMETER                 :: C5 = (/ -1.5861000_WP, -0.3108200_WP,        &
                                                               -0.0837510_WP,  0.0038915_WP /)
!...
REAL(WP), DIMENSION(1:3), PARAMETER                 :: C6 = (/ -0.4803000_WP, -0.082676_WP,         &
                                                                0.0030302_WP /)
!...
REAL(WP), DIMENSION(1:2), PARAMETER                 :: C7 = (/  0.164000_WP,  0.533000_WP /)
REAL(WP), DIMENSION(1:2), PARAMETER                 :: C8 = (/  0.173600_WP,  0.315000_WP /)
REAL(WP), DIMENSION(1:2), PARAMETER                 :: C9 = (/  0.256000_WP, -0.006350_WP /)
REAL(WP), DIMENSION(1:2), PARAMETER                 :: G  = (/ -2.273000_WP,  0.459000_WP /)
LOGICAL, SAVE                                       :: UPPER = .TRUE.
!***
!*******END DECLARATIONS*******
!***
!...
PW =  ONE_W
IF (W >= ZERO_W) W = ONE_W
AN = N
IFAULT = 3
NN2 = N/2
IF (N2 < NN2) RETURN
IFAULT = 1
IF (N < 3) RETURN
!...
!...IF INIT IS FALSE, CALCULATES COEFFICIENTS FOR THE TEST
IF (.NOT. INIT) THEN
    IF (N == 3) THEN
        A(1) = SQRTH
    ELSE
        AN25 = AN+QUART_W
        SUMM2 = ZERO_W
        DO I = 1,N2
            CALL PPND7((I - TH)/AN25,A(I),IFAULT)
            SUMM2 = SUMM2 + A(I)**2
        ENDDO
         SUMM2 = SUMM2*TWO_W
        SSUMM2 = SQRT(SUMM2)
        RSN = ONE_W/SQRT(AN)
        A1 = POLY(C1,6,RSN) - A(1)/SSUMM2
!...
!...NORMALIZE COEFFICIENTS
        IF (N > 5) THEN
            I1 = 3
            A2 = -A(2)/SSUMM2 + POLY(C2,6,RSN)
            FAC = SQRT((SUMM2 - TWO_W*A(1)**2 - TWO_W*A(2)**2)/(ONE_W - TWO_W*A1**2 - TWO_W*A2**2))
            A(1) = A1
            A(2) = A2
        ELSE
            I1 = 2
            FAC = SQRT((SUMM2 - TWO_W*A(1)**2)/(ONE_W - TWO_W*A1**2))
            A(1) = A1
        ENDIF
        DO I = I1,NN2
            A(I) = -A(I)/FAC
        ENDDO
    ENDIF
    INIT = .TRUE.
ENDIF
IF (N1 < 3) RETURN
NCENS = N-N1
IFAULT = 4
IF (NCENS < 0 .OR. (NCENS > 0 .AND. N < 20)) RETURN
IFAULT = 5
DELTA = REAL(NCENS, KIND=WP)/AN
IF (DELTA > 0.8_WP) RETURN
!...
!...IF W INPUT AS NEGATIVE, CALCULATE SIGNIFICANCE LEVEL OF -W
IF (W < ZERO_W) THEN
    W1 = ONE_W + W
    IFAULT = 0
    GOTO 70
ENDIF
!...
!...CHECK FOR ZERO RNGE
IFAULT = 6
RNGE = X(N1)-X(1)
IF (RNGE < SMALL_W) RETURN
!...
!...CHECK FOR CORRECT SORT ORDER ON RNGE - SCALED X
IFAULT = 7
XX = X(1)/RNGE
SX = XX
SA = -A(1)
J  = N-1
DO I = 2,N1
    XI = X(I)/RNGE
    IF (XX-XI > SMALL_W) THEN
        WRITE(*, *) "X(I)s OUT OF ORDER"
        RETURN
    ENDIF
    SX = SX+XI
    IF (I /= J) SA = SA + SIGN(1,I-J)*A(MIN(I,J))
    XX = XI
    J = J-1
ENDDO
IFAULT = 0
IF (N > 5000) IFAULT = 2
!...
!...CALCULATE W STATISTIC AS SQUARED CORRELATION BETWEEN DATA AND COEFFICIENTS
SA  = SA/N1
SX  = SX/N1
SSA = ZERO_W
SSX = ZERO_W
SAX = ZERO_W
J = N
DO I = 1,N1
    IF (I /= J) THEN
        ASA = SIGN(1,I-J)*A(MIN(I,J)) - SA
    ELSE
        ASA = -SA
    ENDIF
    XSX = X(I)/RNGE - SX
    SSA = SSA + ASA*ASA
    SSX = SSX + XSX*XSX
    SAX = SAX + ASA*XSX
    J = J-1
ENDDO
!...
!...W1 EQUALS (1-W) CLACULATED TO AVOID EXCESSIVE ROUNDING ERROR FOR W VERY NEAR 1 (A POTENTIAL PROBLEM IN VERY LARGE SAMPLES)
SSASSX = SQRT(SSA*SSX)
W1 = (SSASSX - SAX)*(SSASSX + SAX)/(SSA*SSX)
70 W = ONE_W-W1
!...
!...CALCULATE SIGNIFICANCE LEVEL FOR W (EXACT FOR N=3)
IF (N == 3) THEN
    PW = PI6*(ASIN(SQRT(W)) - STQR)
    RETURN
ENDIF
Y  = LOG(W1)
XX = LOG(AN)
M  = ZERO_W
S  = ONE_W
IF (N <= 11) THEN
    GMMA = POLY(G,2,AN)
    IF (Y >= GMMA) THEN
        PW = SMALL_W
        RETURN
    ENDIF
    Y = -LOG(GMMA-Y)
    M =  POLY(C3,4,AN)
    S =  EXP(POLY(C4,4,AN))
ELSE
    M = POLY(C5,4,XX)
    S = EXP(POLY(C6,3,XX))
ENDIF
IF (NCENS > 0) THEN
!...
!...CENSORING BY PROPORTION NCENS/N.  CALCULATE MEAN AND SD OF NORMAL EQUIVALENT DEVIATE OF W.
      LD = -LOG(DELTA)
      BF =  ONE_W + XX*BF1
    Z90F =  Z90 + BF*POLY(C7,2,XX90**XX)**LD
    Z95F =  Z95 + BF*POLY(C8,2,XX95**XX)**LD
    Z99F =  Z99 + BF*POLY(C9,2,XX)**LD
!...
!...REGRESS Z90F,...,Z99F ON NORMAL DEVIATES Z90,...,Z99 TO GET PSEUDO-MEAN AND PSEUDO-SD OF Z AS THE SLOPE AND INTERCEPT
     ZFM = (Z90F+Z95F+Z99F)/THREE_W
     ZSD = (Z90*(Z90F-ZFM) + Z95*(Z95F-ZFM) + Z99*(Z99F-ZFM))/ZSS
    ZBAR = ZFM - ZSD*ZM
    M = M+ZBAR*S
    S = S*ZSD
ENDIF
PW = ALNORM((Y-M)/S,UPPER)
!...
!...done
RETURN
!...
!...ADD REQUIRED SUBROUTINES
CONTAINS
    !...
    !-----------------------------------------------------------------------------------------------------
    !...
    ! SUBROUTINE PPND7(P,NORMAL_DEV,IFAULT)
    !...
    !-----------------------------------------------------------------------------------------------------
!...
    SUBROUTINE PPND7(P,NORMAL_DEV,IFAULT)
!...
!...ALGORITHM AS241  APPL. STATIST. (1988) VOL. 37, NO. 3, 477- 484.
!...
!...PRODUCES THE NORMAL DEVIATE Z CORRESPONDING TO A GIVEN LOWER TAIL AREA OF P;
!...Z IS ACCURATE TO ABOUT 1 PART IN 10**7.
!...
!...THE HASH SUMS BELOW ARE THE SUMS OF THE MANTISSAS OF THE COEFFICIENTS.
!...THEY ARE INCLUDED FOR USE IN CHECKING TRANSCRIPTION.
!...
!...THIS ELF90-COMPATIBLE VERSION BY ALAN MILLER - 20 AUGUST 1996
!...N.B. THE ORIGINAL ALGORITHM IS AS A FUNCTION; THIS IS A SUBROUTINE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                           :: ABS, LOG
!...
!...IDENTIFY TRANSFERED VALIABLES
    INTEGER(I4B), INTENT(OUT)                           :: IFAULT
    REAL(WP), INTENT(IN)                                :: P
    REAL(WP), INTENT(OUT)                               :: NORMAL_DEV
!...
!...IDENTIFY SUBROUTINE VALIABLES
    REAL(WP)                                            :: SPLIT1 = 0.425000_WP, SPLIT2 = FIVE_W
    REAL(WP)                                            :: CONST1 = 0.180625_WP, CONST2 = 1.6_WP, Q, R
!...
!...COEFFICIENTS FOR P CLOSE TO 0.5
    REAL(WP)                                            :: A0 = 3.3871327179E+00_WP, A1 = 5.0434271938E+01_WP, &
                                                           A2 = 1.5929113202E+02_WP, A3 = 5.9109374720E+01_WP, &
                                                           B1 = 1.7895169469E+01_WP, B2 = 7.8757757664E+01_WP, &
                                                           B3 = 6.7187563600E+01_WP
!...
!...COEFFICIENTS FOR P NOT CLOSE TO 0, 0.5 OR 1.
    REAL(WP)                                            :: C0 = 1.4234372777E+00_WP, C1 = 2.7568153900E+00_WP, &
                                                           C2 = 1.3067284816E+00_WP, C3 = 1.7023821103E-01_WP, &
                                                           D1 = 7.3700164250E-01_WP, D2 = 1.2021132975E-01_WP
!...
!...COEFFICIENTS FOR P NEAR 0 OR 1.
    REAL(WP)                                            :: E0 = 6.6579051150E+00_WP, E1 = 3.0812263860E+00_WP, &
                                                           E2 = 4.2868294337E-01_WP, E3 = 1.7337203997E-02_WP, &
                                                           F1 = 2.4197894225E-01_WP, F2 = 1.2258202635E-02_WP
!***
!*******END DECLARATIONS*******
!***
!...
    IFAULT = 0
    Q = P-HALF_W
    IF (ABS(Q) <= SPLIT1) THEN
        R = CONST1 - Q*Q
        NORMAL_DEV = Q*(((A3*R+A2)*R+A1)*R + A0)/(((B3*R+B2)*R+B1)*R + ONE_W)
        RETURN
    ELSE
        IF (Q < ZERO_W) THEN
            R = P
        ELSE
            R = ONE_W-P
        ENDIF
        IF (R <= ZERO_W) THEN
            IFAULT = 1
            NORMAL_DEV = ZERO_W
            RETURN
        ENDIF
        R = SQRT(-LOG(R))
        IF (R <= SPLIT2) THEN
            R = R-CONST2
            NORMAL_DEV = (((C3*R+C2)*R+C1)*R + C0)/((D2*R+D1)*R + ONE_W)
        ELSE
            R = R-SPLIT2
            NORMAL_DEV = (((E3*R+E2)*R+E1)*R + E0)/((F2*R+F1)*R + ONE_W)
        ENDIF
        IF (Q < ZERO_W) NORMAL_DEV = -NORMAL_DEV
        RETURN
    ENDIF
!...
!...DONE
    RETURN
    END SUBROUTINE PPND7
    !...
    !-----------------------------------------------------------------------------------------------------
    !...
    ! FUNCTION ALNORM(X,UPPER) RESULT(FN_VAL)
    !...
    !-----------------------------------------------------------------------------------------------------
!...
    FUNCTION ALNORM(X,UPPER) RESULT(FN_VAL)
!...
!...ALGORITHM AS66 APPLIED STATISTICS (1973) VOL.22, NO.3
!...
!...EVALUATES THE TAIL AREA OF THE STANDARDISED NORMAL CURVE
!...FROM X TO INFINITY IF UPPER IS .TRUE. OR
!...FROM MINUS INFINITY TO X IF UPPER IS .FALSE.
!...
!...ELF90-COMPATIBLE VERSION BY ALAN MILLER
!...LATEST REVISION - 29 NOVEMBER 1997
!...
!...IDENTIFY TRANSFERED VALIABLES
    REAL(WP), INTENT(IN)                                :: X
    LOGICAL, INTENT(IN)                                 :: UPPER
!...
!...IDENTIFY SUBROUTINE VALIABLES
    REAL(WP)                                            :: Z, Y
    REAL(WP)                                            :: FN_VAL
    REAL(WP), PARAMETER                                 :: CON = 1.28_WP
    LOGICAL                                             :: UP
!...
!*** MACHINE DEPENDENT CONSTANTS
    REAL(WP), PARAMETER                                 :: LTONE = SEVEN_W, UTZERO = 18.66_WP

    REAL(WP), PARAMETER                                 ::  P =   0.3989422804440_WP,  Q = 0.399903485040_WP,  &
                                                            R =   0.3989422803850_WP, A1 = 5.758854804580_WP,  &
                                                           A2 =   2.6243312167900_WP, A3 = 5.928857244380_WP,  &
                                                           B1 = -29.8213557807000_WP, B2 = 48.69599306920_WP,  &
                                                           C1 =  -3.8052000000E-8_WP, C2 = 3.980647940E-4_WP,  &
                                                           C3 =  -0.1516791166350_WP, C4 = 4.838591280800_WP,  &
                                                           C5 =   0.7423809240270_WP, C6 = 3.990194170110_WP,  &
                                                           D1 =   1.0000061530200_WP, D2 = 1.986153813640_WP,  &
                                                           D3 =   5.2933032492600_WP, D4 = -15.1508972451_WP,  &
                                                           D5 =  30.7899330340000_WP
!***
!*******END DECLARATIONS*******
!***
!...
    UP = UPPER
    Z = X
    IF(Z >=  ZERO_W) GOTO 10
    UP = .NOT. UP
    Z = -Z
10  IF (Z <= LTONE .OR. UP .AND. Z <= UTZERO) GOTO 20
    FN_VAL = ZERO_W
    GOTO 40
20  Y = HALF_W*Z*Z
    IF (Z > CON) GOTO 30
    FN_VAL = HALF_W - Z*(P-Q*Y/(Y+A1+B1/(Y+A2+B2/(Y+A3))))
    GOTO 40
30  FN_VAL = R*EXP(-Y)/(Z+C1+D1/(Z+C2+D2/(Z+C3+D3/(Z+C4+D4/(Z+C5+D5/(Z+C6))))))
40  IF(.NOT. UP) FN_VAL = ONE_W - FN_VAL
!...
!...DONE
    RETURN
    END FUNCTION ALNORM
    !...
    !-----------------------------------------------------------------------------------------------------
    !...
    ! FUNCTION POLY(C,NORD,X) RESULT(FN_VAL)
    !...
    !-----------------------------------------------------------------------------------------------------
!...
    FUNCTION POLY(C,NORD,X) RESULT(FN_VAL)
!...
!...ALGORITHM AS 181.2   APPL. STATIST.  (1982) VOL. 31, NO. 2
!...
!...CALCULATES THE ALGEBRAIC POLYNOMIAL OF ORDER NORED-1 WITH
!...ARRAY OF COEFFICIENTS C.  ZERO_W ORDER COEFFICIENT IS C(1)
!...
!...IDENTIFY TRANSFERED VALIABLES
    INTEGER(I4B), INTENT(IN)                            :: NORD
    REAL(WP)                                            :: FN_VAL
    REAL(WP), INTENT(IN)                                :: X
    REAL(WP), DIMENSION(:), INTENT(IN)                  :: C
!...
!...IDENTIFY SUBROUTINE VALIABLES
    INTEGER(I4B)                                        :: I, J, N2
    REAL(WP)                                            :: P
!***
!*******END DECLARATIONS*******
!***
!...
    FN_VAL = C(1)
    IF (NORD == 1) RETURN
    P = X*C(NORD)
    IF (NORD == 2) GOTO 20
    N2 = NORD-2
    J = N2+1
    DO I = 1,N2
        P = (P+C(J))*X
        J = J-1
    ENDDO
20  FN_VAL = FN_VAL+P
!...
!...DONE
    RETURN
    END FUNCTION POLY
!...
!...REALLY DONE
END SUBROUTINE SWILK
!...
!...
!...LIST OF SUBROUTINES AND ARGUMENTS
! QUICK_SORT (N1,LIST,ORDER)
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                 SUBROUTINE QUICK_SORT                *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 09/10/19          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...SUBROUTINE TO TO DETERMINE IF THE MEASURED DATA CONFORMS TO A NORMAL DISTRIBUTION
!...
RECURSIVE SUBROUTINE QUICK_SORT (N1,LIST,ORDER)
!...
! QUICK SORT ROUTINE FROM:
! BRAINERD, W.S., GOLDBERG, C.H. & ADAMS, J.C. (1990) "PROGRAMMER'S GUIDE TO
! FORTRAN 90", MCGRAW-HILL  ISBN 0-07-000248-7, PAGES 149-150.
! MODIFIED BY ALAN MILLER TO INCLUDE AN ASSOCIATED INTEGER ARRAY WHICH GIVES
! THE POSITIONS OF THE ELEMENTS IN THE ORIGINAL ORDER.
!...
!...CORRECTED BY MALCOLM FIELD 10 SEPTEMBER 2019
!...
!...ADD MODULE DATA TYPE DEFINITION
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...IDENTIFY TRANSFERED VALIABLES
INTEGER(I4B), INTENT(IN)                            :: N1
INTEGER(I4B), DIMENSION (1:N1), INTENT(OUT)         :: ORDER
REAL(WP), DIMENSION (1:N1), INTENT(INOUT)           :: LIST
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                        :: I
!***
!*******END DECLARATIONS*******
!***
!...
DO I = 1,N1
    ORDER(I) = I
ENDDO
!
CALL QUICK_SORT_1(1,N1)
RETURN
!...
!...ADD REQUIRED SUBROUTINES
CONTAINS
    !...
    !-----------------------------------------------------------------------------------------------------
    !...
    ! RECURSIVE SUBROUTINE QUICK_SORT_1(LEFT_END,RIGHT_END)
    !...
    !-----------------------------------------------------------------------------------------------------
!...
    RECURSIVE SUBROUTINE QUICK_SORT_1(LEFT_END,RIGHT_END)
!...
!...IDENTIFY TRANSFERED VALIABLES
    INTEGER(I4B), INTENT(IN)                            :: LEFT_END, RIGHT_END
!...
!...IDENTIFY SUBROUTINE VALIABLES
    INTEGER(I4B)                                        :: I, J, ITEMP
    INTEGER(I4B), PARAMETER                             :: MAX_SIMPLE_SORT_SIZE=6
    REAL(WP)                                            :: REFERENC, TEMP
!***
!*******END DECLARATIONS*******
!***
!...
    IF (RIGHT_END < LEFT_END + MAX_SIMPLE_SORT_SIZE) THEN
!...
!...USE INTERCHANGE SORT FOR SMALL LISTS
        CALL INTERCHANGE_SORT(LEFT_END,RIGHT_END)
    ELSE
!...
!...USE PARTITION ("QUICK") SORT
        REFERENC = LIST((LEFT_END + RIGHT_END)/2)
        I =  LEFT_END-1
        J = RIGHT_END+1
!
        DO
!...
!...SCAN LIST FROM LEFT END UNTIL ELEMENT >= REFERENCE IS FOUND
            DO
                I = I+1
                IF (LIST(I) >= REFERENC) EXIT
            ENDDO
!...
!...SCAN LIST FROM RIGHT END UNTIL ELEMENT <= REFERENCE IS FOUND
            DO
                J = J-1
                IF (LIST(J) <= REFERENC) EXIT
            ENDDO
!
            IF (I < J) THEN
!...
!...SWAP TWO OUT-OF-ORDER ELEMENTS
                TEMP     = LIST(I)
                LIST(I)  = LIST(J)
                LIST(J)  = TEMP
                ITEMP    = ORDER(I)
                ORDER(I) = ORDER(J)
                ORDER(J) = ITEMP
            ELSEIF (I == J) THEN
                I = I+1
                EXIT
            ELSE
                EXIT
            ENDIF
        ENDDO
        IF (LEFT_END < J)  CALL QUICK_SORT_1(LEFT_END, J)
        IF (I < RIGHT_END) CALL QUICK_SORT_1(I, RIGHT_END)
    ENDIF
!...
!...DONE
    RETURN
    END SUBROUTINE QUICK_SORT_1
    !...
    !-----------------------------------------------------------------------------------------------------
    !...
    ! SUBROUTINE INTERCHANGE_SORT(LEFT_END,RIGHT_END)
    !...
    !-----------------------------------------------------------------------------------------------------
!...
    SUBROUTINE INTERCHANGE_SORT(LEFT_END,RIGHT_END)
!...
!...IDENTIFY TRANSFERED VALIABLES
    INTEGER(I4B), INTENT(IN)                            :: LEFT_END, RIGHT_END
!...
!...IDENTIFY SUBROUTINE VALIABLES
    INTEGER(I4B)                                        :: I, J, ITEMP
    REAL(WP)                                            :: TEMP
!***
!*******END DECLARATIONS*******
!***
!...
    DO I = LEFT_END,RIGHT_END-1
        DO J = I+1,RIGHT_END
            IF (LIST(I) > LIST(J)) THEN
                TEMP = LIST(I)
                LIST(I)  = LIST(J)
                LIST(J)  = TEMP
                ITEMP    = ORDER(I)
                ORDER(I) = ORDER(J)
                ORDER(J) = ITEMP
            ENDIF
        ENDDO
    ENDDO
!...
!...DONE
    RETURN
    END SUBROUTINE INTERCHANGE_SORT
!...
!...REALLY DONE
END SUBROUTINE QUICK_SORT
