SUBROUTINE PLUGIN(X,N,Z,M,F,H)

! CODE CONVERTED USING TO_F90 BY ALAN MILLER
! DATE: 2001-06-11  TIME: 12:41:50

! CORRECTED BY MALCOLM FIELD
! DATE: 2017-08-30  TIME: 09:28:30

!-----------------------------------------------------------------------
!       VERSION: 1995
!       FORTRAN77

!       PURPOSE:

!       SIMPLE  SUBROUTINE FOR KERNEL DENSITY ESTIMATION
!       WITH ITERATIVE PLUG-IN BANDWIDTH SELECTION

!       THIS VERSION ONLY USES THE GAUSS KERNEL AND ESTIMATES ONLY
!       THE DENSITY ITSELF AND NOT ITS DERIVATIVES.

!  INPUT    X(N)   DOUBLE PRECISION   SORTED DATA
!  INPUT    N      INTEGER            LENGTH OF  X
!  INPUT    Z(M)   DOUBLE PRECISION   OUTPUT GRID (SORTED)
!  INPUT    M      INTEGER            LENGTH OF Z
!  OUTPUT   F(M)   DOUBLE PRECISION   ESTIMATED DENSITY
!  OUTPUT   H      DOUBLE PRECISION   ESTIMATED ITERATIVE PLUGIN BANDWIDTH

!-----------------------------------------------------------------------
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...IDENTIFY TRANSFERED VALIABLES
INTEGER(I4B), INTENT(IN)                            :: M, N
REAL(WP), INTENT(OUT)                               :: H
REAL(WP), DIMENSION(:), INTENT(IN)                  :: X, Z
REAL(WP), DIMENSION(:), INTENT(OUT)                 :: F
!...
!...IDENTIFY TRANSFERED VALIABLES
INTEGER(I4B)                                        :: I, IT, ITER, J, JBEGIN, JEND
REAL(WP)                                            :: A, CO1, CONST, D2, D3, E2, E3, H2, H3, R2
REAL(WP)                                            :: RHAT2, RHAT3, RT2PI, S, S2, S3, T, XIQR, XN
!...
!...BEGIN OPERATION
XN = N
XIQR = X(NINT(0.75_WP*XN)) - X(NINT(QUART_W*XN)+1)
RT2PI = SQRT(TWOPI_W)
ITER = 5
!...
!...ESTIMATE INFLATION CONSTANT C
H2 = (0.920_WP*XIQR)/(XN**(ONE_W/SEVEN_W))
H3 = (0.912_WP*XIQR)/(XN**(ONE_W/NINE_W))
S2 = ZERO_W
S3 = ZERO_W
LOOP20:  DO I = 1,N-1
    DO J = I + 1,N
        D2 = ((X(I)-X(J))/H2)**2
        D3 = ((X(I)-X(J))/H3)**2
        IF (D2 > FIFTY_W .AND. D3 > 60.0_WP) CYCLE LOOP20
        E2 = EXP(-HALF_W*D2)
        E3 = EXP(-HALF_W*D3)
        S2 = S2 + (D2**2 - SIX_W*D2 + THREE_W)*E2
        S3 = S3 + (D3**3 - 15.0_WP*D3**2 + 45.0_WP*D3 - 15.0_WP)*E3
    ENDDO
ENDDO LOOP20
RHAT2 = (TWO_W*S2)/((XN**2)*(H2**5)*RT2PI)
RHAT2 = RHAT2 + THREE_W/(RT2PI*XN*(H2**5))
RHAT3 = (-TWO_W*S3)/((XN**2)*(H3**7)*RT2PI)
RHAT3 = RHAT3 + 15.0_WP/(RT2PI*XN*(H3**SEVEN_W))
CO1   = 1.357_WP * (RHAT2/RHAT3)**(ONE_W/SEVEN_W)
!...
!...COMPUTE CONSTANT OF ASYMPTOTIC FORMULA
CONST = ONE_W/(TWO_W*SQRT(PI_W))
A = 1.132795764_WP/RHAT3**(ONE_W/SEVEN_W)*XN**(-ONE_W/TWO_W)
!...
!...LOOP OVER ITERATIONS
DO IT = 1,ITER
!...
!...ESTIMATE FUNCTIONAL
    S = ZERO_W
    LOOP40:  DO I = 1,N-1
        DO J = I + 1,N
            D2 = ((X(I) - X(J))/A)**2
            IF (D2 > FIFTY_W) CYCLE LOOP40
            E2 = EXP(-HALF_W*D2)
            S = S + (D2**2 - SIX_W*D2 + THREE_W)*E2
        ENDDO
    ENDDO LOOP40
    R2 = (TWO_W*S)/((XN**2)*(A**5)*RT2PI)
    R2 = R2 + THREE_W/(RT2PI*XN*(A**5))
!...
!...ESTIMATE BANDWIDTH BY ASYMPTOTIC FORMULA
    H = (CONST/(R2*XN))**(FIFTH_W)
    A = CO1 * H**(FIVE_W/SEVEN_W)
ENDDO
!...
!...ESTIMATE DENSITY WITH PLUGIN BANDWIDTH
JBEGIN = 1
JEND = 1
DO I = 1,M
    S = ZERO_W
    DO J = JBEGIN,JEND
        T = (Z(I) - X(J))/H
        IF (T > FIVE_W .AND. JBEGIN < N) THEN
            JBEGIN = JBEGIN+1
            CYCLE
        ENDIF
        S = S + EXP(-T*T/TWO_W)
    ENDDO
    DO JEND = J,N
        T = (Z(I) - X(JEND))/H
        IF (T < -FIVE_W) EXIT
        S = S + EXP(-T*T/TWO_W)
    ENDDO
    F(I) = S/(XN*H*RT2PI)
    JEND = JEND-1
ENDDO
!...
!...DONE
RETURN
END SUBROUTINE PLUGIN
