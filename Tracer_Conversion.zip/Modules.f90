!...
!...
!...
! *******************************************************************
!...
MODULE PLOT_CNTL
    USE NRTYPE
    CHARACTER(LEN=1)                                    :: PLINE, PL, DPMARK, DNPLOT
    INTEGER(I4B)                                        :: IPREPOST, ITM, ICN, IMETHOD
END MODULE PLOT_CNTL
!...
! *******************************************************************
!...
MODULE AA_SIZE
    USE NRTYPE
    INTEGER(I4B), SAVE                                  :: IREDUCE
    INTEGER(I4B)                                        :: NREDUCE
    REAL(WP), ALLOCATABLE, DIMENSION(:), SAVE           :: AA
END MODULE AA_SIZE
!...
! *******************************************************************
!...
MODULE UPDATE_EWMA
!...
!...UPDATE EXPONENTIALLY WEIGHTED MOVING AVERAGES (EWMA) & VARIANCES.
!...NEW AVERAGE = LAMBDA.X + (1 - LAMBDA).(OLD AVERAGE)
!...THE VARIANCE OF THE ESTIMATED MEAN = [LAMBDA/(2 - LAMBDA)].VARIANCE(X)

!...CODE BY ALAN MILLER; SLIGHTLY MODIFIED BY MALCOLM FIELD
!...AMILLER@BIGPOND.NET.AU
!...WEB SITES:
!...HTTP://WWW.OZEMAIL.COM.AU/~MILLERAJ/
!....HTTP://USERS.BIGPOND.NET.AU/AMILLER

!...LATEST REVISION - 11 APRIL 2018
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL, ONLY : NRERROR
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...DECLARE TRANSFERRED VARIABLES
INTEGER(I4B), SAVE, PRIVATE                             :: IEW
REAL(WP), SAVE, PRIVATE                                 :: LAMBDA, ONE_LAMBDA, DEG_FREEDOM
LOGICAL(FLG), SAVE, PRIVATE                             :: INITIALIZED

CONTAINS

    SUBROUTINE INITIALIZE (L)
!...
!...DECLARE TRANSFERRED VARIABLES
    REAL(WP), INTENT(IN)                                :: L
!...
!...OPEN BUTTERWORTH FILTER RESULTS AND WRITE OUTPUT
    OPEN  (NEWUNIT=IEW, FILE="EWMA_ANALYSIS.OUT", STATUS = "UNKNOWN", POSITION = "REWIND")
    WRITE (IEW,100)
!...
!...BEGIN PROGRAM EXECUTION
    LAMBDA = L
    INITIALIZED = .TRUE.
    ONE_LAMBDA  = ONE_W - LAMBDA
    DEG_FREEDOM = TWO_W * ONE_LAMBDA / (LAMBDA*(TWO_W - LAMBDA))
    WRITE (IEW,200) LAMBDA, ONE_LAMBDA, DEG_FREEDOM
    WRITE (IEW,300)
!...
!...FORMAT STATEMENTS
100 FORMAT (//,6X,"EWMA ANALYSIS",/,6X,13("="),//)
200 FORMAT (  11X,"LAMBDA =  ",F6.4,/,7X,"ONE_LAMBDA =  ",F6.4,/,6X,"DEG_FREEDOM = ",F7.4,//)
300 FORMAT (  7X,"ITER",10X,"AVERAGE",9X,"VARIANCE",/,4X,44("-"))
!...
!...DONE
    RETURN
    END SUBROUTINE INITIALIZE
!...
! -------------------------------------------------------------------
!...
    SUBROUTINE UPDATE (N,NN,X,AVERAGE,SUMSQ)
!...
!...NEW AVERAGE = LAMBDA.X + (1 - LAMBDA).(OLD AVERAGE)
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                           :: EXECUTE_COMMAND_LINE
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                            :: N, NN
    REAL(WP), INTENT(IN)                                :: X
    REAL(WP), INTENT(INOUT)                             :: AVERAGE, SUMSQ
!...
!...IDENTIFY SUBROUTINE VALIABLES
    INTEGER(I4B)                                        :: I
    REAL(WP)                                            :: DEV
!...
!...FOR SPEED, THE FOLLOWING LINES CAN BE COMMENTED OUT OR REMOVED
    IF (.NOT. INITIALIZED) THEN
        CALL EXECUTE_COMMAND_LINE("CLS")
        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
        DO I = 1,3
            WRITE (*,*)
        ENDDO
        CALL NRERROR("FATAL ERROR --> EWMA NOT INITIALIZED")
    ENDIF
!...
!...SOLVE FOR EWMA
    DEV = X - AVERAGE
    AVERAGE = AVERAGE + LAMBDA * DEV
    SUMSQ   = ONE_LAMBDA * SUMSQ + DEV * (X - AVERAGE)
    WRITE (IEW,100) N, AVERAGE, VARIANCE(SUMSQ)
    IF (N == NN) THEN
        WRITE (IEW,200)
        CLOSE (IEW)
    ENDIF
!...
!...FORMAT STATEMENTS
100 FORMAT (6X,I5,7X,ES10.4,7X,ES10.4)
200 FORMAT (4X,44("-"))
!...
!...DONE
    RETURN
    END SUBROUTINE UPDATE
!...
! -------------------------------------------------------------------
!...
    FUNCTION VARIANCE(SUMSQ) RESULT(FN_VAL)
!...
!...CALCULATE THE VARIANCE FROM THE SUM OF SQUARES
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...DECLARE TRANSFERRED VARIABLES
    REAL(WP), INTENT(IN)                                :: SUMSQ
    REAL(WP)                                            :: FN_VAL
!...
!...IDENTIFY SUBROUTINE VALIABLES
    FN_VAL = SUMSQ / DEG_FREEDOM
!...
!...DONE
    RETURN
    END FUNCTION VARIANCE
!...
!...DONE
END MODULE UPDATE_EWMA
!...
! *******************************************************************
!...
MODULE SAVIT_GOLAY
!
CONTAINS
!
    FUNCTION SAVGOL(NL,NRR,LD,M)
!...
!...RETURNS IN ARRAY SAVGOL, IN WRAP-AROUND ORDER (N.B.!) CONSISTENT WITH THE ARGUMENT RESPNS IN
!...ROUTINE CONVLV, A SET OF SAVITZKY-GOLAY FILTER COEFFICIENTS.  NL IS THE NUMBER OF LEFTWARD
!...(PAST) DATA POINTS USED, WHILE NRR IS THE NUMBER OF RIGHTWARD (FUTURE) DATA POINTS, MAKING
!...THE TOTAL NUMBER OF DATA POINTS USED NL+NRR+1.  LD IS THE ORDER OF THE DERIVATIVE DESIRED
!...(e.g., LD = 0 FOR SMOOTHED FUNCTION).  M IS THE ORDER OF THE SMOOTHING POLYNOMIAL, ALSO
!...EQUAL TO THE HIGHEST CONSERVED MOMENT; USUAL VALUE IS M = 2 OR M = 4.
!...
!...ADD TYPE AND UTILITY MODULES
    USE NRTYPE
    USE NRUTIL, ONLY : ARTH, ASSERT, POLYW_WWV
    USE NR, ONLY : LUBKSB, LUDCMP
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                           :: MIN, MOD, SUM
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                            :: NL, NRR, LD, M
!...
!...IDENTIFY LOCAL VARIABLES
    INTEGER(I4B)                                        :: NP
    INTEGER(I4B), DIMENSION(1:M+1)                      :: INDX
    INTEGER(I4B), DIMENSION(1:NL+NRR+1)                 :: IRNG
    REAL(WP)                                            :: D
    REAL(WP), DIMENSION(1:M+1)                          :: B
    REAL(WP), DIMENSION(1:M+1,1:M+1)                    :: A
    REAL(WP), DIMENSION(1:NL+NRR+1)                     :: SAVGOL
!...
!...CHECK NL, NRR, LD, M, AND NL+NRR ARRAY SIZES TO ENSURE COMPATIBILITY
    CALL ASSERT(NL >= 0, NRR >= 0, LD <= M, NL+NRR >= M, "             ARGS IN SAVGOL LINE 188")
!...
!...SET UP THE NORMAL EQUATIONS OF THE DESIRED LEAST SQUARES FIT
    BLOCK
        INTEGER(I4B)                                    :: IMJ, IPJ, MM
        REAL(WP)                                        :: SM
!...
        DO IPJ = 0,2*M
            SM = SUM(ARTH(ONE_W,ONE_W,NRR)**IPJ) + SUM(ARTH(-ONE_W,-ONE_W,NL)**IPJ)
            IF (IPJ == 0) SM = SM+ONE_W
            MM = MIN(IPJ,2*M-IPJ)
            DO IMJ = -MM,MM,2
                A(1+(IPJ+IMJ)/2,1 + (IPJ-IMJ)/2) = SM
            ENDDO
        ENDDO
    END BLOCK
!...
!...SOLVE THEM: LU DECOMPOSITION
    CALL LUDCMP(A(:,:),INDX(:),D)
    B(:) = ZERO_W
    B(LD+1) = ONE_W                                                            !...RIGHT-HAND-SIDE VECTOR IS UNIT VECTOR, DEPENDING
    CALL LUBKSB(A(:,:),INDX(:),B(:))                                           !...ON WHICH DERIVATIVE WE WANT.
!...
!...BACKSUBSTITUTE, GIVING ONE ROW OF THE INVERSE MATRIX
    SAVGOL(:) = ZERO_W                                                         !...ZERO THE OUTPUT ARRAY (IT MAY BE BIGGER THAN
    IRNG(:) = ARTH(-NL,1,NRR+NL+1)                                             !...NUMBER OF COEFFICIENTS).
    NP = NL+NRR+1
    SAVGOL(MOD(NP-IRNG(:),NP)+1) = POLYW_WWV(REAL(IRNG(:), KIND=WP),B(:))
!...
!...DONE WITH FNCTION
    END FUNCTION SAVGOL
!...
!...DONE WITH MODULE
END MODULE SAVIT_GOLAY
!...
! *******************************************************************
!...
MODULE FULL_DATA
    USE NRTYPE
    REAL(WP), ALLOCATABLE, DIMENSION(:), SAVE           :: XS, YS
END MODULE FULL_DATA
!...
!**********************************************************************************************
!...
MODULE INTERPOLATION
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...LIMIT ACCESS
PRIVATE
PUBLIC                                                  :: STEPIN
!...
!...INCLUDE INTERPOLATION STEP ROUTINE
CONTAINS
!...
!...BEGIN SUBROUTINE
    SUBROUTINE STEPIN (NN,ZDATA,CWDAT,MZ,XZ,CD,ISMTH)
!...
!...IDENTIFY SUBROUTINE VALIABLES
    INTEGER(I4B), INTENT(IN)                            :: NN, MZ, ISMTH
    REAL(SP), INTENT(IN), DIMENSION(:)                  :: ZDATA, CWDAT
    REAL(SP), INTENT(OUT), DIMENSION(:)                 :: XZ, CD
!...
!...IDENTIFY LOCAL VARIABLES
    INTEGER(I4B)                                        :: I, LWK, IERR
    REAL(SP)                                            :: STEP
    REAL(SP), DIMENSION(SIZE(XZ))                       :: CW, DD
    REAL(SP), DIMENSION(2*NN)                           :: WK
    LOGICAL(TLG)                                        :: SPLINE
!...
!...SET SPLINE TO FALSE
    IF (ISMTH == 1) THEN
        SPLINE = .TRUE.
    ELSE
        SPLINE = .FALSE.
    ENDIF
!...
!...
!...BEGIN INTERPOLATION ROUTINE
!...
!...SET WORK ARRAY SIZE
    LWK = 2*NN
!...
!...ACCESS PIECEWISE CUBIC INTERPOLATION
    CALL PCHEZ (NN,ZDATA,CWDAT,DD,SPLINE,WK,LWK,IERR)
    IF (IERR < 0) THEN
        WRITE (*,*) "   AN ERROR CALLING PCHEZ, IERR = ",IERR
        READ  (*,*)
    ENDIF
!...
!...DETERMINE STEP SIZE
    STEP = (ZDATA(NN) - ZDATA(1))/REAL(MZ,KIND=SP)
!...
!...SET INTERPOLATED FIRST POINT TO ORIGINAL FIRST POINT
    XZ(1) = ZDATA(1)
!...
!...SET INTERPOLATED DATA POINTS
    INTERP: DO I = 2,MZ
        XZ(I) = XZ(I-1) + STEP
    ENDDO INTERP
!...
!...SET INTERPOLATED MAXIMUM POINT TO ORIGINAL MAXIMUM POINT
    XZ(MZ) = ZDATA(NN)
!...
!...ACCESS PIECEWISE CUBIC HERMITE OR SPLINE DERIVATIVE EVALUATOR
    CALL PCHEV (NN,ZDATA,CWDAT,DD,MZ,XZ,CD,CW,IERR)
    IF (IERR /= 0) THEN
        WRITE (*,*) "   AN ERROR CALLING PCHEV, IERR = ",IERR
        READ  (*,*)
    ENDIF
!    DO I = 1,MZ
!        WRITE(111,*) I,XZ(I),CD(I)
!    ENDDO
!...
!...DONE WITH STEPIN SUBROUTINE
    RETURN
    END SUBROUTINE STEPIN
!...
!...DONE WITH INTERPOLATION MODULE
END MODULE INTERPOLATION
!...
! *******************************************************************
!...
MODULE PROGRAM_UNITS
!...
! -------------------------------------------------------------------
!...
INTERFACE
    SUBROUTINE FIT_POLY (X,Y,F,M,N)
    USE NRTYPE
    INTEGER(I4B), INTENT(IN)                            :: M, N
    REAL(WP), DIMENSION(1:N), INTENT(IN)                :: X, Y
    REAL(WP), DIMENSION(1:N), INTENT(OUT)               :: F
    END SUBROUTINE FIT_POLY
END INTERFACE
!...
! -------------------------------------------------------------------
!...
INTERFACE
    SUBROUTINE WEIGHTED_QUINTIC (NN,TT,CC,LAMBDA,FIT)
    USE NRTYPE
    INTEGER(I4B), INTENT(IN)                            :: NN
    REAL(WP), INTENT(IN)                                :: LAMBDA
    REAL(WP), DIMENSION(1:NN), INTENT(IN)               :: TT, CC
    REAL(WP), DIMENSION(1:NN), INTENT(OUT)              :: FIT
    END SUBROUTINE WEIGHTED_QUINTIC
END INTERFACE
!...
! -------------------------------------------------------------------
!...
INTERFACE
    SUBROUTINE LOWESS (X,Y,N,F,NSTEPS,DELTA,YS,RW,RES)
    USE NRTYPE
    INTEGER(I4B), INTENT(IN)                            :: N, NSTEPS
    REAL(WP), INTENT(IN)                                :: DELTA, F
    REAL(WP), INTENT(IN), DIMENSION(1:N)                :: X, Y
    REAL(WP), INTENT(OUT), DIMENSION(1:N)               :: YS, RES, RW
    END SUBROUTINE LOWESS
END INTERFACE
!...
! -------------------------------------------------------------------
!...
INTERFACE
    SUBROUTINE QUINTIC_SPLINE (XX,YY,NN,NS)
    USE NRTYPE
    INTEGER(I4B), INTENT(IN)                            :: NN, NS
    REAL(WP), DIMENSION(1:NN), INTENT(IN)               :: XX
    REAL(WP), DIMENSION(1:NN), INTENT(INOUT)            :: YY
    END SUBROUTINE QUINTIC_SPLINE
END INTERFACE
!...
! -------------------------------------------------------------------
!...
INTERFACE
    SUBROUTINE SMOOTH (DATA1,NN,IPTS)
    USE NRTYPE
    INTEGER(I4B), INTENT(IN)                            :: NN, IPTS
    REAL(WP), DIMENSION(:), INTENT(INOUT)               :: DATA1
    END SUBROUTINE SMOOTH
END INTERFACE
!...
! -------------------------------------------------------------------
!...
INTERFACE
    SUBROUTINE CONTROL (IPREPOST,BCKGRD,METHOD,MOVING,IREDUCE,IZERO,DL,ITM,ICN,PLINE,PL)
    USE NRTYPE
    CHARACTER(LEN=*), INTENT(INOUT)                   :: METHOD, MOVING, PLINE, PL
    INTEGER(I4B), INTENT(INOUT)                       :: IPREPOST, IREDUCE, IZERO, ITM, ICN
    REAL(WP), INTENT(INOUT)                           :: BCKGRD, DL
    END SUBROUTINE CONTROL
END INTERFACE
!...
! -------------------------------------------------------------------
!...
INTERFACE
    SUBROUTINE MOMENTS (NN,DATA1,AMEAN,ADEV,SDEV,VAR,SKEW,CURT,RMS,XMED,XMAD,PRNT)
    USE NRTYPE; USE NRUTIL, ONLY : ARRAY_COPY, NRERROR
    CHARACTER(LEN=*)                                    :: PRNT
    INTEGER(I4B), INTENT(IN)                            :: NN
    REAL(WP), INTENT(OUT)                               :: AMEAN, ADEV, SDEV, VAR, SKEW, CURT, RMS, XMED, XMAD
    REAL(WP), DIMENSION(1:NN), INTENT(IN)               :: DATA1
    END SUBROUTINE MOMENTS
END INTERFACE
!...
! -------------------------------------------------------------------
!...
INTERFACE
    SUBROUTINE SORT_PICKED (NN,ARR)
    USE NRTYPE
    INTEGER(I4B), INTENT(IN)                            :: NN
    REAL(WP), DIMENSION(1:NN), INTENT(INOUT)            :: ARR
    END SUBROUTINE SORT_PICKED
END INTERFACE
!...
! -------------------------------------------------------------------
!...
INTERFACE
    SUBROUTINE PLOT (N1,X1,Y1,DLL,AVEE,IMK,XM,YM,IPLT,IFPLT,FILEOUTT,IEP)
    USE NRTYPE
    USE PLOT_CNTL
    CHARACTER(LEN=*), INTENT(IN)                      :: FILEOUTT
    INTEGER(I4B), INTENT(IN)                          :: N1, IMK, IPLT, IFPLT, IEP
    REAL(WP), INTENT(IN), DIMENSION(1:N1)             :: X1, Y1
    REAL(WP), INTENT(IN), DIMENSION(1:IMK)            :: XM, YM
    REAL(WP), INTENT(IN)                              :: DLL, AVEE
    END SUBROUTINE PLOT
END INTERFACE
!...
! -------------------------------------------------------------------
!...
INTERFACE
    SUBROUTINE PLOT_SMOOTHING (N1,X1,Y1,Z1,DLL,AVEE,IMK,XM,YM,IPLT,IFPLT,FILEOUTT,IEP)
    USE DISLIN
    USE NRTYPE
    USE PLOT_CNTL
    USE FULL_DATA
    CHARACTER(LEN=*), INTENT(IN)                      :: FILEOUTT
    INTEGER(I4B), INTENT(IN)                          :: N1, IMK, IPLT, IFPLT, IEP
    REAL(WP), INTENT(IN), DIMENSION(1:N1)             :: X1, Y1, Z1
    REAL(WP), INTENT(IN), DIMENSION(1:IMK)            :: XM, YM
    REAL(WP), INTENT(IN)                              :: DLL, AVEE
    END SUBROUTINE PLOT_SMOOTHING
END INTERFACE
!...
! -------------------------------------------------------------------
!...
INTERFACE
    SUBROUTINE PLOT_RESIDUAL (N1,X1,Y1,IPLT,IFPLT,FILERSD,ITYPE,IRESD,NPLT,IEP)
    USE DISLIN
    USE NRTYPE
    USE PLOT_CNTL
    USE FULL_DATA
    CHARACTER(LEN=*), INTENT(IN)                      :: FILERSD
    INTEGER(I4B), INTENT(IN)                          :: N1, IPLT, IFPLT, IEP, ITYPE, IRESD, NPLT
    REAL(WP), INTENT(IN), DIMENSION(1:N1)             :: X1, Y1
    END SUBROUTINE PLOT_RESIDUAL
END INTERFACE
!...
! -------------------------------------------------------------------
!...
INTERFACE
    SUBROUTINE PLOT_DISTRIBUTION (N1,X1,Y1,IPLT,IFPLT,FILERSD,ILABEL,IGMIN,IPP)
    USE DISLIN
    USE NRTYPE
    USE PLOT_CNTL,  ONLY : ICN, IMETHOD
    USE INTERPOLATION
    CHARACTER(LEN=*), INTENT(IN)                      :: FILERSD
    INTEGER(I4B), INTENT(IN)                          :: N1, IPLT, IFPLT, ILABEL, IGMIN, IPP
    REAL(WP), INTENT(IN), DIMENSION(1:N1)             :: X1, Y1
    END SUBROUTINE PLOT_DISTRIBUTION
END INTERFACE
!...
! -------------------------------------------------------------------
!...
INTERFACE
    SUBROUTINE PSTNAM (FILEPS,IPS,IEP)
    USE NRTYPE
    CHARACTER(LEN=*), INTENT(INOUT)                   :: FILEPS
    INTEGER(I4B), INTENT(IN)                          :: IEP, IPS
    END SUBROUTINE PSTNAM
END INTERFACE
!...
! -------------------------------------------------------------------
!...
INTERFACE
    SUBROUTINE NEWNAM (KN,FILEE,FILNAM)
    USE NRTYPE
    INTEGER(I4B), INTENT(INOUT)                       :: KN
    CHARACTER (LEN=80), INTENT(IN)                    :: FILEE
    CHARACTER (LEN=80), INTENT(OUT)                   :: FILNAM
    INTERFACE
        INTEGER FUNCTION LENCHR (STRING)
        USE NRTYPE
        CHARACTER (LEN=*), INTENT(IN OUT)             :: STRING
        END FUNCTION LENCHR
    END INTERFACE
    END SUBROUTINE NEWNAM
END INTERFACE
!...
! -------------------------------------------------------------------
!...
INTERFACE
    SUBROUTINE MTVOUT (NOBS,NOUT,ALPHA,XX,YY,PW,OUTL,XMEAN,XSIGMA)
    USE NRTYPE
    INTEGER(I4B), INTENT(INOUT)                       :: NOBS
    REAL(WP), INTENT(IN)                              :: PW, ALPHA
    REAL(WP), INTENT(OUT)                             :: XMEAN, XSIGMA
    REAL(WP), DIMENSION(1:*), INTENT(INOUT)           :: XX, YY, OUTL
    END SUBROUTINE MTVOUT
END INTERFACE
!...
! -------------------------------------------------------------------
!...
INTERFACE
    SUBROUTINE SWILK (INIT,X,N,N1,N2,A,W,PW,IFAULT)
    USE NRTYPE
    INTEGER(I4B), INTENT(IN)                          :: N, N1, N2
    INTEGER(I4B), INTENT(OUT)                         :: IFAULT
    REAL(WP), INTENT(OUT)                             :: PW, W
    REAL(WP), DIMENSION(1:N), INTENT(IN)              :: X
    REAL(WP), DIMENSION(1:N2), INTENT(OUT)            :: A
    LOGICAL, INTENT(INOUT)                            :: INIT
    END SUBROUTINE SWILK
END INTERFACE
!...
! -------------------------------------------------------------------
!...
INTERFACE
    RECURSIVE SUBROUTINE QUICK_SORT (N1,LIST,ORDER)
    USE NRTYPE
    INTEGER(I4B), INTENT(IN)                          :: N1
    INTEGER(I4B), DIMENSION (1:N1), INTENT(OUT)       :: ORDER
    REAL(WP), DIMENSION (1:N1), INTENT(INOUT)         :: LIST
    END SUBROUTINE QUICK_SORT
END INTERFACE
!...
! -------------------------------------------------------------------
!...
END MODULE PROGRAM_UNITS
