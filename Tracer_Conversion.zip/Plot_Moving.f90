!...
!...LIST OF SUBROUTINES AND ARGUMENTS
! SUBROUTINE PLOT_SMOOTHING (N1,X1,Y1,Z1,DLL,AVEE,IMK,XM,YM,IPLT,IFPLT,FILEOUTT,IEP)
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *              SUBROUTINE PLOT_SMOOTHING               *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 03/18/15          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...SUBROUTINE TO PLOT POSSIBLE BREAKTHROUGH CURVE
SUBROUTINE PLOT_SMOOTHING (N1,X1,Y1,Z1,DLL,AVEE,IMK,XM,YM,IPLT,IFPLT,FILEOUTT,IEP)
!...
!...INCLUDE PLOT CONTROL MODULE (COLOR, LINE STYLE, ETC.)
USE DISLIN
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NR_SP,  ONLY : CHSTWO, CHSONE, KSTWO, SORT2
!...
!...ADD PLOT CONTROL MODULE
USE PLOT_CNTL
!...
!...ADD FULL_DATA MODULE TO TRANSFER THE FULL DATA SET FOR PLOTTING
USE FULL_DATA
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ABS, MAXVAL, MINVAL, SIZE, TRIM
!...
!...DECLARE TRANSFERRED VARIABLES
CHARACTER(LEN=*), INTENT(IN)                        :: FILEOUTT
INTEGER(I4B), INTENT(IN)                            :: N1, imk, IPLT, IFPLT, IEP
REAL(WP), INTENT(IN), DIMENSION(1:N1)               :: X1, Y1, Z1
REAL(WP), INTENT(IN), DIMENSION(1:IMK)              :: XM, YM
REAL(WP), INTENT(IN)                                :: DLL, AVEE
!...
!...IDENTIFY SUBROUTINE VALIABLES
CHARACTER(LEN=4)                                    :: CDEV
CHARACTER(LEN=6)                                    :: CPOL
CHARACTER(LEN=14)                                   :: CSTR1
CHARACTER(LEN=30)                                   :: CSTR2
CHARACTER(LEN=80)                                   :: MEASUREOUT
INTEGER(I4B)                                        :: ID1, NDIGX, NDIGY, N2, MEASFILE, ICHSONE
INTEGER(I4B), PARAMETER                             :: IOPT=3, IDIR=0
REAL(SP)                                            :: XL1, XH1, YL1, YH1, XL2, XH2, YL2, YH2, DKS, PROB1, CHSQ1, CHSQ2, PROBDW
REAL(SP)                                            :: XL, XH, YL, YH, XSTEP, YSTEP, AX, BX, AY, BY, D1, AV, NS, PROB2, PROB3, DN
REAL(SP)                                            :: AR1, AR2, ARR, RR, PROBB, ZR, RMSE, NRMSE, CVRMSE, DK, PROBK2S, DCR
REAL(SP)                                            :: DD, ZD, PROBD, RS, PROBRS, TAUK, ZK, PROBK, RSR, DWS, ES, DF1, DF2
REAL(SP)                                            :: C_ALF, BIAS, PBIAS, ME, MAE, MSE, MLE, MALE, MSLE, RMSLE, XHADJ, YHADJ
REAL(SP), PARAMETER                                 :: ALF=0.05_SP!C_ALF=1.224_SP
REAL(SP), DIMENSION(1:N1)                           :: XX, YY, ZZ
REAL(SP), DIMENSION(1:SIZE(XS))                     :: XT, YT
REAL(SP), DIMENSION(1:IMK)                          :: XM1, YM1
!...
!===================================================================================
!...
!...DETERMINE SIZE OF N2
N2 = SIZE(XS)
!...
!...CONVERT SMOOTHING AVERAGE QUAD-PRECISION ARRAYS TO SINGLE-PRECISION ARRAYS
XX = REAL(X1,  KIND=SP)
YY = REAL(Y1,  KIND=SP)
ZZ = REAL(Z1,  KIND=SP)
!...
!...CONVERT FULL DATA QUAD-PRECISION ARRAYS TO SINGLE-PRECISION ARRAYS
XT = REAL(XS,  KIND=SP)
YT = REAL(YS,  KIND=SP)
!
XM1 = REAL(XM, KIND=SP)
YM1 = REAL(YM, KIND=SP)
!...
!...CONVERT QUAD-PRECISION DETECTION LIMIT TO SINGLE-PRECISION
D1 = REAL(DLL, KIND=SP)
!!...
!!...CONVERT QUAD-PRECISION AVERAGE CONCENTRATION TO SINGLE-PRECISION FOR PLOTTING
AV = REAL(AVEE, KIND=SP)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!...
!...TRANSFORM MEASURED AND PREDICTED VALUES TO ELIMINATE NEGATIVE VALUES
!YT = LOG10(ONE_S+YT-MINVAL(YT))
!YY = LOG10(ONE_S+YY-MINVAL(YY))
!...
!...CALCULATE PEARSON CORRELATION COEFFICIENT
CALL PEARSN(YT,YY,N1,RR,PROBB,ZR)
!...
!...CALCULATE FIRST ADJUSTED CORRELATION COEFFICIENT
NS  = REAL(N1, KIND=SP)
AR1 = RR*(ONE_S+((ONE_S-RR*RR)/2*NS))
!...
!...CALCULATE SECOND ADJUSTED CORRELATION COEFFICIENT
AR2 = SQRT(ONE_S-(((ONE_S-RR*RR)*(NS-1))/(NS-2)))
!...
!...CALCULATE ADJUSTED COEFFICIENT OF DETERMINATION
ARR = ONE_S - ((ONE_S-RR*RR)*((NS-1)/(NS-1-1)))
!...
!...CALCULATE SPEARMAN RANK-ORDER CORRELATION COEFFICIENT
CALL SPEAR(YT,YY,N1,DD,ZD,PROBD,RS,PROBRS)
!...
!...CALCULATE KENDALL'S TAU
CALL KENDL1(YT,YY,N1,TAUK,ZK,PROBK)
!...
!...CALCULATE TWO-DIMENSIONAL K�S TEST
CALL KS2D2S(XT,YT,N1,XX,YY,N1,DK,PROBK2S)
DN = REAL(N1, KIND=SP)
C_ALF = SQRT(-HALF_S*LOG(ALF))
DCR = C_ALF*SQRT((DN+DN)/(DN*DN))
!...
!...CALCULATE NASH-SUTCLIFF EFFICIENCY
CALL NASHSU(YT,YY,N1,ES)
!...
!...CALCULATE ROOT MEAN SQUARE ERROR, NORMALIZED ROOT MEAN SQUARE ERROR, etc.
CALL ROOT_MEAN(YT,YY,ME,MAE,MSE,MLE,MALE,MSLE,RMSE,RMSLE,NRMSE,CVRMSE,RSR,N1)
!...
!...CALCULATE FIT MEASURE USING BIAS AND PERCENT BIAS
CALL PERCENT_BIAS(YT,YY,BIAS,PBIAS,N1)
!...
!...CALCULATE DURBIN-WATSON STATISTIC AND ASSOCIATED PROBABILITY
CALL DURBIN(N1,YT,YY,DWS,PROBDW)
!...
!...CALCULATE CHI-SQUARE FUNCTION
!...IF YY AND YT ARE IDENTICAL ARRAY SIZES THEN CALCULATE USING CHSTWO
WRITE(*,*)
IF (SIZE(Y1(:)) == SIZE(YT(:))) THEN
    CALL CHSTWO(YT,YY,N1,0,DF1,CHSQ1,PROB1)
!
    ICHSONE = 0
    IF (ANY(YY(:) <= ZERO_S)) GOTO 10
    CALL CHSONE(YT,YY,N1,1,DF2,CHSQ2,PROB2)
    ICHSONE = 1
ENDIF
10 CONTINUE
!...
!...CALCULATE K-S FUNCTION
CALL KSTWO(YY,YY,DKS,PROB3)
!...
!...WRITE CORRELATION RESULTS TO MAIN OUTPUT FILE
MEASUREOUT = "MEASURE_OF_FIT.OUT"
OPEN (NEWUNIT=MEASFILE, FILE = MEASUREOUT, STATUS = "UNKNOWN", POSITION = "REWIND")
    WRITE (MEASFILE,100) RR, SUPER2_C, RR*RR, PROBB, SUPER2_C, ARR, ZR, AR1, AR2
    WRITE (MEASFILE,110) DD, ZD, PROBD, RS, PROBRS
    WRITE (MEASFILE,120) TAUK, ZK, PROBK
    WRITE (MEASFILE,130) DK, DCR, PROBK2S
    WRITE (MEASFILE,140) ES
    WRITE (MEASFILE,150) RMSE, NRMSE, CVRMSE
!    WRITE (MEASFILE,*) SQRT(ONE_S - ((RR*RR))*SQRT(SUM((Y2(:)-AMEAN)**2)))
    WRITE (MEASFILE,160) BIAS, PBIAS
    WRITE (MEASFILE,170) RSR
    WRITE (MEASFILE,180) DWS, PROBDW
    WRITE (MEASFILE,190) CHSQ1, DF1, PROB1
    IF (ICHSONE == 1) WRITE (MEASFILE,200) CHSQ2, DF2, PROB2
    WRITE (MEASFILE,210) DKS, DCR, PROB3
    WRITE (MEASFILE,220) ME, MAE, MSE, MLE, MALE, MSLE
CLOSE (UNIT=MEASFILE)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!...
!...FORMAT STATEMENTS
100 FORMAT (///,10X,"PEARSON'S CORRELATION COEFFICIENT",18X,"COEFICIENT OF DETERMINATION",/,                &
              10X,43("="),8X,60("="),/,13X,"-> R =  ",G14.8,29X,"-> R",A1," =  ",G14.8,/,                   &
              16X,"P =  ",G14.8,28X,"-> AR",A1," =  ",G14.8,/,16X,"Z = ",G14.8,//,                          &
              11X,"-> AR1 =  ",G14.8,/,11X,"-> AR2 =  ",G14.8,//)
110 FORMAT (/,10X,"SPEARMAN'S RANK-ORDER CORRELATION COEFFICIENT",18X,"KEY",/,10X,43("="),8X,60("="),/,     &
              14X,"D** = ",G14.8,33X,"R = PEARSON CORRELATION COEFFICIENT",/,15X,"ZD = ",G14.8,             &
              33X,"P = STUDENT'S T PROBABILITY",/,15X,"PB =  ",G14.8,32X,"Z = FISHER'S Z TRANSFORMATION",/, &
              12X,"-> Rs =  ",G14.8,/,15X,"Pr =  ",G14.8,30X,"D** = SUM THE SQUARED DIFFERENCE OF RANKS",/, &
              66X,"ZD = NUMBER OF STANDARD DEVIATIONS",/,66X,"PB = SIGNIFICANCE OF STANDARD DEVIATIONS",/,  &
              66X,"Rs = SPEARMAN'S RANK CORRELATION COEFFCIENT")
120 FORMAT (  10X,"KENDALL'S RANK-ORDER CORRELATION COEFFICIENT",                                           &
              12X,"Pr = SIGNIFICANCE OF A NONZERO VALUE OF Rs",/,10X,43("="),/,11X,"-> TAU =  ",G14.8,      &
              30X,"TAU = KENDALL'S RANK-ORDER CORRELATION COEFFICIENT",/,15X,"Zk = ",G14.8,                 &
              32X,"Zk = NUMBER OF STANDARD DEVIATIONS OF TAU FROM ZERO",/,15X,"Pk =  ",G14.8,               &
              31X,"Pk = TWO-SIDED SIGNIFICANCE LEVEL OF TAU",//,66X,"Dk = TWO-DIMENSIONAL K-S STATISTIC",/, &
              65X,"Dcr = K-S CRITICAL VALUE",/,65X,"Pk2 = SIGNIFICANCE LEVEL OF K-S STATISTIC")
130 FORMAT (/,10X,"TWO-DIMENSIONAL K�S TEST",30X,"RMSE = ROOT MEAN SQUARE ERROR",/,10X,43("="),             &
              10X,"NRMSE = NORMALIZED-RMSE",/,11X,"-> Dk =  ",G14.8,27X,"CV-RMSE = COEFFICIENT OF ",        &
                  "VARIATION RMSE",/,13X,"Dcr =  ",G14.8,27X,60("="),/,13X,"Pk2 =  ",G14.8,//)
140 FORMAT (/,10X,"NASH-SUTCLIFF EFFICIENCY",/,10X,43("="),/,11X,"-> NSE =  ",G14.8,//)
150 FORMAT (/,10X,"ROOT MEAN SQUARE ERROR / NORMALIZED-RMSE / CV-RMSE",/,10X,43("="),                       &
            /,10X,"-> RMSE =  ",G14.8,/,9X,"-> NRMSE =  ",G14.8,"%",/,7X,"-> CV-RMSE =  ",G14.8,//)
160 FORMAT (/,10X,"BIAS AND PERCENT BIAS",/,10X,43("="),/,10X,"-> BIAS =  ",G14.8,/,                        &
               9X,"-> PBIAS =  ",G14.8,1X,"%",//)
170 FORMAT (/,10X,"RMSE-OBSERVATIONS STANDARD DEVIATION RATIO",/,10X,43("="),/,11X,"-> RSR =  ",G14.8,//)
180 FORMAT (/,10X,"DURBIN-WATSON STATISTIC",/,10X,43("="),/,12X,"-> DW =  ",G14.8,/,16X,"P =  ",G14.8,//)
190 FORMAT (/,10X,"CHI-SQUARED (CHSTWO) DO TWO SETS OF DATA DIFFER?",/,10X,48("="),/,                       &
               9X,"-> CHI^2 =  ",G14.8,/,15X,"DF =  ",G14.8,/,16X,"P =  ",G14.8,//)
200 FORMAT (/,10X,"CHI-SQUARED (CHSONE) DO TWO SETS OF DATA DIFFER?",/,10X,48("="),/,                       &
               9X,"-> CHI^2 =  ",G14.8,/,15X,"DF =  ",G14.8,/,16X,"P =  ",G14.8,//)
210 FORMAT (/,10X,"KOLMOGOROV-SMIRNOV (KSTWO) DO TWO SETS OF DATA DIFFER?",/,10X,54("="),/,                 &
              11X,"-> DKS =  ",G14.8,/,14X,"Dcr =  ",G14.8,/,16X,"P =  ",G14.8,//)
220 FORMAT (/,10X,"ME = ",G14.8,/,10X,"MAE = ",G14.8,/,10X,"MSE = "G14.8,/,10X,"MLE = "G14.8,/,10X,         &
                  "MALE = ",G14.8,/, 10X,"MSLE = "G14.8)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!...
!...SET MINIMUM PLOT DIMENSIONS
XL1 = MINVAL(XT)
XL2 = MINVAL(XX)
IF (XL1 < XL2) THEN
    XL = XL1
ELSE
    XL = XL2
ENDIF
YL1 = MINVAL(YT)
YL2 = MINVAL(YY)
YL  = ZERO_S
!...
!...SET MAXIMUM PLOT DIMENSIONS
XH1 = MAXVAL(XX)
XH2 = MAXVAL(XT)
IF (XH1 > XH2) THEN
    XH = XH1
ELSE
    XH = XH2
ENDIF
YH1 = MAXVAL(YY)
YH2 = MAXVAL(YT)
IF (YH1 > YH2) THEN
    YH = YH1
ELSE
    YH = YH2
ENDIF
!...
!...SET DISPLAY TYPE FOR SCREEN OR OUTPUT
IF (IPLT < 1) THEN
    CDEV = "XWIN"
ELSE
    IF (IEP == 1) THEN
        CDEV = "EPS"
    ELSE
        CDEV = "PDF"
    ENDIF
ENDIF
!...
!...PREVENT DISLIN PLOTTING ERROR MESSAGES FROM BEING WRITTEN TO SCREEN BY WRITING TO A FILE
CALL ERRDEV ("APPEND")
!CALL ERRMOD ("ALL","OFF")
!...
!...
!...START A NEW PAGE
!...
!...CALL DISLIN TO INITIATE PGPLOT AND OPEN THE OUTPUT DEVICES (VIDEO SCREEN AND/OR POSTSCRIPT PLOT FILE)
CALL METAFL (CDEV)
CALL SETPAG ("USAL")
CALL DISINI
!...
!...SET BACKGROUND COLOR
IF (IPLT == 0) THEN
    CALL SETVLT ("RAIN")                                !SELECTS COLOR TABLE (p. 53)
ELSE
    CALL SETVLT ("GREY")                                !SELECTS GREY TABLE (p. 53)
ENDIF
CALL PAGFLL (0)                                         !DEFAULT BLACK PAGE
IF ((IPLT > 0) .AND. (IFPLT == 3)) CALL PAGFLL (0)
IF (IPLT < 1) THEN
    CALL AXCLRS (190,"LABELS","XYZ")                    !COLORS FOR AXES PARTS (p. 50)
    CALL AXCLRS (230,"NAME","XYZ")                      !COLORS FOR AXES PARTS (p. 50)
ELSE
    CALL AXCLRS (255,"LABELS","XYZ")                    !COLORS FOR AXES PARTS (p. 50)
    CALL AXCLRS (255,"NAME","XYZ")                      !COLORS FOR AXES PARTS (p. 50)
ENDIF
IF ((IPLT > 0) .AND. (IFPLT == 3)) THEN
    CALL AXCLRS (190,"LABELS","XYZ")                    !COLORS FOR AXES PARTS (p. 50)
    CALL AXCLRS (230,"NAME","XYZ")                      !COLORS FOR AXES PARTS (p. 50)
ENDIF
!...
!..ADD BORDER IF NOT HARDCOPY
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!IF (IPLT < 1) CALL PAGERA
!...
!...CHOOSE A FONT
CALL COMPLX
!CALL WINFNT ("ARIAL BOLD")
!CALL PSFONT("HELVETICA-BOLD")
CALL TEXMOD ("ON")
!...
!...SETUP PLOT FORM
CALL SETGRF ("NAME","NAME","TICKS","TICKS")
!...
!...SET LABELS SIZE
CALL HNAME (44)
!...
!...SET LINE WIDTH
CALL LINWID (5)
!...
!...SET PROPER TIME UNITS FOR X-AXIS FOR PRE-TRACER INJECTION
IF (IPREPOST == 1) THEN
    SELECT CASE (ITM)
        CASE (1)
            CALL NAME ("Time prior to injection (d)","X")
        CASE (2)
            CALL NAME ("Time prior to injection (h)","X")
        CASE (3)
            CALL NAME ("Time prior to injection (min)","X")
        CASE (4)
            CALL NAME ("Time prior to injection (s)","X")
        CASE DEFAULT
            CALL NAME ("Time prior to injection (s)","X")
    END SELECT
ELSE
!...
!...SET PROPER TIME UNITS FOR X-AXIS FOR POST-TRACER INJECTION
    SELECT CASE (ITM)
        CASE (1)
            CALL NAME ("Time since injection (d)","X")
        CASE (2)
            CALL NAME ("Time since injection (h)","X")
        CASE (3)
            CALL NAME ("Time since injection (min)","X")
        CASE (4)
            CALL NAME ("Time since injection (s)","X")
        CASE DEFAULT
            CALL NAME ("Time since injection (s)","X")
    END SELECT
ENDIF
!...
!...SET PROPER CONCENTRATION UNITS FOR Y-AXIS
SELECT CASE (ICN)
    CASE (1)
        CALL NAME ("Concentration (kg L$^{-1}$)","Y")
    CASE (2)
        CALL NAME ("Concentration (g L$^{-1}$)","Y")
    CASE (3)
        CALL NAME ("Concentration (mg L$^{-1}$)","Y")
    CASE (4)
        CALL NAME ("Concentration ($\mu$g L$^{-1}$)","Y")
    CASE (5)
        CALL NAME ("Concentration (ng L$^{-1}$)","Y")
    CASE (6)
        CALL NAME ("Concentration (pg L$^{-1}$)","Y")
    CASE DEFAULT
        CALL NAME ("Concentration ($\mu$g L$^{-1}$)","Y")
END SELECT
!...
!...SETS AXES VALUE DISPLAY TYPE
CALL LABDIG ( 1,"X")
IF (XH-XL <= ONE_S) CALL LABDIG (2,"X")
CALL LABDIG (-2,"Y")
IF ((ICN < 4) .OR. (ICN > 4)) CALL LABDIG (1,"Y")
!...
!...ADJUST LABELS DISPLAY
IF ((ABS(XX(1)) > ZERO_S .AND. ABS(XX(1)) <= TMIL_S) .OR. (ABS(XX(N1)) >= THOU_S)) CALL LABELS ("XEXP","X")
IF ((ICN < 4) .OR. (ICN > 4)) CALL LABELS ("XEXP","Y")
!...
!...DEFINE TICK POSITIONS
CALL TICPOS ("REVERS","XY")
!...
!...SETUP GRAPH TICK MARKS
CALL TICKS  (4,"XY")
!...
!...AUTOMATICALLY DETERMINE AXIS LIMITS
CALL SETSCL (XX,N1,"XRESET")
CALL SETSCL (YY,N1,"YRESET")
!....
!...PREPARE TITLE
!IF (IPLT == 0) THEN
    IF (IPREPOST == 1) THEN
        CALL TITLIN ("TRACER RELEASE PRIOR TO INJECTION, FILE NAME:",1)
    ELSE
        CALL TITLIN ("TRACER RELEASE AFTER INJECTION, FILE NAME:",1)
    ENDIF
    CALL TITLIN (FILEOUTT,3)
!ENDIF
!...
!...SET FRAME WIDTH
IF ((IPLT > 0) .AND. (IFPLT == 3)) CALL COLOR ("ORANGE")
CALL FRAME (4)
!...
!...DETERMINE LABEL STEPS (NOT CURRENTLY CORRECT -- JUST TEMPORARY FOR PLACE HOLDING)
XSTEP = ABS(XH-XL)*QUART_S
YSTEP = ABS(YH-YL)*QUART_S
!...
!...DETERMINE AXIS PARAMETERS
IF ((IPLT == 1) .AND. (IFPLT == 3)) CALL COLOR ("WHITE")
CALL GAXPAR (XL,XH,"EXTEND","X",AX,BX,XL,XSTEP,NDIGX)
CALL GAXPAR (YL,YH,"EXTEND","Y",AY,BY,YL,YSTEP,NDIGY)
!...
!...ADJUST X-AXIS LENGTH
IF (XH >= TEN_S) THEN
    XHADJ = REAL(INT(XH,KIND=I4B),KIND=SP)
ELSE
    XHADJ = REAL(INT(XH*TEN_S,KIND=I4B),KIND=SP)*TENTH_S
ENDIF
IF (XHADJ < XH) THEN
    XH = XHADJ + XSTEP*HALF_S
ELSE
    XH = XHADJ
ENDIF
!...
!...ADJUST Y-AXIS LENGTH
IF (YH >= TEN_S) THEN
    YHADJ = REAL(INT(YH,KIND=I4B),KIND=SP)
ELSEIF ((YH < TEN_S) .AND. (YH >= TENTH_S)) THEN
    YHADJ = YH+HUNDTH_S*FIVE_S
    !REAL(INT(YH*TEN_S,KIND=I4B),KIND=SP)*TENTH_S
ELSE
    YHADJ = YH+THOUTH_S*FIVE_S
ENDIF
IF (YHADJ < YH) THEN
    YH = YHADJ + YSTEP*HALF_S!FIVE_S
ELSE
    YH = YHADJ
ENDIF
!...
!...PLOT GRAPH
CALL GRAF (XL,XH,XL,XSTEP,YL,YH,YL,YSTEP)
!...
!...WRITE TITLE
CALL TITLE
!...
!...ENSURE THAT PLOTTED CURVES HAVE NO SPECIAL ATTRIBUTES
CALL CHNCRV ("NONE")
!...
!...SET LINE TYPE TO SOLID AND SHADING COLOR
CALL LINTYP (0)
CALL SETVLT ("RAIN")
!...
!...SET LINE WIDTH
CALL LINWID (7)
!...
!...DETERMINE INTERPOLATION METHOD
CPOL = "LINEAR"
CALL POLCRV (CPOL)
!...
!...SET MARKER SIZE AND SHAPE
CALL HSYMBL (30)
CALL MARKER (15)
!...
!...SET LINE WIDTH
CALL LINWID (7)
!...
!...PLOT ORIGINAL DATA POINTS
SELECT CASE (PL)
    CASE ("L","l")
        CALL SETVLT ("GREY")
        CALL SETCLR (150)
        CALL INCMRK (10000)
        CALL CHNCRV ("NONE")
        CALL SOLID
!        IF (IPLT /= 1) CALL COLOR ("BLUE")
!        IF ((IPLT > 0) .AND. (IFPLT == 2 .OR. IFPLT == 3)) CALL COLOR ("BLUE")
        CPOL = "LINEAR"
        CALL POLCRV (CPOL)
        CALL CURVE  (XT,YT,N2)
    CASE DEFAULT
        CALL SETVLT ("RAIN")
        IF (IPLT <= 0) THEN
            IF (IPLT == 0) THEN
                CALL COLOR ("GREEN")
            ELSE
!                CALL SETCLR (200)                  !FILLS PLOT SYMBOLS WITH LIGHT GREY BACKGROUND
                CALL SETRGB (1., 1., 1.)            !FILLS PLOT SYMBOLS WITH WHITE BACKGROUND
                CALL HSYMBL (20)
            ENDIF
            CALL INCMRK (-1)
            CALL MARKER (21)
            CALL CURVE (XT,YT,N2)
        ENDIF
!
        IF (IPLT == 0) THEN
            CALL COLOR ("BLUE")
        ELSEIF  ((IPLT > 0) .AND. (IFPLT == 3)) THEN
            CALL SETRGB(0., 1., 0.)                 !PLOT SYMBOL DISPLAYED AS GREEN
        ELSE
            CALL SETRGB (0., 0., 0.)                !PLOT SYMBOL DISPLAYED AS BLACK
            IF (IFPLT == 2) THEN
                CALL COLOR ("BLUE")
            ELSEIF (IFPLT == 1) THEN
                CALL SETVLT("GREY")
                CALL SETCLR(130)
            ENDIF
        ENDIF
!
        CALL INCMRK (-1)
        IF (IPLT == 0) THEN
            CALL HSYMBL (40)
        ELSE
            IF ((IFPLT == 2) .OR. (IFPLT == 3)) CALL HSYMBL (40)
            CALL HSYMBL (25)
        ENDIF
        CALL MARKER (15)
        CALL CURVE (XT,YT,N2)
        CALL SETRGB (0., 0., 0.)
END SELECT
!...
!...MARK DOWNLOAD VALUES (POSSIBLE ERRONEOUS DATA)
SELECT CASE (DNPLOT)
    CASE ("Y","y")
        SELECT CASE (DPMARK)
            CASE ("Y","y")
                IF (IPLT == 0) THEN
                    CALL HSYMBL (50)
                ELSE
                    IF ((IFPLT == 2) .OR. (IFPLT == 3)) CALL HSYMBL (50)
                ENDIF
                CALL COLOR ("ORANGE")
                CALL MARKER (0)
                CALL CURVE (XM1,YM1,IMK)
                IF (IPLT == 0) THEN
                    CALL HSYMBL (25)
                    CALL COLOR ("WHITE")
                ELSE
                    IF ((IFPLT == 2) .OR. (IFPLT == 3)) CALL HSYMBL (25)
                    CALL HSYMBL (15)
                    CALL COLOR ("GREEN")
                ENDIF
                CALL MARKER (21)
                CALL CURVE (XM1,YM1,IMK)
            CASE ("N","n")
                CONTINUE
            CASE DEFAULT
                CONTINUE
        END SELECT
    CASE ("N","n")
        CONTINUE
    CASE DEFAULT
        SELECT CASE (DPMARK)
            CASE ("Y","y")
                IF (IPLT == 0) THEN
                    CALL HSYMBL (50)
                ELSE
                    IF ((IFPLT == 2) .OR. (IFPLT == 3)) CALL HSYMBL (50)
                ENDIF
                CALL COLOR ("ORANGE")
                CALL MARKER (0)
                CALL CURVE (XM1,YM1,IMK)
                IF (IPLT == 0) THEN
                    CALL HSYMBL (25)
                    CALL COLOR ("WHITE")
                ELSE
                    IF ((IFPLT == 2) .OR. (IFPLT == 3)) CALL HSYMBL (25)
                    CALL HSYMBL (15)
                    CALL COLOR ("GREEN")
                ENDIF
                CALL MARKER (21)
                CALL CURVE (XM1,YM1,IMK)
            CASE ("N","n")
                CONTINUE
            CASE DEFAULT
                CONTINUE
        END SELECT
END SELECT
!...
!...SET COLOR CONTROL
CALL SETVLT ("RAIN")
!...
!...PLOT ERROR BARS (DOESN'T APPEAR CORRECTLY WHEN DATA IS TOO DENSE)
!CALL COLOR ("YELLOW")
!CALL LINWID (1)
!CALL ERRBAR (XX,YY,ZZ,ZZ,N1)
!...
!...DRAW LINE FOR SMOOTHING DATA
CALL INCMRK (10000)
CALL CHNCRV ("NONE")
CALL SOLID
IF (IPLT /= 1) CALL COLOR ("RED")
IF ((IPLT > 0) .AND. (IFPLT == 2 .OR. IFPLT == 3)) CALL COLOR ("RED")
CPOL = "LINEAR"
CALL POLCRV (CPOL)
CALL CURVE  (XX,YY,N1)
!...
!...SET LINE WIDTH
CALL LINWID (5)
!...
!...DRAW HORIZONTAL DETECTION LIMIT DOTTED LINE
CALL COLOR ("WHITE")
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CALL RLMESS ("Detection Limit",HUND_S,0.03_SP)
CALL LINWID (4)
CALL DASHL
CALL RLINE (XL,D1,XH,D1)
!...
!...SET LINE WIDTH
CALL LINWID (5)
!...
!...DRAW HORIZONTAL AVERAGE CONCENTRATION DASHED LINE
CALL COLOR ("WHITE")
!!!CALL RLMESS ("Mean Concentration",132.0_SP,FIFTH_S)
!!!CALL LINWID (4)
!!!CALL DASH
!!!CALL RLINE (XL,AV,XH,AV)
!...
!...SET LINE WIDTH
CALL LINWID (3)
!...
!...PRINT PAGE HEADER INFORMATION
IF (IMETHOD == 1) THEN
    CSTR2 = TRIM("MOVING-AVERAGE SMOOTHING")
ELSEIF (IMETHOD == 2) THEN
    CSTR2 = TRIM("MOVING-MEDIAN SMOOTHING")
ELSEIF (IMETHOD == 3) THEN
    CSTR2 = TRIM("SAVITZKY-GOLAY SMOOTHING")
ELSEIF (IMETHOD == 5) THEN
    CSTR2 = TRIM("GLKERN SMOOTHING")
ELSEIF (IMETHOD == 6) THEN
    CSTR2 = TRIM("LOKERN SMOOTHING")
ELSEIF (IMETHOD == 7) THEN
    CSTR2 = TRIM("FFT SMOOTHING")
ELSEIF (IMETHOD == 8) THEN
    CSTR2 = TRIM("EXPON. AVERAGE SMOOTHING")
ELSEIF (IMETHOD == 9) THEN
    CSTR2 = TRIM("QUINTIC-SPLINE SMOOTHING")
ELSEIF (IMETHOD == 10) THEN
    CSTR2 = TRIM("LOCAL REGRESS. SMOOTHING")
ELSEIF (IMETHOD == 11) THEN
    CSTR2 = TRIM("CUBIC-SPLINE SMOOTHING")
ELSEIF (IMETHOD == 12) THEN
    CSTR2 = TRIM("BUTTERWORTH FILTER")
ELSEIF (IMETHOD == 13) THEN
    CSTR2 = TRIM("WEIGHTED-QUINTIC-SPLINE")
ELSEIF (IMETHOD == 14) THEN
    CSTR2 = TRIM("B-SPLINE SMOOTHING")
ELSEIF (IMETHOD == 15) THEN
    CSTR2 = TRIM("POLYNOMIAL FIT")
ELSEIF (IMETHOD == 16) THEN
    CSTR2 = TRIM("CURVE FIT")
ENDIF
CSTR1 = "PLOTTING FILE:"
CALL COLOR ("CYAN")
IF ((CDEV == "EPS") .OR. (CDEV == "PDF")) CALL COLOR ("WHITE")
CALL PAGHDR (CSTR1,CSTR2,IOPT,IDIR)
!...
!...DONE
CALL DISFIN
OPEN  (NEWUNIT=ID1, FILE = "dislin.err", STATUS = "UNKNOWN")
CLOSE (ID1, STATUS = "DELETE")
!...
!...DONE WITH SUBROUTINE PLOT
RETURN
END SUBROUTINE PLOT_SMOOTHING


!...
!...LIST OF SUBROUTINES AND ARGUMENTS
! SUBROUTINE PLOT_RESIDUAL (N1,X1,Y1,IPLT,IFPLT,FILERSD,ITYPE,IRESD,NPLT,IEP)
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *              SUBROUTINE PLOT_RESIDUAL               *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 03/18/15          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...SUBROUTINE TO PLOT POSSIBLE BREAKTHROUGH CURVE
SUBROUTINE PLOT_RESIDUAL (N1,X1,Y1,IPLT,IFPLT,FILERSD,ITYPE,IRESD,IEP)
!...
!...NOTE: ITYPE = 1 --> REGULAR RESIDUAL PLOT
!...            = 2 --> SQUARED RESIDUAL PLOT
!...            = 3 --> |RESIDUALS| PLOTTED ON Y AXIS; FITTED VALUE PLOTTED ON X AXIS
!...
!...      IRESD = 1 --> TIME PLOTTED ON X AXIS
!...            = 2 --> FITTED VALUE PLOTTED ON X AXIS
!...
!...INCLUDE PLOT CONTROL MODULE (COLOR, LINE STYLE, ETC.)
USE DISLIN
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ADD PLOT CONTROL MODULE
USE PLOT_CNTL
!...
!...ADD FULL_DATA MODULE TO TRANSFER THE FULL DATA SET FOR PLOTTING
USE FULL_DATA
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ABS, MAXVAL, MINVAL, SIZE, TRIM
!...
!...DECLARE TRANSFERRED VARIABLES
CHARACTER(LEN=*), INTENT(IN)                        :: FILERSD
INTEGER(I4B), INTENT(IN)                            :: N1, IPLT, IFPLT, IEP, ITYPE, IRESD
REAL(WP), INTENT(IN), DIMENSION(1:N1)               :: X1, Y1
!...
!...IDENTIFY SUBROUTINE VALIABLES
CHARACTER(LEN=4)                                    :: CDEV
CHARACTER(LEN=6)                                    :: CPOL
CHARACTER(LEN=14)                                   :: CSTR1
CHARACTER(LEN=30)                                   :: CSTR2
INTEGER(I4B)                                        :: ID2, NDIGX, NDIGY
INTEGER(I4B), PARAMETER                             :: IOPT=3, IDIR=0
REAL(SP)                                            :: XL, XH, YL, YH, XSTEP, YSTEP, AX, BX, AY, BY
REAL(SP), DIMENSION(1:N1)                           :: XX, YY
!...
!===================================================================================
!...
!...CONVERT SMOOTHING AGVERAGE QUAD-PRECISION ARRAYS TO SINGLE-PRECISION ARRAYS
XX = REAL(X1,  KIND=SP)
YY = REAL(Y1,  KIND=SP)
!...
!...SET MINIMUM PLOT DIMENSIONS
XL = MINVAL(XX)
YL = MINVAL(YY)
!...
!...SET MAXIMUM PLOT DIMENSIONS
XH = MAXVAL(XX)
YH = MAXVAL(YY)
!...
!...SET DISPLAY TYPE FOR SCREEN OR OUTPUT
IF (IPLT < 1) THEN
    CDEV = "XWIN"
ELSE
    IF (IEP == 1) THEN
        CDEV = "EPS"
    ELSE
        CDEV = "PDF"
    ENDIF
ENDIF
!...
!...PREVENT DISLIN PLOTTING ERROR MESSAGES FROM BEING WRITTEN TO SCREEN BY WRITING TO A FILE
CALL ERRDEV ("APPEND")
!CALL ERRMOD ("ALL","OFF")
!...
!...
!...START A NEW PAGE
!...
!...CALL DISLIN TO INITIATE PGPLOT AND OPEN THE OUTPUT DEVICES (VIDEO SCREEN AND/OR POSTSCRIPT PLOT FILE)
CALL METAFL (CDEV)
CALL SETPAG ("USAL")
CALL DISINI
!...
!...SET BACKGROUND COLOR
IF (IPLT == 0) THEN
    CALL SETVLT ("RAIN")                                !SELECTS COLOR TABLE (p. 53)
ELSE
    CALL SETVLT ("GREY")                                !SELECTS GREY TABLE (p. 53)
ENDIF
CALL PAGFLL (0)                                         !DEFAULT BLACK PAGE
IF ((IPLT > 0) .AND. (IFPLT == 3)) CALL PAGFLL (0)
IF (IPLT < 1) THEN
    CALL AXCLRS (190,"LABELS","XYZ")                    !COLORS FOR AXES PARTS (p. 50)
    CALL AXCLRS (230,"NAME","XYZ")                      !COLORS FOR AXES PARTS (p. 50)
ELSE
    CALL AXCLRS (255,"LABELS","XYZ")                    !COLORS FOR AXES PARTS (p. 50)
    CALL AXCLRS (255,"NAME","XYZ")                      !COLORS FOR AXES PARTS (p. 50)
ENDIF
IF ((IPLT > 0) .AND. (IFPLT == 3)) THEN
    CALL AXCLRS (190,"LABELS","XYZ")                    !COLORS FOR AXES PARTS (p. 50)
    CALL AXCLRS (230,"NAME","XYZ")                      !COLORS FOR AXES PARTS (p. 50)
ENDIF
!...
!..ADD BORDER IF NOT HARDCOPY
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!IF (IPLT < 1) CALL PAGERA
!...
!...CHOOSE A FONT
CALL COMPLX
!CALL WINFNT ("ARIAL BOLD")
!CALL PSFONT("HELVETICA-BOLD")
CALL TEXMOD ("ON")
!...
!...SETUP PLOT FORM
CALL SETGRF ("NAME","NAME","TICKS","TICKS")
!...
!...SET LABELS SIZE
CALL HNAME (44)
!...
!...SET LINE WIDTH
CALL LINWID (5)
!...
!...SET PROPER TIME UNITS FOR X-AXIS FOR PRE-TRACER INJECTION
IF (IPREPOST == 1) THEN
    IF (IRESD == 1) THEN
        SELECT CASE (ITM)
            CASE (1)
                CALL NAME ("Time prior to injection (d)","X")
            CASE (2)
                CALL NAME ("Time prior to injection (h)","X")
            CASE (3)
                CALL NAME ("Time prior to injection (min)","X")
            CASE (4)
                CALL NAME ("Time prior to injection (s)","X")
            CASE DEFAULT
                CALL NAME ("Time prior to injection (s)","X")
        END SELECT
    ELSEIF (IRESD == 2) THEN
        SELECT CASE (ICN)
            CASE (1)
                CALL NAME ("Fitted Value (kg L$^{-1}$)","X")
            CASE (2)
                CALL NAME ("Fitted Value (g L$^{-1}$)","X")
            CASE (3)
                CALL NAME ("Fitted Value (mg L$^{-1}$)","X")
            CASE (4)
                CALL NAME ("Fitted Value ($\mu$g L$^{-1}$)","X")
            CASE (5)
                CALL NAME ("Fitted Value (ng L$^{-1}$)","X")
            CASE (6)
                CALL NAME ("Fitted Value (pg L$^{-1}$)","X")
            CASE DEFAULT
                CALL NAME ("Fitted Value ($\mu$g L$^{-1}$)","X")
        END SELECT
    ENDIF
ELSEIF (IPREPOST == 2) THEN
!...
!...SET PROPER TIME UNITS FOR X-AXIS FOR POST-TRACER INJECTION
    IF (IRESD == 1) THEN
        SELECT CASE (ITM)
            CASE (1)
                CALL NAME ("Time since injection (d)","X")
            CASE (2)
                CALL NAME ("Time since injection (h)","X")
            CASE (3)
                CALL NAME ("Time since injection (min)","X")
            CASE (4)
                CALL NAME ("Time since injection (s)","X")
            CASE DEFAULT
                CALL NAME ("Time since injection (s)","X")
        END SELECT
    ELSEIF (IRESD == 2) THEN
        SELECT CASE (ICN)
            CASE (1)
                CALL NAME ("Fitted Value (kg L$^{-1}$)","X")
            CASE (2)
                CALL NAME ("Fitted Value (g L$^{-1}$)","X")
            CASE (3)
                CALL NAME ("Fitted Value (mg L$^{-1}$)","X")
            CASE (4)
                CALL NAME ("Fitted Value ($\mu$g L$^{-1}$)","X")
            CASE (5)
                CALL NAME ("Fitted Value (ng L$^{-1}$)","X")
            CASE (6)
                CALL NAME ("Fitted Value (pg L$^{-1}$)","X")
            CASE DEFAULT
                CALL NAME ("Fitted Value ($\mu$g L$^{-1}$)","X")
        END SELECT
    ENDIF
ENDIF
!...
!...SET PROPER CONCENTRATION UNITS FOR Y-AXIS
SELECT CASE (ITYPE)
    CASE (1)
        SELECT CASE (ICN)
            CASE (1)
                CALL NAME ("Residual (kg L$^{-1}$)","Y")
            CASE (2)
                CALL NAME ("Residual (g L$^{-1}$)","Y")
            CASE (3)
                CALL NAME ("Residual (mg L$^{-1}$)","Y")
            CASE (4)
                CALL NAME ("Residual ($\mu$g L$^{-1}$)","Y")
            CASE (5)
                CALL NAME ("Residual (ng L$^{-1}$)","Y")
            CASE (6)
                CALL NAME ("Residual (pg L$^{-1}$)","Y")
            CASE DEFAULT
                CALL NAME ("Residual ($\mu$g L$^{-1}$)","Y")
        END SELECT
    CASE (2)
        SELECT CASE (ICN)
            CASE (1)
                CALL NAME ("Squared Residual (kg L$^{-1}$)$^2$","Y")
            CASE (2)
                CALL NAME ("Squared Residual (g L$^{-1}$)$^2$","Y")
            CASE (3)
                CALL NAME ("Squared Residual (mg L$^{-1}$)$^2$","Y")
            CASE (4)
                CALL NAME ("Squared Residual ($\mu$g L$^{-1}$)$^2$","Y")
            CASE (5)
                CALL NAME ("Squared Residual (ng L$^{-1}$)$^2$","Y")
            CASE (6)
                CALL NAME ("Squared Residual (pg L$^{-1}$)$^2$","Y")
            CASE DEFAULT
                CALL NAME ("Squared Residual ($\mu$g L$^{-1}$)$^2$","Y")
        END SELECT
    CASE (3)
        SELECT CASE (ICN)
            CASE (1)
                CALL NAME ("|Residual| (kg L$^{-1}$)","Y")
            CASE (2)
                CALL NAME ("|Residual| (g L$^{-1}$)","Y")
            CASE (3)
                CALL NAME ("|Residual| (mg L$^{-1}$)","Y")
            CASE (4)
                CALL NAME ("|Residual| ($\mu$g L$^{-1}$)","Y")
            CASE (5)
                CALL NAME ("|Residual| (ng L$^{-1}$)","Y")
            CASE (6)
                CALL NAME ("|Residual| (pg L$^{-1}$)","Y")
            CASE DEFAULT
                CALL NAME ("|Residual| ($\mu$g L$^{-1}$)","Y")
        END SELECT
END SELECT
!...
!...SETS AXES VALUE DISPLAY TYPE
CALL LABDIG (1,"X")
IF (XH-XL <= ONE_S) CALL LABDIG (2,"X")
CALL LABDIG (2,"Y")
!...
!...ADJUST LABELS DISPLAY
IF ((ABS(XX(1)) > ZERO_S .AND. ABS(XX(1)) <= TNAN_S) .OR. (ABS(XX(N1)) >= THOU_S)) CALL LABELS ("XEXP","X")
!...
!...DEFINE TICK POSITIONS
CALL TICPOS ("REVERS","XY")
!...
!...SETUP GRAPH TICK MARKS
CALL TICKS  (4,"XY")
!...
!...AUTOMATICALLY DETERMINE AXIS LIMITS
CALL SETSCL (XX,N1,"XRESET")
CALL SETSCL (YY,N1,"YRESET")
!....
!...PREPARE TITLE
SELECT CASE (ITYPE)
    CASE (1)
        SELECT CASE (IRESD)
            CASE (1)
                CALL TITLIN ("EXPLANATORY VARIABLES RESIDUAL PLOT, FILE NAME:",1)
            CASE (2)
                CALL TITLIN ("FITTED VALUES RESIDUAL PLOT, FILE NAME:",1)
        END SELECT
    CASE (2)
        SELECT CASE (IRESD)
            CASE (1)
                CALL TITLIN ("EXPLANATORY VARIABLES SQUARED RESIDUAL PLOT, FILE NAME:",1)
            CASE (2)
                CALL TITLIN ("FITTED VALUES SQUARED RESIDUAL PLOT, FILE NAME:",1)
        END SELECT
    CASE (3)
        CALL TITLIN ("HOMOSCEDASTICITY PLOT, FILE NAME:",1) !See: https://www.graphpad.com/guides/prism/8/curve-fitting/reg_fit_tab_residuals_2.htm
END SELECT
CALL TITLIN (FILERSD,3)
!...
!...SET FRAME WIDTH
IF ((IPLT > 0) .AND. (IFPLT == 3)) CALL COLOR ("ORANGE")
CALL FRAME (4)
!...
!...DETERMINE LABEL STEPS (NOT CURRENTLY CORRECT -- JUST TEMPORARY FOR PLACE HOLDING)
XSTEP = ABS(XH-XL)*QUART_S
YSTEP = ABS(YH-YL)*QUART_S
!...
!...PLOT GRAPH
IF ((IPLT == 1) .AND. (IFPLT == 3)) CALL COLOR ("WHITE")
CALL GAXPAR (XL,XH,"EXTEND","X",AX,BX,XL,XSTEP,NDIGX)
CALL GAXPAR (YL,YH,"EXTEND","Y",AY,BY,YL,YSTEP,NDIGY)
CALL GRAF   (XL,XH,XL,XSTEP,YL,YH,YL,YSTEP)
!...
!...WRITE TITLE
CALL TITLE
!...
!...ENSURE THAT PLOTTED CURVES HAVE NO SPECIAL ATTRIBUTES
CALL CHNCRV ("NONE")
!...
!...SET LINE TYPE TO SOLID AND SHADING COLOR
CALL LINTYP (0)
CALL SETVLT ("RAIN")
!...
!...SET LINE WIDTH
CALL LINWID (7)
!...
!...DETERMINE INTERPOLATION METHOD
CPOL = "LINEAR"
CALL POLCRV (CPOL)
!...
!...SET MARKER SIZE AND SHAPE
CALL HSYMBL (30)
CALL MARKER (15)
!...
!...SET LINE WIDTH
CALL LINWID (7)
!...
!...PLOT ORIGINAL DATA POINTS
CALL SETVLT ("RAIN")
IF (IPLT <= 0) THEN
    IF (IPLT == 0) THEN
        CALL COLOR ("GREEN")
    ELSE
!        CALL SETCLR (200)                  !FILLS PLOT SYMBOLS WITH LIGHT GREY BACKGROUND
        CALL SETRGB (1., 1., 1.)            !FILLS PLOT SYMBOLS WITH WHITE BACKGROUND
        CALL HSYMBL (20)
    ENDIF
    CALL INCMRK (-1)
    CALL MARKER (21)
    CALL CURVE (XX,YY,N1)
ENDIF
!
IF (IPLT == 0) THEN
    CALL COLOR ("BLUE")
ELSEIF  ((IPLT > 0) .AND. (IFPLT == 3)) THEN
    CALL SETRGB(0., 1., 0.)                 !PLOT SYMBOL DISPLAYED AS GREEN
ELSE
    CALL SETRGB (0., 0., 0.)                !PLOT SYMBOL DISPLAYED AS BLACK
    IF (IFPLT == 2) THEN
        CALL COLOR ("BLUE")
    ELSEIF (IFPLT == 1) THEN
        CALL SETVLT("GREY")
        CALL SETCLR(130)
    ENDIF
ENDIF
!
CALL INCMRK (-1)
IF (IPLT == 0) THEN
    CALL HSYMBL (40)
ELSE
    IF ((IFPLT == 2) .OR. (IFPLT == 3)) CALL HSYMBL (40)
    CALL HSYMBL (25)
ENDIF
CALL MARKER (15)
CALL CURVE (XX,YY,N1)
CALL SETRGB (0., 0., 0.)
CALL SETVLT ("RAIN")
!...
!...DRAW LINE FOR ZERO RESIDUAL REPRESENTATION
SELECT CASE (ITYPE)
    CASE (1)
        CALL COLOR ("RED")
        IF (IPLT == 0) CALL COLOR ("WHITE")
        CALL DASHL
        CALL RLINE (XL,ZERO_S,XH,ZERO_S)
    CASE (2)
        CONTINUE
    CASE DEFAULT
        CONTINUE
END SELECT
!...
!...SET LINE WIDTH
CALL LINWID (3)
!...
!...PRINT PAGE HEADER INFORMATION
IF (IMETHOD == 1) THEN
    CSTR2 = TRIM("MOVING-AVERAGE SMOOTHING")
ELSEIF (IMETHOD == 2) THEN
    CSTR2 = TRIM("MOVING-MEDIAN SMOOTHING")
ELSEIF (IMETHOD == 3) THEN
    CSTR2 = TRIM("SAVITZKY-GOLAY SMOOTHING")
ELSEIF (IMETHOD == 5) THEN
    CSTR2 = TRIM("GLKERN SMOOTHING")
ELSEIF (IMETHOD == 6) THEN
    CSTR2 = TRIM("LOKERN SMOOTHING")
ELSEIF (IMETHOD == 7) THEN
    CSTR2 = TRIM("FFT SMOOTHING")
ELSEIF (IMETHOD == 8) THEN
    CSTR2 = TRIM("EXPON. AVERAGE SMOOTHING")
ELSEIF (IMETHOD == 9) THEN
    CSTR2 = TRIM("QUINTIC-SPLINE SMOOTHING")
ELSEIF (IMETHOD == 10) THEN
    CSTR2 = TRIM("LOCAL REGRESS. SMOOTHING")
ELSEIF (IMETHOD == 11) THEN
    CSTR2 = TRIM("CUBIC-SPLINE SMOOTHING")
ELSEIF (IMETHOD == 12) THEN
    CSTR2 = TRIM("BUTTERWORTH FILTER")
ELSEIF (IMETHOD == 13) THEN
    CSTR2 = TRIM("WEIGHTED-QUINTIC-SPLINE")
ELSEIF (IMETHOD == 14) THEN
    CSTR2 = TRIM("B-SPLINE SMOOTHING")
ELSEIF (IMETHOD == 15) THEN
    CSTR2 = TRIM("POLYNOMIAL FIT")
ELSEIF (IMETHOD == 16) THEN
    CSTR2 = TRIM("CURVE FIT")
ENDIF
CSTR1 = "RESIDUAL FILE:"
CALL COLOR ("CYAN")
IF ((CDEV == "EPS") .OR. (CDEV == "PDF")) CALL COLOR ("WHITE")
CALL PAGHDR (CSTR1,CSTR2,IOPT,IDIR)
!...
!...DONE
CALL DISFIN
OPEN  (NEWUNIT=ID2, FILE = "dislin.err", STATUS = "UNKNOWN")
CLOSE (ID2, STATUS = "DELETE")
!...
!...DONE WITH SUBROUTINE PLOT
RETURN
END SUBROUTINE PLOT_RESIDUAL
