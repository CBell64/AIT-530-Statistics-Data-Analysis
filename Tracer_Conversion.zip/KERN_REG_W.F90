MODULE KERNEL_REGRESSION

! GENERAL REMARKS
! THE SUBROUTINES GLKERN.F AND LOKERN.F USE AN EFFICIENT AND FAST ALGORITHM FOR
! AUTOMATICALLY ADAPTIVE NONPARAMETRIC REGRESSION ESTIMATION WITH A KERNEL METHOD.
! ROUGHLY SPEAKING, THE METHOD PERFORMS A LOCAL AVERAGING OF THE OBSERVATIONS WHEN
! ESTIMATING THE REGRESSION FUNCTION.  ANALOGOUSLY, ONE CAN ESTIMATE DERIVATIVES
! OF SMALL ORDER OF THE REGRESSION FUNCTION.

! CRUCIAL FOR THE KERNEL REGRESSION ESTIMATION USED HERE IS THE CHOICE OF GLOBAL
! OR LOCAL BANDWIDTHS. TOO SMALL ONES WILL LEAD TO A WIGGLY CURVE, TOO LARGE ONES
! WILL SMOOTH AWAY IMPORTANT DETAILS.

! THE SUBROUTINE GLKERN.F CALCULATES AN ESTIMATOR OF THE REGRESSION FUNCTION OR
! DERIVATIVES OF THE REGRESSION FUNCTION WITH AN AUTOMATICALLY CHOSEN GLOBAL
! PLUGIN BANDWIDTH.  THE SUBROUTINE LOKERN.F CALCULATES SUCH AN ESTIMATOR WITH AN
! AUTOMATICALLY CHOSEN BANDWIDTH FUNCTION.  IT IS ALSO POSSIBLE TO USE GLOBAL AND
! LOCAL BANDWIDTHS, RESPECTIVELY, WHICH ARE SPECIFIED BY THE USER.
! THE MAIN IDEA OF THE PLUGIN METHOD IS TO ESTIMATE THE OPTIMAL BANDWIDTHS BY
! ESTIMATING THE ASYMPTOTICALLY OPTIMAL MEAN (INTEGRATED) SQUARED ERROR OPTIMAL
! BANDWIDTHS.  THEREFORE, ONE HAS TO ESTIMATE THE VARIANCE FOR HOMOSCEDASTIC ERROR
! VARIABLES AND A FUNCTIONAL OF A SMOOTH VARIANCE FUNCTION FOR HETEROSCEDASTIC
! ERROR VARIABLES, RESPECTIVELY.  ALSO, ONE HAS TO ESTIMATE AN INTEGRAL FUNCTIONAL
! OF THE SQUARED K-TH DERIVATIVE OF THE REGRESSION FUNCTION (K=KORD) FOR THE
! GLOBAL BANDWIDTH AND THE SQUARED K-TH DERIVATIVE ITSELF FOR THE LOCAL
! BANDWIDTHS.  HERE, A FURTHER KERNEL ESTIMATOR FOR THIS DERIVATIVE IS USED WITH A
! BANDWIDTH WHICH IS ADAPTED ITERATIVELY TO THE REGRESSION FUNCTION.
! A CONVOLUTION FORM OF THE KERNEL ESTIMATOR FOR THE REGRESSION FUNCTION AND ITS
! DERIVATIVES IS USED.  THEREBY, ONE CAN ADAPT THE S-ARRAY (WHICH IS
! S(I)=(T(I)+T(I+1))/2 IN THE STANDARD CONVOLUTION FORM) TO BE A SMOOTHED GRID
! MORE SUITABLE FOR RANDOM DESIGN, SEE HERRMANN (1996). USING THIS ESTIMATOR LEADS
! TO AN ASYMPTOTICALLY MINIMAX EFFICIENT ESTIMATOR FOR FIXED AND RANDOM DESIGN.
! POLYNOMIAL KERNELS AND BOUNDARY KERNELS ARE USED WITH A FAST AND STABLE UPDATING
! ALGORITHM FOR KERNEL REGRESSION ESTIMATION.

! MORE DETAILS CAN BE FOUND IN THE PAPERS REFERRED TO IN THE REFERENCES.

! REFERENCES
! ON THE GLOBAL ITERATIVE PLUGIN BANDWIDTH ESTIMATOR:
! T. GASSER, A. KNEIP, AND W. K�HLER (1991). A FLEXIBLE AND FAST METHOD FOR
! AUTOMATIC SMOOTHING. JOURNAL OF THE AMERICAN STATISTICAL ASSOCIATION, 86,
! 643-652.
! ON THE LOCAL PLUGIN BANDWIDTH ESTIMATOR:
! M. BROCKMANN, T. GASSER, AND E. HERRMANN (1993). LOCALLY ADAPTIVE BANDWIDTH
! CHOICE FOR KERNEL REGRESSION ESTIMATORS. JOURNAL OF THE AMERICAN STATISTICAL
! ASSOCIATION, 88, 1302-1309.
! ON NONPARAMETRIC VARIANCE ESTIMATION:
! T. GASSER, L. SROKA, AND C. JENNEN-STEINMETZ (1986). RESIDUAL AND RESIDUAL
! PATTERN IN NONLINEAR REGRESSION. BIOMETRIKA, 73, 625-633.
! ON ADAPTING HETEROSCEDASTICITY:
! E. HERRMANN (1997). LOCAL BANDWIDTH CHOICE IN KERNEL REGRESSION ESTIMATION.
! JOURNAL OF GRAPHICAL AND COMPUTATIONAL STATISTICS, 6, 35-54.
! ON THE FAST ALGORITHM FOR KERNEL REGRESSION ESTIMATOR:
! T. GASSER AND A. KNEIP (1989) DISCUSSION OF BUJA, A., HASTIE, T. AND TIBSHIRANI,
! R.: LINEAR SMOOTHERS AND ADDITIVE MODELS, THE ANNALS OF STATISTICS, 17, 532-535.
!
! B. SEIFERT, M. BROCKMANN, J. ENGEL, AND T. GASSER (1994). FAST ALGORITHMS FOR
! NONPARAMETRIC CURVE ESTIMATION. J. COMPUTATIONAL AND GRAPHICAL STATISTICS 3,
! 192-213.
! ON THE SPECIAL KERNEL ESTIMATOR FOR RANDOM DESIGN:
! E. HERRMANN (1996). ON THE CONVOLUTION TYPE KERNEL REGRESSION ESTIMATOR.
! PREPRINT 1833, FB MATHEMATIK, TECHNISCHE UNIVERSIT�T DARMSTADT (AVAILABLE FROM
! THE PREPRINT SERVER OF THE MATHEMATICAL DEPARTMENT OF THE TECHNICAL UNIVERSITY
! OF DARMSTADT )

! COMMENTS TO EVA HERRMANN: EHERRMANN@MATHEMATIK.TU-DARMSTADT.DE

! LAST UPDATE (FORTRAN 77): 10-DECEMBER-98 / MZ

! CODE CONVERTED USING TO_F90 BY ALAN MILLER
! DATE: 2000-10-04  TIME: 16:41:52

! CORRECTED BY MALCOLM FIELD
! DATE: 2017-08-30  TIME: 09:27:52

!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE


CONTAINS


    SUBROUTINE GLKERN(T,X,N,TT,M,IHOM,NUE,KORD,IRND,ISMO,M1,TL,TU,S,SIG,B,Y)

    ! N.B. ARGUMENTS WN & W1 HAVE BEEN REMOVED.

    !------------------------------------------------------------------*
    !   SHORT-VERSION: OCT 1996

    !   PURPOSE:

    !   GENERAL SUBROUTINE FOR KERNEL SMOOTHING:
    !   COMPUTATION OF ITERATIVE PLUG-IN ALGORITHM FOR GLOBAL BANDWIDTH
    !   SELECTION FOR KERNELS WITH (NUE,KORD) = (0,2),(0,4),(1,3) OR (2,4).

    !------------------------------------------------------------------*
    !   THE RAW DATA SHOULD BE GIVEN BY THE POINTS
    !   (T(1),X(1)),...,(T(N),X(N))

    !   THE RESULTING ESTIMATOR OF THE NUE-TH DERIVATIVE OF THE
    !   REGRESSION CURVE IS GIVEN THROUGH THE POINTS
    !   (TT(1),Y(1)),...,(TT(M),Y(M))

    !   THE PLUG-IN BANDWIDTH IS GIVEN BY B
    !------------------------------------------------------------------*

    !  PARAMETERS :

    !  INPUT    T(N)         INPUT GRID (T(1)<T(2)<...<T(N))
    !  INPUT    X(N)         DATA
    !  INPUT    N            LENGTH OF X

    !  INPUT    TT(M)        OUTPUT GRID, SHOULD BE ORDERED
    !  INPUT    M            LENGTH OF TT

    !  INPUT    IHOM         HOMOSKEDASTICY OF VARIANCE
    !                        0: HOMOSKEDASTIC ERROR VARIABLES,
    !                        <> 0: IF THE VARIANCE SHOULD ESTIMATED AS
    !                              SMOOTH FUNCTION.
    !                        ****** DEFAULT VALUE: IHOM=0

    !  INPUT    NUE          ORDER OF DERIVATIVE (0-4) OF THE REGRESSION
    !                        FUNCTION WHICH SHALL BE ESTIMATED
    !                        ****** DEFAULT VALUE: NUE=0

    !  INPUT    KORD         ORDER OF KERNEL (<=6), FOR ISMO=0  ONLY
    !                        NUE=0, KORD=2 OR KORD=4
    !                        OR NUE=1, KORD=3 OR NUE=2, KORD=4 ARE ALLOWED
    !                        ****** DEFAULT VALUE: KORD=NUE+2

    !  INPUT    IRND         0: IF RANDOM GRID POINTS T MAY OCCUR
    !                        <>0 ELSE  (ONLY NECESSARY IF S SHOULD BE
    !                            COMPUTED)
    !                        ****** DEFAULT VALUE IRND=0

    !  INPUT    ISMO         0:ESTIMATING THE OPTIMAL GLOBAL BANDWIDTH
    !                        <>0 USING GLOBAL INPUT BANDWIDTH B
    !                        ****** DEFAULT VALUE ISMO=0

    !  INPUT    M1           >=10, LENGTH OF W1, LARGE VALUES WILL INCREASE
    !                        THE ACCURACY OF THE INTEGRAL APPROXIMATION
    !                        ****** DEFAULT VALUE: M1=400

    !
    ! IN/OUTPUT TL/TU        LOWER/UPPER BOUND FOR INTEGRAL APPROXIMATION
    !                        AND VARIANCE ESTIMATION (IF SIG=0 AND IHOM=0),
    !                        IF TU<=TL, [TL,TU] ARE COMPUTED AS ABOUT
    !                        THE 87% MIDDLE PART OF [T(1),T(N)]
    !                        ****** DEFAULT VALUES: TL=1.0, TU=0.0

    ! IN/OUTPUT S(0:N)       IF S(N)<=S(0) THIS ARRAY IS COMPUTED AS
    !                        MIDPOINTS OF T, FOR NON-RANDOM DESIGN AND AS
    !                        SMOOTHED QUANTILES FOR RANDOM DESIGN
    !                        ****** DEFAULT VALUES: S(0)=1.0, S(N)=0.0
    !                               AND THE OTHER S(I) CAN BE UNDEFINED

    ! IN/OUTPUT SIG          RESIDUAL VARIANCE, ESTIMATED FOR SIG=0 OR
    !                        IHOM<>0, ELSE GIVEN BY INPUT
    !                        ****** DEFAULT VALUE: SIG=-1.0

    ! IN/OUTPUT B            GLOBAL PLUG-IN BANDWIDTH
    !                        ****** B CAN BE UNDIFINED IF ISMO=0


    ! WORK     WN(0:N,5)     WORK ARRAY FOR KERNEL SMOOTHING ROUTINE
    !                        OR NUE=1, KORD=3 OR NUE=2, KORD=4 ARE ALLOWED
    !                        ****** WILL BE SET IN SUBROUTINE
    ! WORK     W1(M1,3)      WORK ARRAY FOR INTEGRAL APPROXIMATION
    !                        ****** WILL BE SET IN SUBROUTINE

    !
    ! OUTPUT   Y(M)          KERNEL ESTIMATE WITH BOP (=B0 FOR ISMO<>0)
    !                        ****** WILL BE SET IN SUBROUTINE
    !-----------------------------------------------------------------------
    !  USED SUBROUTINES: COFF, RESEST, KERNEL WITH FURTHER SUBROUTINES
    !                    WHICH ARE CONTAINED IN THE FILE SUBS.F
    !-----------------------------------------------------------------------
    !...
    !...IDENTIFY TRANSFERED VALIABLES
    REAL(WP), DIMENSION(:), INTENT(IN)                      :: T, TT, X
    INTEGER(I4B), INTENT(IN)                                :: IHOM, IRND, M, M1, N, NUE
    INTEGER(I4B), INTENT(INOUT)                             :: KORD, ISMO
    REAL(WP), INTENT(INOUT)                                 :: B, SIG, TL, TU
    REAL(WP), DIMENSION(0:), INTENT(INOUT)                  :: S
    REAL(WP), DIMENSION(:), INTENT(OUT)                     :: Y
    !...
    !...IDENTIFY LOCAL VARIABLES
    REAL(WP), DIMENSION(M1,3)                               :: W1
    REAL(WP), DIMENSION(0:N,5)                              :: WN
    INTEGER(I4B)                                            :: I, II, IIL, IL, INPUTS, IPRINT, ISORT
    INTEGER(I4B)                                            :: IT, ITENDE, ITT, IU, J, KK, KK2, NN, NYG
    REAL(WP)                                                :: ALPHA, B2, BMAX, BMIN, BRES, BS, CONST
    REAL(WP)                                                :: EX, EXS, EXSVI, FAC, Q, R2, RVAR, S0, SN
    REAL(WP)                                                :: SNR, SSI, TLL, TUU, VI, XI, XMY2
    !-
    !-------- 1. INITIALIZATIONS AND SOME ERROR-CHECKS
    REAL(WP), DIMENSION(2,0:2), SAVE                        :: BIAS = RESHAPE(                          &
                        (/ FIFTH_W, 0.04762_WP, 0.4286_WP, 0.1515_WP, 1.33_WP, 0.6293_WP /), (/ 2,3 /))
    REAL(WP), DIMENSION(2,0:2), SAVE                        :: VARK = RESHAPE(                          &
                        (/ 0.6_WP, 1.250_WP, 2.143_WP, 11.93_WP, 35.0_WP, 381.6_WP /), (/ 2,3 /))
    REAL(WP), DIMENSION(2:4), SAVE                          :: FAK2 = (/ FOUR_W, 36.0_WP, 576.0_WP /)

    NYG    = 0
    INPUTS = 0
    !-------- IF NO ERRORS SHOULD BE WRITTEN ON STANDARD OUTPUT, SET IPRINT=1
    !-------- IF ERRORS AND VERY DETAILED WARNINGS SHOULD BE WRITTEN ON STANDARD OUTPUT, SET IPRINT < 0
    IPRINT = 0

    IF (NUE > 4 .OR. NUE < 0) THEN
        IF (IPRINT == 0) WRITE(*,*) "GLKERN: ORDER OF DERIVATIVE NOT ALLOWED"
        STOP
    ENDIF
    IF (NUE > 2 .AND. ISMO == 0) THEN
        IF (IPRINT == 0) WRITE(*,*) "GLKERN: ORDER OF DERIVATIVE NOT ALLOWED"
        STOP
    ENDIF
    IF (N <= 2) THEN
        IF (IPRINT == 0) WRITE(*,*) "GLKERN: NUMBER OF DATA TOO SMALL"
        STOP
    ENDIF
    IF (M < 1) THEN
        IF (IPRINT == 0) WRITE(*,*) "GLKERN: NO OUTPUT POINTS"
        STOP
    ENDIF
    IF (M1 < 10) THEN
        IF (IPRINT == 0) WRITE(*,*) "GLKERN: VARIABLE M1 IS CHOOSEN TOO SMALL"
        STOP
    ENDIF

    KK = (KORD-NUE)/2
    IF (2*KK+NUE /= KORD) THEN
        IF (IPRINT == 0) WRITE(*,*) "GLKERN: KERNEL ORDER NOT ALLOWED, SET TO ",NUE+2
        KORD = NUE+2
    ENDIF
    IF (KORD > 4 .AND. ISMO == 0) THEN
        IF (IPRINT == 0) WRITE(*,*) "GLKERN: KERNEL ORDER NOT ALLOWED, SET TO ",NUE+2
        KORD = NUE+2
    ENDIF
    IF (KORD > 6 .OR. KORD <= NUE) THEN
        IF (IPRINT == 0) WRITE(*,*) "GLKERN: KERNEL ORDER NOT ALLOWED, SET TO ",NUE+2
        KORD = NUE+2
    ENDIF
    IF (ISMO /= 0 .AND. B <= 0) THEN
        IF (IPRINT == 0) WRITE(*,*) "GLKERN: PLUG-IN BANDWIDTH IS USED"
       ISMO = 0
    ENDIF
    RVAR = SIG
    !-
    !-------- 2. COMPUTATION OF S-SEQUENCE
    S0 = 1.5_WP*T(1) - HALF_W*T(2)
    SN = 1.5_WP*T(N) - HALF_W*T(N-1)
    IF (S(N) <= S(0)) THEN
        INPUTS = 1
        DO I = 1,N-1
            S(I) = HALF_W*(T(I)+T(I+1))
        ENDDO
        S(0) = S0
        S(N) = SN
        IF (ISMO /= 0 .AND. IRND /= 0) GOTO 160
    ELSE
        IF (ISMO /= 0) GOTO 160
    ENDIF
    !-
    !-------- 3. COMPUTATION OF MINIMAL, MAXIMAL ALLOWED BANDWIDTH
    BMAX = (SN-S0)*HALF_W
    BMIN = (SN-S0)/REAL(N, KIND=WP)*REAL((KORD-1), KIND=WP)*0.6_WP
    !-
    !-------- 4. WARNINGS IF TT-GRID LARGER THAN T-GRID
    IF (TT(1) < S0 .AND. TT(M) > SN .AND. IPRINT < 0) WRITE(*,*)   &
        "GLKERN: EXTRAPOLATION AT BOTH BOUNDARIES NOT OPTIMIZED"
    IF (TT(1) < S0 .AND. TT(M) <= SN .AND. IPRINT < 0) WRITE(*,*)   &
        "GLKERN: EXTRAPOLATION AT LEFT BOUNDARY NOT OPTIMIZED"
    IF (TT(1) >= S0 .AND. TT(M) > SN .AND. IPRINT < 0) WRITE(*,*)   &
        "GLKERN: EXTRAPOLATION AT RIGHT BOUNDARY NOT OPTIMIZED"

    !-
    !-------- 5. COMPUTE TL,TU AND THEIR T-GRID AS INNER PART FOR INTEGRAL APPROXIMATION IN THE ITERATIONS
    ITT = 0
    51 IF (TU <= TL) THEN
        TL  = 0.933_WP*S0 + 0.067_WP*SN
        TU  = 0.067_WP*S0 + 0.933_WP*SN
        ITT = ITT+1
    ENDIF
    TL = MAX(TL,S0)
    TU = MIN(TU,SN)
    IL = 1
    IU = N
    WN(1,1) = ZERO_W
    WN(N,1) = ZERO_W
    DO I = 1,N
        IF (T(I) <= TL .OR. T(I) >= TU) WN(I,1) = ZERO_W
        IF (T(I) > TL .AND. T(I) < TU)  WN(I,1) = ONE_W
        IF (T(I) < TL) IL = I+1
        IF (T(I) <= TU) IU = I
    ENDDO
    NN = IU-IL+1
    IF (NN == 0 .AND. ITT == 0) THEN
        TU = TL-ONE_W
        GOTO 51
    ENDIF
    IF (NN == 0 .AND. ITT == 1) THEN
        TU = SN
        TL = S0
        GOTO 51
    ENDIF
    !-
    !-------- 6. COMPUTE T-GRID FOR INTEGRAL APPROXIMATION
    DO I = 1,M1
        W1(I,2) = ONE_W
        W1(I,1) = TL+(TU-TL)*REAL((I-1), KIND=WP)/REAL((M1-1), KIND=WP)
    ENDDO
    !-
    !-------- 7. CALCULATION OF WEIGHT FUNCTION
    ALPHA = ONE_W/13.0_WP
    DO I = IL,IU
        XI = (T(I) - TL)/ALPHA/(TU-TL)
        IF (XI > 1) GOTO 71
        WN(I,1) = (TEN_W - 15.0_WP*XI + SIX_W*XI*XI)*XI*XI*XI
    ENDDO
    71 DO I = IU,IL,-1
        XI = (TU-T(I))/ALPHA/(TU-TL)
        IF (XI > 1) GOTO 73
        WN(I,1) = (TEN_W - 15.0_WP*XI + SIX_W*XI*XI)*XI*XI*XI
    ENDDO
    73 DO I = 1,M1
        XI = (W1(I,1)-TL)/ALPHA/(TU-TL)
        IF (XI > 1) GOTO 75
        W1(I,2) = (TEN_W - 15.0_WP*XI + SIX_W*XI*XI)*XI*XI*XI
    ENDDO
    75 DO I = M1,1,-1
        XI = (TU-W1(I,1))/ALPHA/(TU-TL)
        IF (XI > 1) GOTO 77
        W1(I,2) = (TEN_W - 15.0_WP*XI + SIX_W*XI*XI)*XI*XI*XI
    ENDDO
    !-
    !-------- 8. COMPUTE CONSTANTS FOR ITERATION
    77 EX = ONE_W/REAL((KORD+KORD+1), KIND=WP)
    KK2 = (KORD-NUE)
    KK  = KK2/2
    !-
    !-------- 9. ESTIMATING VARIANCE AND SMOOTHED PSEUDO-RESIDUALS
    IF (SIG <= ZERO_W .AND. IHOM == 0) CALL RESEST(T(IL:),X(IL:),NN,WN(IL:,2),R2,SIG)
    IF (IHOM /= 0) THEN
        CALL RESEST(T,X,N,WN(1:,2),SNR,SIG)
        BRES = MAX(BMIN, FIFTH_W*NN**(-FIFTH_W)*(S(IU)-S(IL-1)))
        DO I = 1,N
            WN(I,3) = T(I)
            WN(I,2) = WN(I,2)*WN(I,2)
        ENDDO
        CALL KERNEL(T,WN(1:,2),N,BRES,0,KK2,NYG,S,WN(IL:,3),NN,WN(IL:,4))
    ELSE
        CALL COFF(WN(1:,4),N,SIG)
    ENDIF
    !-
    !-------- 10. ESTIMATE/COMPUTE INTEGRAL CONSTANT
    100 VI = ZERO_W
    DO I = IL,IU
        VI = VI + WN(I,1)*N*(S(I)-S(I-1))**2*WN(I,4)
    ENDDO
    !-
    !-------- 11. REFINEMENT OF S-SEQUENCE FOR RANDOM DESIGN
    IF (INPUTS == 1 .AND. IRND == 0) THEN
        DO I = 0,N
            WN(I,5) =  REAL(I, KIND=WP)/REAL((N+1), KIND=WP)
            WN(I,2) = (REAL(I, KIND=WP)+HALF_W)/REAL((N+1), KIND=WP)
            WN(I,3) =  WN(I,2)
        ENDDO
        EXS   = -REAL((3*KORD+1), KIND=WP)/REAL((6*KORD+3), KIND=WP)
        EXSVI =  REAL(KORD, KIND=WP)/REAL((6*KORD+3), KIND=WP)
        BS    = TENTH_W*(VI/(SN-S0)**2)**EXSVI*N**EXS
        CALL KERNEL(WN(1:,5),T,N,BS,0,2,NYG,WN(0:,3),WN(0:,2),N+1,S(0:))
    111 ISORT = 0
        VI = ZERO_W
        DO I = 1,N
            VI = VI + WN(I,1)*N*(S(I)-S(I-1))**2*WN(I,4)
            IF (S(I) < S(I-1)) THEN
                SSI = S(I-1)
                S(I-1) = S(I)
                S(I) = SSI
                ISORT = 1
            ENDIF
        ENDDO
        IF (ISORT == 1) GOTO 111
        IF (ISMO /=  0) GOTO 160
    ENDIF
    B = BMIN*TWO_W
    !-
    !-------- 12. COMPUTE INFLATION CONSTANT AND EXPONENT AND LOOP OF ITERATIONS
    CONST  = REAL((2*NUE+1), KIND=WP)*FAK2(KORD)*VARK(KK,NUE)*VI/(REAL((2*KORD-2*NUE), KIND=WP)*BIAS(KK,NUE)**2*REAL(N, KIND=WP))
    FAC    = 1.1_WP*(ONE_W+(NUE/TEN_W)+0.05_WP*(KORD-NUE-TWO_W))*N**(TWO_W/REAL(((2*KORD+1)*(2*KORD+3)), KIND=WP))
    ITENDE = 1 + 2*KORD + KORD*(2*KORD+1)

    DO IT = 1,ITENDE
    !-
    !-------- 13. ESTIMATE DERIVATIVE OF ORDER KORD IN ITERATIONS
        B2 = B*FAC
        B2 = MAX(B2,BMIN/REAL((KORD-1), KIND=WP)*REAL((KORD+1), KIND=WP))
        B2 = MIN(B2,BMAX)
        CALL KERNEL(T,X,N,B2,KORD,KORD+2,NYG,S,W1(1:,1),M1,W1(1:,3))
    !-
    !-------- 14. ESTIMATE INTEGRAL FUNCTIONAL IN ITERATIONS
        XMY2 = 0.75_WP*(W1(1,2)*W1(1,3)*W1(1,3) + W1(M1,2)*W1(M1,3)*W1(M1,3))
        DO I = 2,M1-1
            XMY2 = XMY2 + W1(I,2)*W1(I,3)*W1(I,3)
        ENDDO
        XMY2 = XMY2*(TU-TL)/M1
    !-
    !-------- 15. FINISH OF ITERATIONS
        B = (CONST/XMY2)**EX
        B = MAX(BMIN,B)
        B = MIN(BMAX,B)
    ENDDO
    !-
    !-------- 16  COMPUTE SMOOTHED FUNCTION WITH PLUG-IN BANDWIDTH
    160 CALL KERNEL(T,X,N,B,NUE,KORD,NYG,S,TT,M,Y)
    !-
    !-------- 17. VARIANCE CHECK
    IF (IHOM /= 0) SIG = RVAR
    IF (RVAR == SIG .OR. R2 < 0.88_WP .OR. IHOM /= 0 .OR. NUE > 0) RETURN
    II  = 0
    IIL = 0
    J   = 2
    TLL = MAX(TL, TT(1))
    TUU = MIN(TU, TT(M))
    DO I = IL,IU
        IF (T(I) < TLL .OR. T(I) > TUU) CYCLE
        II = II+1
        IF (IIL == 0) IIL = I
    171 IF (TT(J) < T(I)) THEN
            J = J+1
            IF (J <= M) GOTO 171
        ENDIF
        WN(II,3) = X(I)-Y(J) + (Y(J)-Y(J-1))*(TT(J)-T(I))/(TT(J)-TT(J-1))
    ENDDO
    IF (IIL == 0 .OR. II-IIL < 10) THEN
        CALL RESEST(T(IL:),WN(1:,3),NN,WN(1:,4),SNR,RVAR)
    ELSE
        CALL RESEST(T(IIL:),WN(1:,3),II,WN(1:,4),SNR,RVAR)
    ENDIF
    Q = SIG/RVAR
    IF (Q <= TWO_W) RETURN
    IF (Q > FIVE_W .AND. R2 > 0.95_WP) RVAR = RVAR*HALF_W
    SIG = RVAR
    CALL COFF(WN(1:,4),N,SIG)
    GOTO 100
    !...
    !...DONE
    END SUBROUTINE GLKERN



    SUBROUTINE LOKERN(T,X,N,TT,M,IHOM,NUE,KORD,IRND,ISMO,M1,TL,TU,S,SIG,BAN,Y)

    ! N.B. ARGUMENTS WN, W1 & WM HAVE BEEN REMOVED.

    !-------------------------------------------------------------------*
    !--------------------------------------------------------------------
    !    SHORT-VERSION: JANUARY 1997

    !    PURPOSE:

    !    GENERAL SUBROUTINE FOR KERNEL SMOOTHING:
    !    COMPUTATION OF ITERATIVE PLUG-IN ALGORITHM FOR LOCAL BANDWIDTH
    !    SELECTION FOR KERNELS WITH (NUE,KORD) = (0,2),(0,4),(1,3) OR (2,4).

    !-------------------------------------------------------------------*
    !    THE RAW DATA SHOULD BE GIVEN BY THE POINTS
    !    (T(1),X(1)),...,(T(N),X(N))

    !    THE RESULTING ESTIMATOR OF THE NUE-TH DERIVATIVE OF THE
    !    REGRESSION CURVE IS GIVEN THROUGH THE POINTS
    !    (TT(1),Y(1)),...,(TT(M),Y(M))

    !    THE LOCAL PLUG-IN BANDWIDTH ARRAY IS GIVEN BY BAN(1),...,BAN(M)
    !-------------------------------------------------------------------*

    !  PARAMETERS :

    !  INPUT    T(N)         INPUT GRID (T(1)<T(2)<...<T(N))
    !  INPUT    X(N)         DATA
    !  INPUT    N            LENGTH OF X

    !  INPUT    TT(M)        OUTPUT GRID
    !  INPUT    M            LENGTH OF TT

    !  INPUT    IHOM         HOMOSZEDASTICY OF VARIANCE
    !                        0: HOMOSZEDASTIC ERROR VARIABLES
    !                        <> 0: IF THE VARIANCE SHOULD ESTIMATED AS
    !                              SMOOTH FUNCTION.
    !                        ****** DEFAULT VALUE: IHOM=0

    !  INPUT    NUE          ORDER OF DERIVATIVE (0-4)
    !                        ****** DEFAULT VALUE: NUE=0

    !  INPUT    KORD         ORDER OF KERNEL (<=6), FOR ISMO=0  ONLY
    !                        NUE=0, KORD=2 OR KORD=4
    !                        OR NUE=1, KORD=3 OR NUE=2, KORD=4 ARE ALLOWED
    !                        ****** DEFAULT VALUE: KORD=NUE+2

    !  INPUT    IRND         0: IF RANDOM GRID POINTS T MAY OCCUR
    !                        <>0 ELSE  (ONLY NECESSARY IF S SHOULD BE
    !                            COMPUTED)
    !                        ****** DEFAULT VALUE IRND=0

    !  INPUT    ISMO         0:ESTIMATING THE OPTIMAL LOCAL BANDWIDTH
    !                        <>0 USING LOCAL INPUT BANDWIDTH-ARRAY IN BAN
    !                        ****** DEFAULT VALUE ISMO=0

    !  INPUT    M1           >=10, LENGTH OF W1, LARGE VALUES WILL INCREASE
    !                        THE ACCURACY OF THE INTEGRAL APPROXIMATION
    !                        ****** DEFAULT VALUE: M1=400

    !
    ! IN/OUTPUT TL/TU        LOWER/UPPER BOUND FOR INTEGRAL APPROXIMATION
    !                        AND VARIANCE ESTIMATION (IF SIG=0 AND IHOM=0),
    !                        IF TU<=TL, [TL,TU] ARE COMPUTED AS ABOUT
    !                        THE 87% MIDDLE PART OF [T(1),T(N)]
    !                        ****** DEFAULT VALUES: TL=1.0, TU=0.0

    ! IN/OUTPUT S(0:N)       IF S(N)<=S(0) THIS ARRAY IS COMPUTED AS
    !                        MIDPOINTS OF T, FOR NON-RANDOM DESIGN AND AS
    !                        SMOOTHED QUANTILES FOR RANDOM DESIGN
    !                        ****** DEFAULT VALUES: S(0)=1.0, S(N)=0.0
    !                               AND THE OTHER S(I) CAN BE UNDEFINED

    ! IN/OUTPUT SIG          RESIDUAL VARIANCE, ESTIMATED FOR SIG=0 OR
    !                        IHOM<>0, ELSE GIVEN BY INPUT
    !                        ****** DEFAULT VALUE: SIG=-1.0

    ! IN/OUTPUT BAN(M)       LOCAL PLUG-IN BANDWIDTH ARRAY
    !                        ****** WILL BE SET IN SUBROUTINE FOR ISMO=0

    ! WORK     WN(0:N,5)     WORK ARRAY FOR KERNEL SMOOTHING ROUTINE
    !                        ****** WILL BE SET IN SUBROUTINE
    ! WORK     W1(M1,3)      WORK ARRAY FOR INTEGRAL APPROXIMATION
    !                        ****** WILL BE SET IN SUBROUTINE
    ! WORK     WM(M)         WORK ARRAY FOR INTEGRAL APPROXIMATION
    !                        ****** WILL BE SET IN SUBROUTINE
    !
    ! OUTPUT   Y(M)          KERNEL ESTIMATE WITH BOP(=B0 FOR ISMO<>0)
    !                        ****** WILL BE SET IN SUBROUTINE
    !-----------------------------------------------------------------------
    !  USED SUBROUTINES: COFF, RESEST, KERNEL WITH FURTHER SUBROUTINES
    !                     WHICH ARE CONTAINED IN THE FILE SUBS.F
    !-----------------------------------------------------------------------
    !...
    !...IDENTIFY TRANSFERRED VALIABLES
    REAL(WP), DIMENSION(:), INTENT(IN)                      :: T, TT, X
    INTEGER(I4B), INTENT(IN)                                :: IHOM, IRND, ISMO, M, M1, N, NUE
    INTEGER(I4B), INTENT(INOUT)                             :: KORD
    REAL(WP), INTENT(INOUT)                                 :: SIG, TL, TU
    REAL(WP), DIMENSION(0:), INTENT(INOUT)                  :: S
    REAL(WP), DIMENSION(:), INTENT(INOUT)                   :: BAN
    REAL(WP), DIMENSION(:), INTENT(OUT)                     :: Y
    !...
    !...IDENTIFY LOCAL VARIABLES
    REAL(WP), DIMENSION(0:N,5)                              :: WN
    REAL(WP), DIMENSION(M1,3)                               :: W1
    REAL(WP), DIMENSION(M)                                  :: WM
    INTEGER(I4B)                                            :: I, II, IIL, IL, INPUTS, IPRINT, ISORT, IT, ITENDE
    INTEGER(I4B)                                            :: ITT, IU, J, KK, KK2, KORDV, NN, NUEV, NYG, NYL
    REAL(WP)                                                :: ALPHA, B, B2, BMAX, BMIN, BRES, BS, BVAR, CONST, DIST
    REAL(WP)                                                :: EX, EXS, EXSVI, FAC, G1, G2, Q, R2, RVAR, S0, SN, SNR, SSI
    REAL(WP)                                                :: TLL, TUU, VI, WSTEP, XH, XI, XMY2, XXH
    !-
    !-------- 1. INITIALIZATIONS AND SOME ERROR-CHECKS

    REAL(WP), DIMENSION(2,0:2), SAVE                        :: BIAS = RESHAPE(                          &
                        (/ FIFTH_W, 0.04762_WP, 0.4286_WP, 0.1515_WP, 1.33_WP, 0.6293_WP /), (/ 2,3 /))
    REAL(WP), DIMENSION(2,0:2), SAVE                        :: VARK = RESHAPE(                          &
                        (/ 0.6_WP, 1.250_WP, 2.143_WP, 11.93_WP, 35.0_WP, 381.6_WP /), (/ 2,3 /))
    REAL(WP), DIMENSION(2:4), SAVE                          :: FAK2 = (/ FOUR_W, 36.0_WP, 576.0_WP /)

    NYG    = 0
    INPUTS = 0
    !-------- IF NO ERRORS SHOULD BE WRITTEN ON STANDARD OUTPUT, SET IPRINT > 0
    !-------- IF ERRORS AND VERY DETAILED WARNINGS SHOULD BE WRITTEN ON STANDARD OUTPUT, SET IPRINT < 0
    IPRINT = 0

    IF (NUE > 4 .OR. NUE < 0) THEN
        IF (IPRINT == 0) WRITE(*,*) "LOKERN: ORDER OF DERIVATIVE NOT ALLOWED"
        STOP
    ENDIF
    IF (NUE > 2 .AND. ISMO == 0) THEN
        IF (IPRINT == 0) WRITE(*,*) "LOKERN: ORDER OF DERIVATIVE NOT ALLOWED"
        STOP
    ENDIF
    IF (N <= 2) THEN
        IF (IPRINT == 0) WRITE(*,*) "LOKERN: NUMBER OF DATA TOO SMALL"
        STOP
    ENDIF
    IF (M < 1) THEN
        IF (IPRINT == 0) WRITE(*,*) "LOKERN: NO OUTPUT POINTS"
        STOP
    ENDIF
    IF (M1 < 10) THEN
        IF (IPRINT == 0) WRITE(*,*) "LOKERN: VARIABLE M1 IS CHOOSEN TOO SMALL"
        STOP
    ENDIF
    KK = (KORD-NUE)/2
    IF (2*KK+NUE /= KORD) THEN
        IF (IPRINT == 0) WRITE(*,*) "LOKERN: KERNEL ORDER NOT ALLOWED, SET TO ",NUE+2
        KORD = NUE+2
    ENDIF
    IF (KORD > 4 .AND. ISMO == 0) THEN
        IF (IPRINT == 0) WRITE(*,*) "LOKERN: KERNEL ORDER NOT ALLOWED, SET TO ",NUE+2
        KORD = NUE+2
    ENDIF
    IF (KORD > 6 .OR. KORD <= NUE) THEN
        IF (IPRINT == 0) WRITE(*,*) "LOKERN: KERNEL ORDER NOT ALLOWED, SET TO ",NUE+2
        KORD = NUE+2
    ENDIF
    RVAR = SIG
    !-
    !-------- 2. COMPUTATION OF S-SEQUENCE
    S0 = 1.5_WP*T(1)-HALF_W*T(2)
    SN = 1.5_WP*T(N)-HALF_W*T(N-1)
    IF (S(N) <= S(0)) THEN
        INPUTS=1
        DO I = 1,N-1
            S(I) = HALF_W*(T(I)+T(I+1))
        ENDDO
        S(0) = S0
        S(N) = SN
        IF (ISMO /= 0 .AND. IRND /= 0) GOTO 230
    ELSE
        IF (ISMO /= 0) GOTO 230
    ENDIF
    !-
    !-------- 3. COMPUTATION OF MINIMAL, MAXIMAL ALLOWED GLOBAL BANDWIDTH
    BMAX = (SN-S0)*HALF_W
    BMIN = (SN-S0)/REAL(N, KIND=WP)*REAL((KORD-1), KIND=WP)*0.6_WP
    !-
    !-------- 4. WARNINGS IF TT-GRID LARGER THAN T-GRID
    IF (TT(1) < S0 .AND. TT(M) > SN .AND. IPRINT < 0) WRITE(*,*)   &
        "LOKERN: EXTRAPOLATION AT BOTH BOUNDARIES NOT OPTIMIZED"
    IF (TT(1) < S0 .AND. TT(M) <= SN .AND. IPRINT < 0) WRITE(*,*)   &
        "LOKERN: EXTRAPOLATION AT LEFT BOUNDARY NOT OPTIMIZED"
    IF (TT(1) >= S0 .AND. TT(M) > SN .AND. IPRINT < 0) WRITE(*,*)   &
        "LOKERN: EXTRAPOLATION AT RIGHT BOUNDARY NOT OPTIMIZED"
    !-
    !-------- 5. COMPUTE TL,TU AND THEIR T-GRID AS INNER PART FOR INTEGRAL APPROXIMATION IN THE ITERATIONS
    ITT = 0
    51 IF (TU <= TL) THEN
        TL  = 0.933_WP*S0+0.067_WP*SN
        TU  = 0.067_WP*S0+0.933_WP*SN
        ITT = ITT+1
    ENDIF
    TL = MAX(S0,TL)
    TU = MIN(SN,TU)
    IL = 1
    IU = N
    WN(1,1) = ZERO_W
    WN(N,1) = ZERO_W
    DO I = 1,N
        IF (T(I) <= TL .OR. T(I) >= TU) WN(I,1) = ZERO_W
        IF (T(I) > TL .AND. T(I) <  TU) WN(I,1) = ONE_W
        IF (T(I) < TL) IL=I+1
        IF (T(I) <= TU) IU=I
    ENDDO
    NN = IU-IL+1
    IF (NN == 0 .AND. ITT == 0) THEN
        TU = TL-ONE_W
        GOTO 51
    ENDIF
    IF (NN == 0 .AND. ITT == 1) THEN
        TU = SN
        TL = S0
        GOTO 51
    ENDIF
    !-
    !-------- 6. COMPUTE T-GRID FOR INTEGRAL APPROXIMATION
    DO I = 1,M1
        W1(I,2) = ONE_W
        W1(I,1) = TL+(TU-TL)*REAL((I-1), KIND=WP)/REAL((M1-1), KIND=WP)
    ENDDO
    !-
    !-------- 7. CALCULATION OF WEIGHT FUNCTION
    ALPHA = ONE_W/13.0_WP
    DO I = IL,IU
        XI = (T(I)-TL)/ALPHA/(TU-TL)
        IF (XI > 1) GOTO 71
        WN(I,1) = (TEN_W-15.0_WP*XI+SIX_W*XI*XI)*XI*XI*XI
    ENDDO
    71 DO I = IU,IL,-1
        XI = (TU-T(I))/ALPHA/(TU-TL)
        IF (XI > 1) GOTO 73
        WN(I,1) = (TEN_W-15.0_WP*XI+SIX_W*XI*XI)*XI*XI*XI
    ENDDO
    73 DO I = 1,M1
        XI = (W1(I,1)-TL)/ALPHA/(TU-TL)
        IF (XI > 1) GOTO 75
        W1(I,2) = (TEN_W-15.0_WP*XI+SIX_W*XI*XI)*XI*XI*XI
    ENDDO
    75 DO I = M1,1,-1
        XI = (TU-W1(I,1))/ALPHA/(TU-TL)
        IF (XI > 1) GOTO 77
        W1(I,2) = (TEN_W-15.0_WP*XI+SIX_W*XI*XI)*XI*XI*XI
    ENDDO
    !-
    !-------- 8. COMPUTE CONSTANTS FOR ITERATION
    77 EX = ONE_W/REAL((KORD+KORD+1), KIND=WP)
    KK2 = (KORD-NUE)
    KK  = KK2/2
    !-
    !-------- 9. ESTIMATING VARIANCE AND SMOOTHED PSEUDO-RESIDUALS
    IF (SIG <= ZERO_W .AND. IHOM == 0) CALL RESEST(T(IL:),X(IL:),NN,WN(IL:,2),R2,SIG)
    IF (IHOM /= 0) THEN
        CALL RESEST(T,X,N,WN(1:,2),SNR,SIG)
        BRES = MAX(BMIN,FIFTH_W*NN**(-FIFTH_W)*(S(IU)-S(IL-1)))
        DO I = 1,N
            WN(I,3) = T(I)
            WN(I,2) = WN(I,2)*WN(I,2)
        ENDDO
        CALL KERNEL(T,WN(1:,2),N,BRES,0,KK2,NYG,S, WN(1:,3),N,WN(1:,4))
    ELSE
        CALL COFF(WN(1:,4),N,SIG)
    ENDIF
    !-
    !-------- 10. ESTIMATE/COMPUTE INTEGRAL CONSTANT
    100 VI = ZERO_W
    DO I = IL,IU
        VI = VI + WN(I,1)*N*(S(I)-S(I-1))**2*WN(I,4)
    ENDDO
    !-
    !-------- 11. REFINEMENT OF S-SEQUENCE FOR RANDOM DESIGN
    IF (INPUTS == 1 .AND. IRND == 0) THEN
        DO I = 0,N
            WN(I,5) =  REAL(I, KIND=WP)/REAL((N+1), KIND=WP)
            WN(I,2) = (REAL(I, KIND=WP)+HALF_W)/REAL((N+1), KIND=WP)
            WN(I,3) = WN(I,2)
        ENDDO
        EXS   = -REAL((3*KORD+1), KIND=WP)/REAL((6*KORD+3), KIND=WP)
        EXSVI =  REAL(KORD, KIND=WP)/REAL((6*KORD+3), KIND=WP)
        BS = TENTH_W*(VI/(SN-S0)**2)**EXSVI*N**EXS
        CALL KERNEL(WN(1:,5),T,N,BS,0,2,NYG,WN(0:,3),WN(0:,2),N+1,S(0:))
    111 ISORT = 0
        VI = ZERO_W
        DO I = 1,N
            VI = VI + WN(I,1)*N*(S(I)-S(I-1))**2*WN(I,4)
            IF (S(I) < S(I-1)) THEN
                SSI = S(I-1)
                S(I-1) = S(I)
                S(I) = SSI
                ISORT = 1
            ENDIF
        ENDDO
        IF (ISORT == 1) GOTO 111
        IF (ISMO /=  0) GOTO 230
    ENDIF
    B = BMIN*TWO_W
    !-
    !-------- 12. COMPUTE INFLATION CONSTANT AND EXPONENT AND LOOP OF ITERATIONS
    CONST  = REAL((2*NUE+1), KIND=WP)*FAK2(KORD)*VARK(KK,NUE)*VI/(REAL((2*KORD-2*NUE), KIND=WP)*BIAS(KK,NUE)**2*REAL(N, KIND=WP))
    FAC    = 1.1*(ONE_W + (NUE/TEN_W) + 0.05_WP*(KORD-NUE-TWO_W))*N**(TWO_W/REAL(((2*KORD+1)*(2*KORD+3)), KIND=WP))
    ITENDE = 1 + 2*KORD + KORD*(2*KORD+1)

    DO IT = 1,ITENDE
    !-
    !-------- 13. ESTIMATE DERIVATIVE OF ORDER KORD IN ITERATIONS
        B2 = B*FAC
        B2 = MAX(B2,BMIN/REAL((KORD-1), KIND=WP) * REAL((KORD+1), KIND=WP))
        B2 = MIN(B2,BMAX)
        CALL KERNEL(T,X,N,B2,KORD,KORD+2,NYG,S,W1(1:,1),M1,W1(1:,3))
    !-
    !-------- 14. ESTIMATE INTEGRAL FUNCTIONAL IN ITERATIONS
        XMY2 = 0.75_WP*(W1(1,2)*W1(1,3)*W1(1,3) + W1(M1,2)*W1(M1,3)*W1(M1,3))
        DO I = 2,M1-1
            XMY2 = XMY2 + W1(I,2)*W1(I,3)*W1(I,3)
        ENDDO
        XMY2 = XMY2*(TU-TL)/M1
    !-
    !-------- 15. FINISH OF ITERATIONS
        B = (CONST/XMY2)**EX
        B = MAX(BMIN,B)
        B = MIN(BMAX,B)

    ENDDO
    !-------- 16  COMPUTE SMOOTHED FUNCTION WITH GLOBAL PLUG-IN BANDWIDTH
    CALL KERNEL(T,X,N,B,NUE,KORD,NYG,S,TT,M,Y)
    !-
    !-------- 17. VARIANCE CHECK
    IF (IHOM /= 0) SIG=RVAR
    IF (RVAR == SIG .OR. R2 < 0.88_WP .OR. IHOM /= 0 .OR. NUE > 0) GOTO 180
    II  = 0
    IIL = 0
    J = 2
    TLL = MAX(TL,TT(1))
    TUU = MIN(TU, TT(M))
    DO I =IL,IU
        IF (T(I) < TLL .OR. T(I) > TUU) CYCLE
        II = II+1
        IF (IIL == 0) IIL = I
    171 IF (TT(J) < T(I)) THEN
            J = J+1
            IF (J <= M) GOTO 171
        ENDIF
        WN(II,3) = X(I)-Y(J) + (Y(J)-Y(J-1))*(TT(J)-T(I))/(TT(J)-TT(J-1))
    ENDDO
    CALL RESEST(T(IIL:),WN(1:,3),II,WN(1:,4),SNR,RVAR)
    Q = SIG/RVAR
    CALL COFF(WN(1:,4),N,SIG)
    IF (Q <= TWO_W) GOTO 180
    IF (Q > FIVE_W .AND. R2 > 0.95_WP) RVAR=RVAR*HALF_W
    SIG = RVAR
    CALL COFF(WN(1:,4),N,SIG)
    GOTO 100
    !-
    !-------- 18. LOCAL INITIALIZATIONS
    180 BVAR = B
    NUEV  = 0
    KORDV = 2
    NYL   = 1
    !-
    !-------- 19. COMPUTE INNER BANDWIDTHS
    G1 = 0.86_WP*(ONE_W + REAL((KORD-NUE-2), KIND=WP)*0.05_WP)*B
    G1 = G1*REAL(N, KIND=WP)**(FOUR_W/REAL((2*KORD+1), KIND=WP)/(2*KORD+5))
    G1 = MAX(G1,BMIN/REAL((KORD-1), KIND=WP)*REAL((KORD+1), KIND=WP))
    G1 = MIN(G1,BMAX)

    G2 = 1.4_WP*(ONE_W + REAL((KORD-NUE-2), KIND=WP)*0.05)*B
    G2 = G2*REAL(N, KIND=WP)**(TWO_Q/REAL((2*KORD+1), KIND=WP)/REAL((2*KORD+3), KIND=WP))
    G2 = MAX(G2, BMIN)
    G2 = MIN(G2, BMAX)
    !-
    !-------- 20. ESTIMATE/COMPUTE INTEGRAL CONSTANT VI LOCALLY
    DO I = 1,N
        WN(I,4)=REAL(N, KIND=WP)*WN(I,4)*(S(I)-S(I-1))
    ENDDO
    DO J = 1,M
        BAN(J) = BVAR
        WM(J)  = TT(J)
        IF (TT(J) < S(0)+G1) THEN
            DIST = ((TT(J)-G1-S(0))/G1)**2
            BAN(J) = BVAR*(ONE_W + DIST)
            BAN(J) = MIN(BAN(J),BMAX)
            WM(J)  = TT(J) + HALF_W*DIST*G1
        ELSEIF (TT(J) > S(N)-G1) THEN
            DIST   = ((TT(J)-S(N)+G1)/G1)**2
            BAN(J) = BVAR*(ONE_W + DIST)
            BAN(J) = MIN(BAN(J),BMAX)
            WM(J)  = TT(J) - HALF_W*DIST*G1
        ENDIF
    ENDDO
    CALL KERNEL(T,WN(1:,4),N,BVAR,NUEV,KORDV,NYL,S,WM,M,BAN)
    !-
    !-------- 21. ESTIMATION OF KORDTH DERIVATIVE LOCALLY
    WSTEP = (TT(M)-TT(1))/(M1-2)
    DO J = 2,M1
        W1(J,2) = TT(1) + (J-2)*WSTEP
        W1(J,1) = TT(1) + (REAL(J, KIND=WP)-1.5_WP)*WSTEP
    ENDDO
    W1(1,1) = TT(1) + HALF_W*WSTEP

    CALL KERNEL(T,X,N,G1,KORD,KORD+2,NYG,S,W1(2:,2),M1-1,W1(2:,3))

    DO J = 2,M1
        W1(J,3) = W1(J,3)*W1(J,3)
    ENDDO
    DO J = 1,M
        Y(J) = G2
        IF (TT(J) < S(0)+G1) THEN
            Y(J) = G2*(ONE_W + ((TT(J)-G1-S(0))/G1)**2)
            Y(J) = MIN(Y(J),BMAX)
        ELSEIF (TT(J) > S(N)-G1) THEN
            Y(J) = G2*(ONE_W + ((TT(J)-S(N)+G1)/G1)**2)
            Y(J) = MIN(Y(J),BMAX)
        ENDIF
    ENDDO

    CALL KERNP(W1(2:,2),W1(2:,3),M1-1,G2,NUEV,KORDV,NYL,W1(1:,1),WM,M,Y)
    !-
    !-------- 22. FINISH
    DO J = 1,M
        XH  = BMIN**(2*KORD+1)*ABS(Y(J))*VI/CONST
        XXH = CONST*ABS(BAN(J))/VI/BMAX**(2*KORD+1)
        IF (BAN(J) < XH) THEN
            BAN(J) = BMIN
        ELSE
            IF (Y(J) < XXH) THEN
                BAN(J) = BMAX
            ELSE
                BAN(J) = (CONST*BAN(J)/Y(J)/VI)**EX
            ENDIF
        ENDIF
    ENDDO
    !-
    !-------- 23. COMPUTE SMOOTHED FUNCTION WITH LOCAL PLUG-IN BANDWIDTH
    230 Y(1:M) = BAN(1:M)
    CALL KERNEL(T,X,N,B,NUE,KORD,NYL,S,TT,M,Y)
    !...
    !...DONE
    RETURN
    END SUBROUTINE LOKERN



    !---------------------------------------------------------------------
    !     SEVERAL KERNEL SMOOTHING SUBROUTINES WHICH ARE USED BY GLKERN.F
    !     AND LOKERN.F, VERSION JANUARY 1997
    !---------------------------------------------------------------------
    !     THIS FILE CONTAINS:
    !
    !     SUBROUTINE RESEST(T,X,N,RES,SNR,SIGMA2)
    !                FOR VARIANCE ESTIMATION
    !
    !     SUBROUTINE KERNEL(T,X,N,B,NUE,KORD,NY,S,TT,M,Y)
    !                DRIVER SUBROUTINE FOR KERNEL REGRESSION ESTIMATION
    !                CALLS FAST OR CONVENTIAL KERNEL ROUTINE
    !
    !     SUBROUTINE KERNP(T,X,N,B,NUE,KORD,NY,S,TT,M,Y)
    !                DRIVER SUBROUTINE FOR KERNEL REGRESSION ESTIMATION
    !                WITHOUT USE OF BOUNDARY KERNELS
    !---------------------------------------------------------------------
    !     SUBROUTINE KERNFA(T,X,N,B,NUE,KORD,NY,S,TT,M,Y)
    !                FAST ALGORITHM FOR KERNEL ESTIMATION
    !     SUBROUTINE DREG(SW,A1,A2,IORD,X,SL,SR,T,B,IFLOP)
    !                USED BY SUBROUTINE KERNFA,KERNFP
    !     SUBROUTINE LREG(SW,A3,IORD,D,DOLD,Q,C)
    !                USED BY SUBROUTINE KERNFA,KERNFP
    !     SUBROUTINE FREG(SW,NUE,KORD,IBOUN,Y,C,ICALL,A)
    !                USED BY SUBROUTINE KERNFA,KERNFP
    !     SUBROUTINE KERNFP(T,X,N,B,NUE,KORD,NY,S,TT,M,Y)
    !                FAST ALGORITHM FOR KERNP ESTIMATION WITHOUT BOUNDARY
    !---------------------------------------------------------------------
    !     SUBROUTINE KERNCL(T,X,N,B,NUE,KORD,NY,S,TT,M,Y)
    !                CONVENTIONAL ALGORITHM FOR KERNEL ESTIMATION
    !     SUBROUTINE SMO(S,X,N,TAU,WID,NUE,IORD,IBOUN,IST,S1,C,Y)
    !                SINGLE ESTIMATION STEP, USED BY KERNCL
    !     SUBROUTINE KERNCP(T,X,N,B,NUE,KORD,NY,S,TT,M,Y)
    !                CONVENTIONAL ALGORITHM WITHOUT BOUNDARY KERNELS
    !     SUBROUTINE SMOP(S,X,N,TAU,WID,NUE,IORD,IBOUN,IST,S1,C,Y)
    !                SINGLE ESTIMATION STEP, USED BY KERNCP
    !---------------------------------------------------------------------
    !     SUBROUTINE COFFI(NUE,KORD,C)
    !                KERNEL COEFFICIENT OF POLYNOMIAL KERNELS USED BY
    !                KERNCL,KERNCP AND KERNFP
    !     SUBROUTINE COFFB(NUE,KORD,Q,IBOUN,C)
    !                KERNEL COEFFICIENT OF POLYNOMIAL BOUNDARY KERNELS
    !                USED BY KERNFA AND KERNCL
    !---------------------------------------------------------------------
    !     SUBROUTINE COFF(X,N,FA)
    !                SIMPLE SUBROUTINE FOR ARRAY INITIALIZATION
    !---------------------------------------------------------------------


    SUBROUTINE RESEST(T,X,N,RES,SNR,SIGMA2)
    !--------------------------------------------------------------------
    !    VERSION: JUNE, 1996

    !    PURPOSE:

    !    COMPUTES ONE-LEAVE-OUT RESIDUALS FOR NONPARAMETRIC ESTIMATION
    !    OF RESIDUAL VARIANCE (LOCAL LINEAR APPROXIMATION FOLLOWED BY
    !    REWEIGHTING)

    !  PARAMETERS:

    !  INPUT   T(N)      ABSCISSAE (ORDERED: T(I)<=T(I+1))
    !  INPUT   X(N)      DATA
    !  INPUT   N         LENGTH OF DATA ( >2 )
    !  OUTPUT  RES(N)    RESIDUALS AT T(1),...,T(N)
    !  OUTPUT  SNR       EXPLAINED VARIANCE OF THE TRUE CURVE
    !  OUTPUT  SIGMA2    ESTIMATION OF SIGMA**2 (RESIDUAL VARIANCE)

    !--------------------------------------------------------------------
    !...
    !...IDENTIFY TRANSFERRED VALIABLES
    REAL(WP), DIMENSION(:), INTENT(IN)                      :: T, X
    INTEGER(I4B), INTENT(IN)                                :: N
    REAL(WP), DIMENSION(:), INTENT(OUT)                     :: RES
    REAL(WP), INTENT(OUT)                                   :: SNR, SIGMA2
    !...
    !...IDENTIFY LOCAL VARIABLES
    INTEGER(I4B)                                            :: I
    REAL(WP)                                                :: DN, G1, G2, EX, EX2, SX, TT

    SIGMA2 = ZERO_W
    EX  = X(1)*(T(2)-T(1))
    EX2 = X(1)*EX
    DO I = 2,N-1
        TT = T(I+1)-T(I-1)
        IF (TT /= ZERO_W) G1 = (T(I+1)-T(I))/TT
        IF (TT == ZERO_W) G1 = HALF_W
        G2 = ONE_W-G1
        RES(I) = (X(I)-G1*X(I-1)-G2*X(I+1))/SQRT(ONE_W+G1*G1+G2*G2)
        SIGMA2 = SIGMA2+RES(I)*RES(I)
        SX  = X(I)*TT
        EX  = EX+SX
        EX2 = EX2+X(I)*SX
    ENDDO
    TT = T(3)-T(2)
    IF (TT /= ZERO_W) G1 = (T(1)-T(2))/TT
    IF (TT == ZERO_W) G1 = HALF_W
    G2 = ONE_W-G1
    RES(1) = (X(1)-G1*X(3)-G2*X(2))/SQRT(ONE_W+G1*G1+G2*G2)
    TT = T(N-1)-T(N-2)
    IF (TT /= ZERO_W) G1 = (T(N-1)-T(N))/TT
    IF (TT == ZERO_W) G1 = HALF_W
    G2 = ONE_W-G1
    RES(N) = (X(N)-G1*X(N-2)-G2*X(N-1))/SQRT(ONE_W+G1*G1+G2*G2)
    SIGMA2 = (SIGMA2+RES(1)*RES(1)+RES(N)*RES(N))/N
    !
    SX  = X(N)*(T(N)-T(N-1))
    DN  = TWO_W*(T(N)-T(1))
    EX  =(EX+SX)/DN
    EX2 = (EX2+X(N)*SX)/DN
    IF (EX2 == ZERO_W) SNR = ZERO_W
    IF (EX2 >  ZERO_W) SNR = ONE_W-SIGMA2/(EX2-EX*EX)
    !...
    !...DONE
    RETURN
    END SUBROUTINE RESEST



    SUBROUTINE KERNEL(T,X,N,B,NUE,KORD,NY,S,TT,M,Y)
    !-----------------------------------------------------------------------
    !       SHORT-VERSION MAY, 1995

    !       DRIVER SUBROUTINE FOR KERNEL SMOOTHING, CHOOSES BETWEEN
    !       STANDARD AND O(N) ALGORITHM

    !  PARAMETERS :

    !  INPUT    T(N)         INPUT GRID (REGRESSION DESIGN)
    !  INPUT    X(N)         DATA, GIVEN ON T(N)
    !  INPUT    N            LENGTH OF X
    !  INPUT    B            ONE SIDED BANDWIDTH (FOR NY=1 MEAN BANDWIDTH)
    !  INPUT    NUE          ORDER OF DERIVATIVE (0-4)
    !  INPUT    KORD         ORDER OF KERNEL (<=6); DEFAULT IS KORD=NUE+2
    !  INPUT    NY           0: GLOBAL BANDWIDTH (DEFAULT)
    !                        1: VARIABLE BANDWIDTHS, GIVEN IN Y AS INPUT
    !  INPUT    S(0:N)       INTERPOLATION SEQUENCE
    !  INPUT    TT(M)        OUTPUT GRID.  MUST BE PART OF INPUT GRID FOR IEQ=0
    !  INPUT    M            NUMBER OF POINTS WHERE FUNCTION IS ESTIMATED,
    !                         OR  LENGTH OF TT. DEFAULT IS M=400
    !  INPUT    Y(M)         BANDWITH SEQUENCE FOR NY=1, DUMMY FOR NY=0
    !  OUTPUT   Y(M)         ESTIMATED REGRESSION FUNCTION

    !-----------------------------------------------------------------------
    !...
    !...IDENTIFY TRANSFERRED VALIABLES
    REAL(WP), DIMENSION(:), INTENT(IN)                      :: T, TT, X
    INTEGER(I4B), INTENT(IN)                                :: KORD, M, N, NY, NUE
    REAL(WP), INTENT(IN)                                    :: B
    REAL(WP), DIMENSION(0:), INTENT(IN)                     :: S
    REAL(WP), DIMENSION(:), INTENT(INOUT)                   :: Y
    !...
    !...IDENTIFY LOCAL VARIABLES
    REAL(WP)                                                :: CHAN

    !-
    !------  COMPUTING CHANGE POINT
    CHAN = (FIVE_W + KORD)*MAX(ONE_W,SQRT(REAL(N, KIND=WP)/REAL(M, KIND=WP)))
    !------
    IF (B*(N-1)/(T(N)-T(1)) < CHAN) THEN
        CALL KERNCL(T,X,N,B,NUE,KORD,NY,S,TT,M,Y)
    ELSE
        CALL KERNFA(T,X,N,B,NUE,KORD,NY,S,TT,M,Y)
    ENDIF
    !...
    !...DONE
    RETURN
    END SUBROUTINE KERNEL



    SUBROUTINE KERNP(T,X,N,B,NUE,KORD,NY,S,TT,M,Y)
    !-----------------------------------------------------------------------
    !       SHORT-VERSION JANUARY, 1997

    !       DRIVER SUBROUTINE FOR KERNEL SMOOTHING, CHOOSES BETWEEN
    !       STANDARD AND O(N) ALGORITHM WITHOUT USING BOUNDARY KERNELS

    !  PARAMETERS :

    !  INPUT    T(N)         INPUT GRID (REGRESSION DESIGN)
    !  INPUT    X(N)         DATA, GIVEN ON T(N)
    !  INPUT    N            LENGTH OF X
    !  INPUT    B            ONE SIDED BANDWIDTH (FOR NY=1 MEAN BANDWIDTH)
    !  INPUT    NUE          ORDER OF DERIVATIVE (0-4)
    !  INPUT    KORD         ORDER OF KERNEL (<=6); DEFAULT IS KORD=NUE+2
    !  INPUT    NY           0: GLOBAL BANDWIDTH (DEFAULT)
    !                        1: VARIABLE BANDWIDTHS, GIVEN IN Y AS INPUT
    !  INPUT    S(0:N)       INTERPOLATION SEQUENCE
    !  INPUT    TT(M)        OUTPUT GRID. MUST BE PART OF INPUT GRID FOR IEQ=0
    !  INPUT    M            NUMBER OF POINTS WHERE FUNCTION IS ESTIMATED,
    !                         OR  LENGTH OF TT.  DEFAULT IS M=400
    !  INPUT    Y(M)         BANDWITH SEQUENCE FOR NY=1, DUMMY FOR NY=0
    !  OUTPUT   Y(M)         ESTIMATED REGRESSION FUNCTION

    !-----------------------------------------------------------------------
    !...
    !...IDENTIFY TRANSFERRED VALIABLES
    REAL(WP), DIMENSION(:), INTENT(IN)                      :: T, TT, X
    INTEGER(I4B), INTENT(IN)                                :: KORD, M, N, NUE, NY
    REAL(WP), INTENT(IN)                                    :: B
    REAL(WP), DIMENSION(0:), INTENT(IN)                     :: S
    REAL(WP), DIMENSION(:), INTENT(INOUT)                   :: Y
    !...
    !...IDENTIFY LOCAL VARIABLES
    REAL(WP)                                                :: CHAN

    !-
    !------  COMPUTING CHANGE POINT
    CHAN = (FIVE_W+KORD)*MAX(ONE_W,SQRT(REAL(N, KIND=WP)/REAL(M, KIND=WP)))
    !------
    IF (B*(N-1)/(T(N)-T(1)) < CHAN) THEN
        CALL KERNCP(T,X,N,B,NUE,KORD,NY,S,TT,M,Y)
    ELSE
        CALL KERNFP(T,X,N,B,NUE,KORD,NY,S,TT,M,Y)
    ENDIF
    !...
    !...DONE
    RETURN
    END SUBROUTINE KERNP



    SUBROUTINE KERNFA(T,X,N,B,NUE,KORD,NY,S,TT,M,Y)
    !-----------------------------------------------------------------------
    !       SHORT-VERSION: MAY, 1995

    !       PURPOSE:

    !       COMPUTATION OF KERNEL ESTIMATE USING O(N) ALGORITHM BASED ON
    !       LEGENDRE POLYNOMIALS, GENERAL SPACED DESIGN AND LOCAL
    !       BANDWIDTH ALLOWED. (NEW INITIALISATIONS OF THE LEGENDRE SUMS
    !       FOR NUMERICAL REASONS)

    !  PARAMETERS :

    !  INPUT    T(N)         INPUT GRID
    !  INPUT    X(N)         DATA, GIVEN ON T(N)
    !  INPUT    N            LENGTH OF X
    !  INPUT    B            ONE SIDED BANDWIDTH
    !  INPUT    NUE          ORDER OF DERIVATIVE (0-4)
    !  INPUT    KORD         ORDER OF KERNEL (<=6)
    !  INPUT    NY           0, GLOBAL BANDWIDTH; 1, LOCAL BANDWIDTH IN Y
    !  INPUT    S(0:N)       HALF POINT INTERPOLATION SEQUENCE
    !  INPUT    TT(M)        OUTPUT GRID
    !  INPUT    M            NUMBER OF POINTS TO ESTIMATE
    !  INPUT    Y(M)         BANDWITH SEQUENCE FOR NY=1, DUMMY FOR NY=0
    !  OUTPUT   Y(M)         ESTIMATED FUNCTION

    !-----------------------------------------------------------------------
    !...
    !...IDENTIFY TRANSFERRED VALIABLES
    REAL(WP), DIMENSION(:), INTENT(IN)                      :: T, TT, X
    INTEGER(I4B), INTENT(IN)                                :: KORD, M, N, NUE, NY
    REAL(WP), INTENT(IN)                                    :: B
    REAL(WP), DIMENSION(0:), INTENT(IN)                     :: S
    REAL(WP), DIMENSION(:), INTENT(INOUT)                   :: Y

    INTEGER(I4B)                                            :: J, K, IORD, INIT, ICALL, I, IBOUN
    INTEGER(I4B)                                            :: JL, JR, JNR, JNL
    !...
    !...IDENTIFY LOCAL VARIABLES
    REAL(WP), DIMENSION(7)                                  :: A1, A2, C, SW, XF
    REAL(WP), DIMENSION(7,7)                                :: A, A3
    REAL(WP), DIMENSION(7,6)                                :: CM
    REAL(WP)                                                :: BMIN, BMAX, BB, S0, SN, WWL, WWR, WID, WR, WIDO, DOLD
    !-
    !------ COMPUTE CONSTANTS FOR LATER USE
    S0 = 1.5_WP*T(1)-HALF_W*T(2)
    SN = 1.5_WP*T(N)-HALF_W*T(N-1)
    BMIN =(SN-S0)*0.6_WP/REAL(N, KIND=WP)*REAL((KORD-1), KIND=WP)
    BMAX =(S(N)-S(0))*HALF_W
    IF (KORD == 2) BMIN = BMIN*TENTH_W
    IORD = KORD+1
    DO K = 3,IORD
        A1(K) = REAL((2*K-1), KIND=WP)/REAL(K, KIND=WP)
        A2(K) = REAL((1-K),   KIND=WP)/REAL(K, KIND=WP)
    ENDDO
    !-
    INIT  = 0
    ICALL = 0
    DOLD  = ZERO_W
    !-
    !------ SMOOTHING LOOP
    DO I = 1,M
        BB = B
        IF (NY == 1) BB = Y(I)
        IF (BB < BMIN) BB = BMIN
        IF (BB > BMAX) BB = BMAX
        IBOUN = 0
    !-
    !------ COMPUTE LEFT BOUNDARY KERNEL
        IF (TT(I) < S(0)+BB) THEN
            WWL = S(0)
            WWR = S(0)+BB+BB
            WID = WWR-TT(I)
            IBOUN = 1
            CALL COFFB(NUE,KORD,(TT(I)-S(0))/WID,IBOUN,C)
        ENDIF
    !-
    !------ COMPUTE RIGHT BOUNDARY KERNEL
        IF (TT(I)+BB > S(N)) THEN
            WWL = S(N)-(BB+BB)
            WWR = S(N)
            WID = TT(I)-WWL
            IBOUN = -1
            CALL COFFB(NUE,KORD,(S(N)-TT(I))/WID,IBOUN,C)
        ENDIF
    !-
    !------ NO BOUNDARY
        IF (IBOUN == 0) THEN
            WID = BB
            WWL = TT(I)-BB
            WWR = TT(I)+BB
        ENDIF
    !-
    !------ INITIALIZATION FOR INIT=0
        IF (INIT == 0) THEN
            SW(1:IORD) = ZERO_W
            JL = 1
            DO J = 1,N
                IF (S(J-1) < WWL) THEN
                    JL = J+1
                ELSE
                    IF (S(J) > WWR) EXIT
                    CALL DREG(SW,A1,A2,IORD,X(J),S(J-1),S(J),TT(I),WID,1)
                ENDIF
            ENDDO
            JR = J-1
            WR = WWR
            INIT = 1
            GOTO 6666
        ELSE
            INIT = INIT+1
        ENDIF
    !-
    !------ COMPARE OLD SUM WITH NEW SMOOTHING INTERVAL TT(I)-B,TT(I)+B
        IF (S(JR-1) >= WWL) THEN
            JNR = JR
            JNL = JL
            IF (S(JR) > WWR) THEN
                DO J = JR,JL,-1
                    CALL DREG(SW,A1,A2,IORD,X(J),S(J-1),S(J),TT(I-1),WIDO,-1)
                    JNR = J-1
                    IF (S(JNR) <= WWR) EXIT
                ENDDO
            ENDIF
            IF (S(JL-1) < WWL) THEN
                DO J = JL,JR
                    CALL DREG(SW,A1,A2,IORD,X(J),S(J-1),S(J),TT(I-1),WIDO,-1)
                    JNL = J+1
                    IF (S(J) >= WWL) EXIT
                ENDDO
            ENDIF
    !-
    !------ UPDATING OF SW
            CALL LREG(SW,A3,IORD,(TT(I)-TT(I-1))/WID,DOLD,WIDO/WID,CM)
            IF (JNR == JR) THEN
                DO J = JR+1,N
                    IF (S(J) > WWR) EXIT
                    CALL DREG(SW,A1,A2,IORD,X(J),S(J-1),S(J),TT(I),WID,1)
                    JNR = J
                ENDDO
            ENDIF
            JR = JNR
            IF (JL == JNL) THEN
                DO   J = JL-1,1,-1
                    IF (S(J-1) < WWL) EXIT
                    CALL DREG(SW,A1,A2,IORD,X(J),S(J-1),S(J),TT(I),WID,1)
                    JNL = J
                ENDDO
            ENDIF
            JL = JNL
        ELSE
    !-
    !------ NEW INITIALIZATION OF SW
            SW(1:IORD) = ZERO_W
            DO J = JR,N
                IF (S(J-1) < WWL) THEN
                    JL = J+1
                ELSE
                    IF (S(J) > WWR) EXIT
                    CALL DREG(SW,A1,A2,IORD,X(J),S(J-1),S(J),TT(I),WID,1)
                ENDIF
            ENDDO
            JR = J-1
            WR = WWR
        ENDIF
    !-
    !------ IF BANDWIDTH IS TOO SMALL NO SMOOTHING
    6666 IF (WWL >= S(JR-1) .AND. WWR <= S(JR)) THEN
            Y(I) = X(JR)
            IF (NUE > 0) Y(I) = ZERO_W
        ELSE
    !-
    !------ ADD FIRST AND LAST POINT OF THE SMOOTHING INTERVAL
            DO K = 1,IORD
                XF(K) = SW(K)
            ENDDO
            IF (JL /= 1) CALL DREG(XF,A1,A2,IORD,X(JL-1),WWL,S(JL-1),TT(I),WID,1)
            IF (JR /= N) CALL DREG(XF,A1,A2,IORD,X(JR+1),S(JR),WWR,TT(I),WID,1)
    !-
    !------ NOW THE SUMS ARE BUILT THAT ARE NEEDED TO COMPUTE THE ESTIMATE
            CALL FREG(XF,NUE,KORD,IBOUN,Y(I),C,ICALL,A)
            IF (NUE > 0) Y(I) = Y(I)/(WID**NUE)
        ENDIF
    !-
    !------ NEW INITIALIZATION ?
        IF (JL > JR .OR. WWL > WR .OR. INIT > 100) INIT = 0
        WIDO = WID
    ENDDO
    !...
    !...DONE
    RETURN
    END SUBROUTINE KERNFA



    SUBROUTINE KERNFP(T,X,N,B,NUE,KORD,NY,S,TT,M,Y)
    !-----------------------------------------------------------------------
    !       SHORT-VERSION: JANUARY, 1997

    !       PURPOSE:

    !       COMPUTATION OF KERNEL ESTIMATE USING O(N) ALGORITHM BASED ON
    !       LEGENDRE POLYNOMIALS, GENERAL SPACED DESIGN AND LOCAL
    !       BANDWIDTH ALLOWED. (NEW INITIALISATIONS OF THE LEGENDRE SUMS
    !       FOR NUMERICAL REASONS) WITHOUT BOUNDARY KERNELS, JUST NORMALIZING

    !  PARAMETERS :

    !  INPUT    T(N)         INPUT GRID
    !  INPUT    X(N)         DATA, GIVEN ON T(N)
    !  INPUT    N            LENGTH OF X
    !  INPUT    B            ONE SIDED BANDWIDTH
    !  INPUT    NUE          ORDER OF DERIVATIVE (0-4)
    !  INPUT    KORD         ORDER OF KERNEL (<=6)
    !  INPUT    NY           0, GLOBAL BANDWIDTH; 1, LOCAL BANDWIDTH IN Y
    !  INPUT    S(0:N)       HALF POINT INTERPOLATION SEQUENCE
    !  INPUT    TT(M)        OUTPUT GRID
    !  INPUT    M            NUMBER OF POINTS TO ESTIMATE
    !  INPUT    Y(M)         BANDWITH SEQUENCE FOR NY=1, DUMMY FOR NY=0
    !  OUTPUT   Y(M)         ESTIMATED FUNCTION

    !-----------------------------------------------------------------------
    !...
    !...IDENTIFY TRANSFERRED VALIABLES
    REAL(WP), DIMENSION(:), INTENT(IN)                      :: T, TT, X
    INTEGER(I4B), INTENT(IN)                                :: KORD, M, N, NUE, NY
    REAL(WP), INTENT(IN)                                    :: B
    REAL(WP), DIMENSION(0:N), INTENT(IN)                    :: S
    REAL(WP), DIMENSION(:), INTENT(INOUT)                   :: Y
    !...
    !...IDENTIFY LOCAL VARIABLES
    INTEGER(I4B)                                            :: J, K, IORD, INIT, ICALL, I, IBOUN
    INTEGER(I4B)                                            :: JL, JR, JNR, JNL
    REAL(WP)                                                :: DOLD, QQ, Q, XNOR, WID, WR, WIDO
    REAL(WP)                                                :: BMIN, BMAX, BB, S0, SN, WWL, WWR
    REAL(WP), DIMENSION(7)                                  :: A1, A2, C, SW, XF
    REAL(WP), DIMENSION(7,7)                                :: A, A3
    REAL(WP), DIMENSION(7,6)                                :: CM
    !-
    !------ COMPUTE CONSTANTS FOR LATER USE
    S0 = 1.5_WP*T(1)-HALF_W*T(2)
    SN = 1.5_WP*T(N)-HALF_W*T(N-1)
    BMIN = (SN-S0)*0.6_WP/REAL(N, KIND=WP)*REAL((KORD-1), KIND=WP)
    BMAX = (S(N)-S(0))*HALF_W
    IF (KORD == 2) BMIN = BMIN*TENTH_W
    IORD = KORD+1
    CALL COFFI(NUE,KORD,C)
    DO K = 3,IORD
        A1(K)=REAL((2*K-1), KIND=WP)/REAL(K, KIND=WP)
        A2(K)=REAL((1-K),   KIND=WP)/REAL(K, KIND=WP)
    ENDDO
    !-
    INIT  = 0
    ICALL = 0
    DOLD = ZERO_W
    !-
    !------ SMOOTHING LOOP
    DO I = 1,M
        BB = B
        IF (NY == 1)   BB = Y(I)
        IF (BB < BMIN) BB = BMIN
        IF (BB > BMAX) BB = BMAX
        IBOUN=0
    !-
    !------ COMPUTE LEFT BOUNDARY
        IF (TT(I) < S(0)+BB) THEN
            WWL = S(0)
            WWR = S(0)+BB+BB
            WID = WWR-TT(I)
            IBOUN = 1
        ENDIF
    !-
    !------ COMPUTE RIGHT BOUNDARY
        IF (TT(I)+BB > S(N)) THEN
            WWL   = S(N)-(BB+BB)
            WWR   = S(N)
            WID   = TT(I)-WWL
            IBOUN = -1
        ENDIF
    !-
    !------ NO BOUNDARY
        IF (IBOUN == 0) THEN
            WID  = BB
            WWL  = TT(I)-BB
            WWR  = TT(I)+BB
            XNOR = ONE_W
        ENDIF
    !-
    !------ COMPUTE NORMALIZING CONSTANT
        IF (IBOUN /= 0) THEN
            IF (IBOUN ==  1) Q = (TT(I)-S(0))/WID
            IF (IBOUN == -1) Q = (S(N)-TT(I))/WID
            QQ = Q*Q
            XNOR = C(1)*(ONE_W+Q)
            DO K = 3,IORD,2
                Q = Q*QQ
                XNOR = XNOR+C(K)*(ONE_W+Q)
            ENDDO
            IBOUN = 0
        ENDIF
    !-
    !------ INITIALIZATION FOR INIT=0
        IF (INIT == 0) THEN
            DO K = 1,IORD
                SW(K) = ZERO_W
            ENDDO
            JL = 1
            DO J = 1,N
                IF (S(J-1) < WWL) THEN
                    JL = J+1
                ELSE
                    IF (S(J) > WWR) EXIT
                    CALL DREG(SW,A1,A2,IORD,X(J),S(J-1),S(J),TT(I),WID,1)
                ENDIF
            ENDDO
            JR = J-1
            WR = WWR
            INIT = 1
            GOTO 6666
        ELSE
            INIT = INIT+1
        ENDIF
    !-
    !------ COMPARE OLD SUM WITH NEW SMOOTHING INTERVAL TT(I)-B,TT(I)+B
        IF (S(JR-1) >= WWL) THEN
            JNR = JR
            JNL = JL
            IF (S(JR) > WWR) THEN
                DO J = JR,JL,-1
                    CALL DREG(SW,A1,A2,IORD,X(J),S(J-1),S(J),TT(I-1),WIDO,-1)
                    JNR = J-1
                    IF (S(JNR) <= WWR) EXIT
                ENDDO
            ENDIF
            IF (S(JL-1) < WWL) THEN
                DO J = JL,JR
                    CALL DREG(SW,A1,A2,IORD,X(J),S(J-1),S(J),TT(I-1),WIDO,-1)
                    JNL = J+1
                    IF (S(J) >= WWL) EXIT
                ENDDO
            ENDIF
    !-
    !------ UPDATING OF SW
            CALL LREG(SW,A3,IORD,(TT(I)-TT(I-1))/WID,DOLD,WIDO/WID,CM)
            IF (JNR == JR) THEN
                DO J = JR+1,N
                    IF (S(J) > WWR) EXIT
                    CALL DREG(SW,A1,A2,IORD,X(J),S(J-1),S(J),TT(I),WID,1)
                    JNR = J
                ENDDO
            ENDIF
            JR = JNR
            IF (JL == JNL) THEN
                DO J = JL-1,1,-1
                    IF (S(J-1) < WWL) EXIT
                    CALL DREG(SW,A1,A2,IORD,X(J),S(J-1),S(J),TT(I),WID,1)
                    JNL = J
                ENDDO
            ENDIF
            JL = JNL
        ELSE
    !-
    !------ NEW INITIALIZATION OF SW
            SW(1:IORD) = ZERO_W
            DO J = JR,N
                IF (S(J-1) < WWL) THEN
                    JL = J+1
                ELSE
                    IF (S(J) > WWR) EXIT
                    CALL DREG(SW,A1,A2,IORD,X(J),S(J-1),S(J),TT(I),WID,1)
                ENDIF
            ENDDO
            JR = J-1
            WR = WWR
        ENDIF
    !-
    !------ IF BANDWIDTH IS TOO SMALL NO SMOOTHING
    6666 IF (WWL >= S(JR-1) .AND. WWR <= S(JR)) THEN
            Y(I) = X(JR)
            IF (NUE > 0) Y(I) = ZERO_W
        ELSE
    !-
    !------ ADD FIRST AND LAST POINT OF THE SMOOTHING INTERVAL
            DO K = 1,IORD
                XF(K) = SW(K)
            ENDDO
            IF (JL /= 1) CALL DREG(XF,A1,A2,IORD,X(JL-1),WWL,S(JL-1),TT(I),WID,1)
            IF (JR /= N) CALL DREG(XF,A1,A2,IORD,X(JR+1),S(JR),WWR,TT(I),WID,1)
    !-
    !------ NOW THE SUMS ARE BUILT THAT ARE NEEDED TO COMPUTE THE ESTIMATE
            CALL FREG(XF,NUE,KORD,IBOUN,Y(I),C,ICALL,A)
            IF (NUE > 0) Y(I) = Y(I)/(WID**NUE)
            IF (XNOR /= ONE_W) Y(I) = Y(I)/XNOR
        ENDIF
    !-
    !------ NEW INITIALIZATION ?
        IF (JL > JR .OR. WWL > WR .OR. INIT > 100) INIT=0
        WIDO = WID
    ENDDO
    !...
    !...DONE
    RETURN
    END SUBROUTINE KERNFP



    SUBROUTINE DREG(SW,A1,A2,IORD,X,SL,SR,T,B,IFLOP)
    !-----------------------------------------------------------------------
    !    VERSION: MAY, 1995

    !    PURPOSE:

    !    COMPUTES NEW LEGENDRE SUMS (FOR REGRESSION)

    !    PARAMETERS:
    !                 **************   INPUT   *******************

    !     SW(IORD)  :   OLD SUM OF DATA WEIGHTS FOR LEGENDRE POLYNOM.
    !     A1(7)     :   CONSTANTS OF RECURSIVE FORMULA FOR LEGENDRE POL.
    !     A2(7)     :                             "
    !     IORD      :   ORDER OF KERNEL POLYNOMIAL
    !     X         :   DATA POINT
    !     SL        :   LEFT S-VALUE
    !     SR        :   RIGHT S-VALUE
    !     T         :   POINT WHERE THE SMOOTHED VALUE IS TO BE ESTIMATED
    !     B         :   BANDWIDTH
    !     IFLOP     :   1: ADDITION, ELSE SUBTRACTION


    !                 **************   OUTPUT   *******************

    !     SW(IORD)  :   NEW SUM OF DATA WEIGHTS FOR LEGENDRE POLYNOM.

    !-----------------------------------------------------------------------
    !...
    !...IDENTIFY TRANSFERRED VALIABLES
    INTEGER(I4B), INTENT(IN)                                :: IFLOP, IORD
    REAL(WP), INTENT(IN)                                    :: X, SL, SR, T, B
    REAL(WP), DIMENSION(7), INTENT(OUT)                     :: SW
    REAL(WP), DIMENSION(7), INTENT(IN)                      :: A1, A2
    !...
    !...IDENTIFY LOCAL VARIABLES
    INTEGER(I4B)                                            :: K
    REAL(WP), DIMENSION(7,2)                                :: P
    !-
    !------  COMPUTE LEGENDRE POLYNOMIALS
    P(1,1) = (T-SL)/B
    P(1,2) = (T-SR)/B
    P(2,1) = 1.5_WP*P(1,1)*P(1,1)-HALF_W
    P(2,2) = 1.5_WP*P(1,2)*P(1,2)-HALF_W
    DO K = 3,IORD
        P(K,1) = A1(K)*P(K-1,1)*P(1,1)+A2(K)*P(K-2,1)
        P(K,2) = A1(K)*P(K-1,2)*P(1,2)+A2(K)*P(K-2,2)
    ENDDO
    !-
    !------  COMPUTE NEW LEGENDRE SUMS
    IF (IFLOP == 1) THEN
        DO K = 1,IORD
            SW(K) = SW(K)+(P(K,1)-P(K,2))*X
        ENDDO
    ELSE
        DO K = 1,IORD
            SW(K) = SW(K)+(P(K,2)-P(K,1))*X
        ENDDO
    ENDIF
    !...
    !...DONE
    RETURN
    END SUBROUTINE DREG



    SUBROUTINE LREG(SW,A3,IORD,D,DOLD,Q,C)
    !------------------------------------------------------------------
    !    VERSION: MAY, 1995

    !    PURPOSE:

    !    UPDATE OF SW-SEQUENCE ACCORDING TO NEW BANDWIDTH AND NEW DATA
    !    (VERSION FOR REGRESSION)

    !    PARAMETERS :
    !                       **************   INPUT   *******************

    !            SW(IORD)  :  SUM OF DATA WEIGHTS FOR LEGENDRE POLYNOM.
    !            IORD      :  ORDER OF KERNEL POLYNOMIAL
    !            D         :  DIST. TO THE NEXT POINT DIVIDED BY BANDW.
    !            DOLD      :  D       PREVIOUS STEP
    !            Q         :  NEW BANDWIDTH DIVIDED BY OLD BANDWIDTH
    !                       **************    WORK   *******************

    !            A3(7,7)   :  MATRIX (P*Q*P)**(-1)
    !            C(7,6)    :  MATRIX OF COEFFICIENTS
    !                       **************   OUTPUT   ******************

    !            SW(IORD)  :  UPDATED VERSION OF SW

    !---------------------------------------------------------------------
    !...
    !...IDENTIFY TRANSFERRED VALIABLES
    INTEGER(I4B), INTENT(IN)                                :: IORD
    REAL(WP), INTENT(IN)                                    :: D, Q
    REAL(WP), INTENT(INOUT)                                 :: DOLD
    REAL(WP), DIMENSION(7), INTENT(INOUT)                   :: SW
    REAL(WP), DIMENSION(7,7), INTENT(OUT)                   :: A3
    REAL(WP), DIMENSION(7,6), INTENT(OUT)                   :: C
    !...
    !...IDENTIFY LOCAL VARIABLES
    INTEGER(I4B)                                            :: K, I, L
    REAL(WP)                                                :: DD, WW, QQ, XX

    !-
    !- BUILD UP MATRIX
    IF (DOLD /= D .OR. DOLD == 0) THEN
        DOLD = D
        DD = D*D
    !-
        IF (IORD == 7) THEN
            C(7,6) = 13.0_WP*D
            C(7,5) = 71.5_WP*DD
            C(7,4) = (214.5_WP*DD+NINE_W)*D
            C(7,3) = (375.375_WP*DD+77.0_WP)*DD
            C(7,2) = ((375.375_WP*DD+247.5_WP)*DD+FIVE_W)*D
            C(7,1) = ((187.6875_WP*DD+346.5_WP)*DD+40.5_WP)*DD
        ENDIF
    !-
        IF (IORD >= 6) THEN
            C(6,5) = 11.0_WP*D
            C(6,4) = 49.5_WP*DD
            C(6,3) = (115.5_WP*DD+SEVEN_W)*D
            C(6,2) = (144.375_WP*DD+45.0_WP)*DD
            C(6,1) = ((86.625_WP*DD+94.5_WP)*DD+THREE_W)*D
        ENDIF
    !-
        IF (IORD >= 5) THEN
            C(5,4) = NINE_W*D
            C(5,3) = 31.5_WP*DD
            C(5,2) = (52.5_WP*DD+FIVE_W)*D
            C(5,1) = (39.375_WP*DD+21.0_WP)*DD
        ENDIF
    !-
        IF (IORD >= 4) THEN
            C(4,3) = SEVEN_W*D
            C(4,2) = 17.5_WP*DD
            C(4,1) = (17.5_WP*DD+THREE_W)*D
        ENDIF
    !-
        IF (IORD >= 3) THEN
            C(3,2) = FIVE_W*D
            C(3,1) = 7.5_WP*DD
        ENDIF
    !-
        C(2,1) = THREE_W*D
    ENDIF
    IF (Q < 0.9999_WP .OR. Q > 1.0001_WP) THEN
    !-
    !------- BUILT UP MATRIX A3=P*Q*P**-1
        A3(1,1) = Q
        DO K = 2,IORD
            A3(K,K) = A3(K-1,K-1)*Q
        ENDDO
        WW = Q*Q-ONE_W
        DO K = 1,IORD-2
            WW = WW*Q
            A3(K+2,K) = (K+HALF_W)*WW
        ENDDO
    !-
        IF (IORD >= 5) THEN
            QQ = A3(2,2)
            A3(5,1) = Q*(1.875_WP+QQ*(-5.25_WP+QQ*3.375_WP))
        ENDIF
        IF (IORD >= 6) A3(6,2) = QQ*(4.375_WP+QQ*(-11.25_WP+QQ*6.875_WP))
        IF (IORD == 7) THEN
            A3(7,1) = Q*(-2.1875_WP+QQ*(11.8125_WP+QQ*(-18.5625_WP+QQ*8.9375_WP)))
            A3(7,3) = Q*QQ*(7.875_WP+QQ*(-19.25_WP+QQ*11.375_WP))
        ENDIF
    !-
    !------- COMPUTE A*C AND NEW LEGENDRE SUMS
        DO I = IORD,2,-1
            XX = ZERO_W
            DO K = 1,I
                WW = ZERO_W
                DO L = K,I-1,2
                    WW = WW+A3(L,K)*C(I,L)
                ENDDO
                IF (MOD(I-K,2) == 0) WW = WW+A3(I,K)
                XX = XX+WW*SW(K)
            ENDDO
            SW(I) = XX
        ENDDO
        SW(1) = A3(1,1)*SW(1)
    ELSE
        DO I = IORD,2,-1
            DO K = 1,I-1
                SW(I) = SW(I)+C(I,K)*SW(K)
            ENDDO
        ENDDO
    ENDIF
    !...
    !...DONE
    RETURN
    END SUBROUTINE LREG



    SUBROUTINE FREG(SW,NUE,KORD,IBOUN,Y,C,ICALL,A)
    !------------------------------------------------------------------
    !    SHORT-VERSION: MAY, 1995

    !    PURPOSE:

    !    FINAL COMPUTATION OF A SMOOTHED VALUE VIA LEGENDRE POLYNOMIALS

    !    PARAMETERS :
    !                       **************   INPUT   *******************

    !            SW(KORD+1):  SUM OF DATA WEIGHTS FOR LEGENDRE POLYNOM.
    !            NUE       :  ORDER OF DERIVATIVE
    !            KORD      :  ORDER OF KERNEL
    !            IBOUN     :  0: INTERIOR KERNEL, ELSE BOUNDARY KERNEL
    !            C(KORD+1) :  SEQUENCE OF POLYN. COEFF. FOR BOUND. KERNEL
    !            ICALL     :  PARAMETER USED TO INITIALISE COMPUTATION
    !                      :   OF A MATRIX
    !                       **************    WORK    ******************

    !            A(7,7)    :  MATRIX OF COEFFICIENTS
    !                       **************   OUTPUT   ******************

    !            Y          :  COMPUTED ESTIMATE

    !--------------------------------------------------------------------
    !...
    !...IDENTIFY TRANSFERRED VALIABLES
    INTEGER(I4B), INTENT(IN)                                :: IBOUN, KORD, NUE
    INTEGER(I4B), INTENT(INOUT)                             :: ICALL
    REAL(WP), INTENT(OUT)                                   :: Y
    REAL(WP),DIMENSION(7), INTENT(IN)                       :: C, SW
    REAL(WP),DIMENSION(7,7), INTENT(OUT)                    :: A
    !...
    !...IDENTIFY LOCAL VARIABLES
    INTEGER(I4B)                                            :: I, J
    REAL(WP)                                                :: WW
    !-
    !------- DEFINITION OF LEGENDRE COEFFICIENTS FOR BOUNDARY
    IF (ICALL == 0 .AND. IBOUN /= 0) THEN
        A(2,2) = TWO_W/THREE_W
        A(1,3) = 0.6_WP
        A(3,3) = 0.4_WP
        A(2,4) = FOUR_W/SEVEN_W
        A(4,4) = EIGHT_W/35.0_WP
        A(1,5) = 27.0_WP/63.0_WP
        A(3,5) = 28.0_WP/63.0_WP
        A(5,5) = EIGHT_W/63.0_WP
        A(2,6) = 110.0_WP/231.0_WP
        A(4,6) = 72.0_WP/231.0_WP
        A(6,6) = 16.0_WP/231.0_WP
        A(1,7) = 143.0_WP/429.0_WP
        A(3,7) = 182.0_WP/429.0_WP
        A(5,7) = 88.0_WP/429.0_WP
        A(7,7) = 16.0_WP/429.0_WP
        ICALL = 1
    ENDIF
    IF (IBOUN /= 0) THEN
    !-
    !------- COMPUTATION OF THE SMOOTHED VALUE AT BOUNDARY
        Y = C(1)*SW(1)+C(2)*A(2,2)*SW(2)
        DO J = 3,KORD+1
            WW = A(J,J)*SW(J)
            DO I = J-2,1,-2
                WW = WW+A(I,J)*SW(I)
            ENDDO
            Y = Y+C(J)*WW
        ENDDO
    ELSE
    !-
    !------- COMPUTATION OF THE SMOOTHED VALUE AT INTERIOR
        IF (NUE == 0) THEN
            IF (KORD == 2) Y = -TENTH_W*SW(3)+0.6_WP*SW(1)
            IF (KORD == 4) Y = (SW(5)-FOUR_W*SW(3)+NINE_W*SW(1))/TWELVE_W
            IF (KORD == 6) Y = -7.2115379E-02_WP*SW(7)+0.25961537_WP*SW(5)-0.4375_WP*SW(3)+0.75_WP*SW(1)
        ENDIF
        IF (NUE == 1) THEN
            IF (KORD == 3) Y = (THREE_W*SW(4)-TEN_W*SW(2))/14.0_WP
            IF (KORD == 5) Y = (-15.0_WP*SW(6)+48.0_WP*SW(4)-55.0_WP*SW(2))/44.0_WP
        ENDIF
        IF (NUE == 2) THEN
            IF (KORD == 4) Y = (-HALF_W*SW(5)+14.0_WP*SW(3)-NINE_W*SW(1))/SIX_W
            IF (KORD == 6) Y = 2.01923_WP*SW(7)-5.76923_WP*SW(5)+5.25_WP*SW(3)-1.5_WP*SW(1)
        ENDIF
        IF (NUE == 3) Y = 4.772727_WP*SW(6)-12.272727_WP*SW(4)+7.5_WP*SW(2)
        IF (NUE == 4) Y = -36.34615_WP*SW(7)+88.84615_WP*SW(5)-52.5_WP*SW(3)
    ENDIF
    !...
    !...DONE
    RETURN
    END SUBROUTINE FREG



    SUBROUTINE KERNCL(T,X,N,B,NUE,KORD,NY,S,TT,M,Y)
    !-----------------------------------------------------------------------
    !       SHORT-VERSION JANUARY 1995

    !       KERNEL SMOOTHING, CONVENTIONAL ALGORITHM,GENERAL
    !       DESIGN, LOCAL BANDWIDTH ALLOWED

    !  PARAMETERS :

    !  INPUT    T(N)         INPUT GRID
    !  INPUT    X(N)         DATA, GIVEN ON T(N)
    !  INPUT    N            LENGTH OF X
    !  INPUT    B            ONE SIDED BANDWIDTH (FOR NY=1 MEAN BANDWIDTH)
    !  INPUT    NUE          ORDER OF DERIVATIVE (0-4)
    !  INPUT    KORD         ORDER OF KERNEL (<=6)
    !  INPUT    S(0:N)       HALF POINT INTERPOLATION SEQUENCE
    !  INPUT    NY           0: GLOBAL, 1: LOCAL BANDWIDTH INPUTED IN Y
    !  INPUT    TT(M)        OUTPUT GRID
    !  INPUT    M            NUMBER OF POINTS TO ESTIMATE
    !  INPUT    Y(M)         BANDWITH SEQUENCE FOR NY=1, DUMMY FOR NY=0
    !  OUTPUT   Y(M)         ESTIMATED REGRESSION FUNCTION

    !-----------------------------------------------------------------------
    !...
    !...IDENTIFY TRANSFERRED VALIABLES
    INTEGER(I4B), INTENT(IN)                                :: KORD, M, N, NUE, NY
    REAL(WP), INTENT(IN)                                    :: B
    REAL(WP), DIMENSION(:), INTENT(IN)                      :: T, TT, X
    REAL(WP), DIMENSION(0:N), INTENT(IN)                    :: S
    REAL(WP), DIMENSION(:), INTENT(INOUT)                   :: Y
    !...
    !...IDENTIFY LOCAL VARIABLES
    REAL(WP), DIMENSION(7)                                  :: C, C1
    INTEGER(I4B)                                            :: IST, I, IBOUN, IORD
    REAL(WP)                                                :: BB, BMAX, WID, S0, S1, SN, BMIN
    !-
    !------  COMPUTE KERNEL COEFFICIENTS FOR INTERIOR AND SOME CONSTANTS
    CALL COFFI(NUE,KORD,C)
    IORD = KORD+1
    BB = B
    S0 = 1.5_WP*T(1)-HALF_W*T(2)
    SN = 1.5_WP*T(N)-HALF_W*T(N-1)
    BMIN = (SN-S0)*0.6_WP/REAL(N, KIND=WP)*REAL((KORD-1), KIND=WP)
    BMAX = (S(N)-S(0))*HALF_W
    IF (KORD == 2) BMIN = TENTH_W*BMIN
    IST = 1
    !-
    !-------  LOOP OVER OUTPUT GRID
    DO I = 1,M
        IF (NY /= 0) BB = Y(I)
        IF (BB > BMAX) BB = BMAX
        IF (BB < BMIN) BB = BMIN
        WID = BB
        S1 = TT(I)-BB
        IBOUN = 0
    !-
    !-------  COMPUTE LEFT BOUNDARY KERNEL
        IF (S1 < S(0)) THEN
            S1 = S(0)
            WID = BB+BB+S(0)-TT(I)
            CALL COFFB(NUE,KORD,(TT(I)-S(0))/WID,1,C1)
            IBOUN = 1
        ENDIF
    !-
    !-------  COMPUTE RIGHT BOUNDARY KERNEL
        IF (TT(I)+BB > S(N)) THEN
            S1 = S(N)-(BB+BB)
            WID = TT(I)-S1
            CALL COFFB(NUE,KORD,(S(N)-TT(I))/WID,-1,C1)
            IBOUN = -1
        ENDIF
    !-
    !------  SEARCH FIRST S-POINT OF SMOOTHING INTERVAL
    2   IF (S(IST) <= S1) THEN
            IST = IST+1
            GOTO 2
        ENDIF
    3   IF (S(IST-1) > S1) THEN
            IST = IST-1
            GOTO 3
        ENDIF
    !-
    !-------  IF BANDWIDTH IS TOO SMALL NO SMOOTHING
        IF (S(IST) >= TT(I)+WID .OR. IST == N) THEN
            Y(I) = X(IST)
            IF (NUE > 0) Y(I) = ZERO_W
        ELSE
    !-
    !-----  COMPUTE SMOOTHED DATA AT TT(I)
            IF (IBOUN /= 0) THEN
                CALL SMO(S,X,N,TT(I),WID,NUE,IORD,IBOUN,IST,S1,C1,Y(I))
            ELSE
                CALL SMO(S,X,N,TT(I),WID,NUE,IORD,IBOUN,IST,S1,C,Y(I))
            ENDIF
        ENDIF
    ENDDO
    !...
    !...DONE
    RETURN
    END SUBROUTINE KERNCL



    SUBROUTINE SMO(S,X,N,TAU,WID,NUE,IORD,IBOUN,IST,S1,C,Y)
    !-----------------------------------------------------------------------
    !       SHORT-VERSION JANUARY 1995

    !       PERFORMS ONE SMOOTHING STEP

    !  PARAMETERS :

    !  INPUT    S(0:N)       HALF POINT INTERPOLATION SEQUENCE
    !  INPUT    X(N)         DATA
    !  INPUT    N            LENGTH OF X
    !  INPUT    TAU          POINT WHERE FUNCTION IS ESTIMATED
    !  INPUT    WID          ONE SIDED BANDWIDTH
    !  INPUT    NUE          ORDER OF DERIVATIVE (0-4)
    !  INPUT    IORD          ORDER OF KERNEL POLYNOMIAL
    !  INPUT    IBOUN         TYPE OF BOUNDARY
    !  INPUT    IST          INDEX OF FIRST POINT OF SMOOTHING INTERVAL
    !  INPUT    S1           LEFT BOUNDARY OF SMOOTHING INTERVAL
    !  INPUT    C(7)         KERNEL COEFFICIENTS
    !  OUTPUT   Y            SMOOTHED VALUE AT TAU

    !  WORK     WO(7)        WORK ARRAY

    !-----------------------------------------------------------------------
    !...
    !...IDENTIFY TRANSFERRED VALIABLES
    INTEGER(I4B), INTENT(IN)                                :: IBOUN, IORD, IST, N, NUE
    REAL(WP), INTENT(IN)                                    :: S1, TAU, WID
    REAL(WP), INTENT(OUT)                                   :: Y
    REAL(WP), DIMENSION(0:), INTENT(IN)                     :: S
    REAL(WP), DIMENSION(:), INTENT(IN)                      :: X
    REAL(WP), DIMENSION(7), INTENT(IN)                      :: C
    !...
    !...IDENTIFY LOCAL VARIABLES
    INTEGER(I4B)                                            :: JEND, IBEG, INCR, I, J
    REAL(WP)                                                :: YY, YYY, W, WIDNUE
    REAL(WP), DIMENSION(7)                                  :: WO
    !-
    Y = ZERO_W
    JEND = 0
    IBEG = 2
    IF (IBOUN /= 0 .OR. (NUE /= 1 .AND. NUE /= 3)) IBEG = 1
    INCR=2
    IF (IBOUN /= 0) INCR = 1
    !-
    !------  COMPUTE INITIAL KERNEL VALUES
    IF (IBOUN > 0) THEN
        YY = (TAU-S1)/WID
        WO(IBEG)=YY
        DO I = IBEG,IORD-INCR,INCR
            WO(I+INCR) = WO(I)*YY
        ENDDO
    ELSE
        DO I = IBEG,IORD,INCR
            WO(I) = ONE_W
        ENDDO
    ENDIF
    !-
    !------  LOOP OVER SMOOTHING INTERVAL
    DO J = IST,N
        YY = (TAU-S(J))/WID
        IF (YY < -ONE_W) THEN
            YY = -ONE_W
            JEND = 1
        ENDIF
        YYY = YY
        IF (IBOUN == 0) THEN
            YY=YY*YY
            IF (NUE == 1 .OR. NUE == 3) YYY=YY
        ENDIF
    !-
    !------  LOOP FOR COMPUTING WEIGHTS
        W = ZERO_W
        DO I = IBEG,IORD,INCR
            W = W+C(I)*(WO(I)-YYY)
            WO(I) = YYY
            YYY = YYY*YY
        ENDDO
        Y = Y+W*X(J)
        IF (JEND == 1) EXIT
    ENDDO
    !-
    !-------  NORMALIZING FOR NUE>0
    IF (NUE > 0) THEN
        WIDNUE = WID**NUE
        Y = Y/WIDNUE
    ENDIF
    !...
    !...DONE
    RETURN
    END SUBROUTINE SMO



    SUBROUTINE KERNCP(T,X,N,B,NUE,KORD,NY,S,TT,M,Y)
    !-----------------------------------------------------------------------
    !       SHORT-VERSION JANUARY 1997

    !       KERNEL SMOOTHING, CONVENTIONAL ALGORITHM,GENERAL
    !       DESIGN, LOCAL BANDWIDTH ALLOWED, WITHOUT BOUNDARY KERNELS,
    !       JUST NORMALIZING

    !  PARAMETERS :

    !  INPUT    T(N)         INPUT GRID
    !  INPUT    X(N)         DATA, GIVEN ON T(N)
    !  INPUT    N            LENGTH OF X
    !  INPUT    B            ONE SIDED BANDWIDTH (FOR NY=1 MEAN BANDWIDTH)
    !  INPUT    NUE          ORDER OF DERIVATIVE (0-4)
    !  INPUT    KORD         ORDER OF KERNEL (<=6)
    !  INPUT    S(0:N)       HALF POINT INTERPOLATION SEQUENCE
    !  INPUT    NY           0: GLOBAL, 1: LOCAL BANDWIDTH INPUTED IN Y
    !  INPUT    TT(M)        OUTPUT GRID
    !  INPUT    M            NUMBER OF POINTS TO ESTIMATE
    !  INPUT    Y(M)         BANDWITH SEQUENCE FOR NY=1, DUMMY FOR NY=0
    !  OUTPUT   Y(M)         ESTIMATED REGRESSION FUNCTION

    !-----------------------------------------------------------------------
    !...
    !...IDENTIFY TRANSFERRED VALIABLES
    INTEGER(I4B), INTENT(IN)                                :: KORD, M, N, NUE, NY
    REAL(WP), INTENT(IN)                                    :: B
    REAL(WP), DIMENSION(:), INTENT(IN)                      :: T, TT, X
    REAL(WP), DIMENSION(0:N), INTENT(IN)                    :: S
    REAL(WP), DIMENSION(:), INTENT(INOUT)                   :: Y
    !...
    !...IDENTIFY LOCAL VARIABLES
    INTEGER(I4B)                                            :: IST, I, IBOUN, IORD
    REAL(WP)                                                :: BB, BMAX, WID, S0, S1, SN, BMIN
    REAL(WP), DIMENSION(7)                                  :: C, C1
    !-
    !------  COMPUTE KERNEL COEFFICIENTS FOR INTERIOR AND SOME CONSTANTS
    CALL COFFI(NUE,KORD,C)
    IORD = KORD+1
    BB = B
    S0 = 1.5_WP*T(1)-HALF_W*T(2)
    SN = 1.5_WP*T(N)-HALF_W*T(N-1)
    BMIN = (SN-S0)*0.6_WP/REAL(N, KIND=WP)*REAL((KORD-1), KIND=WP)
    BMAX = (S(N)-S(0))*HALF_W
    IF (KORD == 2) BMIN = TENTH_W*BMIN
    IST=1
    !-
    !-------  LOOP OVER OUTPUT GRID
    DO I = 1,M
        IF (NY /= 0)   BB = Y(I)
        IF (BB > BMAX) BB = BMAX
        IF (BB < BMIN) BB = BMIN
        WID = BB
        S1 = TT(I)-BB
        IBOUN = 0
    !-
    !-------  COMPUTE LEFT BOUNDARY KERNEL
        IF (S1 < S(0)) THEN
            S1 = S(0)
            WID = BB+BB+S(0)-TT(I)
            CALL COFFB(NUE,KORD,(TT(I)-S(0))/WID,1,C1)
            IBOUN = 1
        ENDIF
    !-
    !-------  COMPUTE RIGHT BOUNDARY KERNEL
        IF (TT(I)+BB > S(N)) THEN
            S1 = S(N)-(BB+BB)
            WID = TT(I)-S1
            IBOUN = -1
        ENDIF
    !-
    !------  SEARCH FIRST S-POINT OF SMOOTHING INTERVAL
    2   IF (S(IST) <= S1) THEN
            IST = IST+1
            GOTO 2
        ENDIF
    3   IF (S(IST-1) > S1) THEN
            IST = IST-1
            GOTO 3
        ENDIF
    !-
    !-------  IF BANDWIDTH IS TOO SMALL NO SMOOTHING
        IF (S(IST) >= TT(I)+WID .OR. IST == N) THEN
            Y(I) = X(IST)
            IF (NUE > 0) Y(I) = ZERO_W
        ELSE
    !-
    !-----  COMPUTE SMOOTHED DATA AT TT(I)
            CALL SMOP(S,X,N,TT(I),WID,NUE,IORD,IBOUN,IST,S1,C,Y(I))
        ENDIF
    ENDDO
    !...
    !...DONE
    RETURN
    END SUBROUTINE KERNCP



    SUBROUTINE SMOP(S,X,N,TAU,WID,NUE,IORD,IBOUN,IST,S1,C,Y)
    !-----------------------------------------------------------------------
    !       SHORT-VERSION JANUARY 1997

    !       PERFORMS ONE SMOOTHING STEP

    !  PARAMETERS :

    !  INPUT    S(0:N)       HALF POINT INTERPOLATION SEQUENCE
    !  INPUT    X(N)         DATA
    !  INPUT    N            LENGTH OF X
    !  INPUT    TAU          POINT WHERE FUNCTION IS ESTIMATED
    !  INPUT    WID          ONE SIDED BANDWIDTH
    !  INPUT    NUE          ORDER OF DERIVATIVE (0-4)
    !  INPUT    IORD          ORDER OF KERNEL POLYNOMIAL
    !  INPUT    IBOUN         TYPE OF BOUNDARY
    !  INPUT    IST          INDEX OF FIRST POINT OF SMOOTHING INTERVAL
    !  INPUT    S1           LEFT BOUNDARY OF SMOOTHING INTERVAL
    !  INPUT    C(7)         KERNEL COEFFICIENTS
    !  OUTPUT   Y            SMOOTHED VALUE AT TAU

    !  WORK     WO(7)        WORK ARRAY

    !-----------------------------------------------------------------------
    !...
    !...IDENTIFY TRANSFERRED VALIABLES
    INTEGER(I4B), INTENT(IN)                                :: IBOUN, IORD, IST, N, NUE
    REAL(WP), INTENT(IN)                                    :: TAU, WID, S1
    REAL(WP), INTENT(OUT)                                   :: Y
    REAL(WP), DIMENSION(0:), INTENT(IN)                     :: S
    REAL(WP), DIMENSION(:), INTENT(IN)                      :: X
    REAL(WP), DIMENSION(7), INTENT(IN)                      :: C
    !...
    !...IDENTIFY LOCAL VARIABLES
    INTEGER(I4B)                                            :: JEND, IBEG, INCR, I, J
    REAL(WP)                                                :: YY, YYY, W, WIDNUE, WW
    REAL(WP), DIMENSION(7)                                  :: WO
    !-
    Y  = ZERO_W
    WW = ZERO_W
    JEND = 0
    IBEG = 2
    IF (NUE /= 1 .AND. NUE /= 3) IBEG = 1
    INCR = 2
    !-
    !------  COMPUTE INITIAL KERNEL VALUES
    IF (IBOUN > 0) THEN
        YY = (TAU-S1)/WID
        WO(IBEG) = YY
        YY = YY*YY
        IF (NUE == 1 .OR. NUE == 3) WO(IBEG) = YY
        DO I = IBEG,IORD-INCR,INCR
            WO(I+INCR) = WO(I)*YY
        ENDDO
    ELSE
        DO I = IBEG,IORD,INCR
            WO(I) = ONE_W
        ENDDO
    ENDIF
    !-
    !------  LOOP OVER SMOOTHING INTERVAL
    DO J = IST,N
        YY = (TAU-S(J))/WID
        IF (YY < -ONE_W) THEN
            YY = -ONE_W
            JEND = 1
        ENDIF
        YYY = YY
        YY  = YY*YY
        IF (NUE == 1 .OR. NUE == 3) YYY = YY
    !-
    !------  LOOP FOR COMPUTING WEIGHTS
        W = ZERO_W
        DO I = IBEG,IORD,INCR
            W = W+C(I)*(WO(I)-YYY)
            WO(I) = YYY
            YYY = YYY*YY
        ENDDO
        Y = Y+W*X(J)
        WW = WW+W
        IF (JEND == 1) EXIT
    ENDDO
    !-
    !-------  NORMALIZING FOR NUE>0
    IF (WW /= 0) Y = Y/WW
    IF (NUE > 0) THEN
        WIDNUE = WID**NUE
        Y = Y/WIDNUE
    ENDIF
    !...
    !...DONE
    RETURN
    END SUBROUTINE SMOP



    SUBROUTINE COFFI(NUE,KORD,C)
    !-----------------------------------------------------------------------
    !       SHORT-VERSION: JANUARY 1995

    !       PURPOSE:

    !       DEFINES POLYNOMIAL KERNEL COEFFICIENTS FOR INTERIOR.

    !  PARAMETERS:

    !  INPUT  NUE        ORDER OF DERIVATIVE (0-4)
    !  INPUT  KORD       ORDER OF KERNEL (NUE+I, I=2,4,6;  KORD<=6)
    !  OUTPUT C(7)       POLYNOMIAL KERNEL COEFFICIENTS

    !-----------------------------------------------------------------------
    !...
    !...IDENTIFY TRANSFERRED VALIABLES
    INTEGER(I4B), INTENT(IN)                                :: KORD, NUE
    REAL(WP), DIMENSION(7), INTENT(OUT)                     :: C

    !-
    C(1:7) = ZERO_W
    IF (NUE == 0 .AND. KORD == 2) THEN
        C(1) = 0.75_WP
        C(3) = -QUART_W
    ENDIF

    IF (NUE == 0 .AND. KORD == 4) THEN
        C(1) = 1.40625_WP
        C(3) = -1.5625_WP
        C(5) = 0.65625_WP
    ENDIF

    IF (NUE == 0 .AND. KORD == 6) THEN
        C(1) = 2.05078125_WP
        C(3) = -4.78515625_WP
        C(5) = 5.16796875_WP
        C(7) = -1.93359375_WP
    ENDIF

    IF (NUE == 1 .AND. KORD == 3) THEN
        C(2) = -1.875_WP
        C(4) = 0.9375_WP
    ENDIF

    IF (NUE == 1 .AND. KORD == 5) THEN
        C(2) = -8.203125_WP
        C(4) = 11.484375_WP
        C(6) = -4.921875_WP
    ENDIF

    IF (NUE == 2 .AND. KORD == 4) THEN
        C(1) = -6.5625_WP
        C(3) = 13.125_WP
        C(5) = -6.5625_WP
    ENDIF

    IF (NUE == 2 .AND. KORD == 6) THEN
        C(1) = -24.609375_WP
        C(3) = 103.359375_WP
        C(5) = -132.890625_WP
        C(7) = 54.140625_WP
    ENDIF

    IF (NUE == 3 .AND. KORD == 5) THEN
        C(2) = 88.59375_WP
        C(4) = -147.65625_WP
        C(6) = 68.90625_WP
    ENDIF

    IF (NUE == 4 .AND. KORD == 6) THEN
        C(1) = 324.84375_WP
        C(3) = -1624.21875_WP
        C(5) = 2273.90625_WP
        C(7) = -974.53125_WP
    ENDIF
    !...
    !...DONE
    RETURN
    END SUBROUTINE COFFI


    SUBROUTINE COFFB(NUE,KORD,Q,IBOUN,C)
    !-----------------------------------------------------------------------
    !       SHORT-VERSION: JANUARY 1995

    !       PURPOSE:

    !       COMPUTES COEFFICIENTS OF POLYNOMIAL BOUNDARY KERNELS,
    !       FOLLOWING GASSER + MUELLER PREPRINT 38 SFB 123 HEIDELBERG
    !       AND UNPUBLISHED RESULTS

    !  PARAMETERS:

    !  INPUT  NUE        ORDER OF DERIVATIVE (0-4)
    !  INPUT  KORD       ORDER OF KERNEL (NUE+I, I=2,4,6;  KORD<=6)
    !  INPUT  Q          PERCENTAGE OF WID AT BOUNDARY
    !  INPUT  IBOUN      < 0 RIGHT BOUNDARY OF DATA
    !                    > 0 LEFT BOUNDARY OF DATA
    !  OUTPUT C(7)       POLYNOMIAL KERNEL COEFFICIENTS

    !-----------------------------------------------------------------------
    !...
    !...IDENTIFY TRANSFERRED VALIABLES
    INTEGER(I4B), INTENT(IN)                                :: IBOUN, KORD, NUE
    REAL(WP), INTENT(IN)                                    :: Q
    REAL(WP), DIMENSION(7), INTENT(OUT)                     :: C
    !...
    !...IDENTIFY LOCAL VARIABLES
    INTEGER(I4B)                                            :: I, J
    REAL(WP)                                                :: D, P, P1, P3, P6, P12

    C(1:7) = ZERO_W
    P  = -Q
    P1 = ONE_W+Q
    P3 = P1*P1*P1

    IF (NUE == 0 .AND. KORD == 2) THEN
        D = ONE_W/(P3*P1)
        C(1) = (SIX_W+P*(TWELVE_W+P*18.0_WP))*D
        C(2) = NINE_W*(ONE_W+P)*(ONE_W+P)*D
        C(3) = (FOUR_W+P*EIGHT_W)*D
    ENDIF

    IF (NUE == 0 .AND. KORD == 4) THEN
        D = P1/(P3*P3*P3)
        P12  = (ONE_W+P)*(ONE_W+P)*D
        C(1) = 20.0_WP*(ONE_W+P*(TWELVE_W+P*(78.0_WP+P*(164.0_WP+P*(165.0_WP+P*(60.0_WP+P*TEN_W))))))*D
        C(2) = HUND_W*(ONE_W+P*(FIVE_W+P))**2*P12
        C(3) = 200.0_WP*(ONE_W+P*(TWELVE_W+P*(33.0_WP+P*(36.0_WP+P*(14.0_WP+P+P)))))*D
        C(4) = 175.0_WP*(ONE_W+P*(TEN_W+P*THREE_W))*P12
        C(5) = 56.0_WP*(ONE_W+P*(TWELVE_W+P*(18.0_WP+P*FOUR_W)))*D
    ENDIF

    IF (NUE == 0 .AND. KORD == 6) THEN
         P6  = P3*P3
          D  = ONE_W/(P6*P6)
        P12  = (ONE_W+P)*(ONE_W+P)*D
        C(1) = 42.0_WP*(ONE_W+P*(30.0_WP+P*(465.0_WP+P*(3000.0_WP+P*(10050.0_WP+P*(17772.0_WP+P  &
                      *(17430.0_WP+P*(9240.0_WP+P*(2625.0_WP+P*(350.0_WP+P*21.0_WP))))))))))*D
        C(2) = 441.0_WP*(ONE_W+P*(14.0_WP+P*(36.0_WP+P*(14.0_WP+P))))**2*P12
        C(3) = 1960.0_WP*(ONE_W+P*(30.0_WP+P*(255.0_WP+P*(984.0_WP+P*(1902.0_WP+P*(1956.0_WP+P  &
                        *(1065.0_WP+P*(300.0_WP+P*(39.0_WP+P+P)))))))))*D
        C(4) = 4410.0_WP*(ONE_W+P*(28.0_WP+P*(156.0_WP+P*(308.0_WP+P*(188.0_WP+P*(42.0_WP+P*THREE_W)))))) *P12
        C(5) = 5292.0_WP*(ONE_W+P*(30.0_WP+P*(185.0_WP+P*(440.0_WP+P*(485.0_WP+P*(250.0_WP+P*(57.0_WP+P*FOUR_W)))))))*D
        C(6) = 3234.0_WP*(ONE_W+P*(28.0_WP+P*(108.0_WP+P*(56.0_WP+P*FIVE_W))))*P12
        C(7) = 792.0_WP* (ONE_W+P*(30.0_WP+P*(150.0_WP+P*(200.0_WP+P*(75.0_WP+P*SIX_W)))))*D
    ENDIF

    IF (NUE == 1 .AND. KORD == 3) THEN
        D    = -ONE_W/(P3*P3)
        P12  = (ONE_W+P)*(ONE_W+P)*D
        C(1) = (60.0_WP+P*240.0_WP)*P12
        C(2) = 120.0_WP*(TWO_W+P*(SIX_W+P*(SIX_W+P)))*D
        C(3) = 300.0_WP*P12
        C(4) = (120.0_WP+P*180.0_WP)*D
    ENDIF

    IF (NUE == 1 .AND. KORD == 5) THEN
        D    = -ONE_W/(P3*P3*P3*P1)
        P12  = (ONE_W+P)*(ONE_W+P)*D
        C(1) = 420.0_WP*(ONE_W+P*(18.0_WP+P*(98.0_WP+P*(176.0_WP+P*(75.0_WP+P*TEN_W)))))*P12
        C(2) = 2100.0_WP*(TWO_W+P*(25.0_WP+P*(120.0_WP+P*(245.0_WP+P*(238.0_WP+P*(105.0_WP+P*(20.0_WP+P)))))))*D
        C(3) = 14700.0_WP*(ONE_W+P*(FOUR_W+P))**2*P12
        C(4) = 5880.0_WP*(FOUR_W+P*(35.0_WP+P*(90.0_WP+P*(95.0_WP+P*(40.0_WP+P*SIX_W)))))*D
        C(5) = 17640.0_WP*(ONE_W+P*(SIX_W+P+P))*P12
        C(6) = 2520.0_WP*(TWO_W+P*(15.0_WP+P*(20.0_WP+P*FIVE_W)))*D
    ENDIF

    IF (NUE == 2 .AND. KORD == 4) THEN
        D    = P1/(P3*P3*P3)
        P12  = (ONE_W+P)*(ONE_W+P)*D
        C(1) = 840.0_WP*(ONE_W+P*(TWELVE_W+P*(28.0_WP+P*(24.0_WP+P*FIVE_W))))*D
        C(2) = 2100.0_WP*(THREE_W+P*(TEN_W+P))*P12
        C(3) = 1680.0_WP*(NINE_W+P*(28.0_WP+P*(27.0_WP+P*SIX_W)))*D
        C(4) = 14700.0_WP*P12
        C(5) = (5040.0_WP+P*6720.0_WP)*D
    ENDIF

    IF (NUE == 2 .AND. KORD == 6) THEN
        P6   = P3*P3
        D    = ONE_W/(P6*P6)
        P12  = (ONE_W+P)*(ONE_W+P)*D
        C(1) = 5040.0_WP*(TWO_W+P*(60.0_WP+P*(489.0_WP+P*(1786.0_WP+P*(3195.0_WP+P*(2952.0_WP+P  &
                        *(1365.0_WP+P*(294.0_WP+P*21.0_WP))))))))*D
        C(2) = 52920.0_WP*(THREE_W+P*(42.0_WP+P*(188.0_WP+P*(308.0_WP+P*(156.0_WP+P*(28.0_WP+P))))))*P12
        C(3) = 141120.0_WP*(SIX_W+P*(68.0_WP+P*(291.0_WP+P*(570.0_WP+P*(555.0_WP+P*(264.0_WP+P  &
                          *(57.0_WP+P*FOUR_W)))))))*D
        C(4) = 529200.0_WP*(TWO_W+P*(SEVEN_W+P+P))**2*P12
        C(5) = 90720.0_WP*(30.0_WP+P*(228.0_WP+P*(559.0_WP+P*(582.0_WP+P*(255.0_WP+P*40.0_WP)))))*D
        C(6) = 582120.0_WP*(THREE_W+P*(14.0_WP+P*FIVE_W))*P12
        C(7) = 221760.0_WP*(TWO_W+P*(TWELVE_W+P*(15.0_WP+P*FOUR_W)))*D
    ENDIF

    IF (NUE == 3 .AND. KORD == 5) THEN
        D    = -ONE_W/(P3*P3*P3*P1)
        P12  = (ONE_W+P)*(ONE_W+P)*D
        C(1) = 15120.0_WP*(ONE_W+P*(18.0_WP+P*(38.0_WP+P*SIX_W)))*P12
        C(2) = 45360.0_WP*(FOUR_W+P*(35.0_WP+P*(80.0_WP+P*(70.0_WP+P*(20.0_WP+P)))))*D
        C(3) = 352800.0_WP*(TWO_W+P*(SIX_W+P))*P12
        C(4) = 151200.0_WP*(EIGHT_W+P*(25.0_WP+P*(24.0_WP+P*SIX_W)))*D
        C(5) = 952560.0_WP*P12
        C(6) = 70560.0_WP*(FOUR_W+P*FIVE_W)*D
    ENDIF

    IF (NUE == 4 .AND. KORD == 6) THEN
        P6   = P3*P3
        D    = ONE_W/(P6*P6)
        P12  = (ONE_W+P)*(ONE_W+P)*D
        C(1) = 332640.0_WP*(ONE_W+P*(30.0_WP+P*(171.0_WP+P*(340.0_WP+P*(285.0_WP+P*(90.0_WP+P*SEVEN_W))))))*D
        C(2) = 1164240.0_WP*(FIVE_W+P*(56.0_WP+P*(108.0_WP+P*(28.0_WP+P))))*P12
        C(3) = 6652800.0_WP*(FIVE_W+P*(38.0_WP+P*(85.0_WP+P*(76.0_WP+P*(25.0_WP+P+P)))))*D
        C(4) = 17463600.0_WP*(FIVE_W+P*(14.0_WP+P*THREE_W))*P12
        C(5) = 4656960.0_WP*(25.0_WP+P*(78.0_WP+P*(75.0_WP+P*20.0_WP)))*D
        C(6) = 76839840.0_WP*P12
        C(7) = 3991680.0_WP*(FIVE_W+P*SIX_W)*D
    ENDIF

    IF (IBOUN > 0) RETURN
    J = 2
    IF (NUE == 1 .OR. NUE == 3) J = 1
    DO I = J,KORD,2
        C(I) = -C(I)
    ENDDO
    !...
    !...DONE
    RETURN
    END SUBROUTINE COFFB



    SUBROUTINE COFF(X,N,FA)
    !...
    !...IDENTIFY TRANSFERRED VALIABLES
    INTEGER(I4B), INTENT(IN)                                :: N
    REAL(WP), INTENT(IN)                                    :: FA
    REAL(WP), DIMENSION(:), INTENT(OUT)                     :: X

    X(1:N) = FA
    !...
    !...DONE
    RETURN
    END SUBROUTINE COFF
!...
!...DONE
END MODULE KERNEL_REGRESSION
