!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                   TIME_CONVERSION                    *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 08/20/18          *
!...   *                                                      *
!...    ******************************************************
!***
!***************************************************************************************
!***
PROGRAM TIME_CONVERSION
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE NRUTIL,  ONLY : NRERROR, ASSERT_EQ, ARRAY_COPY
USE AA_SIZE, ONLY : IREDUCE, NREDUCE
!...
!...ADD PLOT CONTROL MODULE TO STORE DATA
USE PLOT_CNTL
!...
!...STORE THE FULL SET OF DATA PLOTTING IN SMOOTHED DATA PLOT ROUTINE
USE FULL_DATA
!...
!...ADD SMOOTHING ROUTINES
USE KERNEL_REGRESSION
USE SAVIT_GOLAY
USE UPDATE_EWMA
USE CUBIC_SPLINE_GCV
USE CURVEFIT
!...
!...INCLUDE WEIBULL ANALYSIS MODULE
USE WEIBULL
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: ALLOCATED, DIM, EOSHIFT, EXECUTE_COMMAND_LINE, IABS
INTRINSIC                                           :: LEN_TRIM, MAXVAL, NINT, PRESENT, SIGN, SIZE, TRIM
!...
!...SET PROGRAM VALIABLES
CHARACTER(LEN=82)                                   :: VAL_LOG
CHARACTER(LEN=80)                                   :: FILEIN, FILEOUT, FILERDC, FILEORG, FILEPLT, FILEPS, JUNK, FILESG
CHARACTER(LEN=20)                                   :: EXPLAIN
CHARACTER(LEN=10)                                   :: DETEC_LIMIT
CHARACTER(LEN=4)                                    :: CUNITS
CHARACTER(LEN=3)                                    :: TUNITS
CHARACTER(LEN=1)                                    :: PLT, QUES, RERUN, PREPOST, ZERO, PLTYPE, OUTLIER
CHARACTER(LEN=1)                                    :: TM, CN, SMOOTHING, BACKGROUND, PARAMS, METHOD, MARK
CHARACTER(LEN=1)                                    :: RESID1, RESID2, RESID3, RESID4, RESID5, ALPH, REL_SYMBOL
CHARACTER(LEN=1), DIMENSION(:), ALLOCATABLE         :: LEFT_CEN, MARKER
INTEGER(I4B)                                        :: I, J, IZERO, IPLT, IMOVE, LWRK, JJ=3, NY1, NY2
INTEGER(I4B)                                        :: INN, IIN, ISG, ITMP, NOUT, IMOVE2, IMOVE3, MORDER, LD, IYPMAX, STAT
INTEGER(I4B)                                        :: IFPLT, NDUM, IPARAMS, IERR, KN, LENCHR, IEP, NP, NL, NR, IER, IRES
INTEGER(I4B)                                        :: N_COPIED, N_NOT_COPIED, JOB, IC, NRDC, NORG, NWK, MODE, NN, NW, NF
INTEGER(I4B)                                        :: IFAULT, IMK=0
INTEGER(I4B)                                        :: NCT=0, NCTT=0, N0=0, N1=0, N2=0, N3=0, N4=0, N5=0, N6=0
INTEGER(I4B), PARAMETER                             :: IHOM=0, NUE=0, IRND=0, NSTEPS=0, M1=400, K=1, IOPT=0, KK=5
INTEGER(I4B), PARAMETER                             :: MM=10, MM2=MM*2
INTEGER(I4B)                                        :: IDER, IDM, ISMO=0, KORD=NUE+2, NIREDUCE, NADJ=0, NEST, IPS
INTEGER(I4B), DIMENSION(:), ALLOCATABLE             :: INDX, IWRK
REAL(WP)                                            :: X2, X3, X4, DL, DL_CHECK, MAVE, BCKGRD, CONV, SAMPLING_PERIOD, W1, PW
REAL(WP)                                            :: FRE, XAVE, ADEV, SDEV, DEV, VAR, SKEW, CURT, RMS, XMED, CW1, CW2, ALPHA
REAL(WP)                                            :: MAD, FR_CNTL, AT, BB, SIG=-ONE_W, TL=ONE_W, TU=ZERO_W, FP, A2, A3, ADP
REAL(WP)                                            :: LAMBDA, WEIGHT, VALU, SPLDER, MAXVALY1, XB, XE, SS, WMULT, XMEAN, XSIGMA
REAL(WP)                                            :: XA, YA
REAL(WP), DIMENSION(:), ALLOCATABLE                 :: X1, Y1, Y2, Z1, RP, RP2, XP, YP, ZP, CC, YG, YL, BAN, S1, YT, RW, YZ
REAL(WP), DIMENSION(:), ALLOCATABLE                 :: RES, SE, WK, DF, WX, WY, WRK, TT, TC, WW, OUTL, AA, ORDER, YSW, XM, YM
REAL(WP), DIMENSION(:,:), ALLOCATABLE               :: CT
REAL(WP), PARAMETER                                 :: DELTA=QUART_W, FL=0.03_WP
LOGICAL(FLG)                                        :: OK, INIT
!...
!...SET CONSOLE SIZE AND TEXT COLOR
!CALL EXECUTE_COMMAND_LINE("MODE CON:COLS=200 LINES=65")
CALL EXECUTE_COMMAND_LINE("COLOR 0E")
!...
!...SET PLOT FILE OUTPUT CONTROL (IEP=1 FOR EPS; IEP=2 FOR PEF)
IEP = 0
!...
!...DETERMINE IF STATISTICAL DISTRIBUTION ANALYSES SHOULD BE EXECUTED AND PLOTS PRODUCED (IRES=0 FOR NO; IRES=1 FOR YES)
IRES = 0
!...
!...INTRODUCE THE PROGRAM AND DEVELOPER
WRITE (*,100)
WRITE (*,110, ADVANCE="NO")
READ  (*,*)
!...
!...RUN AND RERUN
10 CONTINUE
!...
!...SET FILE NUMBERS
INN  = 0
!...
!...CLEAR DISTRIBUTION PLOTS AS APPROPRIATE
IF (IRES == 1) THEN
    OPEN (UNIT=1234, IOSTAT=STAT, FILE="Weibul_Probability.pdf", STATUS="OLD")
    IF   (STAT == 0) CLOSE(1234,  STATUS="DELETE")
!...
    OPEN (UNIT=1234, IOSTAT=STAT, FILE="Weibul_PPF.pdf", STATUS="OLD")
    IF   (STAT == 0) CLOSE(1234,  STATUS="DELETE")
!...
    OPEN (UNIT=1234, IOSTAT=STAT, FILE="Gumbel_max_Probability.pdf", STATUS="OLD")
    IF   (STAT == 0) CLOSE(1234,  STATUS="DELETE")
!...
    OPEN (UNIT=1234, IOSTAT=STAT, FILE="Gumbel_min_Probability.pdf", STATUS="OLD")
    IF   (STAT == 0) CLOSE(1234,  STATUS="DELETE")
!...
    OPEN (UNIT=1234, IOSTAT=STAT, FILE="Gumbel_max_PPF.pdf", STATUS="OLD")
    IF   (STAT == 0) CLOSE(1234,  STATUS="DELETE")
!...
    OPEN (UNIT=1234, IOSTAT=STAT, FILE="Gumbel_min_PPF.pdf", STATUS="OLD")
    IF   (STAT == 0) CLOSE(1234,  STATUS="DELETE")
!...
    OPEN (UNIT=1234, IOSTAT=STAT, FILE="Exponential_Probability.pdf", STATUS="OLD")
    IF   (STAT == 0) CLOSE(1234,  STATUS="DELETE")
!...
    OPEN (UNIT=1234, IOSTAT=STAT, FILE="Exponential_PPF.pdf", STATUS="OLD")
    IF   (STAT == 0) CLOSE(1234,  STATUS="DELETE")
ENDIF
!...
!...DETERMINE IF PARAMETER CONTROL FILE IS TO BE USED
WRITE (*,120, ADVANCE="NO")
READ  (*,140) PARAMS(1:1)
KN = LENCHR(PARAMS)
IF (KN < 1) THEN
    IPARAMS = 1
ELSE
    READ (PARAMS,150) IPARAMS
ENDIF
IF ((IPARAMS < 1) .OR. (IPARAMS > 2)) THEN
    CALL EXECUTE_COMMAND_LINE("CLS")
    CALL EXECUTE_COMMAND_LINE("COLOR 0D")
    DO I = 1,3
        WRITE (*,*)
    ENDDO
    CALL NRERROR("FATAL ERROR --> PARAMETER CONTROL SELECTION LESS THEN 1 OR SELECTION GREATER THAN 2")
ENDIF
!...
!...BEGIN READING PARAMETER CONTROL FILE AS APPROPRIATE
IF (IPARAMS == 1) THEN
    CALL CONTROL (IPREPOST,BCKGRD,METHOD,MORDER,LD,SMOOTHING,IZERO,DL,ITM,ICN,PLINE,PL,DPMARK,DNPLOT)
    NIREDUCE = IREDUCE
    IF (SMOOTHING == "N") NIREDUCE = 1
!...
!...BEGIN SCREEN INPUT AS APPROPRIATE
ELSEIF (IPARAMS == 2) THEN
!...
!...DETERMINE IF PRE-TRACER RELEASE DATA OR POST-TRACER RELEASE DATA ARE TO BE CONVERTED
    WRITE (*,130, ADVANCE="NO")
    READ  (*,140) PREPOST(1:1)
    KN = LENCHR(PREPOST)
    IF (KN < 1) THEN
        IPREPOST = 2
    ELSE
        READ (PREPOST,150) IPREPOST
    ENDIF
    IF ((IPREPOST < 1) .OR. (IPREPOST > 2)) THEN
        CALL EXECUTE_COMMAND_LINE("CLS")
        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
        DO I = 1,3
            WRITE (*,*)
        ENDDO
        CALL NRERROR("FATAL ERROR --> PRE- OR POST-INJECTION SELECTION LESS THEN 1 OR SELECTION GREATER THAN 2")
    ENDIF
!...
!...CHECK FOR BACKGROUND VALUE
    IF (IPREPOST == 2) THEN
        WRITE (*,160, ADVANCE="NO")
        READ  (*,140) BACKGROUND(1:1)
        KN = LENCHR(BACKGROUND)
        IF (KN < 1) BACKGROUND = "N"
        SELECT CASE (BACKGROUND)
            CASE ("Y","y","N","n")
                CONTINUE
            CASE DEFAULT
                CALL EXECUTE_COMMAND_LINE("CLS")
                CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                DO I = 1,3
                    WRITE (*,*)
                ENDDO
                CALL NRERROR("FATAL ERROR --> A 'Y' OR 'N' MUST BE LISTED FOR BACKGROUND REQUEST")
        END SELECT
        IF ((BACKGROUND == "N") .OR. (BACKGROUND == "n")) THEN
            BCKGRD = ZERO_W
        ELSE
            WRITE (*,170, ADVANCE="NO") ASCIIMU_C
            READ  (*,*) BCKGRD
        ENDIF
        IF (BCKGRD < ZERO_W) THEN
            BCKGRD = ZERO_W
            WRITE (*,180) ASCIIMU_C
        ENDIF
    ENDIF
    IF (IPREPOST == 1) THEN
        BCKGRD = ZERO_W
        SMOOTHING = "N"
    ELSE
!...
!...SKIP DATA OR DEVELOP A MOVING AVERAGE
        WRITE (*,190, ADVANCE="NO")
        READ  (*,140) SMOOTHING(1:1)
    ENDIF
    KN = LENCHR(SMOOTHING)
    IF (KN < 1) SMOOTHING = "N"
    SELECT CASE (SMOOTHING)
        CASE ("Y","y")
            WRITE (*,200, ADVANCE="NO")
            READ  (*,140) METHOD(1:1)
            KN = LENCHR(METHOD)
            IF (KN < 1) METHOD = "A"
            SELECT CASE (METHOD)
                CASE ("A":"C","a":"c","E":"G","e":"g","K":"M","k":"m","P","p","Q","q","S","s","U","u","W","w")
                    IF ((METHOD == "B") .OR. (METHOD == "b")) THEN
                        IF (IPREPOST == 1) THEN
                            CALL EXECUTE_COMMAND_LINE("CLS")
                            CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                            DO I = 1,3
                                WRITE (*,*)
                            ENDDO
                            CALL NRERROR("FATAL ERROR --> CANNOT REQUEST B-SPLINE SMOOTHING FOR PRE-INJECTION DATA")
                        ENDIF
                        WRITE (*,210, ADVANCE="NO")
                        READ  (*,220) MORDER, LD
                        SELECT CASE (MORDER)
                            CASE (0)
                                MORDER = 4
                            CASE (:-1,5:)
                                CALL EXECUTE_COMMAND_LINE("CLS")
                                CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                                DO I = 1,3
                                    WRITE (*,*)
                                ENDDO
                                CALL NRERROR("FATAL ERROR --> VALUES = 1 -- 4 MUST BE ENTERED")
                            CASE DEFAULT
                                CONTINUE
                        END SELECT
                    ELSEIF ((METHOD == "U") .OR. (METHOD == "u")) THEN
                        IF (IPREPOST == 1) THEN
                            CALL EXECUTE_COMMAND_LINE("CLS")
                            CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                            DO I = 1,3
                                WRITE (*,*)
                            ENDDO
                            CALL NRERROR("FATAL ERROR --> CANNOT REQUEST CURVE-FIT SMOOTHING FOR PRE-INJECTION DATA")
                        ENDIF
                        WRITE (*,210, ADVANCE="NO")
                        READ  (*,220) MORDER, LD
                        SELECT CASE (MORDER)
                            CASE (0)
                                MORDER = 4
                            CASE (:-1,5:)
                                CALL EXECUTE_COMMAND_LINE("CLS")
                                CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                                DO I = 1,3
                                    WRITE (*,*)
                                ENDDO
                                CALL NRERROR("FATAL ERROR --> VALUES = 1 -- 4 MUST BE ENTERED")
                            CASE DEFAULT
                                CONTINUE
                        END SELECT
                    ELSEIF ((METHOD == "G") .OR. (METHOD == "g")) THEN
                        WRITE (*,215, ADVANCE="NO")
                        READ  (*,220) MORDER, LD
                        SELECT CASE (MORDER)
                            CASE (0)
                                MORDER = 4
                            CASE (:-1,1,3,5,7:)
                                CALL EXECUTE_COMMAND_LINE("CLS")
                                CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                                DO I = 1,3
                                    WRITE (*,*)
                                ENDDO
                                CALL NRERROR("FATAL ERROR --> VALUES = 2, 4, OR 6 MUST BE ENTERED")
                            CASE DEFAULT
                                CONTINUE
                        END SELECT
                        SELECT CASE (LD)
                            CASE (0)
                                LD = 0
                            CASE (:-1)
                                CALL EXECUTE_COMMAND_LINE("CLS")
                                CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                                DO I = 1,3
                                    WRITE (*,*)
                                ENDDO
                                CALL NRERROR("FATAL ERROR --> A VALUE > -1 MUST BE ENTERED")
                            CASE DEFAULT
                                CONTINUE
                        END SELECT
                    ELSEIF ((METHOD == "K") .OR. (METHOD == "k")) THEN
                        WRITE (*,225, ADVANCE="NO")
                        READ  (*,150) MORDER
                        SELECT CASE (MORDER)
                            CASE (0)
                                MORDER = 1
                            CASE (:-1,3:)
                                CALL EXECUTE_COMMAND_LINE("CLS")
                                CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                                DO I = 1,3
                                    WRITE (*,*)
                                ENDDO
                                CALL NRERROR("FATAL ERROR --> VALUES = 1 or 2 MUST BE ENTERED")
                            CASE DEFAULT
                                CONTINUE
                        END SELECT
                    ELSEIF ((METHOD == "P") .OR. (METHOD == "p")) THEN
                        WRITE (*,230, ADVANCE="NO")
                        READ  (*,150) MORDER
                        SELECT CASE (MORDER)
                            CASE (0)
                                MORDER = 20
                            CASE (:-1,101:)
                                CALL EXECUTE_COMMAND_LINE("CLS")
                                CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                                DO I = 1,3
                                    WRITE (*,*)
                                ENDDO
                                CALL NRERROR("FATAL ERROR --> VALUES = 1 -- 100 MUST BE ENTERED")
                            CASE DEFAULT
                                CONTINUE
                        END SELECT
                    ENDIF
                CASE DEFAULT
                    CALL EXECUTE_COMMAND_LINE("CLS")
                    CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                    DO I = 1,3
                        WRITE (*,*)
                    ENDDO
                    WRITE (*,*) "AN 'A', 'B', 'C', 'E', 'F', 'G', 'K', 'L', 'M' OR 'P' OR 'Q' OR 'S' OR 'U' MUST BE SELECTED"
                    CALL NRERROR("FATAL ERROR")
            END SELECT
            SELECT CASE (METHOD)
                CASE ("A":"B","a":"b","E":"G","e":"g","K","k","M","m","Q","q","S","s","W","w")
                    WRITE (*,240, ADVANCE="NO")                     !...ENTER DATA FOR SMOOTHING COUNTER
                    READ  (*,*) IREDUCE
                CASE DEFAULT
                    IREDUCE = 1
                    CONTINUE
            END SELECT
        CASE ("N","n")
            WRITE (*,250, ADVANCE="NO")                             !...ENTER DATA REDUCTION COUNTER
            READ  (*,*) IREDUCE
        CASE DEFAULT
            CALL EXECUTE_COMMAND_LINE("CLS")
            CALL EXECUTE_COMMAND_LINE("COLOR 0D")
            DO I = 1,3
                WRITE (*,*)
            ENDDO
            CALL NRERROR("FATAL ERROR --> A 'Y' OR 'N' MUST BE LISTED FOR MOVING AVERAGE")
    END SELECT
!...
!...COPY IREDUCE TO NIREDUCE AND NREDUCE TO ALLOW FOR LATER ADJUSTMENTS
    NIREDUCE = IREDUCE
     NREDUCE = IREDUCE                                              !NREDUCE TRANSFERRED VIA MODULE AA-SIZE TO PLOT
    SELECT CASE (SMOOTHING)
        CASE ("Y","y")
            SELECT CASE (METHOD)
                CASE ("A","a","E","e","G","g","M","m")
                    IF (IREDUCE == 1) THEN
                        SMOOTHING = "N"
                        WRITE (*,260)
                    ENDIF
                CASE ("B":"C","b":"c","F","f","K":"L","k":"l","P":"Q","p":"q","S","s","U","u","W","w")
                    IF (IREDUCE > 1) THEN
                        NIREDUCE = 1
                        WRITE (*,265)
                    ENDIF
                    IF ((METHOD == "K") .OR. METHOD =="k") THEN
                        IF ((MORDER < 1) .OR. (MORDER > 2)) THEN
                            MORDER = 1
                            WRITE (*,267)
                        ENDIF
                    ENDIF
                CASE DEFAULT
                    CONTINUE
            END SELECT
        CASE DEFAULT
            NIREDUCE = 1
    END SELECT
    IF ((IREDUCE < 1) .OR. (IREDUCE > 1000)) THEN
        CALL EXECUTE_COMMAND_LINE("CLS")
        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
        DO I = 1,3
            WRITE (*,*)
        ENDDO
        CALL NRERROR("FATAL ERROR --> DATA REDUCTION SELECTION LESS THEN 1 OR SELECTION GREATER THAN 1000")
    ENDIF
!...
!...CONVERT NEGATIVE CONCENTRATION VALUES TO ZERO OR NOT?
    WRITE (*,270, ADVANCE="NO")
    READ  (*,140) ZERO(1:1)
    KN = LENCHR(ZERO)
    IF (KN < 1) THEN
        IZERO = 1
    ELSE
        READ (ZERO,150) IZERO
    ENDIF
    IF ((IZERO < 1) .OR. (IZERO > 2)) THEN
        CALL EXECUTE_COMMAND_LINE("CLS")
        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
        DO I = 1,3
            WRITE (*,*)
        ENDDO
        CALL NRERROR("FATAL ERROR --> NEGATIVE VALUE CORRECTION SELECTION LESS THEN 1 OR SELECTION GREATER THAN 2")
    ENDIF
!...
!...ENTER A VALUE FOR DETECTION LIMIT
    WRITE (*,280, ADVANCE="NO")
    READ  (*,290) DETEC_LIMIT(1:10)
    DETEC_LIMIT = TRIM(DETEC_LIMIT)
    KN = LENCHR(DETEC_LIMIT)
    IF (KN < 1) THEN
        DL = TEN_W
    ELSE
        READ (DETEC_LIMIT,*) DL
    ENDIF
!...
!...ENSURE THAT DETECTION LIMIT IS GREATER THAN ZERO
    CALL DT_LIMIT(OUT=DL_CHECK)
    DL = DL_CHECK
ENDIF
!...
!...ADJUST NIREDUCE FOR MOVING AVERAGE TO CREATE TRIPLE RUNNING MEAN TO IMPROVE SMOOTHING
!...(SEE https://climategrog.wordpress.com/2013/05/19/triple-running-mean-filters/)
IMOVE2 = NINT(REAL(NIREDUCE, KIND=WP)/1.4303_WP)
IMOVE3 = NINT(REAL(NIREDUCE, KIND=WP)/1.4303_WP/1.4303_WP)
!...
!...OPEN INPUT FILE -- CLEAR AND REDO IF INPUT FILE DOES NOT EXISTS
5 CONTINUE
INN = INN+1
IF (INN > 1) THEN
    IF (KN <= 50) THEN
        WRITE (*,300) FILEIN
    ELSE
        WRITE (*,310) FILEIN
    ENDIF
ENDIF
IF (IPREPOST == 1) WRITE (*,320, ADVANCE="NO")
IF (IPREPOST == 2) WRITE (*,325, ADVANCE="NO")
READ  (*,290) FILEIN
KN = LENCHR(FILEIN)
IF (IPREPOST == 1) THEN
    IF (KN < 1) FILEIN = "BACK.DAT"
ELSEIF (IPREPOST == 2) THEN
    IF (KN < 1) FILEIN = "DATA.DAT"
ENDIF
OPEN (NEWUNIT=IIN, FILE = FILEIN, ACCESS = "SEQUENTIAL", STATUS = "OLD", POSITION = "REWIND", ERR = 5)
INQUIRE(IIN, OPENED = OK)
IF (.NOT. OK) THEN
    WRITE(*,1000) BELL_C, FILEIN
    STOP
ENDIF
!...
!...CREATE BACKGROUND FILE IF REQUESTED
IF (IPREPOST == 1) THEN
6   CONTINUE
    WRITE (*,330, ADVANCE="NO")
    READ  (*,290) FILEOUT
    KN = LENCHR (FILEOUT)
    IF (KN < 1) FILEOUT = "BACK.BCK"
    IF (FILEOUT == FILEIN) THEN
        WRITE (*,350)
        WRITE (*,360, ADVANCE="NO")
        READ  (*,*)
        GOTO 6
    ENDIF
!...
!...CREATE OUTPUT FILES FOR THE ORIGINAL AND THE TRANSFORMED DATA IF SMOOTHING IS REQUESTED
    IF ((SMOOTHING == "Y") .OR. (SMOOTHING == "y")) THEN
!...
!...CREATE A TRANSFORMED DATA FILE IF APPROPRIATE
8       CONTINUE
        WRITE (*,356, ADVANCE="NO")
        READ  (*,290) FILERDC
        KN = LENCHR (FILERDC)
        IF (KN < 1) FILERDC = "BACK.TRF"
        IF ((FILERDC == FILEIN) .OR. (FILERDC == FILEOUT) .OR. (FILERDC == FILEORG)) THEN
            WRITE (*,358)
            WRITE (*,360, ADVANCE="NO")
            READ  (*,*)
            GOTO 8
        ENDIF
    ENDIF
ELSE
!...
!...CREATE A RESULTS FILE IF REQUESTED
7   CONTINUE
    WRITE (*,340, ADVANCE="NO")
    READ  (*,290) FILEOUT
    KN = LENCHR (FILEOUT)
    IF (KN < 1) FILEOUT = "DATA.OUT"
    IF (FILEOUT == FILEIN) THEN
        WRITE (*,350)
        WRITE (*,360, ADVANCE="NO")
        READ  (*,*)
        GOTO 7
    ENDIF
!...
!...CREATE OUTPUT FILES FOR THE ORIGINAL AND THE TRANSFORMED DATA IS SMOOTHING IS REQUESTED
    IF ((SMOOTHING == "Y") .OR. (SMOOTHING == "y")) THEN
!...
!...CREATE AN ORIGINAL DATA FILE IF APPROPRIATE
9       CONTINUE
        WRITE (*,353, ADVANCE="NO")
        READ  (*,290) FILEORG
        KN = LENCHR (FILEORG)
        IF (KN < 1) FILEORG = "DATA.ORG"
        IF ((FILEORG == FILEIN) .OR. (FILEORG == FILEOUT)) THEN
            WRITE (*,354)
            WRITE (*,360, ADVANCE="NO")
            READ  (*,*)
            GOTO 9
        ENDIF
!...
!...CREATE A TRANSFORMED DATA FILE IF APPROPRIATE
11      CONTINUE
        WRITE (*,357, ADVANCE="NO")
        READ  (*,290) FILERDC
        KN = LENCHR (FILERDC)
        IF (KN < 1) FILERDC = "DATA.RDC"
        IF ((FILERDC == FILEIN) .OR. (FILERDC == FILEOUT) .OR. (FILERDC == FILEORG)) THEN
            WRITE (*,358)
            WRITE (*,360, ADVANCE="NO")
            READ  (*,*)
            GOTO 11
        ENDIF
    ENDIF
ENDIF
OPEN (NEWUNIT=NOUT, FILE = FILEOUT, STATUS = "UNKNOWN", POSITION = "REWIND")
INQUIRE(NOUT, OPENED = OK)
IF (.NOT. OK) OPEN(NOUT, FILE = FILEOUT, STATUS = "UNKNOWN")
IF ((SMOOTHING == "Y") .OR. (SMOOTHING == "y")) THEN
    OPEN (NEWUNIT=NRDC, FILE = FILERDC, STATUS = "UNKNOWN", POSITION = "REWIND")
    INQUIRE(NRDC, OPENED = OK)
    IF (.NOT. OK) OPEN(NRDC, FILE = FILERDC, STATUS = "UNKNOWN")
    IF (IPREPOST == 2) THEN
        OPEN (NEWUNIT=NORG, FILE = FILEORG, STATUS = "UNKNOWN", POSITION = "REWIND")
        INQUIRE(NORG, OPENED = OK)
        IF (.NOT. OK) OPEN(NORG, FILE = FILEORG, STATUS = "UNKNOWN")
    ENDIF
ENDIF
!...
!...BEGIN SCREEN INPUT AGAIN
IF (IPARAMS == 2) THEN
!...
!...DETERMINE TIME UNITS FOR DATA OUTPUT
    WRITE (*,370, ADVANCE="NO")
    READ  (*,140) TM(1:1)
    KN = LENCHR(TM)
    IF (KN < 1) THEN
        ITM = 2
    ELSE
        READ (TM,150) ITM
    ENDIF
    IF ((ITM < 1) .OR. (ITM > 4)) THEN
        CALL EXECUTE_COMMAND_LINE("CLS")
        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
        DO I = 1,3
            WRITE (*,*)
        ENDDO
        CALL NRERROR("FATAL ERROR --> TIME LISTING SELECTION LESS THEN 1 OR SELECTION GREATER THAN 4")
    ENDIF
!...
!...DETERMINE CONCENTRATION UNITS FOR DATA OUTPUT
    WRITE (*,380, ADVANCE="NO") ASCIIMU_C
    READ  (*,140) CN(1:1)
    KN = LENCHR(CN)
    IF (KN < 1) THEN
        ICN = 4
    ELSE
        READ (CN,150) ICN
    ENDIF
    IF ((ICN < 1) .OR. (ICN > 6)) THEN
        CALL EXECUTE_COMMAND_LINE("CLS")
        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
        DO I = 1,3
            WRITE (*,*)
        ENDDO
        CALL NRERROR("FATAL ERROR --> CONCENTRATION LISTING SELECTION LESS THEN 1 OR SELECTION GREATER THAN 6")
    ENDIF
ENDIF
!...
!...SET TIME UNITS CHARACTER DATA
IF (ITM == 1) THEN
    TUNITS = "d"
ELSEIF (ITM == 2) THEN
    TUNITS = "h"
ELSEIF (ITM == 3) THEN
    TUNITS = "min"
ELSE
    TUNITS = "s"
ENDIF
TUNITS = TRIM(TUNITS)
!...
!...SET CONCENTRATION UNITS CHARACTER DATA
IF (ICN == 1) THEN
    CUNITS = "kg/L"
ELSEIF (ICN == 2) THEN
    CUNITS = "g/L"
ELSEIF (ICN == 3) THEN
    CUNITS = "mg/L"
ELSEIF (ICN == 4) THEN
    CUNITS = ANSIMU_C
ELSEIF (ICN == 5) THEN
    CUNITS = "ng/L"
ELSE
    CUNITS = "pg/L"
ENDIF
CUNITS = TRIM(CUNITS)
!...
!...COUNT DATA SETS
REWIND(UNIT=IIN)
1 CONTINUE
READ(IIN,*,END=2,ERR=2)
N1 = N1+1
GOTO 1
2 CONTINUE
REWIND(UNIT=IIN)
N1 = N1-3
IC = N1-1
!...
!...ALLOCATE DATA ARRAYS MEMORY SPACE
ALLOCATE(X1(1:N1*2), STAT=IERR)
ALLOCATE(XS(1:N1), STAT=IERR)
ALLOCATE(Y1(1:N1*2), STAT=IERR)
ALLOCATE(YS(1:N1), STAT=IERR)
ALLOCATE(XM(1:N1), STAT=IERR)
ALLOCATE(YM(1:N1), STAT=IERR)
ALLOCATE(MARKER(1:N1), STAT=IERR)
ALLOCATE(LEFT_CEN(1:N1), STAT=IERR)
SELECT CASE (METHOD)
    CASE ("A","a","M","m")
        ALLOCATE(Z1(1:N1), STAT=IERR)
    CASE ("B","b")
        NWK = N1+6*(N1*MM+1)
        ALLOCATE(WK(1:NWK), STAT=IERR)
        ALLOCATE(WX(1:N1),  STAT=IERR)
        ALLOCATE(WY(1:K),   STAT=IERR)
        ALLOCATE(YT(1:N1),  STAT=IERR)
        ALLOCATE(YG(0:MM),  STAT=IERR)
        ALLOCATE(YL(1:MM2), STAT=IERR)
    CASE ("C","c")
        ALLOCATE(YT(1:N1), STAT=IERR)
        ALLOCATE(DF(1:N1), STAT=IERR)
        ALLOCATE(SE(1:N1), STAT=IERR)
        ALLOCATE(WK(1:7*(N1+2)), STAT=IERR)
        ALLOCATE(CT(1:3,1:IC), STAT=IERR)
    CASE ("K","k")
        ALLOCATE(BAN(1:N1), STAT=IERR)
        IF (MORDER == 1) ALLOCATE(YG(1:N1), STAT=IERR)
        IF (MORDER == 2) ALLOCATE(YL(1:N1), STAT=IERR)
        ALLOCATE(S1(0:N1), STAT=IERR)
        S1(0:N1) = (/ (ZERO_W, I=0,N1-1), -ONE_W /)
    CASE ("L","l")
        ALLOCATE(YT(1:N1),  STAT=IERR)
        ALLOCATE(RW(1:N1),  STAT=IERR)
        ALLOCATE(RES(1:N1), STAT=IERR)
    CASE ("U","u")
        NEST = N1+KK+1
        LWRK = N1*(KK+1)+NEST*(7+3*KK)
        ALLOCATE(IWRK(1:NEST), STAT=IERR)
        ALLOCATE( WRK(1:LWRK), STAT=IERR)
        ALLOCATE(  TC(1:NEST), STAT=IERR)
        ALLOCATE(  TT(1:NEST), STAT=IERR)
        ALLOCATE(  WW(1:N1),   STAT=IERR)
        ALLOCATE(  YT(1:N1),   STAT=IERR)
    CASE ("F","f","P","p","S","s","W","w")
        ALLOCATE(YT(1:N1),  STAT=IERR)
    CASE DEFAULT
END SELECT
!...
!...CHECK X1, Y1, AND Z1 ARRAY SIZES TO ENSURE COMPATIBILITY
SELECT CASE (METHOD)
    CASE ("A","a","M","m")
        NDUM = ASSERT_EQ((/SIZE(X1),SIZE(Y1)/),"             TIME_CONVERSION LINE 678")
    CASE ("L","l")
        NDUM = ASSERT_EQ((/SIZE(XS),SIZE(YT)/),"             TIME_CONVERSION LINE 681")
    CASE ("S","s")
        NDUM = ASSERT_EQ((/SIZE(XS),SIZE(YS),SIZE(YT)/),"             TIME_CONVERSION LINE 683")
    CASE DEFAULT
        NDUM = ASSERT_EQ((/SIZE(X1),SIZE(Y1),SIZE(XS),SIZE(YS)/),"             TIME_CONVERSION LINE 685")
END SELECT
!...
!...MOVE DATA FILE DOWN THREE PLACES
DO I = 1,3
    READ (IIN,*) JUNK
ENDDO
!...
!...READ TIME-CONCENTRATION DATA AND DETERMINE MAXIMUM VALUES; MARK WHERE DOWNLOADED DATASETS ARE ADDED
DO I = 1,N1
    READ (IIN,*) XA, YA, MARK
    IF ((DNPLOT == "N") .OR. (DNPLOT == "n")) THEN
        IF (I > 1) THEN
            IF (MARK == "*") CYCLE
        ENDIF
    ENDIF
    NCT = NCT+1
    X1(NCT) = XA
    Y1(NCT) = YA
    MARKER(NCT) = MARK                                            !...MARKER "*" IDENTIFIES DATA CONNECTION INSTANCES
ENDDO
N1 = NCT
X4 = MAXVAL(X1)
MAXVALY1 = MAXVAL(Y1)
!...
!...READ TRACER-INJECTION TIME IF POST-TRACER-INJECTION ANALYSIS (X2 = INJECTION TIME)
REWIND(UNIT=IIN)
READ (IIN,*) JUNK
READ (IIN,*) X2
READ (IIN,*) JUNK
READ (IIN,*) X3
BACKSPACE (IIN)
IF (IPREPOST == 1) THEN
    IF (X3 > X2) THEN
        CALL EXECUTE_COMMAND_LINE("CLS")
        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
        DO I = 1,3
            WRITE (*,*)
        ENDDO
        CALL NRERROR("FATAL ERROR --> MEASURED TIME GREATER THAN INJECTION TIME -- CANNOT RUN BACKGROUND ANALYSIS")
    ENDIF
ENDIF
!...
!...RE-READ DATA FROM INPUT FILE AND ADJUST FOR TIME OF INJECTION
DO I = 1,N1
    READ (IIN,*) X3
    BACKSPACE (IIN)
    IF (X3 > X2) EXIT
    IF (IPREPOST == 1) THEN
        READ (IIN,*) XA, YA, MARK
        IF ((DNPLOT == "N") .OR. (DNPLOT == "n")) THEN
            IF (MARK == "*") CYCLE
        ENDIF
        N2 = N2+1
        X1(N2) = XA
        Y1(N2) = YA
        MARKER(N2) = MARK                                       !...READ POST-INJECTION DATA
        IF (X1(N2) == X3) N0 = N0+1                             !...ADJUST COUNTER FOR > ONE INSTANCE OF ZERO TIME
    ENDIF
    IF (IPREPOST == 2) THEN
        READ (IIN,*) XA, YA, MARK
        IF ((DNPLOT == "N") .OR. (DNPLOT == "n")) THEN
            IF (MARK == "*") CYCLE
        ENDIF
        N2 = N2+1
        X1(N2) = XA
        Y1(N2) = YA
        MARKER(N2) = MARK                                       !...READ POST-INJECTION DATA
        IF (X1(N2) == X3) N0 = N0+1                             !...ADJUST COUNTER FOR > ONE INSTANCE OF ZERO TIME
    ENDIF
ENDDO
!...
!...REARRANGE DATA TO GET RID OF EXTRANEOUS (i.e., INCORRECT) SECOND TIME VALUE WHEN NECESSARY
IF ((DNPLOT == "N") .OR. (DNPLOT == "n")) THEN
    NCT = 0
    DO I = 2,N1
        NCT = NCT+1
        X1(NCT) = X1(I)
        Y1(NCT) = Y1(I)
    ENDDO
ENDIF
IF (N0 == 0) N0 = 1
!...
!...ADJUST PLOT COUNTER FOR DATA REDUCTION
IF (IREDUCE > 1) NADJ = 1
IF (IPREPOST == 1) THEN
    N3 = N2/NIREDUCE
    SELECT CASE (SMOOTHING)
        CASE ("Y","y")
            SELECT CASE (METHOD)
                CASE ("A":"B","a":"b","E":"G","e":"g","K","k","M","m","Q","q","S","s","W","w") !,"Q","q","S","s","W","w" to be removed?
                    NW = (N2/IREDUCE)+NADJ
                    WRITE (*,390) N1, NW
                CASE DEFAULT
                    WRITE (*,390) N1, N1
            END SELECT
        CASE DEFAULT
            NW = (N2/IREDUCE)+NADJ
            WRITE (*,390) N1, NW
    END SELECT
ELSEIF (IPREPOST == 2) THEN
    N3 = (N1-N2)/NIREDUCE
    SELECT CASE (SMOOTHING)
        CASE ("Y","y")
            SELECT CASE (METHOD)
                CASE ("A":"B","a":"b","E":"G","e":"g","K","k","M","m","Q","q","S","s","W","w") !,"Q","q","S","s","W","w" to be removed?
                    NW = ((N1-N2)/IREDUCE)+NADJ
                    WRITE (*,390) N1, NW
                CASE DEFAULT
                    WRITE (*,390) N1, N1
            END SELECT
        CASE DEFAULT
            NW = ((N1-N2)/IREDUCE)+NADJ
            WRITE (*,390) N1, NW
    END SELECT
ENDIF
IF (NW == 0) NW = N1
IF (IREDUCE > 1) N3 = N3+1
!...
!...PRINT A SCREEN NOTE REGARDING EXCESSIVE DATA REDUCTION
SELECT CASE (METHOD)
    CASE ("A","a","G","g","M","m","S","s")
        IF (NIREDUCE > 1) THEN
            IF (REAL(N3, KIND=WP)/REAL(N1, KIND=WP)*HUND_W < 20.0_WP) THEN
                WRITE (*,400) (REAL(N3, KIND=WP)/REAL(N1, KIND=WP)*HUND_W)
            ENDIF
        ENDIF
    CASE DEFAULT
        WRITE (*,402)
END SELECT
!...
!...ALLOCATE PLOT ARRAYS MEMORY SPACE
ALLOCATE(XP(1:N1),  STAT=IERR)
ALLOCATE(YP(1:N1),  STAT=IERR)
ALLOCATE(ZP(1:N1),  STAT=IERR)
ALLOCATE(RP(1:N1),  STAT=IERR)
ALLOCATE(RP2(1:N1), STAT=IERR)
SELECT CASE (SMOOTHING)
    CASE ("Y","y")
        IMOVE = NIREDUCE
        SELECT CASE (METHOD)
            CASE ("G","g")
                NP = 2*IMOVE+1
                NL = IMOVE
                NR = IMOVE
                ALLOCATE(Y2(1:N1),      STAT=IERR)
                ALLOCATE(INDX(1:NP),    STAT=IERR)
                ALLOCATE(CC(1:NL+NR+1), STAT=IERR)
            CASE DEFAULT
                CONTINUE
        END SELECT
        NIREDUCE = 1
    CASE DEFAULT
        CONTINUE
END SELECT
!...
!...CHECK XP, YP, AND ZP ARRAY SIZES TO ENSURE COMPATIBILITY
NDUM = ASSERT_EQ((/SIZE(XP),SIZE(YP),SIZE(ZP)/),"             TIME_CONVERSION LINE 842")
!...
!...ADJUST DATA ACCORDINGLY
IF (IPREPOST == 1) THEN
    X1(:) = X2-X1(:)                                            !...PRE-INJECTION ANALYSIS
ELSEIF (IPREPOST == 2) THEN
    X1(:) = X1(:)-X2                                            !...POST-INJECTION ANALYSIS
    DO I = 1,N1
        IF (X1(I) < ZERO_W) X1(I) = ZERO_W                      !...ENSURE THAT POST INJECTION TIME IS NEVER LESS THAN ZERO
    ENDDO
ENDIF
!...
!...CONVERT TIME DATA TO DAYS, HOURS, MINUTES, OR SECONDS
IF (ITM == 1) THEN
    X1(:) = X1(:)/TDAY_W                                        !...CONVERT TO DAYS
    X2 = X2/TDAY_W
ELSEIF (ITM == 2) THEN
    X1(:) = X1(:)/THR_W                                         !...CONVERT TO HOURS
    X2 = X2/THR_W
ELSEIF (ITM == 3) THEN
    X1(:) = X1(:)/TMIN_W                                        !...CONVERT TO MINUTES
    X2 = X2/TMIN_W
ELSE
    X1(:) = X1(:)*ONE_W                                         !...CONVERT TO SECONDS
ENDIF
!...
!...DETERMINE CONCENTRATION CONVERSION FACTOR FOR SELECTED UNITS
IF (ICN == 1) THEN
    CONV = 1.0E-15_WP                                           !...CONVERT CONCENTRATION TO kg
ELSEIF (ICN == 2) THEN
    CONV = 1.0E-12_WP                                           !...CONVERT CONCENTRATION TO g
ELSEIF (ICN == 3) THEN
    CONV = 1.0E-9_WP                                            !...CONVERT CONCENTRATION TO mg
ELSEIF (ICN == 4) THEN
    CONV = MILLIONTH_W                                          !...CONVERT CONCENTRATION TO �g
ELSEIF (ICN == 5) THEN
    CONV = THOUTH_W                                             !...CONVERT CONCENTRATION TO ng
ELSE
    CONV = ONE_W                                                !...CONVERT CONCENTRATION TO pg
ENDIF
!...
!...CONVERT TIME AND CONCENTRATION DATA AS APPROPRIATE
DO I = 1,N1
    IF (IPREPOST == 1) THEN
        IF (X1(I) /= ZERO_W) X1(I) = SIGN(X1(I),-ONE_W)         !...ENSURES NEGATIVE BACKGROUND TIME LEADING UP TO ZERO TIME
    ENDIF
    IF (IPREPOST == 2) THEN
        Y1(I) = Y1(I)-BCKGRD                                    !...SUBTRACT BACKGROUND VALUE FROM OUTPUT DATA FILE
    ENDIF
    IF (IZERO == 1) THEN
        IF (Y1(I) < ZERO_W) Y1(I) = ZERO_W                      !...CONVERTS NEGATIVE CONCENTATIONS TO ZERO CONCENTATIONS IF REQUESTED
    ENDIF
    IF (MARKER(I) == "*") THEN
        IMK = IMK+1
        XM(IMK) = X1(I)
        YM(IMK) = Y1(I)
    ENDIF
ENDDO
IF (IPREPOST == 2) THEN
    J = 0
    DO I = N0,N1
        J = J+1
        X1(J) = X1(I)
        Y1(J) = Y1(I)
    ENDDO
    N0 = 1
    N1 = J
ENDIF
IF (MARKER(N1) /= "*") MARKER(N1) = "*"
!...
!...CHECK  AUTOCORRELATION
!WRITE (*,*) CORREL(Y1,Y1)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!CALL CORREL(N1,Y1,Y1)
!...
!...CONSIDER REMOVING POSSIBLE OUTLIERS
WRITE (*,404, ADVANCE="NO")
READ  (*,140) OUTLIER
SELECT CASE (OUTLIER)
    CASE ("Y","y")
        WRITE (*,405, ADVANCE="NO") ALPHA_C
        READ  (*,140) ALPH
        SELECT CASE (ALPH)
            CASE ("1")
                ALPHA = TENTH_W
            CASE ("2")
                ALPHA = HALF_W*TENTH_W
            CASE ("3")
                ALPHA = QUART_W*TENTH_W
            CASE ("4")
                ALPHA = HUNDTH_W
            CASE ("5")
                ALPHA = THOUTH_W
            CASE DEFAULT
                ALPHA = HUNDTH_W
        END SELECT
        NY1 = N1
        NY2 = N1/2
        ALLOCATE(AA(1:NY2), STAT=IERR)
        ALLOCATE(YSW(1:N1), STAT=IERR)
        ALLOCATE(ORDER(1:NY1), STAT=IERR)
        CALL ARRAY_COPY (Y1,YSW,N_COPIED,N_NOT_COPIED)
        IF (N_NOT_COPIED > 0) THEN
!                CALL EXECUTE_COMMAND_LINE("CLS")
!                CALL EXECUTE_COMMAND_LINE("COLOR 0D")
!                DO I = 1,3
!                    WRITE (*,*)
!                ENDDO
!                CALL NRERROR("FATAL ERROR --> ARRAY Y1 NOT CORRECTLY COPIED TO ARRAY YSW")
            YSW = Y1
        ENDIF
        CALL QUICK_SORT(N1,YSW,ORDER)
        CALL SWILK(INIT,YSW,N1,NY1,NY2,AA,W1,PW,IFAULT)
        IF (IFAULT /= 0) THEN
            IF (IFAULT /= 2) THEN
                CALL EXECUTE_COMMAND_LINE("CLS")
                CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                DO I = 1,3
                    WRITE (*,*)
                ENDDO
                WRITE (*,*) "IFAULT = ",IFAULT
                CALL NRERROR("FATAL ERROR --> IN SHAPIRO-WILK ROUTINE")
            ENDIF
        ENDIF
        IF (PW < ALPHA) THEN
            REL_SYMBOL = "<"
            EXPLAIN = "REJECT H0 **>"
            VAL_LOG = "DATA NOT NORMALLY DISTRIBUTED; LN OF CONCENTRATION VALUES USED IN OUTLIER ANALYSIS"
            WRITE (*,406) W1, PW, REL_SYMBOL, ALPHA, EXPLAIN
        ELSE
            REL_SYMBOL = GEQ_C
            EXPLAIN = "CANNOT REJECT H0 **>"
            VAL_LOG = "DATA NORMALLY DISTRIBUTED; UNALTERED CONCENTRATION VALUES USED IN OUTLIER ANALYSIS"
            WRITE (*,406) W1, PW, REL_SYMBOL, ALPHA, EXPLAIN
        ENDIF
        ALLOCATE(OUTL(1:N1), STAT=IERR)
        CALL MTVOUT(N1,ALPHA,X1,Y1,PW,OUTL,XMEAN,XSIGMA)
        DEALLOCATE(AA)
        DEALLOCATE(YSW)
        DEALLOCATE(ORDER)
        DEALLOCATE(OUTL)
        WRITE (*,408) VAL_LOG
    CASE ("N","n")
        CONTINUE
    CASE DEFAULT
        CONTINUE
END SELECT
!...
!...CONVERT MEASURED CONCENTRATIONS FROM �g/L TO pg/L
Y1(:) = Y1(:)*MILLION_W
!...
!...WRITE HEADER TO OUTPUT FILES
IF (IPREPOST == 1) THEN
    WRITE (NOUT,410) FILEIN,ANSIMU_C,DL,ITM,ANSIMU_C            !...ADDS THE HEADER FILE FOR USE IN TRACER BACKGROUND PROGRAM
    IF (ITM == 1) THEN
        WRITE (NOUT,420) TUNITS,ANSIMU_C
    ELSEIF (ITM == 2) THEN
        WRITE (NOUT,430) TUNITS,ANSIMU_C
    ELSEIF (ITM == 3) THEN
        WRITE (NOUT,440) TUNITS,ANSIMU_C
    ELSE
        WRITE (NOUT,450) TUNITS,ANSIMU_C
    ENDIF
    IF ((SMOOTHING == "Y") .OR. (SMOOTHING == "y")) THEN
        WRITE (NRDC,464)
        IF (ITM == 1) THEN
            IF (ICN /= 2) THEN
                IF (ICN /= 4) THEN
                    WRITE (NRDC,480) TUNITS,CUNITS,CUNITS
                ELSEIF (ICN == 4) THEN
                    WRITE (NRDC,500) TUNITS,CUNITS,CUNITS
                ENDIF
            ELSE
                WRITE (NRDC,520) TUNITS,CUNITS,CUNITS
            ENDIF
        ELSEIF (ITM == 2) THEN
            IF (ICN /= 2) THEN
                IF (ICN /= 4) THEN
                    WRITE (NRDC,540) TUNITS,CUNITS,CUNITS
                ELSEIF (ICN == 4) THEN
                    WRITE (NRDC,560) TUNITS,CUNITS,CUNITS
                ENDIF
            ELSE
                WRITE (NRDC,580) TUNITS,CUNITS,CUNITS
            ENDIF
        ELSEIF (ITM == 3) THEN
            IF (ICN /= 2) THEN
                IF (ICN /= 4) THEN
                    WRITE (NRDC,600) TUNITS,CUNITS,CUNITS
                ELSEIF (ICN == 4) THEN
                    WRITE (NRDC,620) TUNITS,CUNITS,CUNITS
                ENDIF
            ELSE
                WRITE (NRDC,640) TUNITS,CUNITS,CUNITS
            ENDIF
        ELSE
            IF (ICN /= 2) THEN
                IF (ICN /= 4) THEN
                    WRITE (NRDC,660) TUNITS,CUNITS,CUNITS
                ELSEIF (ICN == 4) THEN
                    WRITE (NRDC,680) TUNITS,CUNITS,CUNITS
                ENDIF
            ELSE
                WRITE (NRDC,700) TUNITS,CUNITS,CUNITS
            ENDIF
        ENDIF
    ENDIF
ELSEIF (IPREPOST == 2) THEN
    IF ((SMOOTHING == "Y") .OR. (SMOOTHING == "y")) THEN
        WRITE (NORG,460)
        WRITE (NRDC,462)
        WRITE (NOUT,464)
    ENDIF
    IF (ITM == 1) THEN
        IF (ICN /= 2) THEN
            IF (ICN /= 4) THEN
                IF (SMOOTHING == "N") WRITE (NOUT,470) TUNITS,CUNITS
                IF (SMOOTHING == "Y") THEN
                    WRITE (NORG,470) TUNITS,CUNITS
                    WRITE (NRDC,470) TUNITS,CUNITS
                    WRITE (NOUT,480) TUNITS,CUNITS,CUNITS
                ENDIF
            ELSEIF (ICN == 4) THEN
                IF (SMOOTHING == "N") WRITE (NOUT,490) TUNITS,CUNITS
                IF (SMOOTHING == "Y") THEN
                    WRITE (NORG,490) TUNITS,CUNITS
                    WRITE (NRDC,490) TUNITS,CUNITS
                    WRITE (NOUT,500) TUNITS,CUNITS,CUNITS
                ENDIF
            ENDIF
        ELSE
            IF (SMOOTHING == "N") WRITE (NOUT,510) TUNITS,CUNITS
            IF (SMOOTHING == "Y") THEN
                WRITE (NORG,510) TUNITS,CUNITS
                WRITE (NRDC,510) TUNITS,CUNITS
                WRITE (NOUT,520) TUNITS,CUNITS,CUNITS
            ENDIF
        ENDIF
    ELSEIF (ITM == 2) THEN
        IF (ICN /= 2) THEN
            IF (ICN /= 4) THEN
                IF (SMOOTHING == "N") WRITE (NOUT,530) TUNITS,CUNITS
                IF (SMOOTHING == "Y") THEN
                    WRITE (NORG,530) TUNITS,CUNITS
                    WRITE (NRDC,530) TUNITS,CUNITS
                    WRITE (NOUT,540) TUNITS,CUNITS,CUNITS
                ENDIF
            ELSEIF (ICN == 4) THEN
                IF (SMOOTHING == "N") WRITE (NOUT,550) TUNITS,CUNITS
                IF (SMOOTHING == "Y") THEN
                    WRITE (NORG,550) TUNITS,CUNITS
                    WRITE (NRDC,550) TUNITS,CUNITS
                    WRITE (NOUT,560) TUNITS,CUNITS,CUNITS
                ENDIF
            ENDIF
        ELSE
            IF (SMOOTHING == "N") WRITE (NOUT,570) TUNITS,CUNITS
            IF (SMOOTHING == "Y") THEN
                WRITE (NORG,570) TUNITS,CUNITS
                WRITE (NRDC,570) TUNITS,CUNITS
                WRITE (NOUT,580) TUNITS,CUNITS,CUNITS
            ENDIF
        ENDIF
    ELSEIF (ITM == 3) THEN
        IF (ICN /= 2) THEN
            IF (ICN /= 4) THEN
                IF (SMOOTHING == "N") WRITE (NOUT,590) TUNITS,CUNITS
                IF (SMOOTHING == "Y") THEN
                    WRITE (NORG,590) TUNITS,CUNITS
                    WRITE (NRDC,590) TUNITS,CUNITS
                    WRITE (NOUT,600) TUNITS,CUNITS,CUNITS
                ENDIF
            ELSEIF (ICN == 4) THEN
                IF (SMOOTHING == "N") WRITE (NOUT,610) TUNITS,CUNITS
                IF (SMOOTHING == "Y") THEN
                    WRITE (NORG,610) TUNITS,CUNITS
                    WRITE (NRDC,610) TUNITS,CUNITS
                    WRITE (NOUT,620) TUNITS,CUNITS,CUNITS
                ENDIF
            ENDIF
        ELSE
            IF (SMOOTHING == "N") WRITE (NOUT,630) TUNITS,CUNITS
            IF (SMOOTHING == "Y") THEN
                WRITE (NORG,630) TUNITS,CUNITS
                WRITE (NRDC,630) TUNITS,CUNITS
                WRITE (NOUT,640) TUNITS,CUNITS,CUNITS
            ENDIF
        ENDIF
    ELSE
        IF (ICN /= 2) THEN
            IF (ICN /= 4) THEN
                IF (SMOOTHING == "N") WRITE (NOUT,650) TUNITS,CUNITS
                IF (SMOOTHING == "Y") THEN
                    WRITE (NORG,650) TUNITS,CUNITS
                    WRITE (NRDC,650) TUNITS,CUNITS
                    WRITE (NOUT,660) TUNITS,CUNITS,CUNITS
                ENDIF
            ELSEIF (ICN == 4) THEN
                IF (SMOOTHING == "N") WRITE (NOUT,670) TUNITS,CUNITS
                IF (SMOOTHING == "Y") THEN
                    WRITE (NORG,670) TUNITS,CUNITS
                    WRITE (NRDC,670) TUNITS,CUNITS
                    WRITE (NOUT,680) TUNITS,CUNITS,CUNITS
                ENDIF
            ENDIF
        ELSE
            IF (SMOOTHING == "N") WRITE (NOUT,690) TUNITS,CUNITS
            IF (SMOOTHING == "Y") THEN
                WRITE (NORG,690) TUNITS,CUNITS
                WRITE (NRDC,690) TUNITS,CUNITS
                WRITE (NOUT,700) TUNITS,CUNITS,CUNITS
            ENDIF
        ENDIF
    ENDIF
ELSE
    CALL EXECUTE_COMMAND_LINE("CLS")
    CALL EXECUTE_COMMAND_LINE("COLOR 0D")
    DO I = 1,3
        WRITE (*,*)
    ENDDO
    CALL NRERROR("       MISSING A '1' FOR PRE-TRACER RELEASE AND A '2' FOR POST-TRACER RELEASE!")
ENDIF
!...
!...BEGIN PREPARING FOR A SMOOTHING OPERATION
SELECT CASE (SMOOTHING)
    CASE ("Y","y")
        SELECT CASE (METHOD)
!...
!...OPEN A TEMPORARY FILE FOR EITHER A MOVING AVERAGE OR FOR MOVING MEDIAN FOR DATA PROCESSING
            CASE ("A","a","M","m")
                OPEN (NEWUNIT=ITMP, ACCESS = "SEQUENTIAL", STATUS = "SCRATCH", POSITION = "REWIND")
!...
!...OPEN A FILE FOR B-SPLINE ANALYSIS
            CASE ("B","b")
                FILESG = "B-SPLINE.OUT"
                OPEN  (NEWUNIT=ISG, FILE = FILESG, STATUS = "UNKNOWN", POSITION = "REWIND")
                INQUIRE(ISG, OPENED = OK)
                IF (.NOT. OK) OPEN(ISG, FILE = FILESG, STATUS = "UNKNOWN")
                WRITE (ISG,704)
!...
!...OPEN A FILE FOR CUBIC-SPLINE ANALYSIS
            CASE ("C","c")
                FILESG = "CUBIC-SPLINE.OUT"
                OPEN  (NEWUNIT=ISG, FILE = FILESG, STATUS = "UNKNOWN", POSITION = "REWIND")
                INQUIRE(ISG, OPENED = OK)
                IF (.NOT. OK) OPEN(ISG, FILE = FILESG, STATUS = "UNKNOWN")
                WRITE (ISG,706)
!...
!...OPEN A FILE FOR SAVISKY-GOLAY COEFFICIENTS AND SOLVE FOR THE SAVITZKY-GOLAY COEFFICIENTS
            CASE ("G","g")
                JJ = 1
                FILESG = "SAVITZKY-GOLAY.OUT"
                OPEN (NEWUNIT=ISG, FILE = FILESG, STATUS = "UNKNOWN", POSITION = "REWIND")
                INQUIRE(ISG, OPENED = OK)
                IF (.NOT. OK) OPEN(ISG, FILE = FILESG, STATUS = "UNKNOWN")
                WRITE (ISG,708)
!...
!...OPEN A FILE OF POLYNOMIAL-FIT ANALYSIS
            CASE ("P","p")
                FILESG = "POLYNOMIAL_FIT.OUT"
                OPEN (NEWUNIT=ISG, FILE = FILESG, STATUS = "UNKNOWN", POSITION = "REWIND")
                INQUIRE(ISG, OPENED = OK)
                IF (.NOT. OK) OPEN(ISG, FILE = FILESG, STATUS = "UNKNOWN")
                WRITE (ISG,712)
!...
!...OPEN A FILE FOR CURVE-FIT ANALYSIS
            CASE ("U","u")
                FILESG = "CURVE_FIT.OUT"
                OPEN  (NEWUNIT=ISG, FILE = FILESG, STATUS = "UNKNOWN", POSITION = "REWIND")
                INQUIRE(ISG, OPENED = OK)
                IF (.NOT. OK) OPEN(ISG, FILE = FILESG, STATUS = "UNKNOWN")
                WRITE (ISG,714)
            CASE ("E","e","K":"L","k":"l","Q","q","S","s","W","w")
                JJ = 1
        END SELECT
    CASE DEFAULT
        JJ = 1
        CONTINUE
END SELECT
!...
!...CONVERT DETECTION LIMIT TO �g/L FOR LEFT-CENSORED DATA DETERMINATION
DL = DL/THOU_W
!...
!...WRITE OUTPUT FILE (REDUCED ACCORDINGLY)
IF (IPREPOST == 1) THEN                                             !...PRE-INJECTION BACKGROUND DATA FILE
    SELECT CASE (SMOOTHING)
        CASE ("Y","y")
            DO I = 1,N2
                N5 = N5+1
                XS(N5) = X1(I)
                YS(N5) = Y1(I)*CONV
            ENDDO
            IF ((METHOD == "S") .OR. (METHOD == "s")) THEN
                CALL ARRAY_COPY (YS,YT,N_COPIED,N_NOT_COPIED)
                IF (N_NOT_COPIED > 0) THEN
                    CALL EXECUTE_COMMAND_LINE("CLS")
                    CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                    DO I = 1,3
                        WRITE (*,*)
                    ENDDO
                    CALL NRERROR("FATAL ERROR --> ARRAY YS NOT CORRECTLY COPIED TO ARRAY YT")
                ENDIF
            ENDIF
        CASE DEFAULT
            CONTINUE
    END SELECT
    N4 = 0
    DO J = 1,JJ
        DO I = 1,N2,NIREDUCE
!            IF (DL*MILLION_W > Y1(I))WRITE(*,*) I,Y1(I),DL*MILLION_W
            IF ((DL*MILLION_W > Y1(I)) .AND. (Y1(I) > ZERO_W)) THEN !...DETERMINE IF MEASURED DATA IS LEFT CENSORED OR REAL
                LEFT_CEN(I) = "C"                                   !..."C" = CENSORED DATA
            ELSE
                LEFT_CEN(I) = "R"                                   !..."R" = REAL DATA
            ENDIF
            N4 = N4+1
            SELECT CASE (SMOOTHING)
                CASE ("Y","y")
                    SELECT CASE (METHOD)
                        CASE ("A","a","M","m")
                            IF (NIREDUCE == 1) NIREDUCE = IMOVE
                            WRITE(ITMP,*) I, Y1(I)
                            MAVE = MOVE_STAT(METHOD,Y1(I),DEV)
                            NIREDUCE = 1
                            Y1(I) = MAVE
                            Z1(I) = DEV
                        CASE DEFAULT
                            CONTINUE
                    END SELECT
                CASE DEFAULT
                    CONTINUE
            END SELECT
            IF (JJ == 3) THEN
                IF (J < 3) EXIT
            ENDIF
        ENDDO
        IF (JJ == 3) THEN
            IF (J == 1) IMOVE = IMOVE2
            IF (J == 2) IMOVE = IMOVE3
            IF (J <  3) N4 = 0
        ENDIF
    ENDDO
    SELECT CASE (SMOOTHING)
        CASE ("Y","y")
            SELECT CASE (METHOD)
                CASE ("B","b")
                    WRITE (*,725)
                    NIREDUCE = 1
                    WX(:) = ONE_W
                    WY(:) = ONE_W
                    VALU = REAL(IREDUCE, KIND=WP)
!                    VALU = 1.0E+9_WP       !...FOR MODE=1
!                    VALU = 1300.0_WP       !...FOR MODE=4
                    MODE = 2
                    AT = (X1(N1/2+1) - X1(N1/2))
                    IF ((N1 < 2*MORDER) .OR. (N1 > N1)) N1 = N1
                    IF ((MODE == 0) .OR. (IABS(MODE) > 5) .OR. (MORDER <= 0) .OR. (MORDER > MM)) CALL NRERROR("GCVTST: FAILURE")
                    CALL GCVSPL(X1,Y1,N1,WX,WY,MORDER,N1,K,MODE,VALU,YT,N1,WK,IER)
                    IF (IER /= 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        WRITE (*,*)  "IER =",IER
                        CALL NRERROR("FATAL ERROR IN GCVTST")
                    ELSE
                        VAR = WK(6)
                        IF (WK(4) == ZERO_W) THEN
                            FRE = HALF_W/AT
                        ELSE
                            FRE = HALF_W/PI_W * WK(4)*AT**(-HALF_W/MORDER)
                        ENDIF
                    ENDIF
                    WRITE (ISG,716) IER, AT, VAR, (WK(I), I=1,4), FRE
                    YT(N1-1) = Y1(N1-1)
                    YT(N1) = Y1(N1)
                    IDM = MIN0(2,MORDER)
                    YG(2) = ZERO_W
                    DO I = 1,N1
                        J = I
                        DO IDER = 0,IDM
                            YG(IDER) = SPLDER(IDER,MORDER,N1,X1(I),X1,YT,J,YL)
                        ENDDO
                        YT(I) = YG(0)
                        WRITE (ISG,718) I, X1(I), Y1(I), (YG(IDER), IDER=0,IDM)
                    ENDDO
                    CALL ARRAY_COPY (YT,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY YT NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
                    DEALLOCATE(YG, STAT=IERR)
                    DEALLOCATE(YL, STAT=IERR)
                    DEALLOCATE(WX, STAT=IERR)
                    DEALLOCATE(WY, STAT=IERR)
                    CLOSE (UNIT=ISG, STATUS = "KEEP")
                CASE ("C","c")
                    JOB   = 1
                    VAR   = -ONE_W
                    DF(:) =  ONE_W
                    CALL CUBGCV (X1,Y1,DF,N1,YT,CT,IC,VAR,JOB,SE,WK,IER)
                    WRITE (ISG,720) IER, VAR, WK(3), WK(4), WK(2)
                    DO I = 1,N1-1
                        WRITE (ISG,722) I, X1(I), Y1(I), YT(I), SE(I), CT(I,1:3)
                    ENDDO
                    WRITE (ISG,722) N1, X1(N1), Y1(N1), YT(N1), SE(N1)
                    CALL ARRAY_COPY (YT,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY YT NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
                    CLOSE (UNIT=ISG, STATUS = "KEEP")
                CASE ("E","e")
                    LAMBDA = TEN_W*(REAL(N3, KIND=WP) / REAL(N1, KIND=WP))
                    CALL INITIALIZE(LAMBDA)
                    MAVE = FIVE_W
                    DEV  = ONE_W
                    DO I = 1,N1
                        CALL UPDATE(I,N1,Y1(I),MAVE,DEV)
                        Y1(I) = MAVE
                        Z1(I) = SQRT(VARIANCE(DEV))
                    ENDDO
                CASE ("F","f")
                    FR_CNTL = REAL(IREDUCE, KIND=WP)*ONE_W
                    CALL BUTTERWORTH_FILTER (N1,X1,Y1,FR_CNTL,YT,CONV)
                    CALL ARRAY_COPY (YT,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY YT NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
                CASE ("G","g")
                    CC = SAVGOL(NL,NR,LD,MORDER)
                    INDX(1) = 0                                     !...SEEK SHIFT INDEX FOR GIVEN CASE NL, NR, M (SEE SAVGOL)
                    J = 3                                           !...EXAMPLE: CASE NL=NR=5; INDEX(2)=-1; INDEX(3)=-2; INDEX(4)=-3; INDEX(5)=-4; INDEX(6)=-5
                    DO I = 2,NL+1
                        INDX(I) = I-J
                        J = J+2
                    ENDDO
                    J = 2                                           !...INDEX(7)=5; INDEX(8)=4; INDEX(9)=3; INDEX(10)=2; INDEX(11)=1
                    DO I = NL+2,NL+NR+1
                        INDX(I) = I-J
                        J = J+2
                    ENDDO
                    CALL ARRAY_COPY (Y1,Y2,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY Y1 NOT CORRECTLY COPIED TO ARRAY Y2")
                    ENDIF
                    WRITE (ISG,723) NL, NR, MORDER                  !...PRINT SAVITZKY-GOLAY ANALYSIS RESULTS
                    DO I = 1,NL+NR+1
                        WRITE (ISG,724) I, CC(I)
                    ENDDO
                    CLOSE (UNIT=ISG, STATUS = "KEEP")
                    DO I = 1,N1-NR                                  !...APPLY SAVITZKY-GOLAY FILTER TO INPUT DATA
                        Y2(I) = ZERO_W
                        DO J = 1,NL+NR+1
                            IF (I+INDX(J) > 0) THEN                 !...SKIP LEFT POINTS THAT DO NOT EXIST
                                Y2(I) = Y2(I)+CC(J)*Y1(I+INDX(J))
                            ENDIF
                        ENDDO
                    ENDDO
                    NIREDUCE = 1
                    CALL ARRAY_COPY (Y2,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY Y2 NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
                CASE ("K","k")
                    NIREDUCE = 1
                    WRITE (*,725)
                    IF (MORDER == 1) THEN
                        CALL GLKERN(X1,Y1,N4,X1,N4,IHOM,NUE,KORD,IRND,ISMO,M1,TL,TU,S1,SIG,BB,YG)
                        CALL ARRAY_COPY (YG,Y1,N_COPIED,N_NOT_COPIED)
                        IF (N_NOT_COPIED > 0) THEN
                            CALL EXECUTE_COMMAND_LINE("CLS")
                            CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                            DO I = 1,3
                                WRITE (*,*)
                            ENDDO
                            CALL NRERROR("FATAL ERROR --> ARRAY YG NOT CORRECTLY COPIED TO ARRAY Y1")
                        ENDIF
                        DEALLOCATE(YG, STAT=IERR)
                    ELSE
                        CALL LOKERN(X1,Y1,N4,X1,N4,IHOM,NUE,KORD,IRND,ISMO,M1,TL,TU,S1,SIG,BAN,YL)
                        CALL ARRAY_COPY (YL,Y1,N_COPIED,N_NOT_COPIED)
                        IF (N_NOT_COPIED > 0) THEN
                            CALL EXECUTE_COMMAND_LINE("CLS")
                            CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                            DO I = 1,3
                                WRITE (*,*)
                            ENDDO
                            CALL NRERROR("FATAL ERROR --> ARRAY YL NOT CORRECTLY COPIED TO ARRAY Y1")
                        ENDIF
                        DEALLOCATE(YL, STAT=IERR)
                    ENDIF
                CASE ("L","l")
                    WRITE (*,725)
                    CALL LOWESS(X1,Y1,N1,FL,NSTEPS,DELTA,YT,RW,RES)
                    CALL ARRAY_COPY (YT,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY YT NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
                    DEALLOCATE(YT, STAT=IERR)
                CASE ("P","p")
                    NIREDUCE = 1
                    WRITE (*,725)
                    CALL FIT_POLY(ISG,X1,Y1,YT,MORDER,N1)
                    CALL ARRAY_COPY (YT,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY YT NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
                    DEALLOCATE(YT, STAT=IERR)
                CASE ("Q","q")
                    NIREDUCE = 1
                    WRITE (*,725)
                    CALL QUINTIC_SPLINE(X1,Y1,N1,IREDUCE,CONV)
                CASE ("S","s")
                    NIREDUCE = 1
                    CALL SMOOTH(Y1,N1,IREDUCE)
                    CALL ARRAY_COPY (Y1*TWO_W,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY Y1*TWO_W NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
                CASE ("U","u")
                    WRITE (*,725)
!...
!...SET WEIGHTS MULTIPLIER
                    WMULT = ONE_W
                    IF (MAXVALY1 > HUNDTH_W .AND. MAXVALY1 <= TENTH_W) THEN
                        WMULT = TEN_W
                    ELSEIF (MAXVALY1 > TENTH_W .AND. MAXVALY1 <= FIFTH_W) THEN
                        WMULT = FIVE_W
                    ELSEIF (MAXVALY1 > FIFTH_W .AND. MAXVALY1 <= ONE_W) THEN
                        WMULT = ONE_W
                    ELSEIF (MAXVALY1 > ONE_W .AND. MAXVALY1 <= FIVE_W) THEN
                        WMULT = FIFTH_W
                    ELSEIF (MAXVALY1 > FIVE_W .AND. MAXVALY1 <= TEN_W) THEN
                        WMULT = TENTH_W
                    ELSEIF (MAXVALY1 > TEN_W .AND. MAXVALY1 <= HUND_W) THEN
                        WMULT = HUNDTH_W
                    ELSEIF (MAXVALY1 > HUND_W .AND. MAXVALY1 <= THOU_W) THEN
                        WMULT = THOUTH_W
                    ENDIF
!...
!...SET WEIGHTS FOR FIRST HALF OF BTC
                    CW1 = 1.963E-9_WP
                    CW2 = 4.55E-10_WP
                    N6 = 0
                    J  = -2
                    DO I = 1,N1/2
                        WW(I) = REAL(I, KIND=WP)*CW1*WMULT
                        N6 = I
                    ENDDO
!...
!...SET WEIGHTS FOR SECOND HALF OF BTC
                    DO I = N1/2,N1
                        J = J+1
                        WW(I) = REAL((N6-J), KIND=WP)*CW2*WMULT
                    ENDDO
                    NN = N1
                    SS = FOUR_W
                    XB = MINVAL(X1)
                    XE = MAXVAL(X1)
                    IF (IOPT == -1) THEN
                        DO I = KK+2,NN-KK-1
                            TT(I) = X1(I)
                        ENDDO
                    ENDIF
                    CALL CURFIT(IOPT,N1,X1,Y1,WW,XB,XE,KK,SS,NEST,NN,TT,TC,FP,WRK,LWRK,IWRK,IER)
                    CALL SPLEV(TT,NN,TC,KK,X1,YT,N1,IER)
                    CALL CRFRPT(ISG,KK,SS,FP,IER,NN,N1,TT,TC,X1,Y1,YT)
                    CLOSE (UNIT=ISG, STATUS = "KEEP")
                    CALL ARRAY_COPY (YT,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY YT NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
                    DEALLOCATE(WW,   STAT=IERR)
                    DEALLOCATE(TT,   STAT=IERR)
                    DEALLOCATE(TC,   STAT=IERR)
                    DEALLOCATE(WRK,  STAT=IERR)
                    DEALLOCATE(IWRK, STAT=IERR)
                CASE ("W","w")
                    NIREDUCE = 1
                    WEIGHT = REAL(IREDUCE, KIND=WP)*HUNDTH_W
                    CALL WEIGHTED_QUINTIC(N1,X1,Y1,WEIGHT,YT,CONV)
                    CALL ARRAY_COPY (YT,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY YT NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
            END SELECT
        CASE DEFAULT
            N5 = N1
    END SELECT
    DO I = 1,N4
        IF (Y1(I) < ZERO_W) Y1(I) = ZERO_W
        XP(I) = X1(I)
        YP(I) = Y1(I)*CONV
    ENDDO
    SELECT CASE (SMOOTHING)
        CASE ("N","n")
            DO I = 1,N4,IREDUCE
                NCTT = NCTT+1
                IF (ITM == 1) THEN
                    WRITE (NOUT,730) X1(I), Y1(I)*CONV, LEFT_CEN(I)
                ELSEIF (ITM == 2) THEN
                    WRITE (NOUT,750) X1(I), Y1(I)*CONV, LEFT_CEN(I)
                ELSEIF (ITM == 3) THEN
                    WRITE (NOUT,770) X1(I), Y1(I)*CONV, LEFT_CEN(I)
                ELSEIF (ITM == 4) THEN
                    WRITE (NOUT,790) X1(I), Y1(I)*CONV, LEFT_CEN(I)
                ENDIF
            ENDDO
        CASE ("Y","y")
            DO I = 1,N4
                NCTT = NCTT+1
                IF (ITM == 1) THEN
                    WRITE (NOUT,730) X1(I), Y1(I)*CONV, LEFT_CEN(I)
                    IF (NCTT < IREDUCE) THEN
                        WRITE (NRDC,740) X1(I), YS(I)
                    ELSE
                        NCTT = 0
                        WRITE (NRDC,740) X1(I), YS(I), Y1(I)*CONV
                    ENDIF
                ELSEIF (ITM == 2) THEN
                    WRITE (NOUT,750) X1(I), Y1(I)*CONV, LEFT_CEN(I)
                    IF (NCTT < IREDUCE) THEN
                        WRITE (NRDC,760) X1(I), YS(I)
                    ELSE
                        NCTT = 0
                        WRITE (NRDC,760) X1(I), YS(I), Y1(I)*CONV
                    ENDIF
                ELSEIF (ITM == 3) THEN
                    WRITE (NOUT,770) X1(I), Y1(I)*CONV, LEFT_CEN(I)
                    IF (NCTT < IREDUCE) THEN
                        WRITE (NRDC,780) X1(I), YS(I)
                    ELSE
                        NCTT = 0
                        WRITE (NRDC,780) X1(I), YS(I), Y1(I)*CONV
                    ENDIF
                ELSEIF (ITM == 4) THEN
                    WRITE (NOUT,790) X1(I), Y1(I)*CONV, LEFT_CEN(I)
                    IF (NCTT < IREDUCE) THEN
                        WRITE (NRDC,800) X1(I), YS(I)
                    ELSE
                        NCTT = 0
                        WRITE (NRDC,800) X1(I), YS(I), Y1(I)*CONV
                    ENDIF
                ENDIF
            ENDDO
    END SELECT
ELSEIF (IPREPOST == 2) THEN                                         !...POST-INJECTION RECOVERY DATA FILE
    SELECT CASE (SMOOTHING)
        CASE ("Y","y")
            DO I = 1,N1
                N5 = N5+1
                XS(N5) = X1(I)
                YS(N5) = Y1(I)*CONV
            ENDDO
            IF ((METHOD == "S") .OR. (METHOD == "s"))  THEN
                CALL ARRAY_COPY (YS,YT,N_COPIED,N_NOT_COPIED)
                IF (N_NOT_COPIED > 0) THEN
                    CALL EXECUTE_COMMAND_LINE("CLS")
                    CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                    DO I = 1,3
                        WRITE (*,*)
                    ENDDO
                    CALL NRERROR("FATAL ERROR --> ARRAY YS NOT CORRECTLY COPIED TO ARRAY YT")
                ENDIF
            ENDIF
        CASE DEFAULT
            CONTINUE
    END SELECT
    N4 = 0
    N2 = N2+1
    DO J = 1,JJ
        DO I = N2,N1,NIREDUCE
            N4 = N4+1
            SELECT CASE (SMOOTHING)
                CASE ("Y","y")
                    SELECT CASE (METHOD)
                        CASE ("A","a","M","m")
                            IF (NIREDUCE == 1) NIREDUCE = IMOVE
                            WRITE (ITMP,*) I, Y1(I)
                            MAVE = MOVE_STAT(METHOD,Y1(I),DEV)
                            NIREDUCE = 1
                            Y1(I) = MAVE
                            Z1(I) = DEV
                        CASE DEFAULT
                            CONTINUE
                    END SELECT
                CASE DEFAULT
                    CONTINUE
            END SELECT
            IF (JJ == 3) THEN
                IF (J < 3) EXIT
            ENDIF
        ENDDO
        IF (JJ == 3) THEN
            IF (J == 1) IMOVE = IMOVE2
            IF (J == 2) IMOVE = IMOVE3
            IF (J <  3) N4 = 0
        ENDIF
    ENDDO
    SELECT CASE (SMOOTHING)
        CASE ("Y","y")
            SELECT CASE (METHOD)
                CASE ("B","b")
                    WRITE (*,725)
                    NIREDUCE = 1
                    WX(:) = ONE_W
                    WY(:) = ONE_W
                    VALU = REAL(IREDUCE, KIND=WP)
!                    VALU = 1.0E+9_WP       !...FOR MODE=1
!                    VALU = 1300.0_WP       !...FOR MODE=4
                    MODE = 2
                    AT = (X1(N1/2+1) - X1(N1/2))
                    IF ((N1 < 2*MORDER) .OR. (N1 > N1)) N1 = N1
                    IF ((MODE == 0) .OR. (IABS(MODE) > 5) .OR. (MORDER <= 0) .OR. (MORDER > MM)) CALL NRERROR("GCVTST: FAILURE")
                    CALL GCVSPL(X1,Y1,N1,WX,WY,MORDER,N1,K,MODE,VALU,YT,N1,WK,IER)
                    IF (IER /= 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        WRITE (*,*)  "IER =",IER
                        CALL NRERROR("FATAL ERROR IN GCVTST")
                    ELSE
                        VAR = WK(6)
                        IF (WK(4) == ZERO_W) THEN
                            FRE = HALF_W/AT
                        ELSE
                            FRE = HALF_W/PI_W * WK(4)*AT**(-HALF_W/MORDER)
                        ENDIF
                    ENDIF
                    WRITE (ISG,716) IER, AT, VAR, (WK(I), I=1,4), FRE
                    YT(N1-1) = Y1(N1-1)
                    YT(N1) = Y1(N1)
                    IDM = MIN0(2,MORDER)
                    YG(2) = ZERO_W
                    DO I = 1,N1
                        J = I
                        DO IDER = 0,IDM
                            YG(IDER) = SPLDER(IDER,MORDER,N1,X1(I),X1,YT,J,YL)
                        ENDDO
                        YT(I) = YG(0)
                        WRITE (ISG,718) I, X1(I), Y1(I), (YG(IDER), IDER=0,IDM)
                    ENDDO
                    CALL ARRAY_COPY (YT,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY YT NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
                    DEALLOCATE(YG, STAT=IERR)
                    DEALLOCATE(YL, STAT=IERR)
                    DEALLOCATE(WX, STAT=IERR)
                    DEALLOCATE(WY, STAT=IERR)
                    CLOSE (UNIT=ISG, STATUS = "KEEP")
                CASE ("C","c")
                    JOB   = 1
                    VAR   = -ONE_W
                    DF(:) =  ONE_W
                    WRITE (*,725)
                    CALL CUBGCV (X1,Y1,DF,N1,YT,CT,IC,VAR,JOB,SE,WK,IER)
                    WRITE (ISG,720) IER, VAR, WK(3), WK(4), WK(2)
                    DO I = 1,N1-1
                        WRITE (ISG,722) I, X1(I), Y1(I), YT(I), SE(I), CT(I,1:3)
                    ENDDO
                    WRITE (ISG,722) N1, X1(N1), Y1(N1), YT(N1), SE(N1)
                    CALL ARRAY_COPY (YT,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY YT NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
                    CLOSE (UNIT=ISG, STATUS = "KEEP")
                CASE ("E","e")
                    LAMBDA = TEN_W*(REAL(N3, KIND=WP) / REAL(N1, KIND=WP))
                    CALL INITIALIZE(LAMBDA)
                    MAVE = FIVE_W
                    DEV  = ONE_W
                    DO I = 1,N1
                        CALL UPDATE(I,N1,Y1(I),MAVE,DEV)
                        Y1(I) = MAVE
                        Z1(I) = SQRT(VARIANCE(DEV))
                    ENDDO
                CASE ("F","f")
                    FR_CNTL = REAL(IREDUCE, KIND=WP)*ONE_W
                    CALL BUTTERWORTH_FILTER (N1,X1,Y1,FR_CNTL,YT,CONV)
                    CALL ARRAY_COPY (YT,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY YT NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
                CASE ("G","g")
                    INDX(1) = 0                                     !...SEEK SHIFT INDEX FOR GIVEN CASE NL, NR, M (SEE SAVGOL)
                    J = 3                                           !...EXAMPLE: CASE NL=NR=5; INDEX(2)=-1; INDEX(3)=-2; INDEX(4)=-3; INDEX(5)=-4; INDEX(6)=-5
                    DO I = 2,NL+1
                        INDX(I) = I-J
                        J = J+2
                    ENDDO
                    J = 2                                           !...INDEX(7)=5; INDEX(8)=4; INDEX(9)=3; INDEX(10)=2; INDEX(11)=1
                    DO I = NL+2,NL+NR+1
                        INDX(I) = I-J
                        J = J+2
                    ENDDO
                    CALL ARRAY_COPY (Y1,Y2,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY Y1 NOT CORRECTLY COPIED TO ARRAY Y2")
                    ENDIF
                    CC = SAVGOL(NL,NR,LD,MORDER)
                    WRITE (ISG,723) NL, NR, MORDER                  !...PRINT SAVITZKY-GOLAY ANALYSIS RESULTS
                    DO I = 1,NL+NR+1
                        WRITE (ISG,724) I, CC(I)
                    ENDDO
                    CLOSE (UNIT=ISG, STATUS = "KEEP")
                    DO I = 1,N1-NR                                  !...APPLY SAVITZKY-GOLAY FILTER TO INPUT DATA
                        Y2(I) = ZERO_W
                        DO J = 1,NL+NR+1
                            IF (I+INDX(J) > 0) THEN                 !...SKIP LEFT POINTS THAT DO NOT EXIST
                                Y2(I) = Y2(I)+CC(J)*Y1(I+INDX(J))
                            ENDIF
                        ENDDO
                    ENDDO
                    NIREDUCE = 1
                    CALL ARRAY_COPY (Y2,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY Y2 NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
                CASE ("K","k")
                    NIREDUCE = 1
                    WRITE (*,725)
                    IF (MORDER == 1) THEN
                        CALL GLKERN(X1,Y1,N1,X1,N1,IHOM,NUE,KORD,IRND,ISMO,IREDUCE,TL,TU,S1,SIG,BB,YG)
                        CALL ARRAY_COPY (YG,Y1,N_COPIED,N_NOT_COPIED)
                        IF (N_NOT_COPIED > 0) THEN
                            CALL EXECUTE_COMMAND_LINE("CLS")
                            CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                            DO I = 1,3
                                WRITE (*,*)
                            ENDDO
                            CALL NRERROR("FATAL ERROR --> ARRAY YG NOT CORRECTLY COPIED TO ARRAY Y1")
                        ENDIF
                        DEALLOCATE(YG, STAT=IERR)
                    ELSE
                        CALL LOKERN(X1,Y1,N1,X1,N1,IHOM,NUE,KORD,IRND,ISMO,IREDUCE,TL,TU,S1,SIG,BAN,YL)
                        CALL ARRAY_COPY (YL,Y1,N_COPIED,N_NOT_COPIED)
                        IF (N_NOT_COPIED > 0) THEN
                            CALL EXECUTE_COMMAND_LINE("CLS")
                            CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                            DO I = 1,3
                                WRITE (*,*)
                            ENDDO
                            CALL NRERROR("FATAL ERROR --> ARRAY YL NOT CORRECTLY COPIED TO ARRAY Y1")
                        ENDIF
                        DEALLOCATE(YL, STAT=IERR)
                    ENDIF
                CASE ("L","l")
                    WRITE (*,725)
                    CALL LOWESS(X1,Y1,N1,FL,NSTEPS,DELTA,YT,RW,RES)
                    CALL ARRAY_COPY (YT,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY YT NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
                    DEALLOCATE(YT, STAT=IERR)
                CASE ("P","p")
                    NIREDUCE = 1
                    WRITE (*,725)
                    CALL FIT_POLY(ISG,X1,Y1,YT,MORDER,N1)
                    CALL ARRAY_COPY (YT,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY YT NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
                    DEALLOCATE(YT, STAT=IERR)
                CASE ("Q","q")
                    NIREDUCE = 1
                    WRITE (*,725)
                    CALL QUINTIC_SPLINE(X1,Y1,N1,IREDUCE,CONV)
                CASE ("S","s")
                    NIREDUCE = 1
                    CALL SMOOTH(Y1,N1,IREDUCE)
                    CALL ARRAY_COPY (Y1*TWO_W,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY Y1*TWO_W NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
                CASE ("U","u")
                    WRITE (*,725)
!...
!...SET WEIGHTS MULTIPLIER
                    WMULT = ONE_W
                    IF (MAXVALY1 > HUNDTH_W .AND. MAXVALY1 <= TENTH_W) THEN
                        WMULT = TEN_W
                    ELSEIF (MAXVALY1 > TENTH_W .AND. MAXVALY1 <= FIFTH_W) THEN
                        WMULT = FIVE_W
                    ELSEIF (MAXVALY1 > FIFTH_W .AND. MAXVALY1 <= ONE_W) THEN
                        WMULT = ONE_W
                    ELSEIF (MAXVALY1 > ONE_W .AND. MAXVALY1 <= FIVE_W) THEN
                        WMULT = FIFTH_W
                    ELSEIF (MAXVALY1 > FIVE_W .AND. MAXVALY1 <= TEN_W) THEN
                        WMULT = TENTH_W
                    ELSEIF (MAXVALY1 > TEN_W .AND. MAXVALY1 <= HUND_W) THEN
                        WMULT = HUNDTH_W
                    ELSEIF (MAXVALY1 > HUND_W .AND. MAXVALY1 <= THOU_W) THEN
                        WMULT = THOUTH_W
                    ENDIF
!...
!...SET WEIGHTS FOR FIRST HALF OF BTC
                    CW1 = 1.963E-9_WP
                    CW2 = 4.55E-10_WP
                    N6 = 0
                    J  = -2
                    DO I = 1,N1/2
                        WW(I) = REAL(I, KIND=WP)*CW1*WMULT
                        N6 = I
                    ENDDO
!...
!...SET WEIGHTS FOR SECOND HALF OF BTC
                    DO I = N1/2,N1
                        J = J+1
                        WW(I) = REAL((N6-J), KIND=WP)*CW2*WMULT
                    ENDDO
                    NN = N1
                    SS = FOUR_W
                    XB = MINVAL(X1)
                    XE = MAXVAL(X1)
                    IF (IOPT == -1) THEN
                        DO I = KK+2,NN-KK-1
                            TT(I) = X1(I)
                        ENDDO
                    ENDIF
                    CALL CURFIT(IOPT,N1,X1,Y1,WW,XB,XE,KK,SS,NEST,NN,TT,TC,FP,WRK,LWRK,IWRK,IER)
                    CALL SPLEV(TT,NN,TC,KK,X1,YT,N1,IER)
                    CALL CRFRPT(ISG,KK,SS,FP,IER,NN,N1,TT,TC,X1,Y1,YT)
                    CLOSE (UNIT=ISG, STATUS = "KEEP")
                    CALL ARRAY_COPY (YT,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY YT NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
                    DEALLOCATE(WW,   STAT=IERR)
                    DEALLOCATE(TT,   STAT=IERR)
                    DEALLOCATE(TC,   STAT=IERR)
                    DEALLOCATE(WRK,  STAT=IERR)
                    DEALLOCATE(IWRK, STAT=IERR)
                CASE ("W","w")
                    NIREDUCE = 1
                    WEIGHT = REAL(IREDUCE, KIND=WP)*HUNDTH_W
                    CALL WEIGHTED_QUINTIC(N1,X1,Y1,WEIGHT,YT,CONV)
                    CALL ARRAY_COPY (YT,Y1,N_COPIED,N_NOT_COPIED)
                    IF (N_NOT_COPIED > 0) THEN
                        CALL EXECUTE_COMMAND_LINE("CLS")
                        CALL EXECUTE_COMMAND_LINE("COLOR 0D")
                        DO I = 1,3
                            WRITE (*,*)
                        ENDDO
                        CALL NRERROR("FATAL ERROR --> ARRAY YT NOT CORRECTLY COPIED TO ARRAY Y1")
                    ENDIF
            END SELECT
        CASE DEFAULT
            N5 = N1
    END SELECT
    IF ((METHOD == "S") .OR. (METHOD == "s")) THEN
        CALL ARRAY_COPY (YT,YS,N_COPIED,N_NOT_COPIED)
        IF (N_NOT_COPIED > 0) THEN
            CALL EXECUTE_COMMAND_LINE("CLS")
            CALL EXECUTE_COMMAND_LINE("COLOR 0D")
            DO I = 1,3
                WRITE (*,*)
            ENDDO
            CALL NRERROR("FATAL ERROR --> ARRAY YT NOT CORRECTLY COPIED TO ARRAY YS")
        ENDIF
    ENDIF
    DO I = 1,N1
        IF (Y1(I) < ZERO_W) Y1(I) = ZERO_W
        XP(I)  = X1(I)
        YP(I)  = Y1(I)*CONV
        RP(I)  = YS(I)-YP(I)
        RP2(I) = RP(I)*RP(I)
    ENDDO
    SELECT CASE (SMOOTHING)
        CASE ("N","n")
            DO I = 1,N1,IREDUCE
                IF (ITM == 1) THEN
                    IF (MARKER(I) /= "*") THEN
                        WRITE (NOUT,730) X1(I),Y1(I)*CONV
                    ELSE
                        WRITE (NOUT,730) X1(I),Y1(I)*CONV,MARKER(I)
                    ENDIF
                ELSEIF (ITM == 2) THEN
                    IF (MARKER(I) /= "*") THEN
                        WRITE (NOUT,750) X1(I),Y1(I)*CONV
                    ELSE
                        WRITE (NOUT,750) X1(I),Y1(I)*CONV,MARKER(I)
                    ENDIF
                ELSEIF (ITM == 3) THEN
                    IF (MARKER(I) /= "*") THEN
                        WRITE (NOUT,770) X1(I),Y1(I)*CONV
                    ELSE
                        WRITE (NOUT,770) X1(I),Y1(I)*CONV,MARKER(I)
                    ENDIF
                ELSEIF (ITM == 4) THEN
                    IF (MARKER(I) /= "*") THEN
                        WRITE (NOUT,790) X1(I),Y1(I)*CONV
                    ELSE
                        WRITE (NOUT,790) X1(I),Y1(I)*CONV,MARKER(I)
                    ENDIF
                ENDIF
            ENDDO
        CASE ("Y","y")
            DO I = 1,N1
                NCTT = NCTT+1
                IF (ITM == 1) THEN
                    IF (MARKER(I) /= "*") THEN
                        WRITE (NORG,730) X1(I),YS(I)
                        WRITE (NRDC,730) X1(I),Y1(I)*CONV
                        IF (NCTT < IREDUCE) THEN
                            IF (MARKER(I) /= "*") THEN
                                WRITE (NOUT,740) X1(I),YS(I)
                            ELSE
                                NCTT = 0
                                WRITE (NOUT,740) X1(I),YS(I),Y1(I)*CONV
                            ENDIF
                        ENDIF
                    ELSE
                        WRITE (NORG,730) X1(I),YS(I),MARKER(I)
                        WRITE (NRDC,730) X1(I),Y1(I)*CONV,MARKER(I)
                        IF (NCTT < IREDUCE) THEN
                            IF (MARKER(I) /= "*") THEN
                                WRITE (NOUT,745) X1(I),YS(I),MARKER(I)
                            ELSE
                                NCTT = 0
                                WRITE (NOUT,745) X1(I),YS(I),Y1(I)*CONV,MARKER(I)
                            ENDIF
                        ENDIF
                    ENDIF
                ELSEIF (ITM == 2) THEN
                    IF (MARKER(I) /= "*") THEN
                        WRITE (NORG,750) X1(I),YS(I)
                        WRITE (NRDC,750) X1(I),Y1(I)*CONV
                        IF (NCTT < IREDUCE) THEN
                            WRITE (NOUT,760) X1(I),YS(I)
                        ELSE
                            NCTT = 0
                            WRITE (NOUT,760) X1(I),YS(I),Y1(I)*CONV
                        ENDIF
                    ELSE
                        WRITE (NORG,750) X1(I),YS(I),MARKER(I)
                        WRITE (NRDC,750) X1(I),Y1(I)*CONV,MARKER(I)
                        IF (NCTT < IREDUCE) THEN
                            IF (MARKER(I) /= "*") THEN
                                WRITE (NOUT,765) X1(I),YS(I),MARKER(I)
                            ELSE
                                NCTT = 0
                                WRITE (NOUT,765) X1(I),YS(I),Y1(I)*CONV,MARKER(I)
                            ENDIF
                        ENDIF
                    ENDIF
                ELSEIF (ITM == 3) THEN
                    IF (MARKER(I) /= "*") THEN
                        WRITE (NORG,770) X1(I),YS(I)
                        WRITE (NRDC,770) X1(I),Y1(I)*CONV
                        IF (NCTT < IREDUCE) THEN
                            WRITE (NOUT,780) X1(I),YS(I)
                        ELSE
                            NCTT = 0
                            WRITE (NOUT,780) X1(I),YS(I),Y1(I)*CONV
                        ENDIF
                    ELSE
                        WRITE (NORG,770) X1(I),YS(I),MARKER(I)
                        WRITE (NRDC,770) X1(I),Y1(I)*CONV,MARKER(I)
                        IF (NCTT < IREDUCE) THEN
                            IF (MARKER(I) /= "*") THEN
                                WRITE (NOUT,785) X1(I),YS(I),MARKER(I)
                            ELSE
                                NCTT = 0
                                WRITE (NOUT,785) X1(I),YS(I),Y1(I)*CONV,MARKER(I)
                            ENDIF
                        ENDIF
                    ENDIF
                ELSEIF (ITM == 4) THEN
                    IF (MARKER(I) /= "*") THEN
                        WRITE (NORG,790) X1(I),YS(I)
                        WRITE (NRDC,790) X1(I),Y1(I)*CONV
                        IF (NCTT < IREDUCE) THEN
                            WRITE (NOUT,800) X1(I),YS(I)
                        ELSE
                            NCTT = 0
                            WRITE (NOUT,800) X1(I),YS(I),Y1(I)*CONV
                        ENDIF
                    ELSE
                        WRITE (NORG,790) X1(I),YS(I),MARKER(I)
                        WRITE (NRDC,790) X1(I),Y1(I)*CONV,MARKER(I)
                        IF (NCTT < IREDUCE) THEN
                            IF (MARKER(I) /= "*") THEN
                                WRITE (NOUT,805) X1(I),YS(I),MARKER(I)
                            ELSE
                                NCTT = 0
                                WRITE (NOUT,805) X1(I),YS(I),Y1(I)*CONV,MARKER(I)
                            ENDIF
                        ENDIF
                    ENDIF
                ENDIF
            ENDDO
    END SELECT
ELSE
    CALL NRERROR("       MISSING A '1' FOR PRE-TRACER RELEASE AND A '2' FOR POST-TRACER RELEASE!")
ENDIF
DO I = 1,N1
    IF (Y1(I) < ZERO_W) THEN
!        WRITE(*,*) I, Y1(I)
        Y1(I) = ZERO_W
    ENDIF
ENDDO
!...
!...CALCULATE SAMPLING PERIOD (IN WEEKS, DAYS, HOURS, MINUTES, AND SECONDS AS APPROPRIATE)
IF (IPREPOST == 1) THEN !USE X3 FOR THIS ROUTINE
    X3 = X1(1)
ELSEIF (IPREPOST == 2) THEN
    X3 = X1(N1)
ENDIF
IF (ITM == 1) THEN
    SAMPLING_PERIOD = (X3 - ZERO_W)*TDAY_W
ELSEIF (ITM == 2) THEN
    SAMPLING_PERIOD = (X3 - ZERO_W)*THR_W
ELSEIF (ITM == 3) THEN
    SAMPLING_PERIOD = (X3 - ZERO_W)*TMIN_W
ELSEIF (ITM == 4) THEN
    SAMPLING_PERIOD = (X3 - ZERO_W)
ENDIF
CALL PROUST (SAMPLING_PERIOD,IPREPOST,1)
!...
!...REPEAT ABOVE CALCULATION FOR PERIOD REFLECTING TRACER DETECTIONS ONLY
IF (IPREPOST == 2) THEN
    IF (ITM == 1) THEN
        SAMPLING_PERIOD = (X3 - X1(N2))*TDAY_W
    ELSEIF (ITM == 2) THEN
        SAMPLING_PERIOD = (X3 - X1(N2))*THR_W
    ELSEIF (ITM == 3) THEN
        SAMPLING_PERIOD = (X3 - X1(N2))*TMIN_W
    ELSEIF (ITM == 4) THEN
        SAMPLING_PERIOD = (X3 - X1(N2))
    ENDIF
    CALL PROUST (SAMPLING_PERIOD,IPREPOST,2)
ENDIF
!...
!...DETERMINE MAXIMUM HEIGHT OF THE DATA PLOT (PEAK CONCENTRATION)
WRITE (*,810) MAXVALY1,ASCIIMU_C
IYPMAX = 1
DO I = 1,N1,IREDUCE
    IF (YP(I) > YP(IYPMAX)) IYPMAX = I
ENDDO
WRITE (*,815) YP(IYPMAX),ASCIIMU_C
!...
!...CLOSE INPUT AND OUTPUT FILES
CLOSE (UNIT=IIN,  STATUS = "KEEP")                                  !...CLOSE INPUT FILE
CLOSE (UNIT=NOUT, STATUS = "KEEP")                                  !...CLOSE OUTPUT FILE
CLOSE (UNIT=NORG, STATUS = "KEEP")
CLOSE (UNIT=NRDC, STATUS = "KEEP")
!...
!...RING BELL INDICATING MODEL HAS FINISHED PROCESSING
WRITE (*,*) BELL_C
!...
!...DETERMINE IF ORIGINAL DATA SHOULD BE PLOTTED AS POINTS OR A CONNECTED LINE
IF (IPARAMS == 2) THEN
    WRITE (*,820, ADVANCE="NO")
    READ  (*,140) PL(1:1)
    KN = LENCHR(PL)
    IF (KN < 1) PL = "P"
!...
!...DETERMINE IF SMOOTHED DATA SHOULD BE CONNECTED WITH A SMOOTH LINE
    IF ((PL == "P") .OR. (PL == "p")) THEN
        WRITE (*,825, ADVANCE="NO")
        READ  (*,140) PLINE(1:1)
        KN = LENCHR(PLINE)
        IF (KN < 1) PLINE = "Y"
    ENDIF
!...
!...DETERMINE IF DOWNLOADED DATA POINTS SHOULD BE PLOTTED
    WRITE (*,826, ADVANCE = "NO")
    READ  (*,140) DNPLOT(1:1)
    KN = LENCHR(DNPLOT)
    IF (KN < 1) DNPLOT = "Y"
!...
!...DETERMINE IF DOWNLOADED DATA POINTS SHOULD BE MARKED ON THE PLOTS
    WRITE (*,827, ADVANCE = "NO")
    READ  (*,140) DPMARK(1:1)
    KN = LENCHR(DPMARK)
    IF (KN < 1) DPMARK = "N"
ENDIF
!...
!...SET PROPER COUNTER FOR THE STATISTICAL ANALYSES
IF (IPREPOST == 1) THEN
    NF = N2
ELSE
    NF = N3
ENDIF
!...
!...ARRANGE FOR LABEL FOR SMOOTHED DATA PLOTS
SELECT CASE (SMOOTHING)
    CASE ("Y","y")
        SELECT CASE (METHOD)
            CASE ("A","a")
                IMETHOD = 1
            CASE ("M","m")
                IMETHOD = 2
            CASE ("G","g")
                IMETHOD = 3
            CASE ("K","k")
                IF (MORDER == 1) IMETHOD = 5
                IF (MORDER == 2) IMETHOD = 6
            CASE ("S","s")
                IMETHOD = 7
            CASE ("E","e")
                IMETHOD = 8
            CASE ("Q","q")
                IMETHOD = 9
            CASE ("L","l")
                IMETHOD = 10
            CASE ("C","c")
                IMETHOD = 11
            CASE ("F","f")
                IMETHOD = 12
            CASE ("W","w")
                IMETHOD = 13
            CASE ("B","b")
                IMETHOD = 14
            CASE ("P","p")
                IMETHOD = 15
            CASE ("U","u")
                IMETHOD = 16
            CASE DEFAULT
                IMETHOD = 0
        END SELECT
!...
!...CONDUCT AN OUTLIER ANALYSIS AND PRODUCE PROBABILITY PLOTS FOR SMOOTHED DATA
        IF (.NOT. ALLOCATED(YT)) ALLOCATE(YT(1:NF), STAT=IERR)
        NW = 0
        DO I = 1,NF,NREDUCE
            NW = NW+1
            YT(NW) = YP(I)
        ENDDO
        IF (IRES == 1) CALL WEIB(YT,NW,NF)
        CALL MOMENTS (NW,YT,XAVE,ADEV,SDEV,VAR,SKEW,CURT,RMS,XMED,MAD,"Y")  !...CALCULATE AVERAGE CONCENTRATION AND RELATED STATISTCS
!!...
!!...CALCULATE ANDERSON-DARLING STATISTIC
        CALL AND_DAR(NW,YT,A2,A3,ADP)
        WRITE (*,830) SUPERSC2_C, A2, SUPERSC2_C, A3,ADP
    CASE DEFAULT
!...
!...CONDUCT AN OUTLIER ANALYSIS AND PRODUCE PROBABILITY PLOTS FOR FULL OR REDUCED DATA SETS
        IF (.NOT. ALLOCATED(YZ)) ALLOCATE(YZ(1:NF), STAT=IERR)
        NW = 0
        DO I = 1,NF,NREDUCE
            NW = NW+1
            YZ(NW) = YP(I)
        ENDDO
        IF (IREDUCE == 1) IMETHOD = 0
        IF (IREDUCE >  1) IMETHOD = 4
        IF (IRES == 1) CALL WEIB(YZ,NW,NF)
        CALL MOMENTS (NW,YZ,XAVE,ADEV,SDEV,VAR,SKEW,CURT,RMS,XMED,MAD,"Y")  !...CALCULATE AVERAGE CONCENTRATION AND RELATED STATISTCS
!!...
!!...CALCULATE ANDERSON-DARLING STATISTIC
        CALL AND_DAR(NW,YZ,A2,A3,ADP)
        WRITE (*,830) SUPERSC2_C, A2, SUPERSC2_C, A3, ADP
END SELECT
!...
!...IF POSTSCRIPT FILE IS TO BE CREATED THEN ESTABLISH PROPER NAME
IF (IRES == 1) THEN
    KN = RENAME ("dislin.pdf","Weibul_Probability.pdf")
    KN = RENAME ("dislin_1.pdf","Weibul_PPF.pdf")
    KN = RENAME ("dislin_2.pdf","Gumbel_max_Probability.pdf")
    KN = RENAME ("dislin_3.pdf","Gumbel_min_Probability.pdf")
    KN = RENAME ("dislin_4.pdf","Gumbel_max_PPF.pdf")
    KN = RENAME ("dislin_5.pdf","Gumbel_min_PPF.pdf")
    KN = RENAME ("dislin_6.pdf","Exponential_Probability.pdf")
    KN = RENAME ("dislin_7.pdf","Exponential_PPF.pdf")
    KN = RENAME ("dislin_8.pdf","Gamma_Probability.pdf")
    KN = RENAME ("dislin_9.pdf","Gamma_PPF.pdf")
ENDIF
!...
!...CALL PLOTTING ROUTINE FOR DATA
IPS = 0
15 CONTINUE
!...
!...CHECK TO SEE IF POSTSCRIPT FILE IS REQUIRED
IPLT  = 0
IFPLT = 0
!...
!...ASK FOR POSTSCRIPT PLOT OUTPUT
WRITE (*,835, ADVANCE="NO")
READ  (*,140) PLT(1:1)
SELECT CASE (PLT)
    CASE ("Y","y")
!...
!...DETERMINE IF AN EPS OR A PDF IS TO BE DEVLOPED
        WRITE (*,840, ADVANCE="NO")
        READ  (*,140) PLTYPE(1:1)
        SELECT CASE (PLTYPE)
            CASE ("E","e")
                IEP = 1
!...
!...DELETE PROBLEM FILES
                CALL NEWNAM (KN,FILEOUT,FILEPS)
                CALL PSTNAM (FILEPS,IPS,IEP)
                OPEN  (KN, FILE   = FILEPS, STATUS = "UNKNOWN")
                CLOSE (KN, STATUS = "DELETE")
                OPEN  (KN, FILE   = "dislin.eps", STATUS = "UNKNOWN")
                CLOSE (KN, STATUS = "DELETE")
                FILEPLT = FILEOUT
                IPLT = 1
!...
!...DETERMINE TYPE OF POSTSCRIPT FILE TO CREATE
                WRITE (*,850, ADVANCE="NO")
                READ  (*,140) QUES(1:1)
                READ  (QUES(1:1),*) IFPLT
            CASE ("P","p")
                IEP = 2
!...
!...DELETE PROBLEM FILES
                CALL NEWNAM (KN,FILEOUT,FILEPS)
                CALL PSTNAM (FILEPS,IPS,IEP)
                OPEN  (KN, FILE   = FILEPS, STATUS = "UNKNOWN")
                CLOSE (KN, STATUS = "DELETE")
                OPEN  (KN, FILE   = "dislin.pdf", STATUS = "UNKNOWN")
                CLOSE (KN, STATUS = "DELETE")
                FILEPLT = FILEOUT
                IPLT = 1
!...
!...DETERMINE TYPE OF POSTSCRIPT FILE TO CREATE
                WRITE (*,850, ADVANCE="NO")
                READ  (*,140) QUES(1:1)
                READ  (QUES(1:1),*) IFPLT
            CASE DEFAULT
                IPLT = 0
        END SELECT
    CASE DEFAULT
        CONTINUE
END SELECT
!***
!*********************PLOT DATA**************************
!***
!...
!...DETERMINE PLOT CONTROL
17 CONTINUE
SELECT CASE (IPLT)
    CASE (0)
!...
!...PLOT DATA ON SCREEN
        SELECT CASE (SMOOTHING)
            CASE ("Y","y")
                IF (IPS == 0) CALL PLOT_SMOOTHING (N1,XP,YP,ZP,DL,XAVE,IMK,XM,YM,IPLT,IFPLT,FILEOUT,IEP)
                IF (IPS == 1) CALL PLOT_RESIDUAL  (N1,XP,RP,IPLT,IFPLT,FILEOUT,1,1,IEP)
                IF (IPS == 2) CALL PLOT_RESIDUAL  (N1,YP,RP,IPLT,IFPLT,FILEOUT,1,2,IEP)
                IF (IPS == 3) CALL PLOT_RESIDUAL  (N1,YP,ABS(RP),IPLT,IFPLT,FILEOUT,3,1,IEP) !HOMOSCEDASTICITY PLOT
                IF (IPS == 4) CALL PLOT_RESIDUAL  (N1,XP,RP2,IPLT,IFPLT,FILEOUT,2,1,IEP)
                IF (IPS == 5) CALL PLOT_RESIDUAL  (N1,YP,RP2,IPLT,IFPLT,FILEOUT,2,2,IEP)
            CASE DEFAULT
                CALL PLOT (N1,XP,YP,DL,XAVE,IMK,XM,YM,IPLT,IFPLT,FILEOUT,IEP)
        END SELECT
    CASE (1)
!...
!...CREATE POSTSCRIPT PLOT FILE
        SELECT CASE (SMOOTHING)
            CASE ("Y","y")
                IF (IPS == 0) CALL PLOT_SMOOTHING (N1,XP,YP,ZP,DL,XAVE,IMK,XM,YM,IPLT,IFPLT,FILEOUT,IEP)
                IF (IPS == 1) CALL PLOT_RESIDUAL  (N1,XP,RP,IPLT,IFPLT,FILEOUT,1,1,IEP)
                IF (IPS == 2) CALL PLOT_RESIDUAL  (N1,YP,RP,IPLT,IFPLT,FILEOUT,1,2,IEP)
                IF (IPS == 3) CALL PLOT_RESIDUAL  (N1,YP,ABS(RP),IPLT,IFPLT,FILEOUT,3,1,IEP) !HOMOSCEDASTICITY PLOT
                IF (IPS == 4) CALL PLOT_RESIDUAL  (N1,XP,RP2,IPLT,IFPLT,FILEOUT,2,1,IEP)
                IF (IPS == 5) CALL PLOT_RESIDUAL  (N1,YP,RP2,IPLT,IFPLT,FILEOUT,2,2,IEP)
            CASE DEFAULT
                CALL PLOT (N1,XP,YP,DL,XAVE,IMK,XM,YM,IPLT,IFPLT,FILEOUT,IEP)
        END SELECT
!...
!...RENAME POSTSCRIPT PLOT FILE TO MATCH ENTERED FILENAME
        KN = 8
        CALL NEWNAM (KN,FILEOUT,FILEPS)
        CALL PSTNAM (FILEPS,IPS,IEP)
        KN = RENAME ("dislin.eps",FILEPS)
        KN = RENAME ("dislin.pdf",FILEPS)
!...
!... RESET PLOT CONTROL PARAMETERS FOR SCREEN PLOTTING
        IPLT  = 0
        IFPLT = 0
!...
!...PLOT DATA ON SCREEN
        SELECT CASE (SMOOTHING)
            CASE ("Y","y")
                IF (IPS == 0) CALL PLOT_SMOOTHING (N1,XP,YP,ZP,DL,XAVE,IMK,XM,YM,IPLT,IFPLT,FILEOUT,IEP)
                IF (IPS == 1) CALL PLOT_RESIDUAL  (N1,XP,RP,IPLT,IFPLT,FILEOUT,1,1,0,IEP)
                IF (IPS == 2) CALL PLOT_RESIDUAL  (N1,YP,RP,IPLT,IFPLT,FILEOUT,1,2,1,IEP)
                IF (IPS == 3) CALL PLOT_RESIDUAL  (N1,YP,ABS(RP),IPLT,IFPLT,FILEOUT,3,1,0,IEP) !HOMOSCEDASTICITY PLOT
                IF (IPS == 4) CALL PLOT_RESIDUAL  (N1,XP,RP2,IPLT,IFPLT,FILEOUT,2,1,0,IEP)
                IF (IPS == 5) CALL PLOT_RESIDUAL  (N1,YP,RP2,IPLT,IFPLT,FILEOUT,2,2,0,IEP)
            CASE DEFAULT
                CALL PLOT (N1,XP,YP,DL,XAVE,IMK,XM,YM,IPLT,IFPLT,FILEOUT,IEP)
        END SELECT
END SELECT
!...
!...IF POSTSCRIPT FILE IS TO BE CREATED THEN ESTABLISH PROPER NAME
IF (IPLT > 0) THEN
    CALL NEWNAM (KN,FILEOUT,FILEPS)
    CALL PSTNAM (FILEPS,IPS,IEP)
    KN = RENAME ("dislin.eps",FILEPS)
    KN = RENAME ("dislin.pdf",FILEPS)
ENDIF
SELECT CASE (SMOOTHING)
    CASE ("Y","y")
        IF (IRES == 1) THEN
            IF (IPS == 0) THEN
                IPS = 1
                WRITE (*,860, ADVANCE="NO")
                READ  (*,140) RESID1
                IF ((RESID1 == "Y") .OR. (RESID1 == "y")) THEN
                    GOTO 15
                ELSE
                    GOTO 17
                ENDIF
            ENDIF
            IF (IPS == 1) THEN
                IPS = 2
                WRITE (*,870, ADVANCE="NO")
                READ  (*,140) RESID2
                IF ((RESID2 == "Y") .OR. (RESID2 == "y")) THEN
                    GOTO 15
                ELSE
                    GOTO 17
                ENDIF
            ENDIF
            IF (IPS == 2) THEN
                IPS = 3
                WRITE (*,880, ADVANCE="NO")
                READ  (*,140) RESID3
                IF ((RESID3 == "Y") .OR. (RESID3 == "y")) THEN
                    GOTO 15
                ELSE
                    GOTO 17
                ENDIF
            ENDIF
            IF (IPS == 3) THEN
                IPS = 4
                WRITE (*,890, ADVANCE="NO")
                READ  (*,140) RESID4
                IF ((RESID4 == "Y") .OR. (RESID4 == "y")) THEN
                    GOTO 15
                ELSE
                    GOTO 17
                ENDIF
            ENDIF
            IF (IPS == 4) THEN
                IPS = 5
                WRITE (*,900, ADVANCE="NO")
                READ  (*,140) RESID5
                IF ((RESID5 == "Y") .OR. (RESID5 == "y")) THEN
                    GOTO 15
                ELSE
                    GOTO 17
                ENDIF
            ENDIF
        ENDIF
    CASE DEFAULT
        CONTINUE
END SELECT
!...
!...FREE UP SOME MEMORY
DEALLOCATE (X1)
DEALLOCATE (Y1)
IF (ALLOCATED(YT)) DEALLOCATE (YT)
IF (ALLOCATED(Z1)) DEALLOCATE (Z1)
!...
!...FREE UP SOME MORE MEMORY
XP(:) = ZERO_W
YP(:) = ZERO_W
ZP(:) = ZERO_W
DEALLOCATE (XP)
DEALLOCATE (YP)
DEALLOCATE (ZP)
DEALLOCATE (XS)
DEALLOCATE (YS)
IF (ALLOCATED(RP))  DEALLOCATE (RP)
IF (ALLOCATED(RP2)) DEALLOCATE (RP2)
!...
!...RERUN PROGRAM OR STOP
WRITE (*,910, ADVANCE="NO")
READ  (*,140) RERUN
IF (RERUN == "Y" .OR. RERUN == "y") THEN
    CALL EXECUTE_COMMAND_LINE("CLS")
    GOTO 10
ENDIF
!...
!...FORMAT STATEMENTS
100 FORMAT (/////,15X,67("*"),/,15X,"*",65X,"*",/,                                                          &
            15X,"*",25X,"TIME CONVERSION",25X,"*",/,15X,"*",65X,"*",/,15X,                                  &
            "*",14X,"PROGRAM TO CONVERT CONVENTIONAL SAMPLE TIME",                                          &
            8X,"*",/,15X,"*",20X,"TO DECIMAL TIME DATA FOR USE IN",14X,"*",/,15X,"*",                       &
            21X,"QTRACER AND TRACER_BACKGROUND",15X,"*",/,15X,"*",65X,"*",/,                                &
            15X,"*",29X,"DEVELOPED",27X,"*",/,15X,"*",65X,"*",/,15X,"*",32X,                                &
            "BY",31X,"*",/,15X,"*",65X,"*",/,15X,"*",25X,                                                   &
            "MALCOLM S. FIELD",24X,"*",/,15X,"*",15X,                                                       &
            "U.S. ENVIRONMENTAL PROTECTION AGENCY",14X,"*",/,15X,"*",                                       &
            65X,"*",/,15X,67("*"))
110 FORMAT (///,16X,"PROGRAM REQUIRES TIME-CONCENTRATION DATA LISTED IN SECONDS IN",/,16X,                  &
            "A DATA FILE AS (1409846160, 0.01350). USER CHOOSES DAYS, HOURS,",/,16X,                        &
            "MINUTES OR SECONDS AS DESIRED FOR SCREEN AND DATA-FILE OUTPUT.",                               &
            ////,32X,"PRESS RETURN TO CONTINUE")
120 FORMAT (//,16X,"PLEASE CHOOSE TO USE A PARAMETER CONTROL FILE OR SCREEN INPUT FILE (1=CONTROL FILE, ",  &
            "2=SCREEN INPUT [<ENTER>=1]):",6X,"")
130 FORMAT (//,16X,"PLEASE CHOOSE PRE-TRACER OR POST-TRACER INJECTION DATA FOR ANALYSIS (1=PRE, 2=POST ",   &
            "[<ENTER>=2]):",6X,"")
140 FORMAT (A1)
150 FORMAT (I2)
!155 FORMAT (I3)
160 FORMAT (//,16X,"DO YOU WANT TO SUBTRACT A BACKGROUND VALUE (Y=YES, N=NO [<ENTER>=NO])?",6X,"")
170 FORMAT (//,16X,"ENTER A BACKGROUND VALUE IN ",A1,"g/L TO SUBTRACT FROM YOUR OUTPUT DATA FILE:",6X,"")
180 FORMAT (   16X,"ENTERED BACKGROUND < ZERO; VALUE CONVERTED TO ZERO ",A1,"g/L")
190 FORMAT (//,16X,"DO YOU WANT TO CREATE A SMOOTHED DATA SET (Y=YES, N=NO [<ENTER>=NO])?",6X,"")
200 FORMAT (//,16X,"PLEASE SELECT A METHOD: A = MOVING AVERAGE,[DEFAULT]",                                  &
             /,40X,"F = BUTTERWORTH FILTER",                                                                &
             /,40X,"C = CUBIC SPLINE",                                                                      &
             /,40X,"E = EXPON. SMOOTHING AVERAGES",                                                         &
             /,40X,"G = SAVITZKY-GOLAY",                                                                    &
             /,40X,"K = KERNAL",                                                                            &
             /,40X,"L = LOWESS",                                                                            &
             /,40X,"M = MOVING MEDIAN",                                                                     &
             /,40X,"P = POLYNOMIAL FIT",                                                                    &
             /,40X,"Q = QUINTIC SPLINE",                                                                    &
             /,40X,"S = SMOOFT",                                                                            &
             /,40X,"U = CURVE FIT",                                                                         &
             /,40X,"W = WEIGHTED-QUINTIC SMOOTHING:",12X,"")
210 FORMAT (//,16X,"PLEASE ENTER THE ORDER OF THE SMOOTHING SPLINE [1 -- 4; DEFAULT=4]",6X,"")

215 FORMAT (//,16X,"PLEASE ENTER THE ORDER OF THE SMOOTHING POLYNOMIAL [2, 4, OR 6; DEFAULT=4]",/,          &
               16X,"AND THE ORDER OF THE DERIVATIVE [>0; DEFAULT=0:",6X,"")
220 FORMAT (2I1)
225 FORMAT (//,16X,"PLEASE ENTER A VALUE OF '1' FOR GLKERN OR '2' FOR LOKERN [DEFAULT=1]",6X,"")
230 FORMAT (//,16X,"PLEASE ENTER A ANY VALUE BETWEEN '0' AND '100', INCLUSIVE, ",                           &
                   "FOR POLYNOMIAL [DEFAULT=20]",6X,"")
240 FORMAT (//,16X,"PLEASE ENTER THE AMOUNT FOR A DATA WINDOW FOR DATA SMOOTHING ",                         &
                   "(e.g., 1, 2, 3, ..., 1000 [<ENTER>=1]):",6X,"")
250 FORMAT (//,16X,"PLEASE ENTER THE AMOUNT TO REDUCE DATA BY (e.g., 1, 2, 3, ..., 1000 ",                  &
                   "[<ENTER>=1]):",6X,"")
260 FORMAT ( /,16X,"*** SMOOTHED DATA FILE NOT CALCULATED BECAUSE '1' SELECTED ***")
265 FORMAT ( /,16X,"*** NO DATA REDUCTION SELECTED SMOOTHING METHOD USES ALL THE DATA ***")
267 FORMAT ( /,16X,"*** GLKERN AUTOMATICALLY IMPLEMENTED ***")
270 FORMAT (//,16X,"CONVERT NEGATIVE CONCENTRATION VALUES TO ZERO CONCENTRATION (1=YES, 2=NO",1X,           &
                   "[<ENTER>=YES]):",6X,"")
280 FORMAT (//,16X,"PLEASE ENTER A VALUE FOR INSTRUMENT DETECTION LIMIT IN ng/L ",                          &
                   "(DEFAULT [<ENTER>=10.0])",6X,"")
290 FORMAT (A80)
300 FORMAT (//,50X,"*** INPUT FILE NAME NOT FOUND ***",///,15X,"RECHECK INPUT FILE NAME: ",A50,//)
310 FORMAT (//,50X,"*** INPUT FILE NAME NOT FOUND ***",///,15X,"RECHECK INPUT FILE NAME:",/,A80,//)
320 FORMAT (//,16X,"PLEASE ENTER A FILE NAME FOR THE FILE CONTAINING THE ORIGINAL DATA (DEFAULT = ",        &
                   "BACK.DAT):",//,16X,"")
325 FORMAT (//,16X,"PLEASE ENTER A FILE NAME FOR THE FILE CONTAINING THE ORIGINAL DATA (DEFAULT = ",        &
                   "DATA.DAT):",//,16X,"")
330 FORMAT (//,16X,"PLEASE ENTER A FILE NAME FOR THE BACKGROUND DATA FILE (DEFAULT = BACK.BCK):",//,16X,"")
340 FORMAT (//,16X,"PLEASE ENTER A FILE NAME FOR THE OUTPUT DATA FILE (DEFAULT = DATA.OUT):",//,16X,"")
350 FORMAT (//,20X,"YOU CANNOT USE THIS FILE NAME FOR YOUR OUTPUT DATA FILE!",/,20X, "ENTER ANOTHER FILE ", &
                   "NAME PLEASE.",//)
353 FORMAT (//,16X,"PLEASE ENTER A FILE NAME FOR THE ORIGINAL DATA FILE (DEFAULT = DATA.ORG):",//,16X,"")
354 FORMAT (//,20X,"YOU CANNOT USE THIS FILE NAME FOR YOUR ORIGINAL DATA FILE!",/,20X,                      &
                   "ENTER ANOTHER FILE NAME PLEASE.",//)
356 FORMAT (//,16X,"PLEASE ENTER A FILE NAME FOR THE TRANSFORMED DATA FILE (DEFAULT = BACK.TRF):",//,16X,"")
357 FORMAT (//,16X,"PLEASE ENTER A FILE NAME FOR THE TRANSFORMED DATA FILE (DEFAULT = DATA.RDC):",//,16X,"")
358 FORMAT (//,20X,"YOU CANNOT USE THIS FILE NAME FOR YOUR TRANSFORMED DATA FILE!",/,20X,                   &
                   "ENTER ANOTHER FILE NAME PLEASE.",//)
360 FORMAT (////,32X,"PRESS RETURN TO CONTINUE ")
370 FORMAT (//,16X,"PLEASE ENTER PREFERED TIME UNITS (1=day, 2=hour, 3=min, 4=sec [<ENTER>=2]):",6X,"")
380 FORMAT (//,16X,"PLEASE ENTER PREFERED CONCENTRATION UNITS (1=kg/L; 2=g/L; 3=mg/L; 4=",A1,               &
                   "g/L; 5=ng/L; 6=pg/L [<ENTER>=4]):",6X,"")
390 FORMAT (//,16X,"TOTAL NUMBER OF DATA POINTS READ = ",I5,1X,"AND PROCESSED = ",I5)
400 FORMAT ( /,16X,"<*** WARNING YOU ARE USING LESS THAN 20 % OF THE DATA (USING JUST ",F4.1,               &
                   " % OF THE DATA) ***>")
402 FORMAT ( /,16X,"<*** NOTE THIS ROUTINE USES 100 % OF THE ORIGINAL DATA SET FOR SMOOTHING ***>")
404 FORMAT (//,16X,"DO YOU WANT POSSIBLE OUTLIERS TO BE AUTOMATICALLY DETECTED? (Y=YES, N=NO [DEFAULT=NO])     ")
405 FORMAT (//,16X,"CHOOSE A DESIRED SIGNIFICANCE LEVEL,",1X,A1,", (1=0.1, 2=0.05, 3=0.025, 4=0.01 [DEFAULT=4], 5=0.001)      ")
406 FORMAT (//,16X,"SHAPIRO-WILK W = ",G13.5,3X,"P-VALUE = ",G13.5,3X,"<** P-VALUE ",A1,1X,F4.2,"; ",A16)
408 FORMAT ( /,16X,A82)
410 FORMAT (112("="),/,"STATION NAME",/,A80,/,112("="),/,"DETEC. LIMITS	UNITS (1=kg/L; 2=g/L; 3=mg/L; ",    &
           "4=",A1,"g/L; 5=ng/L; 6=pg/L)",/,F5.2,10X,"5",/,112("="),/,"ZERO CONCENTRATIONS TREATED AS ",    &
           "REAL VALUES OR CENSORED DATA (1=REAL, 2=CENSORED, 3=MIXED [IDENTIFIED BELOW])",/,"3",/,         &
           112("="),/,"BELOW DETEC. LIM. DATA TREATMENT METHOD",/,                                          &
           "0 = Less than Detects Deleted",/,                                                               &
           "1 = 0.00*DL",/,                                                                                 &
           "2 = 0.50*DL",/,                                                                                 &
           "3 = 0.75*DL",/,                                                                                 &
           "4 = 1.00*DL",/,                                                                                 &
           "5 = DL/(2)^0.5",/,                                                                              &
           "6 = Maximum Likelihood Estimate (MLE)",/,                                                       &
           "---SELECTION---",/,"6",/,112("="),/,"MEASURED BACKGROUND DATA (CONCENTRATION DATA ",&
           "BELOW NEEDS TO BE AVERAGED)",/,112("-"),/,"TIME UNITS",10X,                                     &
           "(1=days; 2=hrs; 3=min; 4=sec)",/,I1,/,"CONCENTRATION UNITS (1=kg/L; 2=g/L; 3=mg/L; ",           &
           "4=",A1,"g/L; 5=ng/L; 6=pg/L)",/,"4",/,112("="))
420 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A1,"g/L)	ZERO CONC. TYPE (R=REAL DATA, ",            &
           "C=CENSORED DATA)",/,80("-"))
430 FORMAT (11X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A1,"g/L)	ZERO CONC. TYPE (R=REAL DATA, ",            &
           "C=CENSORED DATA)",/,80("-"))
440 FORMAT (13X,"TIME",1X,"(",A3,")",10X,"CONC",1X,"(",A1,"g/L)	ZERO CONC. TYPE (R=REAL DATA, ",            &
           "C=CENSORED DATA)",/,80("-"))
450 FORMAT (15X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A1,"g/L)	ZERO CONC. TYPE (R=REAL DATA, ",            &
           "C=CENSORED DATA)",/,80("-"))
460 FORMAT (23X,"ORIGINAL DATA")
462 FORMAT (23X,"TRANSFORMED DATA")
464 FORMAT (23X,"ORIGINAL DATA",5X,"TRANSFORMED DATA")
470 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A4,")",/,80("-"))
480 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A4,")",10X,"CONC",1X,"(",A4,")",/,80("-"))
490 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A1,"g/L)",/,80("-"))
500 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A1,"g/L)",10X,"CONC",1X,"(",A1,"g/L)",/,80("-"))
510 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A3,")",/,80("-"))
520 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A3,")",10X,"CONC",1X,"(",A3,")",/,80("-"))
530 FORMAT ( 9X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A4,")",/,80("-"))
540 FORMAT ( 9X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A4,")",10X,"CONC",1X,"(",A4,")",/,80("-"))
550 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A1,"g/L)",/,80("-"))
560 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A1,"g/L)",10X,"CONC",1X,"(",A1,"g/L)",/,80("-"))
570 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A3,")",/,80("-"))
580 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A3,")",10X,"CONC",1X,"(",A3,")",/,80("-"))
590 FORMAT (13X,"TIME",1X,"(",A3,")",10X,"CONC",1X,"(",A4,")",/,80("-"))
600 FORMAT (13X,"TIME",1X,"(",A3,")",10X,"CONC",1X,"(",A4,")",10X,"CONC",1X,"(",A4,")",/,80("-"))
610 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A1,"g/L)",/,80("-"))
620 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A1,"g/L)",10X,"CONC",1X,"(",A1,"g/L)",/,80("-"))
630 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A3,")",/,80("-"))
640 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A3,")",10X,"CONC",1X,"(",A3,")",/,80("-"))
650 FORMAT (15X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A4,")",/,80("-"))
660 FORMAT (15X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A4,")",10X,"CONC",1X,"(",A4,")",/,80("-"))
670 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A1,"g/L)",/,80("-"))
680 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A1,"g/L)",10X,"CONC",1X,"(",A1,"g/L)",/,80("-"))
690 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A3,")",/,80("-"))
700 FORMAT ( 7X,"TIME",1X,"(",A1,")",10X,"CONC",1X,"(",A3,")",10X,"CONC",1X,"(",A3,")",/,80("-"))
704 FORMAT (//,6X,"B-SPLINE ANALYSIS",/,6X,17("="),//)
706 FORMAT (//,6X,"CUBIC-SPLINE ANALYSIS",/,6X,21("="),//)
708 FORMAT (//,6X,"SAVITZKY-GOLAY FILTER ANALYSIS",/,6X,30("="),//)
712 FORMAT (//,6X,"POYNOMIAL-FIT ANALYSIS",/,6X,22("="),//)
714 FORMAT (//,6X,"CURVE-FIT ANALYSIS",/,6X,18("="),//)
716 FORMAT (   6X,"IER =",I3,//,6X,"SPF =",1ES15.6,/,6X,"VAR =",1ES15.6,/,6X,"GCV =",1ES15.6,/,             &
               6X,"MSR =",1ES15.6,/,7X,"DF =",1ES15.6,/,8X,"P =",1ES15.6,/,6X,"FRE =",1ES15.6,///,          &
               4X,"ITER",12X,"TIME",10X,"ACTUAL",13X,"FIT",12X,"DER1",12X,"DER2",/,4X,84("-"))
718 FORMAT (   4X,I4,4X,F12.4,4X,4(ES12.4,4X))
720 FORMAT ( /,6X,"IER =",I3,/,6X,"VAR =",1ES15.6,//,6X,"GENERALIZED CROSS VALIDATION =",1ES15.6,/,         &
               6X,"MEAN SQUARE RESIDUAL",9X,"=",1ES15.6,/,6X,"RESIDUAL DEGREES OF FREEDOM  =",1ES15.6,///,  &
              54X,"OUTPUT RESULTS",//,57X,"BAYESIAN",16X,"SPLINE COEFFICIENTS",/,6X,"ITER",8X,              &
                  "TIME",8X,"FIT",9X,"ACTUAL",8X,"STND ERROR",7X,"C(I,1)",9X,"C(I,2)",9X,"C(I,3)",/,        &
               6X,106("-"))
722 FORMAT (   6X,I4,F12.4,6ES15.6)
723 FORMAT (   6X,"Number of left points ........:",1X,I3,/,6X,"Number of right points .......:",1X,I3,/,   &
               6X,"Order of smoothing polynomial.:",4X,I1,///,6X,"Savitzky-Golay Filter Coefficients",/,    &
               6X,34("-"),/)
724 FORMAT (  10X,I4,5X,G16.10)
725 FORMAT (//,35X,27("*"),/,35X,"* PATIENCE -- CALCULATING *",/,35X,27("*"),/)
730 FORMAT (5X,F10.6,7X,F14.6,6X,A1)
740 FORMAT (5X,F10.6,7X,F14.6,7X,F14.6)
745 FORMAT (5X,F10.6,7X,F14.6,7X,F14.6,A1)
750 FORMAT (5X,F14.6,7X,F14.6,6X,A1)
760 FORMAT (5X,F14.6,7X,F14.6,7X,F14.6)
765 FORMAT (5X,F14.6,7X,F14.6,7X,F14.6,A1)
770 FORMAT (5X,F14.6,7X,F14.6,6X,A1)
780 FORMAT (5X,F14.6,7X,F14.6,7X,F14.6)
785 FORMAT (5X,F14.6,7X,F14.6,7X,F14.6,A1)
790 FORMAT (5X,F16.6,7X,F14.6,6X,A1)
800 FORMAT (5X,F16.6,7X,F14.6,7X,F14.6)
805 FORMAT (5X,F16.6,7X,F14.6,7X,F14.6,A1)
810 FORMAT (  //,40X,"MEASURED  MAX. CONC. = ",F12.6,1X,A1,"g/L")
815 FORMAT (   /,40X,"DISPLAYED MAX. CONC. = ",F12.6,1X,A1,"g/L")
820 FORMAT (  //,16X,"PLOTTED DATA AS POINTS OR A CONNECTED LINE? (P=POINTS; L=LINE [<ENTER>=POINTS])",6X,"")
825 FORMAT (  //,16X,"CONNECT PLOTTED DATA POINTS WITH A SMOOTH LINE? (Y=YES; N=NO [<ENTER>=YES])",6X,"")
826 fORMAT (  //,16X,"PLOT DATA POINTS THAT INDICATE DOWNLOAD TIMES? (Y=YES; N=NO [<ENTER>=YES])",6X,"")
827 FORMAT (  //,16X,"MARK DATA POINTS THAT INDICATE DOWNLOAD TIMES? (Y=YES; N=NO [<ENTER>=NO])",6X,"")
830 FORMAT (  //,16X,"ANDERSON-DARLING TEST STATISTIC A",A1,"  = ",G14.7,/,                                 &
                 21X,"MODIFIED AD TEST STATISTIC A*",A1," = ",G14.7,/,43X,"P-VALUE  = ",G14.6)
835 FORMAT ( ///,16X,"DO YOU WANT TO CREATE A POSTSCRIPT FILE? (Y=YES, N=NO [<ENTER>=NO])",6X,"")
840 FORMAT ( ///,16X,"DO YOU WANT TO CREATE AN EPS OR A PDF FILE? (E=EPS, P=PDF)      ")
850 FORMAT (////,10X,"CHOOSE THE TYPE OF POSTSCRIPT FILE ",                                                 &
                     "YOU WANT PRODUCED?",                                                                  &
              //,30X,"1 = B/W POSTSCRIPT ",                                                                 &
               /,30X,"2 = COLOR POSTSCRIPT (BLUE  BACKGROUND)",                                             &
               /,30X,"3 = COLOR POSTSCRIPT (BLACK BACKGROUND)",6X,"")
860 FORMAT ( ///,16X,"DO YOU WANT TO CREATE AN EXPLANATORY VARIABLE RESIDUAL POSTSCRIPT FILE ",             &
                     "(Y=YES, N=NO [<ENTER>=NO])?",6X,"")
870 FORMAT ( ///,16X,"DO YOU WANT TO CREATE A FITTED VARIABLE RESIDUAL POSTSCRIPT FILE ",                   &
                     "(Y=YES, N=NO [<ENTER>=NO])?",6X,"")
880 FORMAT ( ///,16X,"DO YOU WANT TO CREATE A HOMOSCEDASTICITY POSTSCRIPT FILE ",                           &
                     "(Y=YES, N=NO [<ENTER>=NO])?",6X,"")
890 FORMAT ( ///,16X,"DO YOU WANT TO CREATE AN EXPLANATORY VARIABLE VS SQUARED FITTED RESIDUAL POSTSCRIPT " &
                     "FILE (Y=YES, N=NO [<ENTER>=NO])?",6X,"")
900 FORMAT ( ///,16X,"DO YOU WANT TO CREATE AN FITTED VARIABLE VS SQUARED FITTED RESIDUAL POSTSCRIPT "      &
                     "FILE (Y=YES, N=NO [<ENTER>=NO])?",6X,"")
910 FORMAT (  //,16X,"DO YOU WANT TO RERUN THE PROGRAM? (Y=YES, N=NO [<ENTER>=NO])",6X,"")
1000 FORMAT(" ", A, " ** FILE NOT FOUND - ", A, " **")
!...
!...
CONTAINS
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                   SUBROUTINE DT_LIMIT                *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 03/18/15          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...
!...GET DEFAULT DETECTION LIMIT VALUE = 10.0 ng/L
    SUBROUTINE DT_LIMIT(AA,OUT)
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                           :: PRESENT
!...
!...DECLARE TRANSFERRED VARIABLES
    REAL(WP), INTENT(IN), OPTIONAL                      :: AA
    REAL(WP), INTENT(OUT)                               :: OUT
!...
!...IDENTIFY LOCAL VARIABLES
    REAL(WP)                                            :: AOP
!...
!...SET 10.0 ng/L AS THE DEFAULT VALUE IF VARIABLE AA IS LESS THAN OR EQUAL TO ZERO
    AOP = TEN_W
!...
!...DETERMINE IF A IS PRESENT; IF NOT SET AOP TO AA
    IF (PRESENT(AA)) THEN
        IF (AA > ZERO_W) AOP = AA
    ENDIF
!...
!...SET OUT TO AOP FOR TRANSFER BACK TO MAIN PROGRAM
    OUT = AOP
!...
!...DONE
    RETURN
    END SUBROUTINE DT_LIMIT
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                  SUBROUTINE PROUST                   *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 09/02/16          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...REMEMBRANCE OF TIME PASSED
!...
    SUBROUTINE PROUST(TT,NEG,NSP)
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                           :: LEN_TRIM, NINT
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                            :: NEG, NSP
    REAL(WP), INTENT(IN)                                ::  TT
!...
!...IDENTIFY LOCAL VARIABLES
    CHARACTER(LEN=28)                                   ::  TEXT
    CHARACTER(LEN=3), DIMENSION(1:5)                    ::  UNAME = (/ "wk ","d  ","hr ","min","sec" /)
    INTEGER(I4B)                                        ::  I, LL, NN, SS
    INTEGER(I4B), DIMENSION(1:5)                        ::  USIZE = (/ 7*24*60*60, 24*60*60, 60*60, 60, 1 /)
!...
!...COPY SECONDS VALUE TO ANOTHER ARRAY
    SS = NINT(TT)
    LL = 0
    IF (NEG == 2) THEN
        DO I = 1,5
            NN = SS/USIZE(I)
            IF (NN > 0) THEN
                SS = SS - NN*USIZE(I)
                IF (LL > 0) THEN
                    LL = LL+2
                    TEXT(LL-1:LL) = ", "
                ENDIF
                WRITE (TEXT(LL+1:),100) NN, UNAME(I)
                LL = LEN_TRIM(TEXT)
            ENDIF
        ENDDO
        IF (NSP == 1) THEN
            WRITE (*,110) TT
        ELSEIF (NSP == 2) THEN
            WRITE (*,115) TT
        ENDIF
        WRITE (*,120) TT/USIZE(4)
        WRITE (*,130) TT/USIZE(3)
        WRITE (*,140) TT/USIZE(2)
        WRITE (*,150) TT/USIZE(1)
        WRITE (*,*)
        IF (NSP == 1) THEN
            WRITE (*,160) NINT(TT),TEXT(1:LL)
        ELSEIF (NSP == 2) THEN
            WRITE (*,165) NINT(TT),TEXT(1:LL)
        ENDIF
    ELSEIF (NEG == 1) THEN
        DO I = 1,5
            NN = SS/USIZE(I)
            IF (NN < 0) THEN
                SS = SS - NN*USIZE(I)
                IF (LL > 0) THEN
                    LL = LL+2
                    TEXT(LL-1:LL) = ", "
                ENDIF
                WRITE (TEXT(LL+1:),100) ABS(NN), UNAME(I)
                LL = LEN_TRIM(TEXT)
            ENDIF
        ENDDO
        WRITE (*,170) ABS(TT)
        WRITE (*,180) ABS(TT/USIZE(4))
        WRITE (*,190) ABS(TT/USIZE(3))
        WRITE (*,200) ABS(TT/USIZE(2))
        WRITE (*,210) ABS(TT/USIZE(1))
        WRITE (*,*)
        WRITE (*,220) ABS(NINT(TT)),TEXT(1:LL)
    ENDIF
!...
!...FORMAT STATEMENTS
100 FORMAT (I0,1X,A)
110 FORMAT (//,40X,"TRACER TRAVEL TIME =",F16.2,1X,"sec")
115 FORMAT (//,36X,"TRACER RECOVERY PERIOD =",F16.2,1X,"sec")
120 FORMAT (66X,F10.2,1X,"min")
130 FORMAT (68X,F8.2, 1X,"hr")
140 FORMAT (70X,F6.2, 1X,"d")
150 FORMAT (71X,F5.2, 1X,"wk")
160 FORMAT ( /,40X,"TRACER TRAVEL TIME =",I13,1X,"sec =",A28)
165 FORMAT (//,36X,"TRACER RECOVERY PERIOD =",I13,1X,"sec =",A28)
170 FORMAT (//,40X,"BACKGROUND SAMPLING PERIOD =",F16.2,1X,"sec")
180 FORMAT (74X,F10.2,1X,"min")
190 FORMAT (76X,F8.2, 1X,"hr")
200 FORMAT (78X,F6.2, 1X,"d")
210 FORMAT (79X,F5.2, 1X,"wk")
220 FORMAT ( /,40X,"BACKGROUND SAMPLING PERIOD =",I13,1X,"sec =",A28)
!...
!...DONE
    RETURN
    END SUBROUTINE PROUST
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                 FUNCTION MOVE_STAT                   *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 03/18/15          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...CALCULATE A SIMPLE MOVING AVERAGE AND SIMPLE MOVING MEDIAN OF THE DATA
    FUNCTION MOVE_STAT (METHOD,S1,DEV)
!...
!...ADD MODULE
    USE AA_SIZE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                       :: DIM, EOSHIFT
!...
!...DECLARE TRANSFERRED VARIABLES
    CHARACTER(LEN=*), INTENT(IN)                    :: METHOD
    REAL(WP), INTENT(IN)                            :: S1
    REAL(WP), INTENT(OUT)                           :: DEV
!...
!...IDENTIFY LOCAL VARIABLES
    INTEGER(I4B)                                    :: IERR
    REAL(WP)                                        :: MOVE_STAT, SMA, SMM, ADEV, VAR, SKEW, CURT, RMS, MAD
    INTEGER(I4B), SAVE                              :: ICOUNTER=0
!...
!...ALLOCATE DATA ARRAY MEMORY SPACE
    ALLOCATE(AA(1:IREDUCE), STAT=IERR)
!...
!...BEGIN COUNTING VALUES FOR SIMPLE MOVING AVERAGE AND SIMPLE MOVING MEDIAN
    IF (ICOUNTER < IREDUCE) THEN
        ICOUNTER = ICOUNTER+1
        AA(ICOUNTER) = S1
    ELSE
        AA = EOSHIFT(AA,SHIFT=1,BOUNDARY=S1,DIM=1)
    ENDIF
!...
!...CALCULATE MOMENTS FOR A SIMPLE MOVING AVERAGE AND SIMPLE MOVING MEDIAN
    CALL MOMENTS(ICOUNTER,AA,SMA,ADEV,SDEV,VAR,SKEW,CURT,RMS,SMM,MAD,"N")
    SELECT CASE (METHOD)
        CASE ("A","a")
            MOVE_STAT = SMA                     !...MOVING AVERAGE
            DEV = SDEV
        CASE ("M","m")
            MOVE_STAT = SMM                     !...MOVING MEDIAN
            DEV = MAD
        CASE DEFAULT
            MOVE_STAT = SMA
            DEV = SDEV
     END SELECT
!...
!...DONE
    RETURN
    END FUNCTION MOVE_STAT
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                 SUBROUTINE CRFRPT                    *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 10/29/18          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...CALCULATE CURVEFIT COEFFICIENTS
    SUBROUTINE CRFRPT (ISG,KK,SS,FP,IER,NN,N1,TT,TC,X1,Y1,YT)
!...
!...ENSURE ALL VARIABLES IDENTIFIED
    IMPLICIT NONE
!...
!...DECLARE TRANSFERRED VARIABLES
    INTEGER(I4B), INTENT(IN)                        :: ISG, KK, IER, NN, N1
    REAL(WP), INTENT(IN)                            :: FP, SS
    REAL(WP), DIMENSION(1:NN), INTENT(IN)           :: TT
    REAL(WP), DIMENSION(1:N1), INTENT(IN)           :: TC, X1, Y1, YT
!...
!...IDENTIFY LOCAL VARIABLES
    INTEGER(I4B)                                    :: NK1
!...
!...WRITE BASIC INPUT PARAMETERS TO CURVEFIT REPORT
    IF (IOPT < 0) THEN
        WRITE (ISG,100) KK
    ELSE
        WRITE (ISG,110) KK
        WRITE (ISG,120) SS
    ENDIF
    WRITE (ISG,130) FP, IER
    WRITE (ISG,140) NN
!...
!...WRITE POSITION OF KNOTS TO CURVEFIT REPORT
    WRITE (ISG,150)
    WRITE (ISG,160) (TT(I), I=1,NN)
    WRITE (ISG,170)
!...
!...WRITE B-SPLINE COEFFICIENTS TO CURVEFIT REPORT
    NK1 = NN-KK-10
    WRITE (ISG,190) (TC(I), I=1,NK1)
    WRITE (ISG,200)
    DO I = 1,N1
        WRITE (ISG,210) I,X1(I),Y1(I),YT(I)
    ENDDO
!...
!...FORMAT STATEMENTS
100 FORMAT (7X,"LEAST=SQUARES SPLINE OF DEGREE =",1X,I1)
110 FORMAT (7X,"SMOOTHING SPLINE OF DEGREE =",1X,I1)
120 FORMAT (7X,"SMOOTHING FACTOR S =",1X,F4.2)
130 FORMAT (7X,"SUM OF SQUARED RESIDUALS =",1X,ES10.4,/,7X,"ERROR FLAG =",1X,I2)
140 FORMAT (7X,"TOTAL NUMBER OF KNOTS N =",1X,I3)
150 FORMAT (//,7X,"POSITION OF THE KNOTS",/,7X,21("="))
160 FORMAT (5X,12ES12.4)
170 FORMAT (//,7X,"B-SPLINE COEFFICIENTS",/,7X,21("="))
190 FORMAT (5X,8ES12.4)
200 FORMAT (///,7X,"ITER",12X,"TIME",10X,"ACTUAL",13X,"FIT",/,4X,64("-"))
210 FORMAT (7X,I4,4X,F12.4,4X,2(ES12.4,4X))
!...
!...DONE
    RETURN
    END SUBROUTINE CRFRPT
!...
!...REALLY DONE
END PROGRAM TIME_CONVERSION
