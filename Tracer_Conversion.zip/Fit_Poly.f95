SUBROUTINE FIT_POLY (ISG,X,Y,F,M,N)
!...
!...A SIMPLE SUBROUTINE TO FIT A POLYNOMIAL IN ONE VARIABLE.
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
USE LSQ
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                       :: NINT
!...
!...IDENTIFY TRANSFERED VALIABLES
INTEGER(I4B), INTENT(IN)                            :: ISG, M, N
REAL(WP), DIMENSION(1:N), INTENT(IN)                :: X, Y
REAL(WP), DIMENSION(1:N), INTENT(OUT)               :: F
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                        :: I, IER, J
INTEGER(I4B)                                        :: NREQ
REAL(WP)                                            :: TOTALSS, VAR
REAL(WP), PARAMETER                                 :: WT=ONE_W
REAL(WP), DIMENSION(0:M)                            :: XROW, BETA, STERR
REAL(WP), DIMENSION(1:N*2)                          :: COVMAT
LOGICAL(TLG)                                        :: FIT_CONST=.TRUE.
LOGICAL(FLG), DIMENSION(0:M)                        :: LINDEP
!...
!===================================================================================
!...
!...
!...INITIALIZE LEAST-SQUARES CALCULATIONS
NREQ = N*2                                          !...ENSURES COVMAT IS ADEQUATELY SIZED
CALL STARTUP(M,FIT_CONST)
DO I = 1,N
    WRITE (*,FMT="(A1,A,T58,I3,A)",ADVANCE="NO") VTAB_C,"                                    PERCENT COMPLETE: ",   &
                NINT((REAL(I, KIND=WP)/REAL(N, KIND=WP))*HUND_W, KIND=I4B)," %"
    XROW(0) = ONE_W
    DO J = 1,M
        XROW(J) = X(I)*XROW(J-1)
    ENDDO
    CALL INCLUD(WT,XROW,Y(I))
ENDDO
!...
!...CHECK FOR SINGULARITY
CALL SING(LINDEP,IER)
IF (IER /= 0) THEN
    DO I = 0,M
        IF (LINDEP(I)) WRITE (ISG,100) I
    ENDDO
ENDIF
!...
!...CALCULATE PROGRESSIVE RESIDUAL SUMS OF SQUARES AND TOTAL SUM OF THE SQUARES
CALL SS()
    VAR = RSS(M+1)/(N-M-1)
TOTALSS = RSS(1)
!...
!...CALCULATE LEAST-SQUARES REGN. COEFFS.
CALL REGCF(BETA,M+1,IER)
!...
!...CALCULATE COVARIANCE MATRIX, AND HENCE STD. ERRORS OF COEFFS.
CALL COV(M+1,VAR,COVMAT,NREQ,STERR,IER)
!...
!...PRINT RESULTS
WRITE (ISG,110)
WRITE (ISG,120)
DO I = 0,M
    WRITE (ISG,130) I, BETA(I), STERR(I), RSS(I+1)
ENDDO
WRITE (ISG,140) SQRT(VAR)
WRITE (ISG,150) SUPER2_C,(TOTALSS - RSS(M+1))/TOTALSS
!...
!...CALCULATE POLYNOMIAL FIT ACCORDING TO THE EQUATION: Y = A(0) + A(1).X + A(2).X^2 + ... + A(M).X^M
DO I = 0,M
    DO J = 1,N
        IF (I ==   0) F(J) = BETA(I)
        IF (I ==   1) F(J) = F(J) + BETA(I)*X(J)
        IF (I ==   2) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==   3) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==   4) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==   5) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==   6) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==   7) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==   8) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==   9) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  10) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  11) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  12) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  13) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  14) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  15) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  16) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  17) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  18) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  19) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  20) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  21) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  22) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  23) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  24) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  25) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  26) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  27) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  28) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  29) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  30) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  31) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  32) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  33) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  34) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  35) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  36) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  37) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  38) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  39) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  40) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  41) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  42) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  43) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  44) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  45) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  46) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  47) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  48) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  49) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  50) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  51) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  52) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  53) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  54) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  55) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  56) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  57) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  58) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  59) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  60) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  61) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  62) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  63) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  64) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  65) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  66) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  67) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  68) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  69) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  70) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  71) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  72) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  73) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  74) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  75) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  76) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  77) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  78) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  79) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  80) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  81) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  82) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  83) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  84) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  85) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  86) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  87) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  88) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  89) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  90) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  91) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  92) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  93) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  94) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  95) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  96) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  97) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  98) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I ==  99) F(J) = F(J) + BETA(I)*X(J)**I
        IF (I == 100) F(J) = F(J) + BETA(I)*X(J)**I
    ENDDO
ENDDO
!...
!...FORMAT STATEMENTS
100 FORMAT (//,10X,"SINGULARITY DETECTED FOR POWER: ",I3,///)
110 FORMAT (//,24X,"LEAST-SQUARES COEFFICIENTS & STD. ERRORS",/,10X,67("="))
120 FORMAT (   11X,"NUM",8X,"POWER COEFFICIENT",6X,"STD. ERROR",4X,"RESID. SUM OF SQ.",/,10X,67("-"))
130 FORMAT (   10X,I4,5X,ES20.12,3X,ES14.6,3X,ES14.6)
140 FORMAT (   10X,67("="),//,12X,"RESIDUAL STANDARD DEVIATION =",ES20.12,/)
150 FORMAT (   12X,"R",A1," = ",ES20.12)
!...DONE
RETURN
END SUBROUTINE FIT_POLY
