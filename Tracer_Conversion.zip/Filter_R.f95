MODULE FILTER_R
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B), PARAMETER                             ::  &
                                                        KLOWPASS=0,      &  !-LOW PASS
                                                        KHIGHPASS=1,     &  !-HIGH PASS
                                                        KBANDPASSCSG=2,  &  !-BAND PASS CSG
                                                        KBANDPASSCZPG=3, &  !-BAND PASS CZPG
                                                        KNOTCH=4,        &  !-NOTCH
                                                        KALL=5,          &  !-ALL PASS
                                                        KPEAKING=6,      &  !-PEAKING
                                                        KLOWSHELF=7,     &  !-LOW SHELF
                                                        KHIGHSHELF=8        !-HIGH SHELF
!...
!...BUTTERWORTH ALL-PURPOSE FILTER
TYPE TRBJEQFILTER
REAL(WP)                                            ::  B0A0, B1A0, B2A0, A1A0, A2A0
REAL(WP)                                            ::  IN1, IN2, OU1, OU2
REAL(WP)                                            ::  FSAMPLERATE
INTEGER(I4B)                                        ::  FMAXBLOCKSIZE
INTEGER(I4B)                                        ::  FFILTERTYPE
REAL(WP)                                            ::  FFREQ, FQ, FDBGAIN
LOGICAL(TLG)                                        ::  FQISBANDWIDTH
REAL(WP), DIMENSION(:), POINTER                     ::  OUT1
!...
!...EXPLANATION
!...METHODS OF FILTER:
!...SUBROUTINE INITFILTER(FILTER,SAMPLERATE, MAXBLOCKSIZE)
!...SUBROUTINE SETQ(FILTER,NEWQ)
!...SUBROUTINE CALCFILTERCOEFF(FILTER)
!...SUBROUTINE CALCFILTERCOEFFS(FILTER,PFILTERTYPE, PFREQ, FLOAT PQ, PDBGAIN, PQISBANDWIDTH)
!...SUBROUTINE PROCESS(FILTER,INPUT,SAMPLEFRAMES)
!...REAL(WP) FUNCTION PROCESS1(FILTER,INPUT)
!...
!...DONE
END TYPE TRBJEQFILTER

CONTAINS
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...INITIALIZE FILTER
    SUBROUTINE INITFILTER (FILTER,SAMPLERATE,MAXBLOCKSIZE)
!...
!...IDENTIFY SUBROUTINE VALIABLES
    TYPE(TRBJEQFILTER) FILTER
    REAL(WP)                                        ::  SAMPLERATE
    INTEGER(I4B)                                    ::  MAXBLOCKSIZE
!...
    FILTER%FMAXBLOCKSIZE = MAXBLOCKSIZE
    FILTER%FSAMPLERATE = SAMPLERATE
!...
    FILTER%FFILTERTYPE = 0
    FILTER%FFREQ = 500
    FILTER%FQ = 0.3_WP
    FILTER%FDBGAIN = 0
    FILTER%FQISBANDWIDTH = .TRUE.
!...
    FILTER%IN1 = 0
    FILTER%IN2 = 0
    FILTER%OU1 = 0
    FILTER%OU2 = 0
!...
!...DONE
    RETURN
    END SUBROUTINE INITFILTER
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
    SUBROUTINE SETQ (FILTER,NEWQ)
!...
!...IDENTIFY SUBROUTINE VALIABLES
    TYPE(TRBJEQFILTER) FILTER
    REAL(WP)                                        ::  NEWQ
!...
    FILTER%FQ = (ONE_W-NEWQ)*0.98_WP
!...
!...DONE
    RETURN
    END SUBROUTINE SETQ
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
    SUBROUTINE CALCFILTERCOEFFS (FILTER,PFILTERTYPE,PFREQ,PQ,PDBGAIN,PQISBANDWIDTH)
!...
!...IDENTIFY SUBROUTINE VALIABLES
    TYPE(TRBJEQFILTER) FILTER
    INTEGER(I4B)                                    ::  PFILTERTYPE
    REAL(WP)                                        ::  PFREQ, PQ, PDBGAIN
    LOGICAL                                         ::  PQISBANDWIDTH
!...
    FILTER%FFILTERTYPE = PFILTERTYPE
    FILTER%FFREQ = PFREQ
    FILTER%FQ = PQ
    FILTER%FDBGAIN = PDBGAIN
    FILTER%FQISBANDWIDTH = PQISBANDWIDTH
!...
    CALL CALCFILTERCOEFF(FILTER)
!...
!...DONE
    RETURN
    END SUBROUTINE CALCFILTERCOEFFS
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
    SUBROUTINE CALCFILTERCOEFF (FILTER)
!...
!...INTRINSIC FUNCTIONS
    INTRINSIC                                       :: LOG, SIN, COS, SINH, SQRT
!...
!...IDENTIFY SUBROUTINE VALIABLES
    TYPE(TRBJEQFILTER) FILTER
    REAL(WP)                                        ::  ALPHA, A0, A1, A2, B0, B1, B2
    REAL(WP)                                        ::  A, BETA, OMEGA, TSIN, TCOS
!...
!...PEAKING, LOW SHELF OR HIGH SHELF
    IF (FILTER%FFILTERTYPE >= 6) THEN
        A = TEN_W**(FILTER%FDBGAIN/40.0_WP)
        OMEGA = TWO_W*FILTER%FFREQ/FILTER%FSAMPLERATE
        TSIN  = SIN(OMEGA)
        TCOS  = COS(OMEGA)
!...
        IF (FILTER%FQISBANDWIDTH) THEN
            ALPHA = TSIN*SINH(LOG(TWO_W)/TWO_W*FILTER%FQ*OMEGA/TSIN)
        ELSE
            ALPHA = TSIN/(TWO_W*FILTER%FQ)
        ENDIF

        BETA = SQRT(A)/FILTER%FQ
!...
!...PEAKING
        IF (FILTER%FFILTERTYPE == 6) THEN
            B0 =  ONE_W+ALPHA*A
            B1 = -TWO_W*TCOS
            B2 =  ONE_W-ALPHA*A
            A0 =  ONE_W+ALPHA/A
            A1 = -TWO_W*TCOS
            A2 =  ONE_W-ALPHA/A
!...
!...LOW SHELF
        ELSEIF (FILTER%FFILTERTYPE == 7) THEN
            B0 = (A*((A+ONE_W)-(A-ONE_W)*TCOS+BETA*TSIN))
            B1 = (TWO_W*A*((A-ONE_W)-(A+ONE_W)*TCOS))
            B2 = (A*((A+ONE_W)-(A-ONE_W)*TCOS-BETA*TSIN))
            A0 = ((A+ONE_W)+(A-ONE_W)*TCOS+BETA*TSIN)
            A1 = (-TWO_W*((A-ONE_W)+(A+ONE_W)*TCOS))
            A2 = ((A+ONE_W)+(A-ONE_W)*TCOS-BETA*TSIN)
!...
!...HIGH SHELF
        ELSEIF (FILTER%FFILTERTYPE == 8) THEN
            B0 = (A*((A+ONE_W)+(A-ONE_W)*TCOS+BETA*TSIN))
            B1 = (-TWO_W*A*((A-ONE_W)+(A+ONE_W)*TCOS))
            B2 = (A*((A+ONE_W)+(A-ONE_W)*TCOS-BETA*TSIN))
            A0 = ((A+ONE_W)-(A-ONE_W)*TCOS+BETA*TSIN)
            A1 = (TWO_W*((A-ONE_W)-(A+ONE_W)*TCOS))
            A2 = ((A+ONE_W)-(A-ONE_W)*TCOS-BETA*TSIN)
        ELSE
            CONTINUE
        ENDIF
    ELSE
!...
!...OTHER FILTER TYPES
        OMEGA = TWO_W*PI_W*FILTER%FFREQ/FILTER%FSAMPLERATE
        TSIN = SIN(OMEGA)
        TCOS = COS(OMEGA)
        IF (FILTER%FQISBANDWIDTH) THEN
            ALPHA = TSIN*SINH(LOG(TWO_W)/TWO_W*FILTER%FQ*OMEGA/TSIN)
        ELSE
            ALPHA = TSIN/(TWO_W*FILTER%FQ)
        ENDIF
!...
!...LOW PASS
        IF (FILTER%FFILTERTYPE == 0) THEN
            B0 = (ONE_W-TCOS)/TWO_W
            B1 =  ONE_W-TCOS
            B2 = (ONE_W-TCOS)/TWO_W
            A0 =  ONE_W+ALPHA
            A1 = -TWO_W*TCOS
            A2 =  ONE_W-ALPHA
!...
!...HIGH PASS
        ELSEIF (FILTER%FFILTERTYPE == 1) THEN
            B0 =  (ONE_W+TCOS)/TWO_W
            B1 = -(ONE_W+TCOS)
            B2 =  (ONE_W+TCOS)/TWO_W
            A0 =   ONE_W+ALPHA
            A1 = -TWO_W*TCOS
            A2 =   ONE_W-ALPHA
!...
!...BAND PASS CSG
        ELSEIF (FILTER%FFILTERTYPE == 2) THEN
            B0 =  TSIN/TWO_W
            B1 =  ZERO_W
            B2 = -TSIN/TWO_W
            A0 =  ONE_W+ALPHA
            A1 = -ONE_W*TCOS
            A2 =  ONE_W-ALPHA
!...
!...BAND PASS CZPG
        ELSEIF (FILTER%FFILTERTYPE == 3) THEN
            B0 =  ALPHA
            B1 =  ZERO_W
            B2 = -ALPHA
            A0 =  ONE_W+ALPHA
            A1 = -TWO_W*TCOS
            A2 =  ONE_W-ALPHA
!...
!...NOTCH
        ELSEIF (FILTER%FFILTERTYPE == 4) THEN
            B0 =  ONE_W
            B1 = -TWO_W*TCOS
            B2 =  ONE_W
            A0 =  ONE_W+ALPHA
            A1 = -TWO_W*TCOS
            A2 =  ONE_W-ALPHA
!...
!...ALL PASS
        ELSEIF (FILTER%FFILTERTYPE == 5) THEN
            B0 =  ONE_W-ALPHA
            B1 = -TWO_W*TCOS
            B2 =  ONE_W+ALPHA
            A0 =  ONE_W+ALPHA
            A1 = -TWO_W*TCOS
            A2 =  ONE_W-ALPHA
        ELSE
            CONTINUE
        ENDIF
    ENDIF
!...
    FILTER%B0A0 = B0/A0
    FILTER%B1A0 = B1/A0
    FILTER%B2A0 = B2/A0
    FILTER%A1A0 = A1/A0
    FILTER%A2A0 = A2/A0
!...
!...DONE
    RETURN
    END SUBROUTINE CALCFILTERCOEFF
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
    REAL(WP) FUNCTION PROCESS1 (FILTER,INPUT)
!...
!...IDENTIFY FUNCTION VALIABLES
    TYPE(TRBJEQFILTER) FILTER
    REAL(WP)                                        ::  INPUT, LASTOUT
!...
!...FILTER
    LASTOUT = (FILTER%B0A0)*INPUT + (FILTER%B1A0)*(FILTER%IN1) +        &
              (FILTER%B2A0)*(FILTER%IN2) - (FILTER%A1A0)*(FILTER%OU1) - &
              (FILTER%A2A0)*(FILTER%OU2)
!...
!...PUSH IN/OUT BUFFERS
    FILTER%IN2 = FILTER%IN1
    FILTER%IN1 = INPUT
    FILTER%OU2 = FILTER%OU1
    FILTER%OU1 = LASTOUT
!...
    PROCESS1 = LASTOUT
!...
!...DONE
    RETURN
    END FUNCTION PROCESS1
!...
!...EXPLANATION:
!...USE PROCESS1(INPUT:SINGLE):SINGLE;
!...FOR PER SAMPLE PROCESSING
!...USE PROCESS(INPUT:PSINGLE;SAMPLEFRAMES:INTEGER);
!...FOR BLOCK PROCESSING. THE INPUT IS A POINTER TO
!...THE START OF AN ARRAY OF SINGLE WHICH CONTAINS
!...THE AUDIO DATA.
!...I.E.
!...RBJFILTER.PROCESS(@WAVEDATA[0],256)
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
    SUBROUTINE PROCESS (FILTER,INPUT,SAMPLEFRAMES)
!...
!...IDENTIFY SUBROUTINE VALIABLES
    TYPE(TRBJEQFILTER) FILTER
    REAL(WP)                                        ::  INPUT(*)
    INTEGER(I4B)                                    ::  SAMPLEFRAMES, I, IALLOC
    REAL(WP)                                        ::  LASTOUT
!...
!...ALLOCATE MEMORY FOR VECTOR FILTER%OUT1
    ALLOCATE(FILTER%OUT1(0:SAMPLEFRAMES), STAT=IALLOC)
!...
    DO I = 0,SAMPLEFRAMES-1
!...
!...FILTER
        LASTOUT = FILTER%B0A0*(INPUT(I)) + FILTER%B1A0*FILTER%IN1 + &
                  FILTER%B2A0*FILTER%IN2 - FILTER%A1A0*FILTER%OU1 - &
                  FILTER%A2A0*FILTER%OU2
!...
!...LASTOUT=INPUT[I];
!...PUSH IN/OUT BUFFERS
        FILTER%IN2 = FILTER%IN1
        FILTER%IN1 = INPUT(I)
        FILTER%OU2 = FILTER%OU1
        FILTER%OU1 = LASTOUT
!...
        FILTER%OUT1(I) = LASTOUT
    ENDDO
!...
!...DONE
    RETURN
    END SUBROUTINE PROCESS
!...
!...REALLY DONE
END MODULE FILTER_R

