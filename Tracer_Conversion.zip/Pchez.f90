!...
!...LIST OF SUBROUTINES, FUNCTIONS, AND ARGUMENTS
! SUBROUTINE PCHEZ     (N,X,F,D,SPLINE,WK,LWK,IERR)
!     SUBROUTINE PCHIM     (N,X,F,D,INCFD,IERR)
!     SUBROUTINE PCHSP     (IC,VC,N,X,F,D,INCFD,WK,NWK,IERR)
!     REAL FUNCTION PCHST  (ARG1,ARG2)
!     REAL FUNCTION DPCHDF (K,X,S,IERR)
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                  SUBROUTINE PCHEZ                    *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 02/12/07          *
!...   *                                                      *
!...    ******************************************************
!...
!...

SUBROUTINE PCHEZ (N,X,F,D,SPLINE,WK,LWK,IERR)
!
!***BEGIN PROLOGUE  PCHEZ
!***DATE WRITTEN   870821   (YYMMDD)
!***REVISION DATE  870908   (YYMMDD)
!***CATEGORY NO.  E1B
!***KEYWORDS  CUBIC HERMITE MONOTONE INTERPOLATION, SPLINE
!             INTERPOLATION, EASY TO USE PIECEWISE CUBIC INTERPOLATION
!***AUTHOR  KAHANER, D.K., (NBS)
!             SCIENTIFIC COMPUTING DIVISION
!             NATIONAL BUREAU OF STANDARDS
!             GAITHERSBURG, MARYLAND 20899
!             (301) 975-3808
!***PURPOSE  EASY TO USE SPLINE OR CUBIC HERMITE INTERPOLATION.
!***DESCRIPTION

!          PCHEZ:  PIECEWISE CUBIC INTERPOLATION, EASY TO USE.

!     FROM THE BOOK "NUMERICAL METHODS AND SOFTWARE"
!          BY  D. KAHANER, C. MOLER, S. NASH
!               PRENTICE HALL 1988

!     SETS DERIVATIVES FOR SPLINE (TWO CONTINUOUS DERIVATIVES) OR
!     HERMITE CUBIC (ONE CONTINUOUS DERIVATIVE) INTERPOLATION.
!     SPLINE INTERPOLATION IS SMOOTHER, BUT MAY NOT "LOOK" RIGHT IF THE
!     DATA CONTAINS BOTH "STEEP" AND "FLAT" SECTIONS.  HERMITE CUBICS
!     CAN PRODUCE A "VISUALLY PLEASING" AND MONOTONE INTERPOLANT TO
!     MONOTONE DATA. THIS IS AN EASY TO USE DRIVER FOR THE ROUTINES
!     BY F. N. FRITSCH IN REFERENCE (4) BELOW. VARIOUS BOUNDARY
!     CONDITIONS ARE SET TO DEFAULT VALUES BY PCHEZ. MANY OTHER CHOICES
!     ARE AVAILABLE IN THE SUBROUTINES PCHIC, PCHIM AND PCHSP.

!     USE PCHEV TO EVALUATE THE RESULTING FUNCTION AND ITS DERIVATIVE.

! ----------------------------------------------------------------------

!  CALLING SEQUENCE:   CALL  PCHEZ (N, X, F, D, SPLINE, WK, LWK, IERR)

!     INTEGER  N, IERR,  LWK
!     REAL  X(N), F(N), D(N), WK(*)
!     LOGICAL SPLINE

!   PARAMETERS:

!     N -- (INPUT) NUMBER OF DATA POINTS.  (ERROR RETURN IF N.LT.2 .)
!           IF N=2, SIMPLY DOES LINEAR INTERPOLATION.

!     X -- (INPUT) REAL ARRAY OF INDEPENDENT VARIABLE VALUES.  THE
!           ELEMENTS OF X MUST BE STRICTLY INCREASING:
!                X(I-1) .LT. X(I),  I = 2(1)N.
!           (ERROR RETURN IF NOT.)

!     F -- (INPUT) REAL ARRAY OF DEPENDENT VARIABLE VALUES TO BE INTER-
!           POLATED.  F(I) IS VALUE CORRESPONDING TO X(I).

!     D -- (OUTPUT) REAL ARRAY OF DERIVATIVE VALUES AT THE DATA POINTS.

!     SPLINE -- (INPUT) LOGICAL VARIABLE TO SPECIFY IF THE INTERPOLANT
!           IS TO BE A SPLINE WITH TWO CONTINUOUS DERIVATIES
!           (SET SPLINE=.TRUE.) OR A HERMITE CUBIC INTERPOLANT WITH ONE
!           CONTINUOUS DERIVATIVE (SET SPLINE=.FALSE.).
!        NOTE: IF SPLINE=.TRUE. THE INTERPOLATING SPLINE SATISFIES THE
!           DEFAULT "NOT-A-KNOT" BOUNDARY CONDITION, WITH A CONTINUOUS
!           THIRD DERIVATIVE AT X(2) AND X(N-1). SEE REFERENCE (3).
!              IF SPLINE=.FALSE. THE INTERPOLATING HERMITE CUBIC WILL BE
!           MONOTONE IF THE INPUT DATA IS MONOTONE. BOUNDARY CONDITIONS ARE
!           COMPUTED FROM THE DERIVATIVE OF A LOCAL QUADRATIC UNLESS THIS
!           ALTERS MONOTONICITY.

!     WK -- (SCRATCH) REAL WORK ARRAY, WHICH MUST BE DECLARED BY THE CALLING
!           PROGRAM TO BE AT LEAST 2*N IF SPLINE IS .TRUE. AND NOT USED
!           OTHERWISE.

!     LWK -- (INPUT) LENGTH OF WORK ARRAY WK. (ERROR RETURN IF
!           LWK.LT.2*N AND SPLINE IS .TRUE., NOT CHECKED OTHERWISE.)

!     IERR -- (OUTPUT) ERROR FLAG.
!           NORMAL RETURN:
!              IERR = 0  (NO ERRORS).
!           WARNING ERROR:
!              IERR.GT.0  (CAN ONLY OCCUR WHEN SPLINE=.FALSE.) MEANS THAT
!                 IERR SWITCHES IN THE DIRECTION OF MONOTONICITY WERE DETECTED.
!                 WHEN SPLINE=.FALSE.,  PCHEZ GUARANTEES THAT IF THE INPUT
!                 DATA IS MONOTONE, THE INTERPOLANT WILL BE TOO. THIS WARNING
!                 IS TO ALERT YOU TO THE FACT THAT THE INPUT DATA WAS NOT
!                 MONOTONE.
!           "RECOVERABLE" ERRORS:
!              IERR = -1  IF N.LT.2 .
!              IERR = -3  IF THE X-ARRAY IS NOT STRICTLY INCREASING.
!              IERR = -7  IF LWK IS LESS THAN 2*N AND SPLINE IS .TRUE.
!             (THE D-ARRAY HAS NOT BEEN CHANGED IN ANY OF THESE CASES.)
!               NOTE:  THE ABOVE ERRORS ARE CHECKED IN THE ORDER LISTED,
!                   AND FOLLOWING ARGUMENTS HAVE **NOT** BEEN VALIDATED.

! ----------------------------------------------------------------------
!***REFERENCES  1. F.N.FRITSCH AND R.E.CARLSON, 'MONOTONE PIECEWISE
!                 CUBIC INTERPOLATION,' SIAM J.NUMER.ANAL. 17, 2 (APRIL
!                 1980), 238-246.
!               2. F.N.FRITSCH AND J.BUTLAND, 'A METHOD FOR CONSTRUCTING
!                 LOCAL MONOTONE PIECEWISE CUBIC INTERPOLANTS,' LLNL
!                 PREPRINT UCRL-87559 (APRIL 1982).
!               3. CARL DE BOOR, A PRACTICAL GUIDE TO SPLINES, SPRINGER-
!                 VERLAG (NEW YORK, 1978).  (ESP. CHAPTER IV, PP.49-62.)
!               4. F.N.FRITSCH, 'PIECEWISE CUBIC HERMITE INTERPOLATION
!                 PACKAGE, FINAL SPECIFICATIONS', LAWRENCE LIVERMORE
!                 NATIONAL LABORATORY, COMPUTER DOCUMENTATION UCID-30194,
!                 AUGUST 1982.
!***ROUTINES CALLED  PCHIM,PCHSP
!***END PROLOGUE  PCHEZ
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B),  INTENT(INOUT)                    :: N
REAL(SP),      INTENT(INOUT)                    :: X(N)
REAL(SP),      INTENT(INOUT)                    :: F(N)
REAL(SP),      INTENT(INOUT)                    :: D(N)
LOGICAL,       INTENT(IN)                       :: SPLINE
INTEGER(I4B),  INTENT(IN)                       :: LWK
INTEGER(I4B),  INTENT(INOUT)                    :: IERR
REAL(SP),      INTENT(INOUT)                    :: WK(LWK)
!
!  DECLARE LOCAL VARIABLES.
!
INTEGER(I4B)                                    :: IC(2), INCFD
REAL(SP)                                        :: VC(2)
DATA IC(1) /0/
DATA IC(2) /0/
DATA INCFD /1/


!***FIRST EXECUTABLE STATEMENT  PCHEZ

IF ( SPLINE ) THEN
  CALL  PCHSP (IC, VC, N, X, F, D, INCFD, WK, LWK, IERR)
ELSE
  CALL  PCHIM (N, X, F, D, INCFD, IERR)
END IF

!  ERROR CONDITIONS ALREADY CHECKED IN PCHSP OR PCHIM

RETURN
!------------- LAST LINE OF PCHEZ FOLLOWS ------------------------------
END SUBROUTINE PCHEZ
!...
! -------------------------------------------------------------------
!...
!...
!...    ******************************************************
!...   *                                                      *
!...   *                   SUBROUTINE PCHIM                   *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 08/28/87          *
!...   *                                                      *
!...    ******************************************************
!...
!...
SUBROUTINE PCHIM (N,X,F,D,INCFD,IERR)
!
!***BEGIN PROLOGUE  PCHIM
!     THIS PROLOGUE HAS BEEN REMOVED FOR REASONS OF SPACE
!     FOR A COMPLETE COPY OF THIS ROUTINE CONTACT THE AUTHORS
!     FROM THE BOOK "NUMERICAL METHODS AND SOFTWARE"
!          BY  D. KAHANER, C. MOLER, S. NASH
!               PRENTICE HALL 1988
!***END PROLOGUE  PCHIM
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B),  INTENT(IN)                       :: N, INCFD
REAL(SP),      INTENT(IN)                       :: X(N)
REAL(SP),      INTENT(IN)                       :: F(INCFD,N)
REAL(SP),      INTENT(OUT)                      :: D(INCFD,N)
INTEGER(I4B),  INTENT(OUT)                      :: IERR
!...
!...LOCAL VARIABLES FOR XERROR REPORTING
CHARACTER(LEN=50)                               :: MESSG
INTEGER(I4B)                                    :: NMESSG
INTEGER(I4B)                                    :: NERR
INTEGER(I4B)                                    :: LEVEL
!
!  DECLARE LOCAL VARIABLES.
!
INTEGER(I4B)                                    :: I, NLESS1
REAL(SP)                                        :: DEL1, DEL2, DMAX, DMIN, DRAT1, DRAT2
REAL(SP)                                        :: DSAVE, H1, H2, HSUM, HSUMT3, W1, W2
REAL(SP)                                        :: PCHST

!  VALIDITY-CHECK ARGUMENTS.

!***FIRST EXECUTABLE STATEMENT  PCHIM
IF ( N < 2 )  GO TO 5001
IF ( INCFD < 1 )  GO TO 5002
DO   I = 2, N
  IF ( X(I) <= X(I-1) )  GO TO 5003
END DO

!  FUNCTION DEFINITION IS OK, GO ON.

IERR = 0
NLESS1 = N - 1
H1 = X(2) - X(1)
DEL1 = (F(1,2) - F(1,1))/H1
DSAVE = DEL1

!  SPECIAL CASE N=2 -- USE LINEAR INTERPOLATION.

IF (NLESS1 > 1)  GO TO 10
D(1,1) = DEL1
D(1,N) = DEL1
GO TO 5000

!  NORMAL CASE  (N .GE. 3).

10 CONTINUE
H2 = X(3) - X(2)
DEL2 = (F(1,3) - F(1,2))/H2

!  SET D(1) VIA NON-CENTERED THREE-POINT FORMULA, ADJUSTED TO BE
!     SHAPE-PRESERVING.

HSUM = H1 + H2
W1 = (H1 + HSUM)/HSUM
W2 = -H1/HSUM
D(1,1) = W1*DEL1 + W2*DEL2
IF ( PCHST(D(1,1),DEL1) <= ZERO_S)  THEN
  D(1,1) = ZERO_S
ELSE IF ( PCHST(DEL1,DEL2) < ZERO_S)  THEN
!        NEED DO THIS CHECK ONLY IF MONOTONICITY SWITCHES.
  DMAX = THREE_S*DEL1
  IF (ABS(D(1,1)) > ABS(DMAX))  D(1,1) = DMAX
END IF

!  LOOP THROUGH INTERIOR POINTS.

DO   I = 2, NLESS1
  IF (I == 2)  GO TO 40

  H1 = H2
  H2 = X(I+1) - X(I)
  HSUM = H1 + H2
  DEL1 = DEL2
  DEL2 = (F(1,I+1) - F(1,I))/H2
  40    CONTINUE

!        SET D(I)=0 UNLESS DATA ARE STRICTLY MONOTONIC.

  D(1,I) = ZERO_S
  IF ( PCHST(DEL1,DEL2)  < 0.0) THEN
    GO TO    42
  ELSE IF ( PCHST(DEL1,DEL2)  == 0.0) THEN
    GO TO    41
  ELSE
    GO TO    45
  END IF

!        COUNT NUMBER OF CHANGES IN DIRECTION OF MONOTONICITY.

  41    CONTINUE
  IF (DEL2 == ZERO_S)  CYCLE
  IF ( PCHST(DSAVE,DEL2) < ZERO_S)  IERR = IERR + 1
  DSAVE = DEL2
  CYCLE

  42    CONTINUE
  IERR = IERR + 1
  DSAVE = DEL2
  CYCLE

!        USE BRODLIE MODIFICATION OF BUTLAND FORMULA.

  45    CONTINUE
  HSUMT3 = HSUM+HSUM+HSUM
  W1 = (HSUM + H1)/HSUMT3
  W2 = (HSUM + H2)/HSUMT3
  DMAX = AMAX1( ABS(DEL1), ABS(DEL2) )
  DMIN = AMIN1( ABS(DEL1), ABS(DEL2) )
  DRAT1 = DEL1/DMAX
  DRAT2 = DEL2/DMAX
  D(1,I) = DMIN/(W1*DRAT1 + W2*DRAT2)

END DO

!  SET D(N) VIA NON-CENTERED THREE-POINT FORMULA, ADJUSTED TO BE
!     SHAPE-PRESERVING.

W1 = -H2/HSUM
W2 = (H2 + HSUM)/HSUM
D(1,N) = W1*DEL1 + W2*DEL2
IF ( PCHST(D(1,N),DEL2) <= ZERO_S)  THEN
  D(1,N) = ZERO_S
ELSE IF ( PCHST(DEL1,DEL2) < ZERO_S)  THEN
!        NEED DO THIS CHECK ONLY IF MONOTONICITY SWITCHES.
  DMAX = THREE_S*DEL2
  IF (ABS(D(1,N)) > ABS(DMAX))  D(1,N) = DMAX
END IF

!  NORMAL RETURN.

5000 CONTINUE
RETURN

!  ERROR RETURNS.

5001 CONTINUE
!     N.LT.2 RETURN.
IERR = -1
MESSG  = 'PCHIM -- NUMBER OF DATA POINTS LESS THAN TWO'
NMESSG = 44
NERR   = IERR
LEVEL  = 1
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
RETURN

5002 CONTINUE
!     INCFD.LT.1 RETURN.
IERR = -2
MESSG  = 'PCHIM -- INCREMENT LESS THAN ONE'
NMESSG = 32
NERR   = IERR
LEVEL  = 1
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
RETURN

5003 CONTINUE
!     X-ARRAY NOT STRICTLY INCREASING.
IERR = -3
MESSG  = 'PCHIM -- X-ARRAY NOT STRICTLY INCREASING'
NMESSG = 40
NERR   = IERR
LEVEL  = 1
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
RETURN
!------------- LAST LINE OF PCHIM FOLLOWS ------------------------------
END SUBROUTINE PCHIM
!...
! -------------------------------------------------------------------
!...
!...
!...    ******************************************************
!...   *                                                      *
!...   *                  FUNCTION PCHST                      *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 09/08/87          *
!...   *                                                      *
!...    ******************************************************
!...
!...
REAL FUNCTION PCHST (ARG1,ARG2)
!
!***BEGIN PROLOGUE  PCHST
!***REFER TO  PCHCE,PCHCI,PCHCS,PCHIM
!***END PROLOGUE  PCHST
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...IDENTIFY SUBROUTINE VALIABLES
REAL(SP),      INTENT(INOUT)                    :: ARG1
REAL(SP),      INTENT(INOUT)                    :: ARG2
!
!  DECLARE LOCAL VARIABLES.
!

!  PERFORM THE TEST.

!***FIRST EXECUTABLE STATEMENT  PCHST
PCHST = SIGN(ONE_S,ARG1) * SIGN(ONE_S,ARG2)
IF ((ARG1 == ZERO_S) .OR. (ARG2 == ZERO_S))  PCHST = ZERO_S

RETURN
!------------- LAST LINE OF PCHST FOLLOWS ------------------------------
END FUNCTION PCHST
!...
! -------------------------------------------------------------------
!...
!...
!...    ******************************************************
!...   *                                                      *
!...   *                   SUBROUTINE PCHSP                   *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 08/28/87          *
!...   *                                                      *
!...    ******************************************************
!...
!...
SUBROUTINE PCHSP (IC,VC,N,X,F,D,INCFD,WK,NWK,IERR)
!
!***BEGIN PROLOGUE  PCHSP
!     THIS PROLOGUE HAS BEEN REMOVED FOR REASONS OF SPACE
!     FOR A COMPLETE COPY OF THIS ROUTINE CONTACT THE AUTHORS
!     FROM THE BOOK "NUMERICAL METHODS AND SOFTWARE"
!          BY  D. KAHANER, C. MOLER, S. NASH
!               PRENTICE HALL 1988
!***END PROLOGUE  PCHSP
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B),  INTENT(IN)                       :: IC(2)
REAL(SP),      INTENT(IN)                       :: VC(2)
INTEGER(I4B),  INTENT(IN)                       :: N, INCFD
REAL(SP),      INTENT(IN)                       :: X(N)
REAL(SP),      INTENT(IN)                       :: F(INCFD,N)
REAL(SP),      INTENT(OUT)                      :: D(INCFD,N)
REAL(SP),      INTENT(OUT)                      :: WK(2,N)
INTEGER(I4B),  INTENT(IN)                       :: NWK
INTEGER(I4B),  INTENT(OUT)                      :: IERR
!...
!...LOCAL VARIABLES FOR XERROR REPORTING
CHARACTER(LEN=50)                               :: MESSG
INTEGER(I4B)                                    :: NMESSG
INTEGER(I4B)                                    :: NERR
INTEGER(I4B)                                    :: LEVEL
!
!  DECLARE LOCAL VARIABLES.
!
INTEGER(I4B)                                    :: IBEG, IEND, INDEX, J, NM1
REAL(SP)                                        :: G, STEMP(3)
REAL(SP)                                        :: PCHDF, XTEMP(4)

!  VALIDITY-CHECK ARGUMENTS.

!***FIRST EXECUTABLE STATEMENT  PCHSP
IF ( N < 2 )  GO TO 5001
IF ( INCFD < 1 )  GO TO 5002
DO   J = 2, N
  IF ( X(J) <= X(J-1) )  GO TO 5003
END DO

IBEG = IC(1)
IEND = IC(2)
IERR = 0
IF ( (IBEG < 0).OR.(IBEG > 4) )  IERR = IERR - 1
IF ( (IEND < 0).OR.(IEND > 4) )  IERR = IERR - 2
IF ( IERR < 0 )  GO TO 5004

!  FUNCTION DEFINITION IS OK -- GO ON.

IF ( NWK < 2*N )  GO TO 5007

!  COMPUTE FIRST DIFFERENCES OF X SEQUENCE AND STORE IN WK(1,.). ALSO,
!  COMPUTE FIRST DIVIDED DIFFERENCE OF DATA AND STORE IN WK(2,.).
DO   J=2,N
  WK(1,J) = X(J) - X(J-1)
  WK(2,J) = (F(1,J) - F(1,J-1))/WK(1,J)
END DO

!  SET TO DEFAULT BOUNDARY CONDITIONS IF N IS TOO SMALL.

IF ( IBEG > N )  IBEG = 0
IF ( IEND > N )  IEND = 0

!  SET UP FOR BOUNDARY CONDITIONS.

IF ( (IBEG == 1).OR.(IBEG == 2) )  THEN
  D(1,1) = VC(1)
ELSE IF (IBEG > 2)  THEN
!        PICK UP FIRST IBEG POINTS, IN REVERSE ORDER.
  DO   J = 1, IBEG
    INDEX = IBEG-J+1
!           INDEX RUNS FROM IBEG DOWN TO 1.
    XTEMP(J) = X(INDEX)
    IF (J < IBEG)  STEMP(J) = WK(2,INDEX)
  END DO
!                 --------------------------------
  D(1,1) = PCHDF (IBEG, XTEMP, STEMP, IERR)
!                 --------------------------------
  IF (IERR /= 0)  GO TO 5009
  IBEG = 1
END IF

IF ( (IEND == 1).OR.(IEND == 2) )  THEN
  D(1,N) = VC(2)
ELSE IF (IEND > 2)  THEN
!        PICK UP LAST IEND POINTS.
  DO   J = 1, IEND
    INDEX = N-IEND+J
!           INDEX RUNS FROM N+1-IEND UP TO N.
    XTEMP(J) = X(INDEX)
    IF (J < IEND)  STEMP(J) = WK(2,INDEX+1)
  END DO
!                 --------------------------------
  D(1,N) = PCHDF (IEND, XTEMP, STEMP, IERR)
!                 --------------------------------
  IF (IERR /= 0)  GO TO 5009
  IEND = 1
END IF

! --------------------( BEGIN CODING FROM CUBSPL )--------------------

!  **** A TRIDIAGONAL LINEAR SYSTEM FOR THE UNKNOWN SLOPES S(J) OF
!  F  AT X(J), J=1,...,N, IS GENERATED AND THEN SOLVED BY GAUSS ELIM-
!  INATION, WITH S(J) ENDING UP IN D(1,J), ALL J.
!     WK(1,.) AND WK(2,.) ARE USED FOR TEMPORARY STORAGE.

!  CONSTRUCT FIRST EQUATION FROM FIRST BOUNDARY CONDITION, OF THE FORM
!             WK(2,1)*S(1) + WK(1,1)*S(2) = D(1,1)

IF (IBEG == 0)  THEN
  IF (N == 2)  THEN
!           NO CONDITION AT LEFT END AND N = 2.
    WK(2,1) = ONE_S
    WK(1,1) = ONE_S
    D(1,1) = TWO_S*WK(2,2)
  ELSE
!           NOT-A-KNOT CONDITION AT LEFT END AND N .GT. 2.
    WK(2,1) = WK(1,3)
    WK(1,1) = WK(1,2) + WK(1,3)
    D(1,1) =((WK(1,2) + TWO_S*WK(1,1))*WK(2,2)*WK(1,3) + WK(1,2)**2*WK(2,3)) / WK(1,1)
  END IF
ELSE IF (IBEG == 1)  THEN
!        SLOPE PRESCRIBED AT LEFT END.
  WK(2,1) = ONE_S
  WK(1,1) = ZERO_S
ELSE
!        SECOND DERIVATIVE PRESCRIBED AT LEFT END.
  WK(2,1) = TWO_S
  WK(1,1) = ONE_S
  D(1,1) = THREE_S*WK(2,2) - HALF_S*WK(1,2)*D(1,1)
END IF

!  IF THERE ARE INTERIOR KNOTS, GENERATE THE CORRESPONDING EQUATIONS AND
!  CARRY OUT THE FORWARD PASS OF GAUSS ELIMINATION, AFTER WHICH THE J-TH
!  EQUATION READS    WK(2,J)*S(J) + WK(1,J)*S(J+1) = D(1,J).

NM1 = N-1
IF (NM1 > 1)  THEN
  DO  J=2,NM1
    IF (WK(2,J-1) == ZERO_S)  GO TO 5008
    G = -WK(1,J+1)/WK(2,J-1)
    D(1,J) = G*D(1,J-1) + THREE_S*(WK(1,J)*WK(2,J+1) + WK(1,J+1)*WK(2,J))
    WK(2,J) = G*WK(1,J-1) + TWO_S*(WK(1,J) + WK(1,J+1))
  END DO
END IF

!  CONSTRUCT LAST EQUATION FROM SECOND BOUNDARY CONDITION, OF THE FORM
!           (-G*WK(2,N-1))*S(N-1) + WK(2,N)*S(N) = D(1,N)

!     IF SLOPE IS PRESCRIBED AT RIGHT END, ONE CAN GO DIRECTLY TO BACK-
!     SUBSTITUTION, SINCE ARRAYS HAPPEN TO BE SET UP JUST RIGHT FOR IT
!     AT THIS POINT.
IF (IEND == 1)  GO TO 30

IF (IEND == 0)  THEN
  IF (N == 2 .AND. IBEG == 0)  THEN
!           NOT-A-KNOT AT RIGHT ENDPOINT AND AT LEFT ENDPOINT AND N = 2.
    D(1,2) = WK(2,2)
    GO TO 30
  ELSE IF ((N == 2) .OR. (N == 3 .AND. IBEG == 0))  THEN
!           EITHER (N=3 AND NOT-A-KNOT ALSO AT LEFT) OR (N=2 AND *NOT*
!           NOT-A-KNOT AT LEFT END POINT).
    D(1,N) = TWO_S*WK(2,N)
    WK(2,N) = ONE_S
    IF (WK(2,N-1) == ZERO_S)  GO TO 5008
    G = -ONE_S/WK(2,N-1)
  ELSE
!           NOT-A-KNOT AND N .GE. 3, AND EITHER N.GT.3 OR  ALSO NOT-A-
!           KNOT AT LEFT END POINT.
    G = WK(1,N-1) + WK(1,N)
!           DO NOT NEED TO CHECK FOLLOWING DENOMINATORS (X-DIFFERENCES).
    D(1,N) = ((WK(1,N)+TWO_S*G)*WK(2,N)*WK(1,N-1)  &
        + WK(1,N)**2*(F(1,N-1)-F(1,N-2))/WK(1,N-1))/G
    IF (WK(2,N-1) == ZERO_S)  GO TO 5008
    G = -G/WK(2,N-1)
    WK(2,N) = WK(1,N-1)
  END IF
ELSE
!        SECOND DERIVATIVE PRESCRIBED AT RIGHT ENDPOINT.
  D(1,N) = THREE_S*WK(2,N) + HALF_S*WK(1,N)*D(1,N)
  WK(2,N) = TWO_S
  IF (WK(2,N-1) == ZERO_S)  GO TO 5008
  G = -ONE_S/WK(2,N-1)
END IF

!  COMPLETE FORWARD PASS OF GAUSS ELIMINATION.

WK(2,N) = G*WK(1,N-1) + WK(2,N)
IF (WK(2,N) == ZERO_S)   GO TO 5008
D(1,N) = (G*D(1,N-1) + D(1,N))/WK(2,N)

!  CARRY OUT BACK SUBSTITUTION

30 CONTINUE
DO  J=NM1,1,-1
  IF (WK(2,J) == ZERO_S)  GO TO 5008
  D(1,J) = (D(1,J) - WK(1,J)*D(1,J+1))/WK(2,J)
END DO
! --------------------(  END  CODING FROM CUBSPL )--------------------

!  NORMAL RETURN.

RETURN

!  ERROR RETURNS.

5001 CONTINUE
!     N.LT.2 RETURN.
IERR = -1
MESSG  = 'PCHSP -- NUMBER OF DATA POINTS LESS THAN TWO'
NMESSG = 44
NERR   = IERR
LEVEL  = 1
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
RETURN

5002 CONTINUE
!     INCFD.LT.1 RETURN.
IERR = -2
MESSG  = 'PCHSP -- INCREMENT LESS THAN ONE'
NMESSG = 32
NERR   = IERR
LEVEL  = 1
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
RETURN

5003 CONTINUE
!     X-ARRAY NOT STRICTLY INCREASING.
IERR = -3
MESSG  = 'PCHSP -- X-ARRAY NOT STRICTLY INCREASING'
NMESSG = 40
NERR   = IERR
LEVEL  = 1
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
RETURN

5004 CONTINUE
!     IC OUT OF RANGE RETURN.
IERR = IERR - 3
MESSG  = 'PCHSP -- IC OUT OF RANGE'
NMESSG = 24
NERR   = IERR
LEVEL  = 1
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
RETURN

5007 CONTINUE
!     NWK TOO SMALL RETURN.
IERR = -7
MESSG  = 'PCHSP -- WORK ARRAY TOO SMALL'
NMESSG = 29
NERR   = IERR
LEVEL  = 1
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
RETURN

5008 CONTINUE
!     SINGULAR SYSTEM.
!   *** THEORETICALLY, THIS CAN ONLY OCCUR IF SUCCESSIVE X-VALUES   ***
!   *** ARE EQUAL, WHICH SHOULD ALREADY HAVE BEEN CAUGHT (IERR=-3). ***
IERR = -8
MESSG  = 'PCHSP -- SINGULAR LINEAR SYSTEM'
NMESSG = 31
NERR   = IERR
LEVEL  = 1
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
RETURN

5009 CONTINUE
!     ERROR RETURN FROM PCHDF.
!   *** THIS CASE SHOULD NEVER OCCUR ***
IERR = -9
MESSG  = 'PCHSP -- ERROR RETURN FROM PCHDF'
NMESSG = 32
NERR   = IERR
LEVEL  = 1
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
RETURN
!------------- LAST LINE OF PCHSP FOLLOWS ------------------------------
END SUBROUTINE PCHSP
!...
! -------------------------------------------------------------------
!...
!...
!...    ******************************************************
!...   *                                                      *
!...   *                  FUNCTION PCHDF                      *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 09/08/87          *
!...   *                                                      *
!...    ******************************************************
!...
!...
REAL FUNCTION PCHDF (K,X,S,IERR)
!
!***BEGIN PROLOGUE  PCHDF
!***REFER TO  PCHCE,PCHSP
!***END PROLOGUE  PCHDF
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B),  INTENT(IN)                       :: K
REAL(SP),      INTENT(IN)                       :: X(K)
REAL(SP),      INTENT(OUT)                      :: S(K)
INTEGER(I4B),  INTENT(OUT)                      :: IERR
!...
!...LOCAL VARIABLES FOR XERROR REPORTING
CHARACTER(LEN=50)                               :: MESSG
INTEGER(I4B)                                    :: NMESSG
INTEGER(I4B)                                    :: NERR
INTEGER(I4B)                                    :: LEVEL
!
!  DECLARE LOCAL VARIABLES.
!
INTEGER(I4B)                                    :: I, J
REAL(SP)                                        :: VALUEE

!  CHECK FOR LEGAL VALUE OF K.

!***FIRST EXECUTABLE STATEMENT  PCHDF
IF (K < 3)  GO TO 5001

!  COMPUTE COEFFICIENTS OF INTERPOLATING POLYNOMIAL.

DO   J = 2, K-1
  DO   I = 1, K-J
    S(I) = (S(I+1)-S(I))/(X(I+J)-X(I))
  END DO
END DO

!  EVALUATE DERIVATIVE AT X(K).

VALUEE = S(1)
DO   I = 2, K-1
  VALUEE = S(I) + VALUEE*(X(K)-X(I))
END DO

!  NORMAL RETURN.

IERR = 0
PCHDF = VALUEE
RETURN

!  ERROR RETURN.

5001 CONTINUE
!     K.LT.3 RETURN.
IERR = -1
MESSG  = 'PCHDF -- K LESS THAN THREE'
NMESSG = 26
NERR   = IERR
LEVEL  = 1
CALL XERROR (MESSG,NMESSG,NERR,LEVEL)
PCHDF = ZERO_S
RETURN
!------------- LAST LINE OF PCHDF FOLLOWS ------------------------------
END FUNCTION PCHDF
