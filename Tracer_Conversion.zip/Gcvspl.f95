!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                  SUBROUTINE GCVSPL                   *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 08/20/18          *
!...   *                                                      *
!...    ******************************************************
!...

! CODE CONVERTED USING TO_F90 BY ALAN MILLER
! DATE: 2018-08-10  TIME: 15:26:40

! DELIVERY-DATE:  8 NOVEMBER 1991 16:31 MST
! DELIVERY-BY:  NETWORK_SERVER.DAEMON (LISTSERV@HEARN.BITNET@UNCANVE)
! DATE:  FRIDAY, 8 NOVEMBER 1991 10:19 MST
! FROM:  LISTSERV AT HEARN
! TO:  BOGERT AT UNCAMULT

! GCVSPL.FOR, 1986-05-12

!***********************************************************************

! SUBROUTINE GCVSPL (REAL*8)

! PURPOSE:
! *******

!       NATURAL B-SPLINE DATA SMOOTHING SUBROUTINE, USING THE GENERALI-
!       ZED CROSS-VALIDATION AND MEAN-SQUARED PREDICTION ERROR CRITERIA
!       OF CRAVEN & WAHBA (1979). ALTERNATIVELY, THE AMOUNT OF SMOOTHING
!       CAN BE GIVEN EXPLICITLY, OR IT CAN BE BASED ON THE EFFECTIVE
!       NUMBER OF DEGREES OF FREEDOM IN THE SMOOTHING PROCESS AS DEFINED
!       BY WAHBA (1980). THE MODEL ASSUMES UNCORRELATED, ADDITIVE NOISE
!       AND ESSENTIALLY SMOOTH, UNDERLYING FUNCTIONS. THE NOISE MAY BE
!       NON-STATIONARY, AND THE INDEPENDENT CO-ORDINATES MAY BE SPACED
!       NON-EQUIDISTANTLY. MULTIPLE DATASETS, WITH COMMON INDEPENDENT
!       VARIABLES AND WEIGHT FACTORS ARE ACCOMODATED.


! CALLING CONVENTION:
! ******************

!       CALL GCVSPL ( X, Y, NY, WX, WY, M, N, K, MD, VALU, C, NC, WK, IER )

! MEANING OF PARAMETERS:
! *********************

!       X(N)    ( I )   INDEPENDENT VARIABLES: STRICTLY INCREASING KNOT
!                       SEQUENCE, WITH X(I-1) < X(I), I=2,...,N.
!       Y(NY,K) ( I )   INPUT DATA TO BE SMOOTHED (OR INTERPOLATED).
!       NY      ( I )   FIRST DIMENSION OF ARRAY Y(NY,K), WITH NY >= N.
!       WX(N)   ( I )   WEIGHT FACTOR ARRAY; WX(I) CORRESPONDS WITH
!                       THE RELATIVE INVERSE VARIANCE OF POINT Y(I,*).
!                       IF NO RELATIVE WEIGHTING INFORMATION IS
!                       AVAILABLE, THE WX(I) SHOULD BE SET TO ONE.
!                       ALL WX(I) > ZERO, I=1,...,N.
!       WY(K)   ( I )   WEIGHT FACTOR ARRAY; WY(J) CORRESPONDS WITH
!                       THE RELATIVE INVERSE VARIANCE OF POINT Y(*,J).
!                       IF NO RELATIVE WEIGHTING INFORMATION IS
!                       AVAILABLE, THE WY(J) SHOULD BE SET TO ONE.
!                       ALL WY(J) > ZERO, J=1,...,K.
!                       NB: THE EFFECTIVE WEIGHT FOR POINT Y(I,J) IS
!                       EQUAL TO WX(I)*WY(J).
!       M       ( I )   HALF ORDER OF THE REQUIRED B-SPLINES (SPLINE
!                       DEGREE 2*M-1), WITH M > 0. THE VALUES M =
!                       1,2,3,4 CORRESPOND TO LINEAR, CUBIC, QUINTIC,
!                       AND HEPTIC SPLINES, RESPECTIVELY.
!       N       ( I )   NUMBER OF OBSERVATIONS PER DATASET, WITH N >= 2*M.
!       K       ( I )   NUMBER OF DATASETS, WITH K >= 1.
!       MD      ( I )   OPTIMIZATION MODE SWITCH:
!                       |MD| = 1: PRIOR GIVEN VALUE FOR P IN VALU
!                                 (VALU >= ZERO). THIS IS THE FASTEST
!                                 USE OF GCVSPL, SINCE NO ITERATION
!                                 IS PERFORMED IN P.
!                       |MD| = 2: GENERALIZED CROSS VALIDATION.
!                       |MD| = 3: TRUE PREDICTED MEAN-SQUARED ERROR,
!                                 WITH PRIOR GIVEN VARIANCE IN VALU.
!                       |MD| = 4: PRIOR GIVEN NUMBER OF DEGREES OF
!                                 FREEDOM IN VALU (ZERO <= VALU <= N-M).
!                        MD  < 0: IT IS ASSUMED THAT THE CONTENTS OF
!                                 X, W, M, N, AND WK HAVE NOT BEEN
!                                 MODIFIED SINCE THE PREVIOUS INVOCA-
!                                 TION OF GCVSPL. IF MD < -1, WK(4)
!                                 IS USED AS AN INITIAL ESTIMATE FOR
!                                 THE SMOOTHING PARAMETER P.  AT THE
!                                 FIRST CALL TO GCVSPL, MD MUST BE > 0.
!                       OTHER VALUES FOR |MD|, AND INAPPROPRIATE VALUES
!                       FOR VALU WILL RESULT IN AN ERROR CONDITION, OR
!                       CAUSE A DEFAULT VALUE FOR VALU TO BE SELECTED.
!                       AFTER RETURN FROM MD /= 1, THE SAME NUMBER OF
!                       DEGREES OF FREEDOM CAN BE OBTAINED, FOR IDENTICAL
!                       WEIGHT FACTORS AND KNOT POSITIONS, BY SELECTING
!                       |MD|=1, AND BY COPYING THE VALUE OF P FROM WK(4)
!                       INTO VALU. IN THIS WAY, NO ITERATIVE OPTIMIZATION
!                       IS REQUIRED WHEN PROCESSING OTHER DATA IN Y.
!       VALU    ( I )   MODE VALUE, AS DESCRIBED ABOVE UNDER MD.
!       C(NC,K) ( O )   SPLINE COEFFICIENTS, TO BE USED IN CONJUNCTION
!                       WITH FUNCTION SPLDER. NB: THE DIMENSIONS OF C
!                       IN GCVSPL AND IN SPLDER ARE DIFFERENT! IN SPLDER,
!                       ONLY A SINGLE COLUMN OF C(N,K) IS NEEDED, AND THE
!                       PROPER COLUMN C(1,J), WITH J=1...K SHOULD BE USED
!                       WHEN CALLING SPLDER.
!       NC       ( I )  FIRST DIMENSION OF ARRAY C(NC,K), NC >= N.
!       WK(IWK) (I/W/O) WORK VECTOR, WITH LENGTH IWK >= 6*(N*M+1)+N.
!                       ON NORMAL EXIT, THE FIRST 6 VALUES OF WK ARE
!                       ASSIGNED AS FOLLOWS:

!                       WK(1) = GENERALIZED CROSS VALIDATION VALUE
!                       WK(2) = MEAN SQUARED RESIDUAL.
!                       WK(3) = ESTIMATE OF THE NUMBER OF DEGREES OF
!                               FREEDOM OF THE RESIDUAL SUM OF SQUARES
!                               PER DATASET, WITH 0 < WK(3) < N-M.
!                       WK(4) = SMOOTHING PARAMETER P, MULTIPLICATIVE
!                               WITH THE SPLINES' DERIVATIVE CONSTRAINT.
!                       WK(5) = ESTIMATE OF THE TRUE MEAN SQUARED ERROR
!                               (DIFFERENT FORMULA FOR |MD| = 3).
!                       WK(6) = GAUSS-MARKOV ERROR VARIANCE.

!                       IF WK(4) -->  0, WK(3) -->  0, AND AN INTER-
!                       POLATING SPLINE IS FITTED TO THE DATA (P --> 0).
!                       A VERY SMALL VALUE > 0 IS USED FOR P, IN ORDER
!                       TO AVOID DIVISION BY ZERO IN THE GCV FUNCTION.

!                       IF WK(4) --> INF, WK(3) --> N-M, AND A LEAST-
!                       SQUARES POLYNOMIAL OF ORDER M (DEGREE M-1) IS
!                       FITTED TO THE DATA (P --> INF). FOR NUMERICAL
!                       REASONS, A VERY HIGH VALUE IS USED FOR P.

!                       UPON RETURN, THE CONTENTS OF WK CAN BE USED FOR
!                       COVARIANCE PROPAGATION IN TERMS OF THE MATRICES
!                       B AND WE: SEE THE SOURCE LISTINGS. THE VARIANCE
!                       ESTIMATE FOR DATASET J FOLLOWS AS WK(6)/WY(J).

!       IER     ( O )   ERROR PARAMETER:

!                       IER = 0:        NORMAL EXIT
!                       IER = 1:        M <= 0 .OR. N < 2*M
!                       IER = 2:        KNOT SEQUENCE IS NOT STRICTLY
!                                       INCREASING, OR SOME WEIGHT
!                                       FACTOR IS NOT POSITIVE.
!                       IER = 3:        WRONG MODE, PARAMETER, OR VALUE.

! REMARKS:
! *******

!       (1) GCVSPL CALCULATES A NATURAL SPLINE OF ORDER 2*M (DEGREE
!       2*M-1) WHICH SMOOTHES OR INTERPOLATES A GIVEN SET OF DATA
!       POINTS, USING STATISTICAL CONSIDERATIONS TO DETERMINE THE
!       AMOUNT OF SMOOTHING REQUIRED (CRAVEN & WAHBA, 1979). IF THE
!       ERROR VARIANCE IS A PRIORI KNOWN, IT SHOULD BE SUPPLIED TO
!       THE ROUTINE IN VALU, FOR |MD|=3. THE DEGREE OF SMOOTHING IS
!       THEN DETERMINED TO MINIMIZE AN UNBIASED ESTIMATE OF THE TRUE
!       MEAN SQUARED ERROR. ON THE OTHER HAND, IF THE ERROR VARIANCE
!       IS NOT KNOWN, USER MAY SELECT |MD|=2. THE ROUTINE THEN DETER-
!       MINES THE DEGREE OF SMOOTHING TO MINIMIZE THE GENERALIZED
!       CROSS VALUIDATION FUNCTION. THIS IS ASYMPTOTICALLY THE SAME
!       AS MINIMIZING THE TRUE PREDICTED MEAN SQUARED ERROR (CRAVEN &
!       WAHBA, 1979). IF THE ESTIMATES FROM |MD|=2 OR 3 DO NOT APPEAR
!       SUITABLE TO THE USER (AS APPARENT FROM THE SMOOTHNESS OF THE
!       M-TH DERIVATIVE OR FROM THE EFFECTIVE NUMBER OF DEGREES OF
!       FREEDOM RETURNED IN WK(3)), THE USER MAY SELECT ANOTHER
!       VALUE FOR THE NOISE VARIANCE IF |MD|=3, OR A REASONABLY LARGE
!       NUMBER OF DEGREES OF FREEDOM IF |MD|=4. IF |MD|=1, THE PROCE-
!       DURE IS NON-ITERATIVE, AND RETURNS A SPLINE FOR THE GIVEN
!       VALUE OF THE SMOOTHING PARAMETER P AS ENTERED IN VALU.

!       (2) THE NUMBER OF ARITHMETIC OPERATIONS AND THE AMOUNT OF
!       STORAGE REQUIRED ARE BOTH PROPORTIONAL TO N, SO VERY LARGE
!       DATASETS MAY BE ACCOMODATED. THE DATA POINTS DO NOT HAVE
!       TO BE EQUIDISTANT IN THE INDEPENDANT VARIABLE X OR UNIFORMLY
!       WEIGHTED IN THE DEPENDANT VARIABLE Y. HOWEVER, THE DATA
!       POINTS IN X MUST BE STRICTLY INCREASING. MULTIPLE DATASET
!       PROCESSING (K < 1) IS NUMERICALLY MORE EFFICIENT DAN
!       SEPARATE PROCESSING OF THE INDIVIDUAL DATASETS (K == 1).

!       (3) IF |MD| = 3 (A PRIORI KNOWN NOISE VARIANCE), ANY VALUE OF
!       N >= 2*M IS ACCEPTABLE. HOWEVER, IT IS ADVISABLE FOR N-2*M
!       BE RATHER LARGE (AT LEAST 20) IF |MD| = 2 (GCV).

!       (4) FOR |MD| > 1, GCVSPL TRIES TO ITERATIVELY MINIMIZE THE
!       SELECTED CRITERION FUNCTION. THIS MINIMUM IS UNIQUE FOR |MD|
!       = 4, BUT NOT NECESSARILY FOR |MD| = 2 OR 3. CONSEQUENTLY,
!       LOCAL OPTIMA RATHER THAT THE GLOBAL OPTIMUM MIGHT BE FOUND,
!       AND SOME ACTUAL FINDINGS SUGGEST THAT LOCAL OPTIMA MIGHT
!       YIELD MORE MEANINGFUL RESULTS THAN THE GLOBAL OPTIMUM IF N
!       IS SMALL. THEREFORE, THE USER HAS SOME CONTROL OVER THE
!       SEARCH PROCEDURE. IF MD > 1, THE ITERATIVE SEARCH STARTS
!       FROM A VALUE WHICH YIELDS A NUMBER OF DEGREES OF FREEDOM
!       WHICH IS APPROXIMATELY EQUAL TO N/2, UNTIL THE FIRST (LOCAL)
!       MINIMUM IS FOUND VIA A GOLDEN SECTION SEARCH PROCEDURE
!       (UTRERAS, 1980). IF MD < -1, THE VALUE FOR P CONTAINED IN
!       WK(4) IS USED INSTEAD. THUS, IF MD = 2 OR 3 YIELD TOO NOISY
!       AN ESTIMATE, THE USER MIGHT TRY |MD| = 1 OR 4, FOR SUITABLY
!       SELECTED VALUES FOR P OR FOR THE NUMBER OF DEGREES OF
!       FREEDOM, AND THEN RUN GCVSPL WITH MD = -2 OR -3. THE CON-
!       TENTS OF N, M, K, X, WX, WY, AND WK ARE ASSUMED UNCHANGED
!       SINCE THE LAST CALL TO GCVSPL IF MD < 0.

!       (5) GCVSPL CALCULATES THE SPLINE COEFFICIENT ARRAY C(N,K);
!       THIS ARRAY CAN BE USED TO CALCULATE THE SPLINE FUNCTION
!       VALUE AND ANY OF ITS DERIVATIVES UP TO THE DEGREE 2*M-1
!       AT ANY ARGUMENT T WITHIN THE KNOT RANGE, USING SUBROU-
!       TINES SPLDER AND SEARCH, AND THE KNOT ARRAY X(N). SINCE
!       THE SPLINES ARE CONSTRAINED AT THEIR MTH DERIVATIVE, ONLY
!       THE LOWER SPLINE DERIVATIVES WILL TEND TO BE RELIABLE
!       ESTIMATES OF THE UNDERLYING, TRUE SIGNAL DERIVATIVES.

!       (6) GCVSPL COMBINES ELEMENTS OF SUBROUTINE CRVO5 BY UTRE-
!       RAS (1980), SUBROUTINE SMOOTH BY LYCHE ET AL. (1983), AND
!       SUBROUTINE CUBGCV BY HUTCHINSON (1985). THE TRACE OF THE
!       INFLUENCE MATRIX IS ASSESSED IN A SIMILAR WAY AS DESCRIBED
!       BY HUTCHINSON & DE HOOG (1985). THE MAJOR DIFFERENCE IS
!       THAT THE PRESENT APPROACH UTILIZES NON-SYMMETRICAL B-SPLINE
!       DESIGN MATRICES AS DESCRIBED BY LYCHE ET AL. (1983); THERE-
!       FORE, THE ORIGINAL ALGORITHM BY ERISMAN & TINNEY (1975) HAS
!       BEEN USED, RATHER THAN THE SYMMETRICAL VERSION ADOPTED BY
!       HUTCHINSON & DE HOOG.

! REFERENCES:
! **********

!       P. CRAVEN & G. WAHBA (1979), SMOOTHING NOISY DATA WITH
!       SPLINE FUNCTIONS. NUMERISCHE MATHEMATIK 31, 377-403.

!       A.M. ERISMAN & W.F. TINNEY (1975), ON COMPUTING CERTAIN
!       ELEMENTS OF THE INVERSE OF A SPARSE MATRIX. COMMUNICATIONS
!       OF THE ACM 18(3), 177-179.

!       M.F. HUTCHINSON & F.R. DE HOOG (1985), SMOOTHING NOISY DATA
!       WITH SPLINE FUNCTIONS. NUMERISCHE MATHEMATIK 47(1), 99-106.

!       M.F. HUTCHINSON (1985), SUBROUTINE CUBGCV. CSIRO DIVISION OF
!       MATHEMATICS AND STATISTICS, P.O. BOX 1965, CANBERRA, ACT 2601,
!       AUSTRALIA.

!       T. LYCHE, L.L. SCHUMAKER, & K. SEPEHRNOORI (1983), FORTRAN
!       SUBROUTINES FOR COMPUTING SMOOTHING AND INTERPOLATING NATURAL
!       SPLINES. ADVANCES IN ENGINEERING SOFTWARE 5(1), 2-5.

!       F. UTRERAS (1980), UN PAQUETE DE PROGRAMAS PARA AJUSTAR CURVAS
!       MEDIANTE FUNCIONE_WS SPLINE. INFORME TECNICO MA-80-B-209, DEPAR-
!       TAMENTO DE MATEMATICAS, FACULDAD DE CIENCIAS FISICAS Y MATEMA-
!       TICAS, UNIVERSIDAD DE CHILE, SANTIAGO.

!       WAHBA, G. (1980). NUMERICAL AND STATISTICAL METHODS FOR MILDLY,
!       MODERATELY AND SEVERELY ILL-POSED PROBLEMS WITH NOISY DATA.
!       TECHNICAL REPORT NR. 595 (FEBRUARY 1980). DEPARTMENT OF STATIS-
!       TICS, UNIVERSITY OF MADISON (WI), U.S.A.

! SUBPROGRAMS REQUIRED:
! ********************

!       BASIS, PREP, SPLC, BANDET, BANSOL, TRINV
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
SUBROUTINE GCVSPL(X,Y,NY,WX,WY,M,N,K,MD,VALU,C,NC,WK,IER)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                               :: IABS
!...
!...DECLARE TRANSFERRED VARIABLES
INTEGER(I4B), INTENT(IN)                                :: K, N, M, MD, NC, NY
INTEGER(I4B), INTENT(OUT)                               :: IER
REAL(WP), INTENT(IN)                                    :: VALU
REAL(WP), DIMENSION(1:N), INTENT(IN)                    :: X, WX
REAL(WP), DIMENSION(1:K), INTENT(IN)                    :: WY
REAL(WP), DIMENSION(1:NY,1:K), INTENT(IN)               :: Y
REAL(WP), DIMENSION(1:NC,1:K), INTENT(OUT)              :: C
REAL(WP), DIMENSION(1:N+(6*((N*M)+1))), INTENT(INOUT)   :: WK
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                            :: I, IB, IWE, J, M2=0, NM1=0, NM2M1, NM2P1
INTEGER(I4B), PARAMETER                                 :: IBWE = 7
REAL(WP)                                                :: ALPHA, EL=ZERO_W, ERR1, GF1, GF2, GF3, GF4, R1, R2, R3, R4, SPLC
REAL(WP), PARAMETER                                     :: RATIO = TWO_W
REAL(WP), PARAMETER                                     :: TOL = MILLIONTH_W
REAL(WP), PARAMETER                                     :: EPS = 1.0E-15_WP
REAL(WP), PARAMETER                                     :: EPSINV = ONE_W/EPS

SAVE EL, NM1, M2

IER = 0
IF (((((IABS(MD) > 4) .OR. (MD == 0)) .OR. ((IABS(MD) == 1) .AND.           &
      (VALU < ZERO_W))) .OR. ((IABS(MD) == 3) .AND.                         &
      (VALU < ZERO_W))) .OR. ((IABS(MD) == 4) .AND.                         &
     ((VALU < ZERO_W)   .OR.  (VALU > (N-M))))) THEN
!...
!...WRONG MODE VALUE
    IER = 3
    RETURN
!...
!...CHECK ON M AND N
ENDIF
IF (MD > 0) THEN
    M2 = 2*M
    NM1 = N-1
ELSE
    IF ((M2 /= (2*M)) .OR. (NM1 /= (N-1))) THEN
!...
!...M OR N MODIFIED SINCE PREVIOUS CALL
        IER = 3
        RETURN
    ENDIF
ENDIF
IF ((M <= 0) .OR. (N < M2)) THEN
!...
!...M OR N INVALID
    IER = 1
    RETURN
!...
!...CHECK ON KNOT SEQUENCE AND WEIGHTS
ENDIF
IF (WX(1) <= ZERO_W) IER = 2
DO I = 2,N
    IF ((WX(I) <= ZERO_W) .OR. (X(I-1) >= X(I))) IER = 2
    IF (IER /= 0) RETURN
ENDDO
DO J = 1,K
    IF (WY(J) <= ZERO_W) IER = 2
    IF (IER /= 0) RETURN
!...
!...WORK ARRAY PARAMETERS (ADDRESS INFORMATION FOR COVARIANCE
!...PROPAGATION BY MEANS OF THE MATRICES STAT, B, AND WE). NB:
!...BWE CANNOT BE USED SINCE IT IS MODIFIED BY FUNCTION TRINV.

ENDDO
NM2P1 = N*(M2+1)
!...
!...ISTAT = 1               STATISTICS ARRAY STATT(6)
!...IBWE  = ISTAT + 6       SMOOTHING MATRIX BWE(-M:M,N)
NM2M1 = N*(M2-1)
!...
!...DESIGN MATRIX B         (1-M:M-1,N)
IB = IBWE+NM2P1
!...
!...IWK = IWE + NM2P1       TOTAL WORK ARRAY LENGTH N + 6*(N*M+1)
!...
!...COMPUTE THE DESIGN MATRICES B AND WE, THE RATIO
!...OF THEIR L1-NORMS, AND CHECK FOR ITERATIVE MODE.
!...
!...DESIGN MATRIX WE(-M:M,N)
IWE = IB+NM2M1
IF (MD > 0) THEN
    CALL BASIS(M,N,X,WK(IB),R1,WK(IBWE))
    CALL  PREP(M,N,X,WX,WK(IWE),EL)
!...
!...L1-NORMS RATIO (SAVED UPON RETURN)
    EL = EL/R1
ENDIF
!...
!...PRIOR GIVEN VALUE FOR P
IF (IABS(MD) /= 1) GOTO 20
R1 = VALU
!...
!...ITERATE TO MINIMIZE THE GCV FUNCTION (|MD|=2), THE MSE FUNCTION (|MD|=3),
!...OR TO OBTAIN THE PRIOR GIVEN NUMBER OF DEGREES OF FREEDOM (|MD|=4).

GOTO 100
20 CONTINUE
IF (MD < (-1)) THEN
!...
!...USER-DETERMINED STARTING VALUE
    R1 = WK(4)
ELSE
!...
!...DEFAULT (DOF ~ 0.5)
    R1 = ONE_W/EL
ENDIF
R2 = R1*RATIO
GF2 = SPLC(M,N,K,Y,NY,WX,WY,MD,VALU,R2,EPS,C,NC,WK,WK(IB),WK(IWE),EL,WK(IBWE))
40 CONTINUE
GF1 = SPLC(M,N,K,Y,NY,WX,WY,MD,VALU,R1,EPS,C,NC,WK,WK(IB),WK(IWE),EL,WK(IBWE))
IF (GF1 > GF2) GOTO 50
!...
!...INTERPOLATION
IF (WK(4) <= ZERO_W) GOTO 100
R2 = R1
GF2 = GF1
R1 = R1/RATIO
GOTO 40
50 CONTINUE
R3 = R2*RATIO
60 CONTINUE
GF3 = SPLC(M,N,K,Y,NY,WX,WY,MD,VALU,R3,EPS,C,NC,WK,WK(IB),WK(IWE),EL,WK(IBWE))
IF (GF3 > GF2) GOTO 70
!...
!...LEAST-SQUARES POLYNOMIAL
IF (WK(4) >= EPSINV) GOTO 100
R2 = R3
GF2 = GF3
R3 = R3*RATIO
GOTO 60
70 CONTINUE
R2 = R3
GF2 = GF3
ALPHA = (R2-R1)/PHI_W   !PHI = GOLDEN RATIO
R4 = R1+ALPHA
R3 = R2-ALPHA
GF3 = SPLC(M,N,K,Y,NY,WX,WY,MD,VALU,R3,EPS,C,NC,WK,WK(IB),WK(IWE),EL,WK(IBWE))
GF4 = SPLC(M,N,K,Y,NY,WX,WY,MD,VALU,R4,EPS,C,NC,WK,WK(IB),WK(IWE),EL,WK(IBWE))
80 CONTINUE
IF (GF3 <= GF4) THEN
    R2 = R4
    GF2 = GF4
    ERR1 = (R2-R1) / (R1+R2)
    IF ((((ERR1*ERR1) + ONE_W) == ONE_W) .OR. (ERR1 <= TOL)) GOTO 90
    R4 = R3
    GF4 = GF3
    ALPHA = ALPHA/PHI_W
    R3 = R2-ALPHA
    GF3 = SPLC(M,N,K,Y,NY,WX,WY,MD,VALU,R3,EPS,C,NC,WK,WK(IB),WK(IWE),EL,WK(IBWE))
ELSE
    R1 = R3
    GF1 = GF3
    ERR1 = (R2-R1) / (R1+R2)
    IF ((((ERR1 * ERR1) + ONE_W) == ONE_W) .OR. (ERR1 <= TOL)) GOTO 90
    R3 = R4
    GF3 = GF4
    ALPHA = ALPHA/PHI_W
    R4 = R1 + ALPHA
    GF4 = SPLC(M,N,K,Y,NY,WX,WY,MD,VALU,R4,EPS,C,NC,WK,WK(IB),WK(IWE),EL,WK(IBWE))
ENDIF
GOTO 80
!...
!...CALCULATE FINAL SPLINE COEFFICIENTS
90 CONTINUE
R1 = HALF_W*(R1+R2)
!...
!...READY
100 CONTINUE
GF1 = SPLC(M,N,K,Y,NY,WX,WY,MD,VALU,R1,EPS,C,NC,WK,WK(IB),WK(IWE),EL,WK(IBWE))
!...
!...DONE
RETURN
END SUBROUTINE GCVSPL
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                   SUBROUTINE BASIS                   *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 08/20/18          *
!...   *                                                      *
!...    ******************************************************
!...
! BASIS.FOR, 1985-06-03

!***********************************************************************

! SUBROUTINE BASIS (REAL*8)

! PURPOSE:
! *******

!       SUBROUTINE TO ASSESS A B-SPLINE TABLEAU, STORED IN VECTORIZED
!       FORM.

! CALLING CONVENTION:
! ******************

!       CALL BASIS ( M, N, X, B, BL, Q )

! MEANING OF PARAMETERS:
! *********************

!       M               ( I )   HALF_W ORDER OF THE SPLINE (DEGREE 2*M-1),
!                               M > 0.
!       N               ( I )   NUMBER OF KNOTS, N >= 2*M.
!       X(N)            ( I )   KNOT SEQUENCE, X(I-1) < X(I), I=2,N.
!       B(1-M:M-1,N)    ( O )   OUTPUT TABLEAU. ELEMENT B(J,I) OF ARRAY
!                               B CORRESPONDS WITH ELEMENT B(I,I+J) OF
!                               THE TABLEAU MATRIX B.
!       BL              ( O )   L1-NORM OF B.
!       Q(1-M:M)        ( W )   INTERNAL WORK ARRAY.

! REMARK:
! ******

!       THIS SUBROUTINE IS AN ADAPTATION OF SUBROUTINE BASIS FROM THE
!       PAPER BY LYCHE ET AL. (1983). NO CHECKING IS PERFORMED ON THE
!       VALIDITY OF M AND N. IF THE KNOT SEQUENCE IS NOT STRICTLY IN-
!       CREASING, DIVISION BY ZERO_W MAY OCCUR.

! REFERENCE:
! *********

!       T. LYCHE, L.L. SCHUMAKER, & K. SEPEHRNOORI, FORTRAN SUBROUTINES
!       FOR COMPUTING SMOOTHING AND INTERPOLATING NATURAL SPLINES.
!       ADVANCES IN ENGINEERING SOFTWARE 5(1983)1, PP. 2-5.
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
SUBROUTINE BASIS(M,N,X,B,BL,Q)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                               :: ABS, MAX0, MIN0
!...
!...DECLARE TRANSFERRED VARIABLES
INTEGER(I4B), INTENT(IN)                                :: M, N
REAL(WP), DIMENSION(1:N), INTENT(IN)                    :: X
REAL(WP), INTENT(OUT)                                   :: BL
REAL(WP), DIMENSION(1-M:M-1,N), INTENT(OUT)             :: B
REAL(WP), DIMENSION(1-M:M), INTENT(OUT)                 :: Q
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                            :: I, IR, J, J1, J2, K, L, M2, MM1, MP1, NMIP1
REAL(WP)                                                :: ARG, U, V, Y
!...
!...LINEAR SPLINE
IF (M == 1) THEN
    DO I = 1,N
        B(0,I) = ONE_W
    ENDDO
    BL = ONE_W
    RETURN
!...
!...GENERAL SPLINES
ENDIF
MM1 = M-1
MP1 = M+1
M2  = 2*M
!...
!...1ST ROW
DO L = 1,N
    DO J = -MM1,M
        Q(J) = ZERO_W
    ENDDO
    Q(MM1) = ONE_W
!...
!...SUCCESSIVE ROWS
    IF ((L /= 1) .AND. (L /= N)) Q(MM1) = ONE_W/(X(L+1)-X(L-1))
    ARG = X(L)
    DO I = 3,M2
        IR = MP1-I
        V = Q(IR)
!...
!...LEFT-HAND B-SPLINES
        IF (L < I) THEN
            DO J = L+1,I
                U = V
                V = Q(IR+1)
                Q(IR) = U+((X(J)-ARG)*V)
                IR = IR+1
            ENDDO
        ENDIF
        J1 = MAX0((L-I)+1, 1)
        J2 = MIN0(L-1, N-I)
!...
!...ORDINARY B-SPLINES
        IF (J1 <= J2) THEN
            IF (I < M2) THEN
                DO J = J1,J2
                    Y = X(I+J)
                    U = V
                    V = Q(IR+1)
                    Q(IR) = U + (((V-U)*(Y-ARG))/(Y-X(J)))
                    IR = IR+1
                ENDDO
            ELSE
                DO J = J1,J2
                    U = V
                    V = Q(IR+1)
                    Q(IR) = ((ARG-X(J))*U) + ((X(I+J) - ARG)*V)
                    IR = IR + 1
                ENDDO
            ENDIF
        ENDIF
        NMIP1 = (N-I) + 1
!...
!...RIGHT-HAND B-SPLINES
        IF (NMIP1 < L) THEN
            DO J = NMIP1,L-1
                U = V
                V = Q(IR+1)
                Q(IR) = ((ARG-X(J))*U) + V
                IR = IR+1
            ENDDO
        ENDIF
    ENDDO
    DO  J = -MM1,MM1
        B(J,L) = Q(J)
    ENDDO
ENDDO
!...
!...ZERO_W UNUSED PARTS OF B
DO I = 1,MM1
    DO K = I,MM1
        B(-K,I) = ZERO_W
        B(K,(N+1) - I) = ZERO_W
    ENDDO
ENDDO
!...
!...ASSESS L1-NORM OF B
BL = ZERO_W
DO I = 1,N
    DO K = -MM1,MM1
        BL = BL + ABS(B(K,I))
    ENDDO
ENDDO
BL = BL/N
!...
!...DONE
RETURN
END SUBROUTINE BASIS
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                   SUBROUTINE PREP                    *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 08/20/18          *
!...   *                                                      *
!...    ******************************************************
!...
! PREP.FOR, 1985-07-04

!***********************************************************************

! SUBROUTINE PREP (REAL*8)

! PURPOSE:
! *******

!       TO COMPUTE THE MATRIX WE OF WEIGHTED DIVIDED DIFFERENCE COEFFI-
!       CIENTS NEEDED TO SET UP A LINEAR SYSTEM OF EQUATIONS FOR SOL-
!       VING B-SPLINE SMOOTHING PROBLEMS, AND ITS L1-NORM EL. THE MATRIX
!       WE IS STORED IN VECTORIZED FORM.

! CALLING CONVENTION:
! ******************

!       CALL PREP ( M, N, X, W, WE, EL )

! MEANING OF PARAMETERS:
! *********************

!       M               ( I )   HALF_W ORDER OF THE B-SPLINE (DEGREE
!                               2*M-1), WITH M > 0.
!       N               ( I )   NUMBER OF KNOTS, WITH N >= 2*M.
!       X(N)            ( I )   STRICTLY INCREASING KNOT ARRAY, WITH
!                               X(I-1) < X(I), I=2,N.
!       W(N)            ( I )   WEIGHT MATRIX (DIAGONAL), WITH
!                               W(I) > 0.0, I=1,N.
!       WE(-M:M,N)      ( O )   ARRAY CONTAINING THE WEIGHTED DIVIDED
!                               DIFFERENCE TERMS IN VECTORIZED FORMAT.
!                               ELEMENT WE(J,I) OF ARRAY E CORRESPONDS
!                               WITH ELEMENT E(I,I+J) OF THE MATRIX
!                               W**-1 * E.
!       EL              ( O )   L1-NORM OF WE.

! REMARK:
! ******

!       THIS SUBROUTINE IS AN ADAPTATION OF SUBROUTINE PREP FROM THE PAPER
!       BY LYCHE ET AL. (1983). NO CHECKING IS PERFORMED ON THE VALIDITY
!       OF M AND N. DIVISION BY ZERO_W MAY OCCUR IF THE KNOT SEQUENCE IS
!       NOT STRICTLY INCREASING.

! REFERENCE:
! *********

!       T. LYCHE, L.L. SCHUMAKER, & K. SEPEHRNOORI, FORTRAN SUBROUTINES
!       FOR COMPUTING SMOOTHING AND INTERPOLATING NATURAL SPLINES.
!       ADVANCES IN ENGINEERING SOFTWARE 5(1983)1, PP. 2-5.

!***********************************************************************


SUBROUTINE PREP(M,N,X,W,WE,EL)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                               :: ABS
!...
!...DECLARE TRANSFERRED VARIABLES
INTEGER(I4B), INTENT(IN)                                :: M, N
REAL(WP), DIMENSION(1:N), INTENT(IN)                    :: W, X
REAL(WP), INTENT(OUT)                                   :: EL
REAL(WP), DIMENSION(1:((2*M)+1)*N), INTENT(OUT)         :: WE
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                            :: I, I1P1, I1, I2, I2M1, INC, J, JJ, JM, K, KL, KU, L
INTEGER(I4B)                                            :: M2, M2M1, M2P1, MP1, N2M, NM
REAL(WP)                                                :: F, F1, FF, WI, Y
!...
!...CALCULATE THE FACTOR F1
M2   =  2*M
MP1  =  M+1
M2M1 =  M2-1
M2P1 =  M2+1
NM   =  N-M
F1   = -ONE_W
IF (M /= 1) THEN
    DO I = 2,M
        F1 = -(F1*I)
    ENDDO
    DO I = MP1,M2M1
        F1 = F1*I
    ENDDO
ENDIF
!...
!...COLUMN-WISE EVALUATION OF THE UNWEIGHTED DESIGN MATRIX E
I1 = 1
I2 = M
JM = MP1
DO J = 1,N
    INC = M2P1
    IF (J > NM) THEN
        F1 = -F1
        F  =  F1
    ELSE
        IF (J < MP1) THEN
            INC = 1
            F = F1
        ELSE
            F = F1 * (X(J+M)-X(J-M))
        ENDIF
    ENDIF
    IF (J > MP1) I1 = I1+1
    IF (I2 <  N) I2 = I2+1
!...
!...LOOP FOR DIVIDED DIFFERENCE COEFFICIENTS
    JJ = JM
    FF = F
     Y = X(I1)
    I1P1 = I1+1
    DO I = I1P1,I2
        FF = FF/(Y-X(I))
    ENDDO
    WE(JJ) = FF
    JJ = JJ+M2
    I2M1 = I2-1
    IF (I1P1 <= I2M1) THEN
        DO L = I1P1,I2M1
            FF = F
             Y = X(L)
            DO I = I1,L-1
                FF = FF/(Y-X(I))
            ENDDO
            DO I = L+1,I2
                FF = FF/(Y-X(I))
            ENDDO
            WE(JJ) = FF
            JJ = JJ+M2
        ENDDO
    ENDIF
    FF = F
     Y = X(I2)
    DO I = I1,I2M1
        FF = FF/(Y-X(I))
    ENDDO
    WE(JJ) = FF
    JJ = JJ+M2
    JM = JM+INC
ENDDO
!...
!...ZERO THE UPPER LEFT AND LOWER RIGHT CORNERS OF E
KL  = 1
N2M = (M2P1*N)+1
DO I = 1,M
    KU = (KL+M)-I
    DO K = KL,KU
        WE(K) = ZERO_W
        WE(N2M-K) = ZERO_W
    ENDDO
    KL = KL+M2P1
ENDDO
!...
!...WEIGHTED MATRIX WE = W**-1 * E AND ITS L1-NORM
JJ = 0
EL = ZERO_W
DO I = 1,N
    WI = W(I)
    DO J = 1,M2P1
        JJ = JJ+1
        WE(JJ) = WE(JJ)/WI
        EL = EL + ABS(WE(JJ))
    ENDDO
ENDDO
EL = EL/N
!...
!...DONE
RETURN
END SUBROUTINE PREP
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                   SUBROUTINE SPLC                    *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 08/20/18          *
!...   *                                                      *
!...    ******************************************************
!...
! SPLC.FOR, 1985-12-12

! AUTHOR: H.J. WOLTRING

! ORGANIZATIONS: UNIVERSITY OF NIJMEGEN, AND
!                PHILIPS MEDICAL SYSTEMS, EINDHOVEN
!                (THE NETHERLANDS)

!***********************************************************************

! FUNCTION SPLC (REAL*8)

! PURPOSE:
! *******

!       TO ASSESS THE COEFFICIENTS OF A B-SPLINE AND VARIOUS STATISTICAL
!       PARAMETERS, FOR A GIVEN VALUE OF THE REGULARIZATION PARAMETER P.

! CALLING CONVENTION:
! ******************

!       FV = SPLC ( M, N, K, Y, NY, WX, WY, MODE, VALU, P, EPS, C, NC,
!       1           STAT, B, WE, EL, BWE)

! MEANING OF PARAMETERS:
! *********************

!       SPLC            ( O )   GCV FUNCTION VALUE IF |MODE| == 2,
!                               MSE VALUE IF |MODE| == 3, AND ABSOLUTE
!                               DIFFERENCE WITH THE PRIOR GIVEN NUMBER OF
!                               DEGREES OF FREEDOM IF |MODE| == 4.
!       M               ( I )   HALF_W ORDER OF THE B-SPLINE (DEGREE 2*M-1),
!                               WITH M > 0.
!       N               ( I )   NUMBER OF OBSERVATIONS, WITH N >= 2*M.
!       K               ( I )   NUMBER OF DATASETS, WITH K >= 1.
!       Y(NY,K)         ( I )   OBSERVED MEASUREMENTS.
!       NY              ( I )   FIRST DIMENSION OF Y(NY,K), WITH NY >= N
!.
!       WX(N)           ( I )   WEIGHT FACTORS, CORRESPONDING TO THE
!                               RELATIVE INVERSE VARIANCE OF EACH MEASURE-
!                               MENT, WITH WX(I) > 0.0.
!       WY(K)           ( I )   WEIGHT FACTORS, CORRESPONDING TO THE
!                               RELATIVE INVERSE VARIANCE OF EACH DATASET,
!                               WITH WY(J) > 0.0.
!       MODE            ( I )   MODE SWITCH, AS DESCRIBED IN GCVSPL.
!       VALU            ( I )   PRIOR VARIANCE IF |MODE| == 3, AND
!                               PRIOR NUMBER OF DEGREES OF FREEDOM IF
!                               |MODE| == 4. FOR OTHER VALUES OF MODE,
!                               VALU IS NOT USED.
!       P               ( I )   SMOOTHING PARAMETER, WITH P >= 0.0. IF
!                               P == 0.0, AN INTERPOLATING SPLINE IS
!                               CALCULATED.
!       EPS             ( I )   RELATIVE ROUNDING TOLERANCE*10.0. EPS IS
!                               THE SMALLEST POSITIVE NUMBER SUCH THAT
!                               EPS/10.0 + 1.0 /= 1.0.
!       C(NC,K)         ( O )   CALCULATED SPLINE COEFFICIENT ARRAYS. NB:
!                               THE DIMENSIONS OF IN GCVSPL AND IN SPLDER
!                               ARE DIFFERENT! IN SPLDER, ONLY A SINGLE
!                               COLUMN OF C(N,K) IS NEEDED, AND THE PROPER
!                               COLUMN C(1,J), WITH J=1...K, SHOULD BE USED
!                               WHEN CALLING SPLDER.
!       NC              ( I )   FIRST DIMENSION OF C(NC,K), WITH NC >= N.
!       STATT(6)        ( O )   STATISTICS ARRAY. SEE THE DESCRIPTION IN
!                               SUBROUTINE GCVSPL.
!       B (1-M:M-1,N)   ( I )   B-SPLINE TABLEAU AS EVALUATED BY SUBROUTINE
!                               BASIS.
!       WE( -M:M  ,N)   ( I )   WEIGHTED B-SPLINE TABLEAU (W**-1 * E) AS
!                               EVALUATED BY SUBROUTINE PREP.
!       EL              ( I )   L1-NORM OF THE MATRIX WE AS EVALUATED BY
!                               SUBROUTINE PREP.
!       BWE(-M:M,N)     ( O )   CENTRAL 2*M+1 BANDS OF THE INVERTED
!                               MATRIX ( B  +  P * W**-1 * E )**-1

! REMARKS:
! *******

!       THIS SUBROUTINE COMBINES ELEMENTS OF SUBROUTINE SPLC0 FROM THE
!       PAPER BY LYCHE ET AL. (1983), AND OF SUBROUTINE SPFIT1 BY
!       HUTCHINSON (1985).

! REFERENCES:
! **********

!       M.F. HUTCHINSON (1985), SUBROUTINE CUBGCV. CSIRO DIVISION OF
!       MATHEMATICS AND STATISTICS, P.O. BOX 1965, CANBERRA, ACT 2601,
!       AUSTRALIA.

!       T. LYCHE, L.L. SCHUMAKER, & K. SEPEHRNOORI, FORTRAN SUBROUTINES
!       FOR COMPUTING SMOOTHING AND INTERPOLATING NATURAL SPLINES.
!       ADVANCES IN ENGINEERING SOFTWARE 5(1983)1, PP. 2-5.

!***********************************************************************

REAL(WP) FUNCTION SPLC(M,N,K,Y,NY,WX,WY,MODE,VALU,P,EPS,C,NC,STATT,B,WE,EL,BWE)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                               :: ABS, IABS, MAX0, MIN0
!...
!...DECLARE TRANSFERRED VARIABLES
INTEGER(I4B), INTENT(IN)                                :: K, N, M, MODE, NC, NY
REAL(WP), INTENT(IN)                                    :: EL, EPS, P
REAL(WP), INTENT(IN)                                    :: VALU
REAL(WP), DIMENSION(1-M:M-1,N), INTENT(IN)              :: B
REAL(WP), DIMENSION(1:N), INTENT(IN)                    :: WX
REAL(WP), DIMENSION(1:K), INTENT(IN)                    :: WY
REAL(WP), DIMENSION(1:NY,1:K), INTENT(IN)               :: Y
REAL(WP), DIMENSION(-M:M,1:N), INTENT(IN)               :: WE
REAL(WP), DIMENSION(1:NC,1:K), INTENT(OUT)              :: C
REAL(WP), DIMENSION(-M:M,1:N), INTENT(OUT)              :: BWE
REAL(WP), DIMENSION(1:6), INTENT(OUT)                   :: STATT
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                            :: I, J, KM, KP, L
REAL(WP)                                                :: DQ, DT, ESN, PEL, TRN, TRINV
!...
!...CHECK ON P-VALUE
DQ = P
STATT(4) = P
!...
!...PSEUDO-INTERPOLATION IF P IS TOO SMALL
PEL = P*EL
IF (PEL < EPS) THEN
    DQ = EPS/EL
    STATT(4) = ZERO_W
ENDIF
!...
!...PSEUDO LEAST-SQUARES POLYNOMIAL IF P IS TOO LARGE
IF ((PEL*EPS) > ONE_W) THEN
    DQ = ONE_W/(EL*EPS)
    STATT(4) = DQ
ENDIF
!...
!...CALCULATE  BWE = B + P * W**-1 * E
DO I = 1,N
    KM = -MIN0(M, I-1)
    KP =  MIN0(M, N-I)
    DO L = KM,KP
        IF (IABS(L) == M) THEN
            BWE(L,I) = DQ*WE(L,I)
        ELSE
            BWE(L,I) = B(L,I) + (DQ*WE(L,I))
        ENDIF
    ENDDO
ENDDO
!...
!...SOLVE BWE * C = Y, AND ASSESS TRACE (B * BWE**-1)
CALL BANDET(BWE,M,N)
CALL BANSOL(BWE,Y,NY,C,NC,M,N,K)
!...
!...TRACE * P = RES. D.O.
STATT(3) = TRINV(WE,BWE,M,N)*DQ
!...
!...COMPUTE MEAN-SQUARED WEIGHTED RESIDUAL
TRN = STATT(3)/N
ESN = ZERO_W
DO J = 1,K
    DO I = 1,N
        DT = -Y(I,J)
        KM = -MIN0(M-1, I-1)
        KP =  MIN0(M-1, N-I)
        DO L = KM,KP
            DT = DT + (B(L,I)*C(I+L,J))
        ENDDO
        ESN = ESN + (((DT*DT)*WX(I))*WY(J))
    ENDDO
ENDDO
!...
!...CALCULATE STATISTICS AND FUNCTION VALUE
ESN = ESN/(N*K)
!...
!...ESTIMATED VARIANCE
STATT(6) = ESN/TRN
!...
!...GCV FUNCTION VALUE
STATT(1) = STATT(6)/TRN
!...
!...STATT(3) = TRACE [P*B * BWE**-1]    ESTIMATED RESIDUALS' D.O.F.
!...STATT(4) = P                        NORMALIZED SMOOTHING FACTOR
!...
!...MEAN SQUARED RESIDUAL
STATT(2) = ESN
!...
!...UNKNOWN VARIANCE: GCV
IF (IABS(MODE) /= 3) THEN
    STATT(5) = STATT(6) - ESN
    IF (IABS(MODE) == 1) SPLC = ZERO_W
    IF (IABS(MODE) == 2) SPLC = STATT(1)
    IF (IABS(MODE) == 4) SPLC = ABS(STATT(3) - VALU)
!...
!...KNOWN VARIANCE: ESTIMATED MEAN SQUARED ERROR
ELSE
    STATT(5) = ESN - (VALU*((TWO_W*TRN)-ONE_W))
    SPLC = STATT(5)
ENDIF
!...
!...DONE
RETURN
END FUNCTION SPLC
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                  SUBROUTINE BANDET                   *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 08/20/18          *
!...   *                                                      *
!...    ******************************************************
!...
! BANDET.FOR, 1985-06-03

!***********************************************************************

! SUBROUTINE BANDET (REAL*8)

! PURPOSE:
! *******

!       THIS SUBROUTINE COMPUTES THE LU DECOMPOSITION OF AN N*N MATRIX
!       E. IT IS ASSUMED THAT E HAS M BANDS ABOVE AND M BANDS BELOW THE
!       DIAGONAL. THE DECOMPOSITION IS RETURNED IN E. IT IS ASSUMED THAT
!       E CAN BE DECOMPOSED WITHOUT PIVOTING. THE MATRIX E IS STORED IN
!       VECTORIZED FORM IN THE ARRAY E(-M:M,N), WHERE ELEMENT E(J,I) OF
!       THE ARRAY E CORRESPONDS WITH ELEMENT E(I,I+J) OF THE MATRIX E.

! CALLING CONVENTION:
! ******************

!       CALL BANDET ( E, M, N )

! MEANING OF PARAMETERS:
! *********************

!       E(-M:M,N)       (I/O)   MATRIX TO BE DECOMPOSED.
!       M, N            ( I )   MATRIX DIMENSIONING PARAMETERS,
!                               M >= 0, N >= 2*M.

! REMARK:
! ******

!       NO CHECKING ON THE VALIDITY OF THE INPUT DATA IS PERFORMED.
!       IF (M <= 0), NO ACTION IS TAKEN.

!***********************************************************************

SUBROUTINE BANDET(E,M,N)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                               :: MIN0
!...
!...DECLARE TRANSFERRED VARIABLES
INTEGER(I4B), INTENT(IN)                                :: M, N
REAL(WP), DIMENSION(-M:M,1:N), INTENT(INOUT)            :: E
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                            :: I, K, KM, L, LM, MI
REAL(WP)                                                :: DI, DL, DU
!...
!...BEGIN CALCULATIONS
IF (M <= 0) RETURN
DO I = 1,N
    DI = E(0,I)
    MI = MIN0(M, I-1)
    IF (MI >= 1) THEN
        DO K = 1,MI
            DI = DI - (E(-K,I)*E(K,I-K))
        ENDDO
        E(0,I) = DI
    ENDIF
    LM = MIN0(M, N-I)
    IF (LM >= 1) THEN
        DO L = 1,LM
            DL = E(-L,I+L)
            KM = MIN0(M-L, I-1)
            IF (KM >= 1) THEN
                DU = E(L,I)
                DO K = 1,KM
                    DU = DU - (E(-K,I)*E(L+K,I-K))
                    DL = DL - (E((-L)-K,L+I)*E(K,I-K))
                ENDDO
                E(L,I) = DU
            ENDIF
            E(-L,I+L) = DL/I
        ENDDO
    ENDIF
ENDDO
!...
!...DONE
RETURN
END SUBROUTINE BANDET
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                  SUBROUTINE BANSOL                   *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 08/20/18          *
!...   *                                                      *
!...    ******************************************************
!...
! BANSOL.FOR, 1985-12-12

!***********************************************************************

! SUBROUTINE BANSOL (REAL*8)

! PURPOSE:
! *******

!       THIS SUBROUTINE SOLVES SYSTEMS OF LINEAR EQUATIONS GIVEN AN LU
!       DECOMPOSITION OF THE DESIGN MATRIX. SUCH A DECOMPOSITION IS PRO-
!       VIDED BY SUBROUTINE BANDET, IN VECTORIZED FORM. IT IS ASSUMED
!       THAT THE DESIGN MATRIX IS NOT SINGULAR.

! CALLING CONVENTION:
! ******************

!       CALL BANSOL ( E, Y, NY, C, NC, M, N, K )

! MEANING OF PARAMETERS:
! *********************

!       E(-M:M,N)       ( I )   INPUT DESIGN MATRIX, IN LU-DECOMPOSED,
!                               VECTORIZED FORM. ELEMENT E(J,I) OF THE
!                               ARRAY E CORRESPONDS WITH ELEMENT
!                               E(I,I+J) OF THE N*N DESIGN MATRIX E.
!       Y(NY,K)         ( I )   RIGHT HAND SIDE VECTORS.
!       C(NC,K)         ( O )   SOLUTION VECTORS.
!       NY, NC, M, N, K ( I )   DIMENSIONING PARAMETERS, WITH M >= 0,
!                               N > 2*M, AND K >= 1.

! REMARK:
! ******

!       THIS SUBROUTINE IS AN ADAPTATION OF SUBROUTINE BANSOL FROM THE
!       PAPER BY LYCHE ET AL. (1983). NO CHECKING IS PERFORMED ON THE
!       VALIDITY OF THE INPUT PARAMETERS AND DATA. DIVISION BY ZERO_W MAY
!       OCCUR IF THE SYSTEM IS SINGULAR.

! REFERENCE:
! *********

!       T. LYCHE, L.L. SCHUMAKER, & K. SEPEHRNOORI, FORTRAN SUBROUTINES
!       FOR COMPUTING SMOOTHING AND INTERPOLATING NATURAL SPLINES.
!       ADVANCES IN ENGINEERING SOFTWARE 5(1983)1, PP. 2-5.

!***********************************************************************

SUBROUTINE BANSOL(E,Y,NY,C,NC,M,N,K)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                               :: MIN0
!...
!...DECLARE TRANSFERRED VARIABLES
INTEGER(I4B), INTENT(IN)                                :: K, N, M, NC, NY
REAL(WP), DIMENSION(-M:M,1:N), INTENT(IN)               :: E
REAL(WP), DIMENSION(1:NY,1:K), INTENT(IN)               :: Y
REAL(WP), DIMENSION(1:NC,1:K), INTENT(OUT)              :: C
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                            :: I, J, L, MI, NM1
REAL(WP)                                                :: D
!...
!...CHECK ON SPECIAL CASES: M = 0, M = 1, M > 1
NM1 = N-1
!...
!...M = 0: DIAGONAL SYSTEM
IF (M-1 < 0) THEN
    GOTO 10
ELSEIF (M-1 == 0) THEN
    GOTO 40
ELSE
    GOTO 80
ENDIF
10 CONTINUE
DO I = 1,N
    DO J = 1,K
        C(I,J) = Y(I,J)/E(0,I)
    ENDDO
ENDDO
!...
!...M = 1: TRIDIAGONAL SYSTEM
RETURN
40 CONTINUE
DO J = 1,K
    C(1,J) = Y(1,J)
!...
!...FORWARD SWEEP
    DO I = 2,N
        C(I,J) = Y(I,J) - (E(-1,I)*C(I-1,J))
    ENDDO
    C(N,J) = C(N,J)/E(0,N)
!...
!...BACKWARD SWEEP
    DO I = NM1,1,-1
        C(I,J) = (C(I,J) - (E(1,I)*C(I+1,J)))/E(0,I)
    ENDDO
ENDDO
!...
!...M > 1: GENERAL SYSTEM
RETURN
80 CONTINUE
DO J = 1,K
    C(1,J) = Y(1,J)
!...
!...FORWARD SWEEP
    DO I = 2,N
        MI = MIN0(M, I-1)
        D = Y(I,J)
        DO L = 1,MI
            D = D - (E(-L,I)*C(I-L,J))
        ENDDO
        C(I,J) = D
    ENDDO
    C(N,J) = C(N,J)/E(0,N)
!...
!...BACKWARD SWEEP
    DO I = NM1,1,-1
        MI = MIN0(M, N-I)
        D = C(I,J)
        DO L = 1,MI
            D = D - (E(L,I)*C(I+L,J))
        ENDDO
        C(I,J) = D/E(0,I)
    ENDDO
ENDDO
!...
!...DONE
RETURN
END SUBROUTINE BANSOL
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                   SUBROUTINE TRINV                   *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 08/20/18          *
!...   *                                                      *
!...    ******************************************************
!...
! TRINV.FOR, 1985-06-03

!***********************************************************************

! FUNCTION TRINV

! PURPOSE:
! *******

!       TO CALCULATE TRACE (B * E**-1), WHERE B AND E ARE N * N
!       MATRICES WITH BANDWIDTH 2*M+1, AND WHERE E IS A REGULAR MATRIX
!       IN LU-DECOMPOSED FORM. B AND E ARE STORED IN VECTORIZED FORM,
!       COMPATIBLE WITH SUBROUTINES BANDET AND BANSOL.

! CALLING CONVENTION:
! ******************

!       TRACE = TRINV ( B, E, M, N )

! MEANING OF PARAMETERS:
! *********************

!       B(-M:M,N)       ( I ) INPUT ARRAY FOR MATRIX B. ELEMENT B(J,I)
!                             CORRESPONDS WITH ELEMENT B(I,I+J) OF THE
!                             MATRIX B.
!       E(-M:M,N)       (I/O) INPUT ARRAY FOR MATRIX E. ELEMENT E(J,I)
!                             CORRESPONDS WITH ELEMENT E(I,I+J) OF THE
!                             MATRIX E. THIS MATRIX IS STORED IN LU-
!                             DECOMPOSED FORM, WITH L UNIT LOWER TRI-
!                             ANGULAR, AND U UPPER TRIANGULAR. THE UNIT
!                             DIAGONAL OF L IS NOT STORED. UPON RETURN,
!                             THE ARRAY E HOLDS THE CENTRAL 2*M+1 BANDS
!                             OF THE INVERSE E**-1, IN SIMILAR ORDERING.
!       M, N            ( I ) ARRAY AND MATRIX DIMENSIONING PARAMETERS
!                             (M > 0, N >= 2*M+1).
!       TRINV           ( O ) OUTPUT FUNCTION VALUE TRACE [ B * E**-1 ]

! REFERENCE:
! *********

!       A.M. ERISMAN & W.F. TINNEY, ON COMPUTING CERTAIN ELEMENTS OF THE
!       INVERSE OF A SPARSE MATRIX. COMMUNICATIONS OF THE ACM 18(1975),
!       NR. 3, PP. 177-179.

!***********************************************************************

REAL(WP) FUNCTION TRINV(B,E,M,N)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                               :: MIN0
!...
!...DECLARE TRANSFERRED VARIABLES
INTEGER(I4B), INTENT(IN)                                :: M, N
REAL(WP), DIMENSION(-M:M,1:N), INTENT(IN)               :: B
REAL(WP), DIMENSION(-M:M,1:N), INTENT(INOUT)            :: E
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                            :: I, J, K, MI, MN, MP
REAL(WP)                                                :: DD, DL, DU
!...
!...ASSESS CENTRAL 2*M+1 BANDS OF E**-1 AND STORE IN ARRAY E

!...
!...NTH PIVOT
E(0,N) = ONE_W/E(0,N)
DO I = N-1,1,-1
    MI = MIN0(M, N-I)
!...
!...SAVE ITH COLUMN OF L AND ITH ROW OF U, AND NORMALIZE U ROW
!...
!...ITH PIVOT
    DD = ONE_W/E(0,I)
    DO K = 1,MI
!...
!...ITH ROW OF U (NORMALIZED)
        E(K,N) = E(K,I)*DD
!...
!...ITH COLUMN OF L
        E(-K,1) = E(-K,K+I)
    ENDDO
!...
!...INVERT AROUND ITH PIVOT
    DD = TWO_W*DD
    DO J = MI,1,-1
        DU = ZERO_W
        DL = ZERO_W
        DO K = 1,MI
            DU = DU - (E(K,N) *E(J-K,I+K))
            DL = DL - (E(-K,1)*E(K-J,I+J))
        ENDDO
        E(J,I) = DU
        E(-J,J+I) = DL
        DD = DD - ((E(J,N)*DL)+(E(-J,1)*DU))
    ENDDO
    E(0,I) = HALF_W*DD
ENDDO
!...
!...ASSESS TRACE (B * E**-1) AND CLEAR WORKING STORAGE
DD = ZERO_W
DO I = 1,N
    MN = -MIN0(M, I-1)
    MP =  MIN0(M, N-I)
    DO K = MN,MP
        DD = DD+(B(K,I)*E(-K,K+I))
    ENDDO
ENDDO
TRINV = DD
DO K = 1,M
    E( K,N) = ZERO_W
    E(-K,1) = ZERO_W
ENDDO
!...
!...DONE
RETURN
END FUNCTION TRINV
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                   FUNCTION SPLDER                    *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 10/30/18          *
!...   *                                                      *
!...    ******************************************************
!...
! SPLDER.FOR, 1985-06-11

!***********************************************************************

! FUNCTION SPLDER (REAL*8)

! PURPOSE:
! *******

!       TO PRODUCE THE VALUE OF THE FUNCTION (IDER == 0) OR OF THE
!       IDERTH DERIVATIVE (IDER > 0) OF A 2M-TH ORDER B-SPLINE AT
!       THE POINT T. THE SPLINE IS DESCRIBED IN TERMS OF THE HALF_W
!       ORDER M, THE KNOT SEQUENCE X(N), N.GE.2*M, AND THE SPLINE
!       COEFFICIENTS C(N).

! CALLING CONVENTION:
! ******************

!       SVIDER = SPLDER ( IDER, M, N, T, X, C, L, Q )

! MEANING OF PARAMETERS:
! *********************

!       SPLDER  ( O )   FUNCTION OR DERIVATIVE VALUE.
!       IDER    ( I )   DERIVATIVE ORDER REQUIRED, WITH 0 <= IDER
!                       AND IDER <= 2*M. IF IDER. == 0, THE FUNCTION
!                       VALUE IS RETURNED; OTHERWISE, THE IDER-TH
!                       DERIVATIVE OF THE SPLINE IS RETURNED.
!       M       ( I )   HALF ORDER OF THE SPLINE, WITH M > 0.
!       N       ( I )   NUMBER OF KNOTS AND SPLINE COEFFICIENTS,
!                       WITH N >= 2*M.
!       T       ( I )   ARGUMENT AT WHICH THE SPLINE OR ITS DERI-
!                       VATIVE IS TO BE EVALUATED, WITH X(1) <= T
!                       AND T <= X(N).
!       X(N)    ( I )   STRICTLY INCREASING KNOT SEQUENCE ARRAY,
!                       X(I-1) < X(I), I=2,...,N.
!       C(N)    ( I )   SPLINE COEFFICIENTS, AS EVALUATED BY
!                       SUBROUTINE GVCSPL.
!       L       (I/O)   L CONTAINS AN INTEGER(I4B) SUCH THAT:
!                       X(L) <= T AND T < X(L+1) IF T IS WITHIN
!                       THE RANGE X(1).LE.T AND T < X(N). IF
!                       T < X(1), L IS SET TO 0, AND IF T >= X(N),
!                       L IS SET TO N. THE SEARCH FOR L IS FACILI-
!                       TATED IF L HAS APPROXIMATELY THE RIGHT
!                       VALUE ON ENTRY.
!       Q(2*M)  ( W )   INTERNAL WORK ARRAY.

! REMARK:
! ******

!       THIS SUBROUTINE IS AN ADAPTATION OF SUBROUTINE SPLDER OF
!       THE PAPER BY LYCHE ET AL. (1983). NO CHECKING IS PERFORMED
!       ON THE VALIDITY OF THE INPUT PARAMETERS.

! REFERENCE:
! *********

!       T. LYCHE, L.L. SCHUMAKER, & K. SEPEHRNOORI, FORTRAN SUBROUTINES
!       FOR COMPUTING SMOOTHING AND INTERPOLATING NATURAL SPLINES.
!       ADVANCES IN ENGINEERING SOFTWARE 5(1983)1, PP. 2-5.

!***********************************************************************

REAL(WP) FUNCTION SPLDER(IDER,M,N,T,X,C,L,Q)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                               :: MAX0, MIN0
!...
!...DECLARE TRANSFERRED VARIABLES
INTEGER(I4B), INTENT(IN)                                :: IDER, M, N
INTEGER(I4B), INTENT(INOUT)                             :: L
REAL(WP), INTENT(OUT)                                   :: T
REAL(WP), DIMENSION(1:N), INTENT(IN)                    :: C, X
REAL(WP), DIMENSION(1:2*M), INTENT(OUT)                 :: Q
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                            :: I, I1, II, IR, J, J1, J2, JIN, JJ, JL, JM, JU
INTEGER(I4B)                                            :: K, K1, KI, LK, LK1, LK1I, LK1I1, LM
INTEGER(I4B)                                            :: M2, M2M1, MI, ML, MP1, NK, NKI, NKI1, NPM
REAL(WP)                                                :: TT, XJKI, Z
!...
!...DERIVATIVES OF IDER >= 2*M ARE ALWAY ZERO
M2 = 2*M
K = M2-IDER
IF (K < 1) THEN
    SPLDER = ZERO_W
    RETURN
ENDIF
!...
!...SEARCH FOR THE INTERVAL VALUE L
!...
!...INITIALIZE PARAMETERS AND THE 1ST ROW OF THE B-SPLINE COEFFICIENTS TABLEAU
CALL SEARCH(N,X,T,L)
TT   = T
MP1  = M+1
NPM  = N+M
M2M1 = M2-1
K1   = K-1
NK   = N-K
LK   = L-K
LK1  = LK+1
LM   = L-M
JL   = L+1
JU   = L+M2
II   = N-M2
ML   = -L
DO J = JL,JU
    IF ((J >= MP1) .AND. (J <= NPM)) THEN
        Q(J+ML) = C(J-M)
    ELSE
        Q(J+ML) = ZERO_W
    ENDIF
ENDDO
!...
!...THE FOLLOWING LOOP COMPUTES DIFFERENCES OF THE B-SPLINE COEFFICIENTS.
!...IF THE VALUE OF THE SPLINE IS REQUIRED, DIFFERENCING IS NOT NECESSARY.
IF (IDER > 0) THEN
    JL = JL-M2
    ML = ML+M2
    DO I = 1,IDER
        JL = JL+1
        II = II+1
        J1 = MAX0(1, JL)
        J2 = MIN0(L, II)
        MI = M2-I
         J = J2+1
        IF (J1 <= J2) THEN
            DO JIN = J1,J2
                J  =  J-1
                JM = ML+J
                Q(JM) = (Q(JM)-Q(JM-1))/(X(J+MI)-X(J))
            ENDDO
        ENDIF
        IF (JL >= 1) CYCLE
        I1 =  I+1
        J  = ML+1
        IF (I1 <= ML) THEN
            DO JIN = I1,ML
                J = J-1
                Q(J) = -Q(J-1)
            ENDDO
        ENDIF
    ENDDO
    DO J = 1,K
        Q(J) = Q(J+IDER)
    ENDDO
ENDIF
!...
!...COMPUTE LOWER HALF OF THE EVALUATION TABLEAU
!...
!...TABLEAU READY IF IDER == 2*M-1
IF (K1 >= 1) THEN
    DO I = 1,K1
        NKI = NK+I
        IR = K
        JJ = L
        KI = K-I
        NKI1 = NKI+1
!...
!...RIGHT-HAND B-SPLINES
        IF (L >= NKI1) THEN
            DO J = NKI1,L
                Q(IR) = Q(IR-1)+((TT-X(JJ))*Q(IR))
                JJ = JJ-1
                IR = IR-1
            ENDDO
        ENDIF
!...
!...MIDDLE B-SPLINES
        LK1I = LK1+I
        J1 = MAX0(1, LK1I)
        J2 = MIN0(L, NKI)
        IF (J1 <= J2) THEN
            DO J = J1,J2
                XJKI = X(JJ+KI)
                Z = Q(IR)
                Q(IR) = Z + (((XJKI-TT)*(Q(IR-1)-Z))/(XJKI-X(JJ)))
                IR = IR-1
                JJ = JJ-1
            ENDDO
        ENDIF
!...
!...LEFT-HAND B-SPLINES
        IF (LK1I <= 0) THEN
            JJ = KI
            LK1I1 = 1-LK1I
            DO J = 1,LK1I1
                Q(IR) = Q(IR) + ((X(JJ)-TT)*Q(IR-1))
                JJ = JJ-1
                IR = IR-1
            ENDDO
        ENDIF
    ENDDO
ENDIF
!...
!...COMPUTE THE RETURN VALUE
!...
!...MULTIPLY WITH FACTORIAL IF IDER > 0
Z = Q(K)
IF (IDER > 0) THEN
    DO J = K,M2M1
        Z = Z*J
    ENDDO
ENDIF
SPLDER = Z
!...
!...DONE
RETURN
END FUNCTION SPLDER
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                  SUBROUTINE SEARCH                   *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 08/20/18          *
!...   *                                                      *
!...    ******************************************************
!...
! SEARCH.FOR, 1985-06-03

!***********************************************************************

! SUBROUTINE SEARCH (REAL*8)

! PURPOSE:
! *******

!       GIVEN A STRICTLY INCREASING KNOT SEQUENCE X(1) < ... < X(N),
!       WHERE N >= 1, AND A REAL NUMBER T, THIS SUBROUTINE FINDS THE
!       VALUE L SUCH THAT X(L) <= T < X(L+1).  IF T < X(1), L = 0;
!       IF X(N) <= T, L = N.

! CALLING CONVENTION:
! ******************

!       CALL SEARCH ( N, X, T, L )

! MEANING OF PARAMETERS:
! *********************

!       N       ( I )   KNOT ARRAY DIMENSIONING PARAMETER.
!       X(N)    ( I )   STRICLY INCREASING KNOT ARRAY.
!       T       ( I )   INPUT ARGUMENT WHOSE KNOT INTERVAL IS TO
!                       BE FOUND.
!       L       (I/O)   KNOT INTERVAL PARAMETER. THE SEARCH PROCEDURE
!                       IS FACILITATED IF L HAS APPROXIMATELY THE
!                       RIGHT VALUE ON ENTRY.

! REMARK:
! ******

!       THIS SUBROUTINE IS AN ADAPTATION OF SUBROUTINE SEARCH FROM
!       THE PAPER BY LYCHE ET AL. (1983). NO CHECKING IS PERFORMED
!       ON THE INPUT PARAMETERS AND DATA; THE ALGORITHM MAY FAIL IF
!       THE INPUT SEQUENCE IS NOT STRICTLY INCREASING.

! REFERENCE:
! *********

!       T. LYCHE, L.L. SCHUMAKER, & K. SEPEHRNOORI, FORTRAN SUBROUTINES
!       FOR COMPUTING SMOOTHING AND INTERPOLATING NATURAL SPLINES.
!       ADVANCES IN ENGINEERING SOFTWARE 5(1983)1, PP. 2-5.

!***********************************************************************

SUBROUTINE SEARCH(N,X,T,L)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: MAX0
!...
!...DECLARE TRANSFERRED VARIABLES
INTEGER(I4B), INTENT(IN)                            :: N
INTEGER(I4B), INTENT(INOUT)                         :: L
REAL(WP), INTENT(IN)                                :: T
REAL(WP), DIMENSION(1:N), INTENT(IN)                :: X
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B)                                        :: IL, IU
!...
!...OUT OF RANGE TO THE LEFT
IF (T < X(1)) THEN
    L = 0
    RETURN
ENDIF
!...
!...OUT OF RANGE TO THE RIGHT
IF (T >= X(N)) THEN
    L = N
    RETURN
ENDIF
!...
!...VALEDATE INPUT VALUE OF L
L = MAX0(L, 1)
!...
!...OFTEN L WILL BE IN AN INTERVAL ADJOINING THE INTERVAL FOUND IN A PREVIOUS CALL TO SEARCH
IF (L >= N) L = N-1
IF (T >= X(L)) GOTO 5
L = L-1
!...
!...PERFORM BISECTION
IF (T >= X(L)) RETURN
IL = 1
3 CONTINUE
IU = L
4 CONTINUE
L = (IL+IU)/2
IF ((IU-IL) <= 1) RETURN
IF (T < X(L)) GOTO 3
IL = L
GOTO 4
5 CONTINUE
IF (T < X(L+1)) RETURN
L = L+1
IF (T < X(L+1)) RETURN
IL = L+1
IU = N
GOTO 4
!...
!...DONE
END SUBROUTINE SEARCH
