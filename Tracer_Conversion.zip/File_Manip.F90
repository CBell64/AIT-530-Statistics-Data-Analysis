!...LIST OF SUBROUTINES, FUNCTIONS, AND ARGUMENTS
! INTEGER FUNCTION LENCHR (STRING)
! SUBROUTINE PLTNAM (FILEPLT)
! SUBROUTINE PSTNAM (FILEPS)
! SUBROUTINE NEWNAM (KN,FILE,FILNAM)
!...
!...
!///////////////////////////////////////////////////////////////////////
!...
!...    ******************************************************
!...   *                                                      *
!...   *                  FUNCTION LENCHR                     *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 02/12/07          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...FUNCTION LENCHR CALCULATES THE LENGTH OF A CHARACTER STRING
!...(CODE FROM R. STEVE REGAN, USGS)

INTEGER FUNCTION LENCHR (STRING)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...IDENTIFY SUBROUTINE VALIABLES
CHARACTER (LEN=*), INTENT(INOUT)                    :: STRING
!...
!...ARGUMENT DEFINITIONS
!...STRING -> INPUT STRING TO DETERMINE LENGTH
!...
!...LOCAL VARIABLES
INTEGER(I4B)                                        :: MAXL, I
!INTEGER(I4B), INTRINSIC                             :: LEN
!...
!...SET INITIAL MAXIMUM STRING LENGTH
MAXL = LEN(STRING)
!...
!...ADJUST MAXIMUM STRING LENGTH AS APPROPRIATE
DO I = MAXL,1,-1
    IF (STRING(I:I) /= ' ') THEN
        LENCHR = I
        GOTO 10
    ENDIF
ENDDO
!...
!...RESET LENCHR TO ZERO LENGTH
LENCHR = 0
!...
!...DONE
10 RETURN
END FUNCTION LENCHR
!...
! -------------------------------------------------------------------
!...
!...
!...    ******************************************************
!...   *                                                      *
!...   *                 SUBROUTINE PLTNAM                    *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 02/12/07          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...SUBROUTINE TO CORRECT FILE EXTENSION FOR PLOT FILE

SUBROUTINE PLTNAM (FILEPLT)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: INDEX
!...
!...IDENTIFY SUBROUTINE VALIABLES
CHARACTER (LEN=*), INTENT(INOUT)                    :: FILEPLT
!...
!...IDENTIFY CHARACTER AND INTEGER VARIABLES
INTEGER(I4B)                                        :: STR0
!...
!...IF AUTOMATIC PLOT FILE GENERATION IS REQUESTED THEN CHECK FILENAMES
!...FOR PERIODS TYPICAL OF FILES WITH EXTENSIONS (E.G., *.DAT).  IF A
!...PERIOD IS FOUND DELETE IT AND CONCANTENATE THE FILENAME.
!...
!...FIRST CHECK TO SEE IF A PERIOD EXISTS IN THE FILENAME.  IF A PERIOD
!...EXISTS THEN REMOVE IT AND RETURN.
!...
!...ADJUST INPUT FILE IF EXTENSION INCLUDED
STR0 = INDEX(FILEPLT,'.')
IF (STR0 > 0) THEN
    FILEPLT (STR0:STR0+2) = '.PLT         '
ELSE
!...ADD EXTENSION IF NONE FOR INPUT FILE
    STR0 = INDEX(FILEPLT,' ')
    IF (STR0 > 0) THEN
        FILEPLT (STR0:STR0) = '.PLT         '
    ENDIF
ENDIF
!...
!...READJUST INPUT FILE TO INCLUDE EXTENSION IF EXTENSION MISSING
STR0 = INDEX(FILEPLT,'.')
IF (STR0 > 0) FILEPLT (STR0:STR0+3) = '.PLT         '
!...
!...DONE
RETURN
END SUBROUTINE PLTNAM
!...
! -------------------------------------------------------------------
!...
!...
!...    ******************************************************
!...   *                                                      *
!...   *                 SUBROUTINE PSTNAM                    *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 02/12/07          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...SUBROUTINE TO CORRECT FILE EXTENSION FOR POSTSCRIPT FILE

SUBROUTINE PSTNAM (FILEPS,IEP)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...INTRINSIC FUNCTIONS
INTRINSIC                                           :: INDEX
!...
!...IDENTIFY SUBROUTINE VALIABLES
CHARACTER (LEN=*), INTENT(INOUT)                    :: FILEPS
INTEGER(I4B), INTENT(IN)                            :: IEP
!...
!...IDENTIFY CHARACTER AND INTEGER VALIABLES
INTEGER(I4B)                                        :: NUM, STR0
!...
!...IF AUTOMATIC PLOT FILE GENERATION IS REQUESTED THEN CHECK FILENAMES
!...FOR PERIODS TYPICAL OF FILES WITH EXTENSIONS (E.G., *.DAT).  IF A
!...PERIOD IS FOUND DELETE IT AND CONCANTENATE THE FILENAME.
!...
!...FIRST CHECK TO SEE IF A PERIOD EXISTS IN THE FILENAME.  IF A PERIOD
!...EXISTS THEN REMOVE IT AND RETURN.
!...
!...ZERO COUNTERS
NUM  = 0
STR0 = 0
!...
!...ADJUST INPUT FILE IF EXTENSION INCLUDED AND ADD EXTENSION IF NONE FOR INPUT FILE
STR0 = INDEX(FILEPS,'.')
NUM  = 80-STR0
IF (IEP == 1) THEN
    IF (STR0 > 0) THEN
        FILEPS (STR0:STR0+NUM) = '.EPS'
    ELSE
        STR0 = INDEX(FILEPS,'     ')
        IF (STR0 > 0) THEN
            FILEPS (STR0:STR0) = '.EPS'
        ENDIF
    ENDIF
ELSE
    IF (STR0 > 0) THEN
        FILEPS (STR0:STR0+NUM) = '.PDF'
    ELSE
        STR0 = INDEX(FILEPS,'     ')
        IF (STR0 > 0) THEN
            FILEPS (STR0:STR0) = '.PDF'
        ENDIF
    ENDIF
ENDIF
!...
!...COUNT SPACES IN FILE NAME FOR DETERMINING NUMBER OF UNDERSCORES NEEDED
NUM = INDEX(FILEPS,'.')
!...
!...CONNECT SPACES IN FILE NAMES WITH UNDERSCORES
10 CONTINUE
STR0 = INDEX(FILEPS,' ')
IF (STR0 > NUM) GOTO 20
IF (STR0 > 0) THEN
    FILEPS (STR0:STR0) = '_'
    IF (STR0 /= NUM+1) GOTO 10
ENDIF
!...
!...READJUST INPUT FILE TO INCLUDE EXTENSION IF EXTENSION MISSING
20 CONTINUE
STR0 = INDEX(FILEPS,'.')
IF (IEP == 1) THEN
    IF (STR0 > 0) FILEPS (STR0:STR0+3) = '.EPS'
ELSE
    IF (STR0 > 0) FILEPS (STR0:STR0+3) = '.PDF'
ENDIF
!...
!...DONE
RETURN
END SUBROUTINE PSTNAM
!...
! -------------------------------------------------------------------
!...
!...
!...    ******************************************************
!...   *                                                      *
!...   *                 SUBROUTINE NEWNAM                    *
!...   *                                                      *
!...   *          VERSION 1.0 CURRENT AS OF 02/12/07          *
!...   *                                                      *
!...    ******************************************************
!...
!...
!...SUBROUTINE TO CORRECT STATION NAME FOR PRINTING

SUBROUTINE NEWNAM (KN,FILEE,FILNAM)
!...
!...ADD TYPE AND UTILITY MODULES
USE NRTYPE
!...
!...ENSURE ALL VARIABLES IDENTIFIED
IMPLICIT NONE
!...
!...IDENTIFY SUBROUTINE VALIABLES
INTEGER(I4B), INTENT(INOUT)                         :: KN
CHARACTER (LEN=*), INTENT(IN)                       :: FILEE
CHARACTER (LEN=80), INTENT(OUT)                     :: FILNAM
!...
!...IDENTIFY CHARACTER AND INTEGER VARIABLES
INTEGER(I4B)                                        :: LENCHR
!...
!...COPY STATION NAME TO FILNAM
FILNAM = FILEE
KN = LENCHR(FILNAM)
!...
!...DONE
RETURN
END SUBROUTINE NEWNAM
