MODULE NR
    INTERFACE
        SUBROUTINE AIRY(X,AI,BI,AIP,BIP)
        USE NRTYPE
        REAL(WP), INTENT(IN)                                    :: X
        REAL(WP), INTENT(OUT)                                   :: AI,BI,AIP,BIP
        END SUBROUTINE AIRY
    END INTERFACE
    INTERFACE
        SUBROUTINE AMEBSA(P,Y,PB,YB,FTOL,FUNC,ITER,TEMPTR)
        USE NRTYPE
        INTEGER(I4B), INTENT(INOUT)                             :: ITER
        REAL(WP), INTENT(INOUT)                                 :: YB
        REAL(WP), INTENT(IN)                                    :: FTOL,TEMPTR
        REAL(WP), DIMENSION(:), INTENT(INOUT)                   :: Y,PB
        REAL(WP), DIMENSION(:,:), INTENT(INOUT)                 :: P
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN)                  :: X
            REAL(WP)                                            :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END SUBROUTINE AMEBSA
    END INTERFACE
    INTERFACE
        SUBROUTINE AMOEBA(P,Y,FTOL,FUNC,ITER)
        USE NRTYPE
        INTEGER(I4B), INTENT(OUT)                               :: ITER
        REAL(WP), INTENT(IN)                                    :: FTOL
        REAL(WP), DIMENSION(:), INTENT(INOUT)                   :: Y
        REAL(WP), DIMENSION(:,:), INTENT(INOUT)                 :: P
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN)                  :: X
            REAL(WP)                                            :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END SUBROUTINE AMOEBA
    END INTERFACE
    INTERFACE
        SUBROUTINE ANNEAL(X,Y,IORDER)
        USE NRTYPE
        INTEGER(I4B), DIMENSION(:), INTENT(INOUT)               :: IORDER
        REAL(WP), DIMENSION(:), INTENT(IN)                      :: X,Y
        END SUBROUTINE ANNEAL
    END INTERFACE
    INTERFACE
        SUBROUTINE ASOLVE(B,X,ITRNSP)
        USE NRTYPE
        REAL(DP), DIMENSION(:), INTENT(IN)                      :: B
        REAL(DP), DIMENSION(:), INTENT(OUT)                     :: X
        INTEGER(I4B), INTENT(IN)                                :: ITRNSP
        END SUBROUTINE ASOLVE
    END INTERFACE
    INTERFACE
        SUBROUTINE ATIMES(X,R,ITRNSP)
        USE NRTYPE
        REAL(DP), DIMENSION(:), INTENT(IN)                      :: X
        REAL(DP), DIMENSION(:), INTENT(OUT)                     :: R
        INTEGER(I4B), INTENT(IN)                                :: ITRNSP
        END SUBROUTINE ATIMES
    END INTERFACE
    INTERFACE
        SUBROUTINE AVEVAR(DATA1,AVE,VAR)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN)                      :: DATA1
        REAL(WP), INTENT(OUT)                                   :: AVE,VAR
        END SUBROUTINE AVEVAR
    END INTERFACE
    INTERFACE
        SUBROUTINE BALANC(A)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(INOUT)                 :: A
        END SUBROUTINE BALANC
    END INTERFACE
    INTERFACE
        SUBROUTINE BANBKS(A,M1,M2,AL,INDX,B)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN)                                :: M1,M2
        INTEGER(I4B), DIMENSION(:), INTENT(IN)                  :: INDX
        REAL(WP), DIMENSION(:,:), INTENT(IN)                    :: A,AL
        REAL(WP), DIMENSION(:), INTENT(INOUT)                   :: B
        END SUBROUTINE BANBKS
    END INTERFACE
    INTERFACE
        SUBROUTINE BANDEC(A,M1,M2,AL,INDX,D)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN)                                :: M1,M2
        INTEGER(I4B), DIMENSION(:), INTENT(OUT)                 :: INDX
        REAL(WP), INTENT(OUT)                                   :: D
        REAL(WP), DIMENSION(:,:), INTENT(INOUT)                 :: A
        REAL(WP), DIMENSION(:,:), INTENT(OUT)                   :: AL
        END SUBROUTINE BANDEC
    END INTERFACE
    INTERFACE
        SUBROUTINE BANMUL(A,M1,M2,X,B)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN)                                :: M1,M2
        REAL(WP), DIMENSION(:), INTENT(IN)                      :: X
        REAL(WP), DIMENSION(:), INTENT(OUT)                     :: B
        REAL(WP), DIMENSION(:,:), INTENT(IN)                    :: A
        END SUBROUTINE BANMUL
    END INTERFACE
    INTERFACE
        SUBROUTINE BCUCOF(Y,Y1,Y2,Y12,D1,D2,C)
        USE NRTYPE
        REAL(WP), INTENT(IN)                                    :: D1,D2
        REAL(WP), DIMENSION(4), INTENT(IN)                      :: Y,Y1,Y2,Y12
        REAL(WP), DIMENSION(4,4), INTENT(OUT)                   :: C
        END SUBROUTINE BCUCOF
    END INTERFACE
    INTERFACE
        SUBROUTINE BCUINT(Y,Y1,Y2,Y12,X1L,X1U,X2L,X2U,X1,X2,ANSY,ANSY1,ANSY2)
        USE NRTYPE
        REAL(WP), DIMENSION(4), INTENT(IN)                      :: Y,Y1,Y2,Y12
        REAL(WP), INTENT(IN)                                    :: X1L,X1U,X2L,X2U,X1,X2
        REAL(WP), INTENT(OUT)                                   :: ANSY,ANSY1,ANSY2
        END SUBROUTINE BCUINT
    END INTERFACE
    INTERFACE BESCHB
        SUBROUTINE BESCHB_W(X,GAM1,GAM2,GAMPL,GAMMI)
        USE NRTYPE
        REAL(DP), INTENT(IN)                                    :: X
        REAL(DP), INTENT(OUT)                                   :: GAM1,GAM2,GAMPL,GAMMI
        END SUBROUTINE BESCHB_W
!BL
        SUBROUTINE BESCHB_V(X,GAM1,GAM2,GAMPL,GAMMI)
        USE NRTYPE
        REAL(DP), DIMENSION(:), INTENT(IN)                      :: X
        REAL(DP), DIMENSION(:), INTENT(OUT)                     :: GAM1,GAM2,GAMPL,GAMMI
        END SUBROUTINE BESCHB_V
    END INTERFACE
    INTERFACE BESSI
        FUNCTION BESSI_W(N,X)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN)                                :: N
        REAL(WP), INTENT(IN)                                    :: X
        REAL(WP)                                                :: BESSI_W
        END FUNCTION BESSI_W
!BL
        FUNCTION BESSI_V(N,X)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN)                                :: N
        REAL(WP), DIMENSION(:), INTENT(IN)                      :: X
        REAL(WP), DIMENSION(SIZE(X))                            :: BESSI_V
        END FUNCTION BESSI_V
    END INTERFACE
    INTERFACE BESSI0
        FUNCTION BESSI0_W(X)
        USE NRTYPE
        REAL(WP), INTENT(IN)                                    :: X
        REAL(WP)                                                :: BESSI0_W
        END FUNCTION BESSI0_W
!MF
!        FUNCTION BESSI0_D(X)
!        USE NRTYPE
!        REAL(DP), INTENT(IN)                                    :: X
!        REAL(DP)                                                :: BESSI0_D
!        END FUNCTION BESSI0_D
!BL
        FUNCTION BESSI0_V(X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN)                      :: X
        REAL(WP), DIMENSION(SIZE(X))                            :: BESSI0_V
        END FUNCTION BESSI0_V
    END INTERFACE
    INTERFACE BESSI1
        FUNCTION BESSI1_W(X)
        USE NRTYPE
        REAL(WP), INTENT(IN)                                    :: X
        REAL(WP)                                                :: BESSI1_W
        END FUNCTION BESSI1_W
!MF
!        FUNCTION BESSI1_D(X)
!        USE NRTYPE
!        REAL(DP), INTENT(IN)                                    :: X
!        REAL(DP)                                                :: BESSI1_D
!        END FUNCTION BESSI1_D
!BL
        FUNCTION BESSI1_V(X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN)                      :: X
        REAL(WP), DIMENSION(SIZE(X))                            :: BESSI1_V
        END FUNCTION BESSI1_V
    END INTERFACE
    INTERFACE
        SUBROUTINE BESSIK(X,XNU,RI,RK,RIP,RKP)
        USE NRTYPE
        REAL(WP), INTENT(IN)                                    :: X,XNU
        REAL(WP), INTENT(OUT)                                   :: RI,RK,RIP,RKP
        END SUBROUTINE BESSIK
    END INTERFACE
    INTERFACE BESSJ
        FUNCTION BESSJ_W(N,X)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN)                                :: N
        REAL(WP), INTENT(IN)                                    :: X
        REAL(WP)                                                :: BESSJ_W
        END FUNCTION BESSJ_W
!BL
        FUNCTION BESSJ_V(N,X)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN)                                :: N
        REAL(WP), DIMENSION(:), INTENT(IN)                      :: X
        REAL(WP), DIMENSION(SIZE(X))                            :: BESSJ_V
        END FUNCTION BESSJ_V
    END INTERFACE
    INTERFACE BESSJ0
        FUNCTION BESSJ0_W(X)
        USE NRTYPE
        REAL(WP), INTENT(IN)                                    :: X
        REAL(WP)                                                :: BESSJ0_W
        END FUNCTION BESSJ0_W
!MF
!        FUNCTION BESSJ0_D(X)
!        USE NRTYPE
!        REAL(DP), INTENT(IN)                                    :: X
!        REAL(DP)                                                :: BESSJ0_D
!        END FUNCTION BESSJ0_D
!BL
        FUNCTION BESSJ0_V(X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN)                      :: X
        REAL(WP), DIMENSION(SIZE(X))                            :: BESSJ0_V
        END FUNCTION BESSJ0_V
    END INTERFACE
    INTERFACE BESSJ1
        FUNCTION BESSJ1_W(X)
        USE NRTYPE
        REAL(WP), INTENT(IN)                                    :: X
        REAL(WP) :: BESSJ1_W
        END FUNCTION BESSJ1_W
!MF
!        FUNCTION BESSJ1_D(X)
!        USE NRTYPE
!        REAL(DP), INTENT(IN)                                    :: X
!        REAL(DP)                                                :: BESSJ1_D
!        END FUNCTION BESSJ1_D
!BL
        FUNCTION BESSJ1_V(X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X
        REAL(WP), DIMENSION(SIZE(X)) :: BESSJ1_V
        END FUNCTION BESSJ1_V
    END INTERFACE
    INTERFACE BESSJY
        SUBROUTINE BESSJY_W(X,XNU,RJ,RY,RJP,RYP)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X,XNU
        REAL(WP), INTENT(OUT) :: RJ,RY,RJP,RYP
        END SUBROUTINE BESSJY_W
!BL
        SUBROUTINE BESSJY_V(X,XNU,RJ,RY,RJP,RYP)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: XNU
        REAL(WP), DIMENSION(:), INTENT(IN) :: X
        REAL(WP), DIMENSION(:), INTENT(OUT) :: RJ,RJP,RY,RYP
        END SUBROUTINE BESSJY_V
    END INTERFACE
    INTERFACE BESSK
        FUNCTION BESSK_W(N,X)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N
        REAL(WP), INTENT(IN) :: X
        REAL(WP) :: BESSK_W
        END FUNCTION BESSK_W
!BL
        FUNCTION BESSK_V(N,X)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N
        REAL(WP), DIMENSION(:), INTENT(IN) :: X
        REAL(WP), DIMENSION(SIZE(X)) :: BESSK_V
        END FUNCTION BESSK_V
    END INTERFACE
    INTERFACE BESSK0
        FUNCTION BESSK0_W(X)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X
        REAL(WP) :: BESSK0_W
        END FUNCTION BESSK0_W
!BL
        FUNCTION BESSK0_V(X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X
        REAL(WP), DIMENSION(SIZE(X)) :: BESSK0_V
        END FUNCTION BESSK0_V
    END INTERFACE
    INTERFACE BESSK1
        FUNCTION BESSK1_W(X)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X
        REAL(WP) :: BESSK1_W
        END FUNCTION BESSK1_W
!BL
        FUNCTION BESSK1_V(X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X
        REAL(WP), DIMENSION(SIZE(X)) :: BESSK1_V
        END FUNCTION BESSK1_V
    END INTERFACE
    INTERFACE BESSY
        FUNCTION BESSY_W(N,X)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N
        REAL(WP), INTENT(IN) :: X
        REAL(WP) :: BESSY_W
        END FUNCTION BESSY_W
!BL
        FUNCTION BESSY_V(N,X)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N
        REAL(WP), DIMENSION(:), INTENT(IN) :: X
        REAL(WP), DIMENSION(SIZE(X)) :: BESSY_V
        END FUNCTION BESSY_V
    END INTERFACE
    INTERFACE BESSY0
        FUNCTION BESSY0_W(X)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X
        REAL(WP) :: BESSY0_W
        END FUNCTION BESSY0_W
!BL
        FUNCTION BESSY0_V(X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X
        REAL(WP), DIMENSION(SIZE(X)) :: BESSY0_V
        END FUNCTION BESSY0_V
    END INTERFACE
    INTERFACE BESSY1
        FUNCTION BESSY1_W(X)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X
        REAL(WP) :: BESSY1_W
        END FUNCTION BESSY1_W
!BL
        FUNCTION BESSY1_V(X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X
        REAL(WP), DIMENSION(SIZE(X)) :: BESSY1_V
        END FUNCTION BESSY1_V
    END INTERFACE
    INTERFACE BETA
        FUNCTION BETA_W(Z,W)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: Z,W
        REAL(WP) :: BETA_W
        END FUNCTION BETA_W
!BL
        FUNCTION BETA_V(Z,W)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: Z,W
        REAL(WP), DIMENSION(SIZE(Z)) :: BETA_V
        END FUNCTION BETA_V
    END INTERFACE
    INTERFACE BETACF
        FUNCTION BETACF_W(A,B,X)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B,X
        REAL(WP) :: BETACF_W
        END FUNCTION BETACF_W
!BL
        FUNCTION BETACF_V(A,B,X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: A,B,X
        REAL(WP), DIMENSION(SIZE(X)) :: BETACF_V
        END FUNCTION BETACF_V
    END INTERFACE
    INTERFACE BETAI
        FUNCTION BETAI_W(A,B,X)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B,X
        REAL(WP) :: BETAI_W
        END FUNCTION BETAI_W
!BL
        FUNCTION BETAI_V(A,B,X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: A,B,X
        REAL(WP), DIMENSION(SIZE(A)) :: BETAI_V
        END FUNCTION BETAI_V
    END INTERFACE
    INTERFACE BICO
        FUNCTION BICO_W(N,K)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N,K
        REAL(WP) :: BICO_W
        END FUNCTION BICO_W
!BL
        FUNCTION BICO_V(N,K)
        USE NRTYPE
        INTEGER(I4B), DIMENSION(:), INTENT(IN) :: N,K
        REAL(WP), DIMENSION(SIZE(N)) :: BICO_V
        END FUNCTION BICO_V
    END INTERFACE
    INTERFACE
        FUNCTION BNLDEV(PP,N)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: PP
        INTEGER(I4B), INTENT(IN) :: N
        REAL(WP) :: BNLDEV
        END FUNCTION BNLDEV
    END INTERFACE
    INTERFACE
        FUNCTION BRENT(AX,BX,CX,FUNC,TOL,XMIN)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: AX,BX,CX,TOL
        REAL(WP), INTENT(OUT) :: XMIN
        REAL(WP) :: BRENT
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END FUNCTION BRENT
    END INTERFACE
    INTERFACE
        SUBROUTINE BROYDN(X,CHECK)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: X
        LOGICAL(TLG), INTENT(OUT) :: CHECK
        END SUBROUTINE BROYDN
    END INTERFACE
    INTERFACE
        SUBROUTINE BSSTEP(Y,DYDX,X,HTRY,EPS,YSCAL,HDID,HNEXT,DERIVS)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: Y
        REAL(WP), DIMENSION(:), INTENT(IN) :: DYDX,YSCAL
        REAL(WP), INTENT(INOUT) :: X
        REAL(WP), INTENT(IN) :: HTRY,EPS
        REAL(WP), INTENT(OUT) :: HDID,HNEXT
        INTERFACE
            SUBROUTINE DERIVS(X,Y,DYDX)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP), DIMENSION(:), INTENT(IN) :: Y
            REAL(WP), DIMENSION(:), INTENT(OUT) :: DYDX
            END SUBROUTINE DERIVS
        END INTERFACE
        END SUBROUTINE BSSTEP
    END INTERFACE
    INTERFACE
        SUBROUTINE CALDAT(JULIAN,MM,ID,IYYY)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: JULIAN
        INTEGER(I4B), INTENT(OUT) :: MM,ID,IYYY
        END SUBROUTINE CALDAT
    END INTERFACE
    INTERFACE
        FUNCTION CHDER(A,B,C)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B
        REAL(WP), DIMENSION(:), INTENT(IN) :: C
        REAL(WP), DIMENSION(SIZE(C)) :: CHDER
        END FUNCTION CHDER
    END INTERFACE
    INTERFACE CHEBEV
        FUNCTION CHEBEV_W(A,B,C,X)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B,X
        REAL(WP), DIMENSION(:), INTENT(IN) :: C
        REAL(WP) :: CHEBEV_W
        END FUNCTION CHEBEV_W
!BL
        FUNCTION CHEBEV_V(A,B,C,X)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B
        REAL(WP), DIMENSION(:), INTENT(IN) :: C,X
        REAL(WP), DIMENSION(SIZE(X)) :: CHEBEV_V
        END FUNCTION CHEBEV_V
    END INTERFACE
    INTERFACE
        FUNCTION CHEBFT(A,B,N,FUNC)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B
        INTEGER(I4B), INTENT(IN) :: N
        REAL(WP), DIMENSION(N) :: CHEBFT
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: X
            REAL(WP), DIMENSION(SIZE(X)) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END FUNCTION CHEBFT
    END INTERFACE
    INTERFACE
        FUNCTION CHEBPC(C)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: C
        REAL(WP), DIMENSION(SIZE(C)) :: CHEBPC
        END FUNCTION CHEBPC
    END INTERFACE
    INTERFACE
        FUNCTION CHINT(A,B,C)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B
        REAL(WP), DIMENSION(:), INTENT(IN) :: C
        REAL(WP), DIMENSION(SIZE(C)) :: CHINT
        END FUNCTION CHINT
    END INTERFACE
    INTERFACE
        SUBROUTINE CHOLDC(A,P)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(INOUT) :: A
        REAL(WP), DIMENSION(:), INTENT(OUT) :: P
        END SUBROUTINE CHOLDC
    END INTERFACE
    INTERFACE
        SUBROUTINE CHOLSL(A,P,B,X)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(IN) :: A
        REAL(WP), DIMENSION(:), INTENT(IN) :: P,B
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: X
        END SUBROUTINE CHOLSL
    END INTERFACE
    INTERFACE
        SUBROUTINE CHSONE(BINS,EBINS,KNSTRN,DF,CHSQ,PROB)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: KNSTRN
        REAL(WP), INTENT(OUT) :: DF,CHSQ,PROB
        REAL(WP), DIMENSION(:), INTENT(IN) :: BINS,EBINS
        END SUBROUTINE CHSONE
    END INTERFACE
    INTERFACE
        SUBROUTINE CHSTWO(BINS1,BINS2,KNSTRN,DF,CHSQ,PROB)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: KNSTRN
        REAL(WP), INTENT(OUT) :: DF,CHSQ,PROB
        REAL(WP), DIMENSION(:), INTENT(IN) :: BINS1,BINS2
        END SUBROUTINE CHSTWO
    END INTERFACE
    INTERFACE
        SUBROUTINE CISI(X,CI,SI)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X
        REAL(WP), INTENT(OUT) :: CI,SI
        END SUBROUTINE CISI
    END INTERFACE
    INTERFACE
        SUBROUTINE CNTAB1(NN,CHISQ,DF,PROB,CRAMRV,CCC)
        USE NRTYPE
        INTEGER(I4B), DIMENSION(:,:), INTENT(IN) :: NN
        REAL(WP), INTENT(OUT) :: CHISQ,DF,PROB,CRAMRV,CCC
        END SUBROUTINE CNTAB1
    END INTERFACE
    INTERFACE
        SUBROUTINE CNTAB2(NN,H,HX,HY,HYGX,HXGY,UYGX,UXGY,UXY)
        USE NRTYPE
        INTEGER(I4B), DIMENSION(:,:), INTENT(IN) :: NN
        REAL(WP), INTENT(OUT) :: H,HX,HY,HYGX,HXGY,UYGX,UXGY,UXY
        END SUBROUTINE CNTAB2
    END INTERFACE
    INTERFACE
        FUNCTION CONVLV(DATA1,RESPNS,ISGN)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: DATA1
        REAL(WP), DIMENSION(:), INTENT(IN) :: RESPNS
        INTEGER(I4B), INTENT(IN) :: ISGN
        REAL(WP), DIMENSION(SIZE(DATA1)) :: CONVLV
        END FUNCTION CONVLV
    END INTERFACE
    INTERFACE
        SUBROUTINE CORREL(N,DATA1,DATA2)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: DATA1, DATA2
        END SUBROUTINE CORREL
    END INTERFACE
    INTERFACE
        SUBROUTINE COSFT1(Y)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: Y
        END SUBROUTINE COSFT1
    END INTERFACE
    INTERFACE
        SUBROUTINE COSFT2(Y,ISGN)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: Y
        INTEGER(I4B), INTENT(IN) :: ISGN
        END SUBROUTINE COSFT2
    END INTERFACE
    INTERFACE
        SUBROUTINE COVSRT(COVAR,MASKA)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(INOUT) :: COVAR
        LOGICAL(TLG), DIMENSION(:), INTENT(IN) :: MASKA
        END SUBROUTINE COVSRT
    END INTERFACE
    INTERFACE
        SUBROUTINE CYCLIC(A,B,C,ALPHA,BETA,R,X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN):: A,B,C,R
        REAL(WP), INTENT(IN) :: ALPHA,BETA
        REAL(WP), DIMENSION(:), INTENT(OUT):: X
        END SUBROUTINE CYCLIC
    END INTERFACE
    INTERFACE
        SUBROUTINE DAUB4(A,ISGN)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: A
        INTEGER(I4B), INTENT(IN) :: ISGN
        END SUBROUTINE DAUB4
    END INTERFACE
    INTERFACE DAWSON
        FUNCTION DAWSON_W(X)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X
        REAL(WP) :: DAWSON_W
        END FUNCTION DAWSON_W
!BL
        FUNCTION DAWSON_V(X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X
        REAL(WP), DIMENSION(SIZE(X)) :: DAWSON_V
        END FUNCTION DAWSON_V
    END INTERFACE
    INTERFACE
        FUNCTION DBRENT(AX,BX,CX,FUNC,DBRENT_DFUNC,TOL,XMIN)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: AX,BX,CX,TOL
        REAL(WP), INTENT(OUT) :: XMIN
        REAL(WP) :: DBRENT
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP) :: FUNC
            END FUNCTION FUNC
!BL
            FUNCTION DBRENT_DFUNC(X)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP) :: DBRENT_DFUNC
            END FUNCTION DBRENT_DFUNC
        END INTERFACE
        END FUNCTION DBRENT
    END INTERFACE
    INTERFACE
        SUBROUTINE DDPOLY(C,X,PD)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X
        REAL(WP), DIMENSION(:), INTENT(IN) :: C
        REAL(WP), DIMENSION(:), INTENT(OUT) :: PD
        END SUBROUTINE DDPOLY
    END INTERFACE
    INTERFACE
        FUNCTION DECCHK(STRING,CH)
        USE NRTYPE
        CHARACTER(1), DIMENSION(:), INTENT(IN) :: STRING
        CHARACTER(1), INTENT(OUT) :: CH
        LOGICAL(TLG) :: DECCHK
        END FUNCTION DECCHK
    END INTERFACE
    INTERFACE
        SUBROUTINE DFPMIN(P,GTOL,ITER,FRET,FUNC,DFUNC)
        USE NRTYPE
        INTEGER(I4B), INTENT(OUT) :: ITER
        REAL(WP), INTENT(IN) :: GTOL
        REAL(WP), INTENT(OUT) :: FRET
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: P
        INTERFACE
            FUNCTION FUNC(P)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: P
            REAL(WP) :: FUNC
            END FUNCTION FUNC
!BL
            FUNCTION DFUNC(P)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: P
            REAL(WP), DIMENSION(SIZE(P)) :: DFUNC
            END FUNCTION DFUNC
        END INTERFACE
        END SUBROUTINE DFPMIN
    END INTERFACE
    INTERFACE
        FUNCTION DFRIDR(FUNC,X,H,ERR)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X,H
        REAL(WP), INTENT(OUT) :: ERR
        REAL(WP) :: DFRIDR
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END FUNCTION DFRIDR
    END INTERFACE
    INTERFACE
        SUBROUTINE DFTCOR(W,DELTA,A,B,ENDPTS,CORRE,CORIM,CORFAC)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: W,DELTA,A,B
        REAL(WP), INTENT(OUT) :: CORRE,CORIM,CORFAC
        REAL(WP), DIMENSION(:), INTENT(IN) :: ENDPTS
        END SUBROUTINE DFTCOR
    END INTERFACE
    INTERFACE
        SUBROUTINE DFTINT(FUNC,A,B,W,COSINT,SININT)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B,W
        REAL(WP), INTENT(OUT) :: COSINT,SININT
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: X
            REAL(WP), DIMENSION(SIZE(X)) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END SUBROUTINE DFTINT
    END INTERFACE
    INTERFACE
        SUBROUTINE DIFEQ(K,K1,K2,JSF,IS1,ISF,INDEXV,S,Y)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: IS1,ISF,JSF,K,K1,K2
        INTEGER(I4B), DIMENSION(:), INTENT(IN) :: INDEXV
        REAL(WP), DIMENSION(:,:), INTENT(OUT) :: S
        REAL(WP), DIMENSION(:,:), INTENT(IN) :: Y
        END SUBROUTINE DIFEQ
    END INTERFACE
    INTERFACE
        FUNCTION ECLASS(LISTA,LISTB,N)
        USE NRTYPE
        INTEGER(I4B), DIMENSION(:), INTENT(IN) :: LISTA,LISTB
        INTEGER(I4B), INTENT(IN) :: N
        INTEGER(I4B), DIMENSION(N) :: ECLASS
        END FUNCTION ECLASS
    END INTERFACE
    INTERFACE
        FUNCTION ECLAZZ(EQUIV,N)
        USE NRTYPE
        INTERFACE
            FUNCTION EQUIV(I,J)
            USE NRTYPE
            LOGICAL(TLG) :: EQUIV
            INTEGER(I4B), INTENT(IN) :: I,J
            END FUNCTION EQUIV
        END INTERFACE
        INTEGER(I4B), INTENT(IN) :: N
        INTEGER(I4B), DIMENSION(N) :: ECLAZZ
        END FUNCTION ECLAZZ
    END INTERFACE
    INTERFACE
        FUNCTION EI(X)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X
        REAL(WP) :: EI
        END FUNCTION EI
    END INTERFACE
    INTERFACE
        SUBROUTINE EIGSRT(D,V)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: D
        REAL(WP), DIMENSION(:,:), INTENT(INOUT) :: V
        END SUBROUTINE EIGSRT
    END INTERFACE
    INTERFACE ELLE
        FUNCTION ELLE_W(PHI,AK)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: PHI,AK
        REAL(WP) :: ELLE_W
        END FUNCTION ELLE_W
!BL
        FUNCTION ELLE_V(PHI,AK)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: PHI,AK
        REAL(WP), DIMENSION(SIZE(PHI)) :: ELLE_V
        END FUNCTION ELLE_V
    END INTERFACE
    INTERFACE ELLF
        FUNCTION ELLF_W(PHI,AK)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: PHI,AK
        REAL(WP) :: ELLF_W
        END FUNCTION ELLF_W
!BL
        FUNCTION ELLF_V(PHI,AK)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: PHI,AK
        REAL(WP), DIMENSION(SIZE(PHI)) :: ELLF_V
        END FUNCTION ELLF_V
    END INTERFACE
    INTERFACE ELLPI
        FUNCTION ELLPI_W(PHI,EN,AK)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: PHI,EN,AK
        REAL(WP) :: ELLPI_W
        END FUNCTION ELLPI_W
!BL
        FUNCTION ELLPI_V(PHI,EN,AK)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: PHI,EN,AK
        REAL(WP), DIMENSION(SIZE(PHI)) :: ELLPI_V
        END FUNCTION ELLPI_V
    END INTERFACE
    INTERFACE
        SUBROUTINE ELMHES(A)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(INOUT) :: A
        END SUBROUTINE ELMHES
    END INTERFACE
    INTERFACE ERF
        FUNCTION ERF_W(X)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X
        REAL(WP) :: ERF_W
        END FUNCTION ERF_W
!BL
        FUNCTION ERF_V(X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X
        REAL(WP), DIMENSION(SIZE(X)) :: ERF_V
        END FUNCTION ERF_V
    END INTERFACE
    INTERFACE ERFC
        FUNCTION ERFC_W(X)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X
        REAL(WP) :: ERFC_W
        END FUNCTION ERFC_W
!BL
        FUNCTION ERFC_V(X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X
        REAL(WP), DIMENSION(SIZE(X)) :: ERFC_V
        END FUNCTION ERFC_V
    END INTERFACE
    INTERFACE ERFCC
        FUNCTION ERFCC_W(X)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X
        REAL(WP) :: ERFCC_W
        END FUNCTION ERFCC_W
!BL
        FUNCTION ERFCC_V(X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X
        REAL(WP), DIMENSION(SIZE(X)) :: ERFCC_V
        END FUNCTION ERFCC_V
    END INTERFACE
    INTERFACE
        SUBROUTINE EULSUM(SUM,TERM,JTERM)
        USE NRTYPE
        REAL(WP), INTENT(INOUT) :: SUM
        REAL(WP), INTENT(IN) :: TERM
        INTEGER(I4B), INTENT(IN) :: JTERM
        END SUBROUTINE EULSUM
    END INTERFACE
    INTERFACE
        FUNCTION EVLMEM(FDT,D,XMS)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: FDT,XMS
        REAL(WP), DIMENSION(:), INTENT(IN) :: D
        REAL(WP) :: EVLMEM
        END FUNCTION EVLMEM
    END INTERFACE
    INTERFACE EXPDEV
        SUBROUTINE EXPDEV_W(HARVEST)
        USE NRTYPE
        REAL(WP), INTENT(OUT) :: HARVEST
        END SUBROUTINE EXPDEV_W
!BL
        SUBROUTINE EXPDEV_V(HARVEST)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(OUT) :: HARVEST
        END SUBROUTINE EXPDEV_V
    END INTERFACE
    INTERFACE
        FUNCTION EXPINT(N,X)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N
        REAL(WP), INTENT(IN) :: X
        REAL(WP) :: EXPINT
        END FUNCTION EXPINT
    END INTERFACE
    INTERFACE FACTLN
        FUNCTION FACTLN_W(N)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N
        REAL(WP) :: FACTLN_W
        END FUNCTION FACTLN_W
!BL
        FUNCTION FACTLN_V(N)
        USE NRTYPE
        INTEGER(I4B), DIMENSION(:), INTENT(IN) :: N
        REAL(WP), DIMENSION(SIZE(N)) :: FACTLN_V
        END FUNCTION FACTLN_V
    END INTERFACE
    INTERFACE FACTRL
        FUNCTION FACTRL_W(N)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N
        REAL(WP) :: FACTRL_W
        END FUNCTION FACTRL_W
!BL
        FUNCTION FACTRL_V(N)
        USE NRTYPE
        INTEGER(I4B), DIMENSION(:), INTENT(IN) :: N
        REAL(WP), DIMENSION(SIZE(N)) :: FACTRL_V
        END FUNCTION FACTRL_V
    END INTERFACE
    INTERFACE
        SUBROUTINE FASPER(X,Y,OFAC,HIFAC,PX,PY,JMAX,PROB)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,Y
        REAL(WP), INTENT(IN) :: OFAC,HIFAC
        INTEGER(I4B), INTENT(OUT) :: JMAX
        REAL(WP), INTENT(OUT) :: PROB
        REAL(WP), DIMENSION(:), POINTER :: PX,PY
        END SUBROUTINE FASPER
    END INTERFACE
    INTERFACE
        SUBROUTINE FDJAC(X,FVEC,DF)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: FVEC
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: X
        REAL(WP), DIMENSION(:,:), INTENT(OUT) :: DF
        END SUBROUTINE FDJAC
    END INTERFACE
    INTERFACE
        SUBROUTINE FGAUSS(X,A,Y,DYDA)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,A
        REAL(WP), DIMENSION(:), INTENT(OUT) :: Y
        REAL(WP), DIMENSION(:,:), INTENT(OUT) :: DYDA
        END SUBROUTINE FGAUSS
    END INTERFACE
    INTERFACE
        SUBROUTINE FIT(X,Y,A,B,SIGA,SIGB,CHI2,Q,SIG)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,Y
        REAL(WP), INTENT(OUT) :: A,B,SIGA,SIGB,CHI2,Q
        REAL(WP), DIMENSION(:), OPTIONAL, INTENT(IN) :: SIG
        END SUBROUTINE FIT
    END INTERFACE
    INTERFACE
        SUBROUTINE FITEXY(X,Y,SIGX,SIGY,A,B,SIGA,SIGB,CHI2,Q)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,Y,SIGX,SIGY
        REAL(WP), INTENT(OUT) :: A,B,SIGA,SIGB,CHI2,Q
        END SUBROUTINE FITEXY
    END INTERFACE
    INTERFACE
        SUBROUTINE FIXRTS(D)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: D
        END SUBROUTINE FIXRTS
    END INTERFACE
    INTERFACE
        FUNCTION FLEG(X,N)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X
        INTEGER(I4B), INTENT(IN) :: N
        REAL(WP), DIMENSION(N) :: FLEG
        END FUNCTION FLEG
    END INTERFACE
    INTERFACE
        SUBROUTINE FLMOON(N,NPH,JD,FRAC)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N,NPH
        INTEGER(I4B), INTENT(OUT) :: JD
        REAL(WP), INTENT(OUT) :: FRAC
        END SUBROUTINE FLMOON
    END INTERFACE
    INTERFACE FOUR1
!        SUBROUTINE FOUR1_DP(DATA1,ISGN)
!        USE NRTYPE
!        COMPLEX(DPC), DIMENSION(:), INTENT(INOUT) :: DATA1
!        INTEGER(I4B), INTENT(IN) :: ISGN
!        END SUBROUTINE FOUR1_DP
!BL
        SUBROUTINE FOUR1_WP(DATA1,ISGN)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: ISGN
        COMPLEX(WPC), DIMENSION(:), INTENT(INOUT) :: DATA1
        END SUBROUTINE FOUR1_WP
    END INTERFACE
    INTERFACE
        SUBROUTINE FOUR1_ALT_WP(DATA1,ISGN)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: ISGN
        COMPLEX(WPC), DIMENSION(:), INTENT(INOUT) :: DATA1
        END SUBROUTINE FOUR1_ALT_WP
    END INTERFACE
    INTERFACE
        SUBROUTINE FOUR1_GATHER(DATA1,ISGN)
        USE NRTYPE
        COMPLEX(WPC), DIMENSION(:), INTENT(INOUT) :: DATA1
        INTEGER(I4B), INTENT(IN) :: ISGN
        END SUBROUTINE FOUR1_GATHER
    END INTERFACE
    INTERFACE
        SUBROUTINE FOUR2(DATA1,ISGN)
        USE NRTYPE
        COMPLEX(WPC), DIMENSION(:,:), INTENT(INOUT) :: DATA1
        INTEGER(I4B),INTENT(IN) :: ISGN
        END SUBROUTINE FOUR2
    END INTERFACE
    INTERFACE
        SUBROUTINE FOUR2_ALT(DATA1,ISGN)
        USE NRTYPE
        COMPLEX(WPC), DIMENSION(:,:), INTENT(INOUT) :: DATA1
        INTEGER(I4B), INTENT(IN) :: ISGN
        END SUBROUTINE FOUR2_ALT
    END INTERFACE
    INTERFACE
        SUBROUTINE FOUR3(DATA1,ISGN)
        USE NRTYPE
        COMPLEX(WPC), DIMENSION(:,:,:), INTENT(INOUT) :: DATA1
        INTEGER(I4B),INTENT(IN) :: ISGN
        END SUBROUTINE FOUR3
    END INTERFACE
    INTERFACE
        SUBROUTINE FOUR3_ALT(DATA1,ISGN)
        USE NRTYPE
        COMPLEX(WPC), DIMENSION(:,:,:), INTENT(INOUT) :: DATA1
        INTEGER(I4B), INTENT(IN) :: ISGN
        END SUBROUTINE FOUR3_ALT
    END INTERFACE
    INTERFACE
        SUBROUTINE FOURCOL_WP(DATA1,ISGN)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: ISGN
        COMPLEX(WPC), DIMENSION(:,:), INTENT(INOUT) :: DATA1
        END SUBROUTINE FOURCOL_WP
    END INTERFACE
    INTERFACE
        SUBROUTINE FOURCOL_3D(DATA1,ISGN)
        USE NRTYPE
        COMPLEX(WPC), DIMENSION(:,:,:), INTENT(INOUT) :: DATA1
        INTEGER(I4B), INTENT(IN) :: ISGN
        END SUBROUTINE FOURCOL_3D
    END INTERFACE
    INTERFACE
        SUBROUTINE FOURN_GATHER(DATA1,NN,ISGN)
        USE NRTYPE
        COMPLEX(WPC), DIMENSION(:), INTENT(INOUT) :: DATA1
        INTEGER(I4B), DIMENSION(:), INTENT(IN) :: NN
        INTEGER(I4B), INTENT(IN) :: ISGN
        END SUBROUTINE FOURN_GATHER
    END INTERFACE
    INTERFACE FOURROW
!        SUBROUTINE FOURROW_DP(DATA1,ISGN)
!        USE NRTYPE
!        COMPLEX(DPC), DIMENSION(:,:), INTENT(INOUT) :: DATA1
!        INTEGER(I4B), INTENT(IN) :: ISGN
!        END SUBROUTINE FOURROW_DP
!BL
        SUBROUTINE FOURROW_WP(DATA1,ISGN)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: ISGN
        COMPLEX(WPC), DIMENSION(:,:), INTENT(INOUT) :: DATA1
        END SUBROUTINE FOURROW_WP
    END INTERFACE
    INTERFACE
        SUBROUTINE FOURROW_3D(DATA1,ISGN)
        USE NRTYPE
        COMPLEX(WPC), DIMENSION(:,:,:), INTENT(INOUT) :: DATA1
        INTEGER(I4B), INTENT(IN) :: ISGN
        END SUBROUTINE FOURROW_3D
    END INTERFACE
    INTERFACE
        FUNCTION FPOLY(X,N)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X
        INTEGER(I4B), INTENT(IN) :: N
        REAL(WP), DIMENSION(N) :: FPOLY
        END FUNCTION FPOLY
    END INTERFACE
    INTERFACE
        SUBROUTINE FRED2(A,B,T,F,W,G,AK)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B
        REAL(WP), DIMENSION(:), INTENT(OUT) :: T,F,W
        INTERFACE
            FUNCTION G(T)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: T
            REAL(WP), DIMENSION(SIZE(T)) :: G
            END FUNCTION G
!BL
            FUNCTION AK(T,S)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: T,S
            REAL(WP), DIMENSION(SIZE(T),SIZE(S)) :: AK
            END FUNCTION AK
        END INTERFACE
        END SUBROUTINE FRED2
    END INTERFACE
    INTERFACE
        FUNCTION FREDIN(X,A,B,T,F,W,G,AK)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,T,F,W
        REAL(WP), DIMENSION(SIZE(X)) :: FREDIN
        INTERFACE
            FUNCTION G(T)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: T
            REAL(WP), DIMENSION(SIZE(T)) :: G
            END FUNCTION G
!BL
            FUNCTION AK(T,S)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: T,S
            REAL(WP), DIMENSION(SIZE(T),SIZE(S)) :: AK
            END FUNCTION AK
        END INTERFACE
        END FUNCTION FREDIN
    END INTERFACE
    INTERFACE
        SUBROUTINE FRENEL(X,S,C)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X
        REAL(WP), INTENT(OUT) :: S,C
        END SUBROUTINE FRENEL
    END INTERFACE
    INTERFACE
        SUBROUTINE FRPRMN(P,FTOL,ITER,FRET)
        USE NRTYPE
        INTEGER(I4B), INTENT(OUT) :: ITER
        REAL(WP), INTENT(IN) :: FTOL
        REAL(WP), INTENT(OUT) :: FRET
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: P
        END SUBROUTINE FRPRMN
    END INTERFACE
    INTERFACE
        SUBROUTINE FTEST(DATA11,DATA12,F,PROB)
        USE NRTYPE
        REAL(WP), INTENT(OUT) :: F,PROB
        REAL(WP), DIMENSION(:), INTENT(IN) :: DATA11,DATA12
        END SUBROUTINE FTEST
    END INTERFACE
    INTERFACE
        FUNCTION GAMDEV(IA)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: IA
        REAL(WP) :: GAMDEV
        END FUNCTION GAMDEV
    END INTERFACE
    INTERFACE GAMMLN
        FUNCTION GAMMLN_W(XX)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: XX
        REAL(WP) :: GAMMLN_W
        END FUNCTION GAMMLN_W
!BL
        FUNCTION GAMMLN_V(XX)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: XX
        REAL(WP), DIMENSION(SIZE(XX)) :: GAMMLN_V
        END FUNCTION GAMMLN_V
    END INTERFACE
    INTERFACE GAMMP
        FUNCTION GAMMP_W(A,X)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,X
        REAL(WP) :: GAMMP_W
        END FUNCTION GAMMP_W
!BL
        FUNCTION GAMMP_V(A,X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: A,X
        REAL(WP), DIMENSION(SIZE(A)) :: GAMMP_V
        END FUNCTION GAMMP_V
    END INTERFACE
    INTERFACE GAMMQ
        FUNCTION GAMMQ_W(A,X)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,X
        REAL(WP) :: GAMMQ_W
        END FUNCTION GAMMQ_W
!BL
        FUNCTION GAMMQ_V(A,X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: A,X
        REAL(WP), DIMENSION(SIZE(A)) :: GAMMQ_V
        END FUNCTION GAMMQ_V
    END INTERFACE
    INTERFACE GASDEV
        SUBROUTINE GASDEV_W(HARVEST)
        USE NRTYPE
        REAL(WP), INTENT(OUT) :: HARVEST
        END SUBROUTINE GASDEV_W
!BL
        SUBROUTINE GASDEV_V(HARVEST)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(OUT) :: HARVEST
        END SUBROUTINE GASDEV_V
    END INTERFACE
    INTERFACE
        SUBROUTINE GAUCOF(A,B,AMU0,X,W)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: AMU0
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: A,B
        REAL(WP), DIMENSION(:), INTENT(OUT) :: X,W
        END SUBROUTINE GAUCOF
    END INTERFACE
    INTERFACE
        SUBROUTINE GAUHER(X,W)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(OUT) :: X,W
        END SUBROUTINE GAUHER
    END INTERFACE
    INTERFACE
        SUBROUTINE GAUJAC(X,W,ALF,BET)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: ALF,BET
        REAL(WP), DIMENSION(:), INTENT(OUT) :: X,W
        END SUBROUTINE GAUJAC
    END INTERFACE
    INTERFACE
        SUBROUTINE GAULAG(X,W,ALF)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: ALF
        REAL(WP), DIMENSION(:), INTENT(OUT) :: X,W
        END SUBROUTINE GAULAG
    END INTERFACE
    INTERFACE
        SUBROUTINE GAULEG(X1,X2,X,W)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X1,X2
        REAL(WP), DIMENSION(:), INTENT(OUT) :: X,W
        END SUBROUTINE GAULEG
    END INTERFACE
    INTERFACE
        SUBROUTINE GAUSSJ(A,B)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(INOUT) :: A,B
        END SUBROUTINE GAUSSJ
    END INTERFACE
    INTERFACE GCF
        FUNCTION GCF_W(A,X,GLN)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,X
        REAL(WP), OPTIONAL, INTENT(OUT) :: GLN
        REAL(WP) :: GCF_W
        END FUNCTION GCF_W
!BL
        FUNCTION GCF_V(A,X,GLN)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: A,X
        REAL(WP), DIMENSION(:), OPTIONAL, INTENT(OUT) :: GLN
        REAL(WP), DIMENSION(SIZE(A)) :: GCF_V
        END FUNCTION GCF_V
    END INTERFACE
    INTERFACE
        FUNCTION GOLDEN(AX,BX,CX,FUNC,TOL,XMIN)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: AX,BX,CX,TOL
        REAL(WP), INTENT(OUT) :: XMIN
        REAL(WP) :: GOLDEN
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END FUNCTION GOLDEN
    END INTERFACE
    INTERFACE GSER
        FUNCTION GSER_W(A,X,GLN)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,X
        REAL(WP), OPTIONAL, INTENT(OUT) :: GLN
        REAL(WP) :: GSER_W
        END FUNCTION GSER_W
!BL
        FUNCTION GSER_V(A,X,GLN)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: A,X
        REAL(WP), DIMENSION(:), OPTIONAL, INTENT(OUT) :: GLN
        REAL(WP), DIMENSION(SIZE(A)) :: GSER_V
        END FUNCTION GSER_V
    END INTERFACE
    INTERFACE
        SUBROUTINE HQR(A,WR,WI)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(OUT) :: WR,WI
        REAL(WP), DIMENSION(:,:), INTENT(INOUT) :: A
        END SUBROUTINE HQR
    END INTERFACE
    INTERFACE
        SUBROUTINE HUNT(XX,X,JLO)
        USE NRTYPE
        INTEGER(I4B), INTENT(INOUT) :: JLO
        REAL(WP), INTENT(IN) :: X
        REAL(WP), DIMENSION(:), INTENT(IN) :: XX
        END SUBROUTINE HUNT
    END INTERFACE
    INTERFACE
        SUBROUTINE HYPDRV(S,RY,RDYDS)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: S
        REAL(WP), DIMENSION(:), INTENT(IN) :: RY
        REAL(WP), DIMENSION(:), INTENT(OUT) :: RDYDS
        END SUBROUTINE HYPDRV
    END INTERFACE
    INTERFACE
        FUNCTION HYPGEO(A,B,C,Z)
        USE NRTYPE
        COMPLEX(WPC), INTENT(IN) :: A,B,C,Z
        COMPLEX(WPC) :: HYPGEO
        END FUNCTION HYPGEO
    END INTERFACE
    INTERFACE
        SUBROUTINE HYPSER(A,B,C,Z,SERIES,DERIV)
        USE NRTYPE
        COMPLEX(WPC), INTENT(IN) :: A,B,C,Z
        COMPLEX(WPC), INTENT(OUT) :: SERIES,DERIV
        END SUBROUTINE HYPSER
    END INTERFACE
    INTERFACE
        FUNCTION ICRC(CRC,BUF,JINIT,JREV)
        USE NRTYPE
        CHARACTER(1), DIMENSION(:), INTENT(IN) :: BUF
        INTEGER(I2B), INTENT(IN) :: CRC,JINIT
        INTEGER(I4B), INTENT(IN) :: JREV
        INTEGER(I2B) :: ICRC
        END FUNCTION ICRC
    END INTERFACE
    INTERFACE
        FUNCTION IGRAY(N,IS)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N,IS
        INTEGER(I4B) :: IGRAY
        END FUNCTION IGRAY
    END INTERFACE
    INTERFACE
        RECURSIVE SUBROUTINE INDEX_BYPACK(ARR,INDEX,PARTIAL)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: ARR
        INTEGER(I4B), DIMENSION(:), INTENT(INOUT) :: INDEX
        INTEGER, OPTIONAL, INTENT(IN) :: PARTIAL
        END SUBROUTINE INDEX_BYPACK
    END INTERFACE
    INTERFACE INDEXX
        SUBROUTINE INDEXX_WP(ARR,INDEX)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: ARR
        INTEGER(I4B), DIMENSION(:), INTENT(OUT) :: INDEX
        END SUBROUTINE INDEXX_WP
        SUBROUTINE INDEXX_I4B(IARR,INDEX)
        USE NRTYPE
        INTEGER(I4B), DIMENSION(:), INTENT(IN) :: IARR
        INTEGER(I4B), DIMENSION(:), INTENT(OUT) :: INDEX
        END SUBROUTINE INDEXX_I4B
    END INTERFACE
    INTERFACE
        FUNCTION INTERP(UC)
        USE NRTYPE
        REAL(DP), DIMENSION(:,:), INTENT(IN) :: UC
        REAL(DP), DIMENSION(2*SIZE(UC,1)-1,2*SIZE(UC,1)-1) :: INTERP
        END FUNCTION INTERP
    END INTERFACE
    INTERFACE
        FUNCTION RANKK(INDX)
        USE NRTYPE
        INTEGER(I4B), DIMENSION(:), INTENT(IN) :: INDX
        INTEGER(I4B), DIMENSION(SIZE(INDX)) :: RANKK
        END FUNCTION RANKK
    END INTERFACE
    INTERFACE
        FUNCTION IRBIT1(ISEED)
        USE NRTYPE
        INTEGER(I4B), INTENT(INOUT) :: ISEED
        INTEGER(I4B) :: IRBIT1
        END FUNCTION IRBIT1
    END INTERFACE
    INTERFACE
        FUNCTION IRBIT2(ISEED)
        USE NRTYPE
        INTEGER(I4B), INTENT(INOUT) :: ISEED
        INTEGER(I4B) :: IRBIT2
        END FUNCTION IRBIT2
    END INTERFACE
    INTERFACE
        SUBROUTINE JACOBI(A,D,V,NROT)
        USE NRTYPE
        INTEGER(I4B), INTENT(OUT) :: NROT
        REAL(WP), DIMENSION(:), INTENT(OUT) :: D
        REAL(WP), DIMENSION(:,:), INTENT(INOUT) :: A
        REAL(WP), DIMENSION(:,:), INTENT(OUT) :: V
        END SUBROUTINE JACOBI
    END INTERFACE
    INTERFACE
        SUBROUTINE JACOBN(X,Y,DFDX,DFDY)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X
        REAL(WP), DIMENSION(:), INTENT(IN) :: Y
        REAL(WP), DIMENSION(:), INTENT(OUT) :: DFDX
        REAL(WP), DIMENSION(:,:), INTENT(OUT) :: DFDY
        END SUBROUTINE JACOBN
    END INTERFACE
    INTERFACE
        FUNCTION JULDAY(MM,ID,IYYY)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: MM,ID,IYYY
        INTEGER(I4B) :: JULDAY
        END FUNCTION JULDAY
    END INTERFACE
    INTERFACE
        SUBROUTINE KENDL1(DATA11,DATA12,TAU,Z,PROB)
        USE NRTYPE
        REAL(WP), INTENT(OUT) :: TAU,Z,PROB
        REAL(WP), DIMENSION(:), INTENT(IN) :: DATA11,DATA12
        END SUBROUTINE KENDL1
    END INTERFACE
    INTERFACE
        SUBROUTINE KENDL2(TAB,TAU,Z,PROB)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(IN) :: TAB
        REAL(WP), INTENT(OUT) :: TAU,Z,PROB
        END SUBROUTINE KENDL2
    END INTERFACE
    INTERFACE
        FUNCTION KERMOM(Y,M)
        USE NRTYPE
        REAL(DP), INTENT(IN) :: Y
        INTEGER(I4B), INTENT(IN) :: M
        REAL(DP), DIMENSION(M) :: KERMOM
        END FUNCTION KERMOM
    END INTERFACE
    INTERFACE
        SUBROUTINE KS2D1S(X1,Y1,QUADVL,D1,PROB)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X1,Y1
        REAL(WP), INTENT(OUT) :: D1,PROB
        INTERFACE
            SUBROUTINE QUADVL(X,Y,FA,FB,FC,FD)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X,Y
            REAL(WP), INTENT(OUT) :: FA,FB,FC,FD
            END SUBROUTINE QUADVL
        END INTERFACE
        END SUBROUTINE KS2D1S
    END INTERFACE
    INTERFACE
        SUBROUTINE KS2D2S(X1,Y1,X2,Y2,D,PROB)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X1,Y1,X2,Y2
        REAL(WP), INTENT(OUT) :: D,PROB
        END SUBROUTINE KS2D2S
    END INTERFACE
    INTERFACE
        SUBROUTINE KSONE(DATA1,FUNC,D,PROB)
        USE NRTYPE
        REAL(WP), INTENT(OUT) :: D,PROB
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: DATA1
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: X
            REAL(WP), DIMENSION(SIZE(X)) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END SUBROUTINE KSONE
    END INTERFACE
    INTERFACE
        SUBROUTINE KSTWO(DATA11,DATA12,D,PROB)
        USE NRTYPE
        REAL(WP), INTENT(OUT) :: D,PROB
        REAL(WP), DIMENSION(:), INTENT(IN) :: DATA11,DATA12
        END SUBROUTINE KSTWO
    END INTERFACE
    INTERFACE
        SUBROUTINE LAGUER(A,X,ITS)
        USE NRTYPE
        INTEGER(I4B), INTENT(OUT) :: ITS
        COMPLEX(WPC), INTENT(INOUT) :: X
        COMPLEX(WPC), DIMENSION(:), INTENT(IN) :: A
        END SUBROUTINE LAGUER
    END INTERFACE
    INTERFACE
        SUBROUTINE LFIT(X,Y,SIG,A,MASKA,COVAR,CHISQ,FUNCS)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,Y,SIG
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: A
        LOGICAL(TLG), DIMENSION(:), INTENT(IN) :: MASKA
        REAL(WP), DIMENSION(:,:), INTENT(INOUT) :: COVAR
        REAL(WP), INTENT(OUT) :: CHISQ
        INTERFACE
            SUBROUTINE FUNCS(X,ARR)
            USE NRTYPE
            REAL(WP),INTENT(IN) :: X
            REAL(WP), DIMENSION(:), INTENT(OUT) :: ARR
            END SUBROUTINE FUNCS
        END INTERFACE
        END SUBROUTINE LFIT
    END INTERFACE
    INTERFACE
        SUBROUTINE LINBCG(B,X,ITOL,TOL,ITMAX,ITER,ERR)
        USE NRTYPE
        REAL(DP), DIMENSION(:), INTENT(IN) :: B
        REAL(DP), DIMENSION(:), INTENT(INOUT) :: X
        INTEGER(I4B), INTENT(IN) :: ITOL,ITMAX
        REAL(DP), INTENT(IN) :: TOL
        INTEGER(I4B), INTENT(OUT) :: ITER
        REAL(DP), INTENT(OUT) :: ERR
        END SUBROUTINE LINBCG
    END INTERFACE
    INTERFACE
        SUBROUTINE LINMIN(P,XI,FRET)
        USE NRTYPE
        REAL(WP), INTENT(OUT) :: FRET
        REAL(WP), DIMENSION(:), TARGET, INTENT(INOUT) :: P,XI
        END SUBROUTINE LINMIN
    END INTERFACE
    INTERFACE
        SUBROUTINE LNSRCH(XOLD,FOLD,G,P,X,F,STPMAX,CHECK,FUNC)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: XOLD,G
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: P
        REAL(WP), INTENT(IN) :: FOLD,STPMAX
        REAL(WP), DIMENSION(:), INTENT(OUT) :: X
        REAL(WP), INTENT(OUT) :: F
        LOGICAL(TLG), INTENT(OUT) :: CHECK
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP) :: FUNC
            REAL(WP), DIMENSION(:), INTENT(IN) :: X
            END FUNCTION FUNC
        END INTERFACE
        END SUBROUTINE LNSRCH
    END INTERFACE
    INTERFACE
        FUNCTION LOCATE(XX,X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: XX
        REAL(WP), INTENT(IN) :: X
        INTEGER(I4B) :: LOCATE
        END FUNCTION LOCATE
    END INTERFACE
    INTERFACE
        FUNCTION LOP(U)
        USE NRTYPE
        REAL(DP), DIMENSION(:,:), INTENT(IN) :: U
        REAL(DP), DIMENSION(SIZE(U,1),SIZE(U,1)) :: LOP
        END FUNCTION LOP
    END INTERFACE
    INTERFACE
        SUBROUTINE LUBKSB(A,INDX,B)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(IN) :: A
        INTEGER(I4B), DIMENSION(:), INTENT(IN) :: INDX
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: B
        END SUBROUTINE LUBKSB
    END INTERFACE
    INTERFACE
        SUBROUTINE LUDCMP(A,INDX,D)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(INOUT) :: A
        INTEGER(I4B), DIMENSION(:), INTENT(OUT) :: INDX
        REAL(WP), INTENT(OUT) :: D
        END SUBROUTINE LUDCMP
    END INTERFACE
    INTERFACE
        SUBROUTINE MACHAR(IBETA,IT,IRND,NGRD,MACHEP,NEGEP,IEXP,MINEXP,MAXEXP,EPS,EPSNEG,XMIN,XMAX)
        USE NRTYPE
        INTEGER(I4B), INTENT(OUT) :: IBETA,IEXP,IRND,IT,MACHEP,MAXEXP,MINEXP,NEGEP,NGRD
        REAL(WP), INTENT(OUT) :: EPS,EPSNEG,XMAX,XMIN
        END SUBROUTINE MACHAR
    END INTERFACE
    INTERFACE
        SUBROUTINE MEDFIT(X,Y,A,B,ABDEV)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,Y
        REAL(WP), INTENT(OUT) :: A,B,ABDEV
        END SUBROUTINE MEDFIT
    END INTERFACE
    INTERFACE
        SUBROUTINE MEMCOF(DATA1,XMS,D)
        USE NRTYPE
        REAL(WP), INTENT(OUT) :: XMS
        REAL(WP), DIMENSION(:), INTENT(IN) :: DATA1
        REAL(WP), DIMENSION(:), INTENT(OUT) :: D
        END SUBROUTINE MEMCOF
    END INTERFACE
    INTERFACE
        SUBROUTINE MGFAS(U,MAXCYC)
        USE NRTYPE
        REAL(DP), DIMENSION(:,:), INTENT(INOUT) :: U
        INTEGER(I4B), INTENT(IN) :: MAXCYC
        END SUBROUTINE MGFAS
    END INTERFACE
    INTERFACE
        SUBROUTINE MGLIN(U,NCYCLE)
        USE NRTYPE
        REAL(DP), DIMENSION(:,:), INTENT(INOUT) :: U
        INTEGER(I4B), INTENT(IN) :: NCYCLE
        END SUBROUTINE MGLIN
    END INTERFACE
    INTERFACE
        SUBROUTINE MIDEXP(FUNK,AA,BB,S,N)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: AA,BB
        REAL(WP), INTENT(INOUT) :: S
        INTEGER(I4B), INTENT(IN) :: N
        INTERFACE
            FUNCTION FUNK(X)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: X
            REAL(WP), DIMENSION(SIZE(X)) :: FUNK
            END FUNCTION FUNK
        END INTERFACE
        END SUBROUTINE MIDEXP
    END INTERFACE
    INTERFACE
        SUBROUTINE MIDINF(FUNK,AA,BB,S,N)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: AA,BB
        REAL(WP), INTENT(INOUT) :: S
        INTEGER(I4B), INTENT(IN) :: N
        INTERFACE
            FUNCTION FUNK(X)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: X
            REAL(WP), DIMENSION(SIZE(X)) :: FUNK
            END FUNCTION FUNK
        END INTERFACE
        END SUBROUTINE MIDINF
    END INTERFACE
    INTERFACE
        SUBROUTINE MIDPNT(FUNC,A,B,S,N)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B
        REAL(WP), INTENT(INOUT) :: S
        INTEGER(I4B), INTENT(IN) :: N
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: X
            REAL(WP), DIMENSION(SIZE(X)) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END SUBROUTINE MIDPNT
    END INTERFACE
    INTERFACE
        SUBROUTINE MIDSQL(FUNK,AA,BB,S,N)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: AA,BB
        REAL(WP), INTENT(INOUT) :: S
        INTEGER(I4B), INTENT(IN) :: N
        INTERFACE
            FUNCTION FUNK(X)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: X
            REAL(WP), DIMENSION(SIZE(X)) :: FUNK
            END FUNCTION FUNK
        END INTERFACE
        END SUBROUTINE MIDSQL
    END INTERFACE
    INTERFACE
        SUBROUTINE MIDSQU(FUNK,AA,BB,S,N)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: AA,BB
        REAL(WP), INTENT(INOUT) :: S
        INTEGER(I4B), INTENT(IN) :: N
        INTERFACE
            FUNCTION FUNK(X)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: X
            REAL(WP), DIMENSION(SIZE(X)) :: FUNK
            END FUNCTION FUNK
        END INTERFACE
        END SUBROUTINE MIDSQU
    END INTERFACE
    INTERFACE
        RECURSIVE SUBROUTINE MISER(FUNC,REGN,NDIM,NPTS,DITH,AVE,VAR)
        USE NRTYPE
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP) :: FUNC
            REAL(WP), DIMENSION(:), INTENT(IN) :: X
            END FUNCTION FUNC
        END INTERFACE
        REAL(WP), DIMENSION(:), INTENT(IN) :: REGN
        INTEGER(I4B), INTENT(IN) :: NDIM,NPTS
        REAL(WP), INTENT(IN) :: DITH
        REAL(WP), INTENT(OUT) :: AVE,VAR
        END SUBROUTINE MISER
    END INTERFACE
    INTERFACE
        SUBROUTINE MMID(Y,DYDX,XS,HTOT,NSTEP,YOUT,DERIVS)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: NSTEP
        REAL(WP), INTENT(IN) :: XS,HTOT
        REAL(WP), DIMENSION(:), INTENT(IN) :: Y,DYDX
        REAL(WP), DIMENSION(:), INTENT(OUT) :: YOUT
        INTERFACE
            SUBROUTINE DERIVS(X,Y,DYDX)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP), DIMENSION(:), INTENT(IN) :: Y
            REAL(WP), DIMENSION(:), INTENT(OUT) :: DYDX
            END SUBROUTINE DERIVS
        END INTERFACE
        END SUBROUTINE MMID
    END INTERFACE
    INTERFACE
        SUBROUTINE MNBRAK(AX,BX,CX,FA,FB,FC,FUNC)
        USE NRTYPE
        REAL(WP), INTENT(INOUT) :: AX,BX
        REAL(WP), INTENT(OUT) :: CX,FA,FB,FC
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END SUBROUTINE MNBRAK
    END INTERFACE
    INTERFACE
        SUBROUTINE MNEWT(NTRIAL,X,TOLX,TOLF,USRFUN)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: NTRIAL
        REAL(WP), INTENT(IN) :: TOLX,TOLF
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: X
        INTERFACE
            SUBROUTINE USRFUN(X,FVEC,FJAC)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: X
            REAL(WP), DIMENSION(:), INTENT(OUT) :: FVEC
            REAL(WP), DIMENSION(:,:), INTENT(OUT) :: FJAC
            END SUBROUTINE USRFUN
        END INTERFACE
        END SUBROUTINE MNEWT
    END INTERFACE
    INTERFACE
        SUBROUTINE MOMENT(DATA1,AVE,ADEV,SDEV,VAR,SKEW,CURT,RMS,XMED)
        USE NRTYPE
        REAL(WP), INTENT(OUT) :: AVE,ADEV,SDEV,VAR,SKEW,CURT,RMS,XMED
        REAL(WP), DIMENSION(:), INTENT(IN) :: DATA1
        END SUBROUTINE MOMENT
    END INTERFACE
    INTERFACE
        SUBROUTINE MP2DFR(A,S,N,M)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N
        INTEGER(I4B), INTENT(OUT) :: M
        CHARACTER(1), DIMENSION(:), INTENT(INOUT) :: A
        CHARACTER(1), DIMENSION(:), INTENT(OUT) :: S
        END SUBROUTINE MP2DFR
    END INTERFACE
    INTERFACE
        SUBROUTINE MPDIV(Q,R,U,V,N,M)
        USE NRTYPE
        CHARACTER(1), DIMENSION(:), INTENT(OUT) :: Q,R
        CHARACTER(1), DIMENSION(:), INTENT(IN) :: U,V
        INTEGER(I4B), INTENT(IN) :: N,M
        END SUBROUTINE MPDIV
    END INTERFACE
    INTERFACE
        SUBROUTINE MPINV(U,V,N,M)
        USE NRTYPE
        CHARACTER(1), DIMENSION(:), INTENT(OUT) :: U
        CHARACTER(1), DIMENSION(:), INTENT(IN) :: V
        INTEGER(I4B), INTENT(IN) :: N,M
        END SUBROUTINE MPINV
    END INTERFACE
    INTERFACE
        SUBROUTINE MPMUL(W,U,V,N,M)
        USE NRTYPE
        CHARACTER(1), DIMENSION(:), INTENT(IN) :: U,V
        CHARACTER(1), DIMENSION(:), INTENT(OUT) :: W
        INTEGER(I4B), INTENT(IN) :: N,M
        END SUBROUTINE MPMUL
    END INTERFACE
    INTERFACE
        SUBROUTINE MPPI(N)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N
        END SUBROUTINE MPPI
    END INTERFACE
    INTERFACE
        SUBROUTINE MPROVE(A,ALUD,INDX,B,X)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(IN) :: A,ALUD
        INTEGER(I4B), DIMENSION(:), INTENT(IN) :: INDX
        REAL(WP), DIMENSION(:), INTENT(IN) :: B
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: X
        END SUBROUTINE MPROVE
    END INTERFACE
    INTERFACE
        SUBROUTINE MPSQRT(W,U,V,N,M)
        USE NRTYPE
        CHARACTER(1), DIMENSION(:), INTENT(OUT) :: W,U
        CHARACTER(1), DIMENSION(:), INTENT(IN) :: V
        INTEGER(I4B), INTENT(IN) :: N,M
        END SUBROUTINE MPSQRT
    END INTERFACE
    INTERFACE
        SUBROUTINE MRQCOF(X,Y,SIG,A,MASKA,ALPHA,BETA,CHISQ,FUNCS)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,Y,A,SIG
        REAL(WP), DIMENSION(:), INTENT(OUT) :: BETA
        REAL(WP), DIMENSION(:,:), INTENT(OUT) :: ALPHA
        REAL(WP), INTENT(OUT) :: CHISQ
        LOGICAL(TLG), DIMENSION(:), INTENT(IN) :: MASKA
        INTERFACE
            SUBROUTINE FUNCS(X,A,YFIT,DYDA)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: X,A
            REAL(WP), DIMENSION(:), INTENT(OUT) :: YFIT
            REAL(WP), DIMENSION(:,:), INTENT(OUT) :: DYDA
            END SUBROUTINE FUNCS
        END INTERFACE
        END SUBROUTINE MRQCOF
    END INTERFACE
    INTERFACE
        SUBROUTINE MRQMIN(X,Y,SIG,A,MASKA,COVAR,ALPHA,CHISQ,FUNCS,ALAMDA)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,Y,SIG
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: A
        REAL(WP), DIMENSION(:,:), INTENT(OUT) :: COVAR,ALPHA
        REAL(WP), INTENT(OUT) :: CHISQ
        REAL(WP), INTENT(INOUT) :: ALAMDA
        LOGICAL(TLG), DIMENSION(:), INTENT(IN) :: MASKA
        INTERFACE
            SUBROUTINE FUNCS(X,A,YFIT,DYDA)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: X,A
            REAL(WP), DIMENSION(:), INTENT(OUT) :: YFIT
            REAL(WP), DIMENSION(:,:), INTENT(OUT) :: DYDA
            END SUBROUTINE FUNCS
        END INTERFACE
        END SUBROUTINE MRQMIN
    END INTERFACE
    INTERFACE
        SUBROUTINE NEWT(X,CHECK)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: X
        LOGICAL(TLG), INTENT(OUT) :: CHECK
        END SUBROUTINE NEWT
    END INTERFACE
    INTERFACE
        SUBROUTINE ODEINT(YSTART,X1,X2,EPS,H1,HMIN,DERIVS,RKQS)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: YSTART
        REAL(WP), INTENT(IN) :: X1,X2,EPS,H1,HMIN
        INTERFACE
            SUBROUTINE DERIVS(X,Y,DYDX)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP), DIMENSION(:), INTENT(IN) :: Y
            REAL(WP), DIMENSION(:), INTENT(OUT) :: DYDX
            END SUBROUTINE DERIVS
!BL
            SUBROUTINE RKQS(Y,DYDX,X,HTRY,EPS,YSCAL,HDID,HNEXT,DERIVS)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(INOUT) :: Y
            REAL(WP), DIMENSION(:), INTENT(IN) :: DYDX,YSCAL
            REAL(WP), INTENT(INOUT) :: X
            REAL(WP), INTENT(IN) :: HTRY,EPS
            REAL(WP), INTENT(OUT) :: HDID,HNEXT
                INTERFACE
                SUBROUTINE DERIVS(X,Y,DYDX)
                    USE NRTYPE
                    REAL(WP), INTENT(IN) :: X
                    REAL(WP), DIMENSION(:), INTENT(IN) :: Y
                    REAL(WP), DIMENSION(:), INTENT(OUT) :: DYDX
                    END SUBROUTINE DERIVS
                END INTERFACE
            END SUBROUTINE RKQS
        END INTERFACE
        END SUBROUTINE ODEINT
    END INTERFACE
    INTERFACE
        SUBROUTINE ORTHOG(ANU,ALPHA,BETA,A,B)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: ANU,ALPHA,BETA
        REAL(WP), DIMENSION(:), INTENT(OUT) :: A,B
        END SUBROUTINE ORTHOG
    END INTERFACE
    INTERFACE
        SUBROUTINE PADE(COF,RESID)
        USE NRTYPE
        REAL(DP), DIMENSION(:), INTENT(INOUT) :: COF
        REAL(WP), INTENT(OUT) :: RESID
        END SUBROUTINE PADE
    END INTERFACE
    INTERFACE
        FUNCTION PCCHEB(D)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: D
        REAL(WP), DIMENSION(SIZE(D)) :: PCCHEB
        END FUNCTION PCCHEB
    END INTERFACE
    INTERFACE
        SUBROUTINE PCSHFT(A,B,D)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: D
        END SUBROUTINE PCSHFT
    END INTERFACE
    INTERFACE
        SUBROUTINE PEARSN(X,Y,R,PROB,Z)
        USE NRTYPE
        REAL(WP), INTENT(OUT) :: R,PROB,Z
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,Y
        END SUBROUTINE PEARSN
    END INTERFACE
    INTERFACE
        SUBROUTINE PERIOD(X,Y,OFAC,HIFAC,PX,PY,JMAX,PROB)
        USE NRTYPE
        INTEGER(I4B), INTENT(OUT) :: JMAX
        REAL(WP), INTENT(IN) :: OFAC,HIFAC
        REAL(WP), INTENT(OUT) :: PROB
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,Y
        REAL(WP), DIMENSION(:), POINTER :: PX,PY
        END SUBROUTINE PERIOD
    END INTERFACE
    INTERFACE PLGNDR
        FUNCTION PLGNDR_W(L,M,X)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: L,M
        REAL(WP), INTENT(IN) :: X
        REAL(WP) :: PLGNDR_W
        END FUNCTION PLGNDR_W
!BL
        FUNCTION PLGNDR_V(L,M,X)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: L,M
        REAL(WP), DIMENSION(:), INTENT(IN) :: X
        REAL(WP), DIMENSION(SIZE(X)) :: PLGNDR_V
        END FUNCTION PLGNDR_V
    END INTERFACE
    INTERFACE
        FUNCTION POIDEV(XM)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: XM
        REAL(WP) :: POIDEV
        END FUNCTION POIDEV
    END INTERFACE
    INTERFACE
        FUNCTION POLCOE(X,Y)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,Y
        REAL(WP), DIMENSION(SIZE(X)) :: POLCOE
        END FUNCTION POLCOE
    END INTERFACE
    INTERFACE
        FUNCTION POLCOF(XA,YA)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: XA,YA
        REAL(WP), DIMENSION(SIZE(XA)) :: POLCOF
        END FUNCTION POLCOF
    END INTERFACE
    INTERFACE
        SUBROUTINE POLDIV(U,V,Q,R)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: U,V
        REAL(WP), DIMENSION(:), INTENT(OUT) :: Q,R
        END SUBROUTINE POLDIV
    END INTERFACE
    INTERFACE
        SUBROUTINE POLIN2(X1A,X2A,YA,X1,X2,Y,DY)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X1A,X2A
        REAL(WP), DIMENSION(:,:), INTENT(IN) :: YA
        REAL(WP), INTENT(IN) :: X1,X2
        REAL(WP), INTENT(OUT) :: Y,DY
        END SUBROUTINE POLIN2
    END INTERFACE
    INTERFACE
        SUBROUTINE POLINT(XA,YA,X,Y,DY)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: XA,YA
        REAL(WP), INTENT(IN) :: X
        REAL(WP), INTENT(OUT) :: Y,DY
        END SUBROUTINE POLINT
    END INTERFACE
    INTERFACE
        SUBROUTINE POWELL(P,XI,FTOL,ITER,FRET)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: P
        REAL(WP), DIMENSION(:,:), INTENT(INOUT) :: XI
        INTEGER(I4B), INTENT(OUT) :: ITER
        REAL(WP), INTENT(IN) :: FTOL
        REAL(WP), INTENT(OUT) :: FRET
        END SUBROUTINE POWELL
    END INTERFACE
    INTERFACE
        FUNCTION PREDIC(DATA1,D,NFUT)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: DATA1,D
        INTEGER(I4B), INTENT(IN) :: NFUT
        REAL(WP), DIMENSION(NFUT) :: PREDIC
        END FUNCTION PREDIC
    END INTERFACE
    INTERFACE
        FUNCTION PROBKS(ALAM)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: ALAM
        REAL(WP) :: PROBKS
        END FUNCTION PROBKS
    END INTERFACE
    INTERFACE PSDES
        SUBROUTINE PSDES_W(LWORD,RWORD)
        USE NRTYPE
        INTEGER(I4B), INTENT(INOUT) :: LWORD,RWORD
        END SUBROUTINE PSDES_W
!BL
        SUBROUTINE PSDES_V(LWORD,RWORD)
        USE NRTYPE
        INTEGER(I4B), DIMENSION(:), INTENT(INOUT) :: LWORD,RWORD
        END SUBROUTINE PSDES_V
    END INTERFACE
    INTERFACE
        SUBROUTINE PWT(A,ISGN)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: A
        INTEGER(I4B), INTENT(IN) :: ISGN
        END SUBROUTINE PWT
    END INTERFACE
    INTERFACE
        SUBROUTINE PWTSET(N)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N
        END SUBROUTINE PWTSET
    END INTERFACE
    INTERFACE PYTHAG
!        FUNCTION PYTHAG_DP(A,B)
!        USE NRTYPE
!        REAL(DP), INTENT(IN) :: A,B
!        REAL(DP) :: PYTHAG_DP
!        END FUNCTION PYTHAG_DP
!BL
        FUNCTION PYTHAG_WP(A,B)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B
        REAL(WP) :: PYTHAG_WP
        END FUNCTION PYTHAG_WP
    END INTERFACE
    INTERFACE
        SUBROUTINE PZEXTR(IEST,XEST,YEST,YZ,DY)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: IEST
        REAL(WP), INTENT(IN) :: XEST
        REAL(WP), DIMENSION(:), INTENT(IN) :: YEST
        REAL(WP), DIMENSION(:), INTENT(OUT) :: YZ,DY
        END SUBROUTINE PZEXTR
    END INTERFACE
    INTERFACE
        SUBROUTINE QRDCMP(A,C,D,SING)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(INOUT) :: A
        REAL(WP), DIMENSION(:), INTENT(OUT) :: C,D
        LOGICAL(TLG), INTENT(OUT) :: SING
        END SUBROUTINE QRDCMP
    END INTERFACE
    INTERFACE
        FUNCTION QROMB(FUNC,A,B)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B
        REAL(WP) :: QROMB
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: X
            REAL(WP), DIMENSION(SIZE(X)) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END FUNCTION QROMB
    END INTERFACE
    INTERFACE
        FUNCTION QROMO(FUNC,A,B,CHOOSE)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B
        REAL(WP) :: QROMO
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: X
            REAL(WP), DIMENSION(SIZE(X)) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        INTERFACE
            SUBROUTINE CHOOSE(FUNK,AA,BB,S,N)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: AA,BB
            REAL(WP), INTENT(INOUT) :: S
            INTEGER(I4B), INTENT(IN) :: N
            INTERFACE
                FUNCTION FUNK(X)
                USE NRTYPE
                REAL(WP), DIMENSION(:), INTENT(IN) :: X
                REAL(WP), DIMENSION(SIZE(X)) :: FUNK
                END FUNCTION FUNK
            END INTERFACE
            END SUBROUTINE CHOOSE
        END INTERFACE
        END FUNCTION QROMO
    END INTERFACE
    INTERFACE
        SUBROUTINE QROOT(P,B,C,EPS)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: P
        REAL(WP), INTENT(INOUT) :: B,C
        REAL(WP), INTENT(IN) :: EPS
        END SUBROUTINE QROOT
    END INTERFACE
    INTERFACE
        SUBROUTINE QRSOLV(A,C,D,B)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(IN) :: A
        REAL(WP), DIMENSION(:), INTENT(IN) :: C,D
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: B
        END SUBROUTINE QRSOLV
    END INTERFACE
    INTERFACE
        SUBROUTINE QRUPDT(R,QT,U,V)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(INOUT) :: R,QT
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: U
        REAL(WP), DIMENSION(:), INTENT(IN) :: V
        END SUBROUTINE QRUPDT
    END INTERFACE
    INTERFACE
        FUNCTION QSIMP(FUNC,A,B)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B
        REAL(WP) :: QSIMP
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: X
            REAL(WP), DIMENSION(SIZE(X)) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END FUNCTION QSIMP
    END INTERFACE
    INTERFACE
        FUNCTION QTRAP(FUNC,A,B)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B
        REAL(WP) :: QTRAP
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: X
            REAL(WP), DIMENSION(SIZE(X)) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END FUNCTION QTRAP
    END INTERFACE
    INTERFACE
        SUBROUTINE QUADCT(X,Y,XX,YY,FA,FB,FC,FD)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X,Y
        REAL(WP), DIMENSION(:), INTENT(IN) :: XX,YY
        REAL(WP), INTENT(OUT) :: FA,FB,FC,FD
        END SUBROUTINE QUADCT
    END INTERFACE
    INTERFACE
        SUBROUTINE QUADMX(A)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(OUT) :: A
        END SUBROUTINE QUADMX
    END INTERFACE
    INTERFACE
        SUBROUTINE QUADVL(X,Y,FA,FB,FC,FD)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X,Y
        REAL(WP), INTENT(OUT) :: FA,FB,FC,FD
        END SUBROUTINE QUADVL
    END INTERFACE
    INTERFACE
        FUNCTION RANN(IDUM)
        INTEGER(SELECTED_INT_KIND(9)), INTENT(INOUT) :: IDUM
        REAL :: RANN
        END FUNCTION RANN
    END INTERFACE
    INTERFACE RAN0
        SUBROUTINE RAN0_W(HARVEST)
        USE NRTYPE
        REAL(WP), INTENT(OUT) :: HARVEST
        END SUBROUTINE RAN0_W
!BL
        SUBROUTINE RAN0_V(HARVEST)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(OUT) :: HARVEST
        END SUBROUTINE RAN0_V
    END INTERFACE
    INTERFACE RAN1
        SUBROUTINE RAN1_W(HARVEST)
        USE NRTYPE
        REAL(WP), INTENT(OUT) :: HARVEST
        END SUBROUTINE RAN1_W
!BL
        SUBROUTINE RAN1_V(HARVEST)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(OUT) :: HARVEST
        END SUBROUTINE RAN1_V
    END INTERFACE
    INTERFACE RAN2
        SUBROUTINE RAN2_W(HARVEST)
        USE NRTYPE
        REAL(WP), INTENT(OUT) :: HARVEST
        END SUBROUTINE RAN2_W
!BL
        SUBROUTINE RAN2_V(HARVEST)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(OUT) :: HARVEST
        END SUBROUTINE RAN2_V
    END INTERFACE
    INTERFACE RAN3
        SUBROUTINE RAN3_W(HARVEST)
        USE NRTYPE
        REAL(WP), INTENT(OUT) :: HARVEST
        END SUBROUTINE RAN3_W
!BL
        SUBROUTINE RAN3_V(HARVEST)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(OUT) :: HARVEST
        END SUBROUTINE RAN3_V
    END INTERFACE
    INTERFACE
        SUBROUTINE RATINT(XA,YA,X,Y,DY)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: XA,YA
        REAL(WP), INTENT(IN) :: X
        REAL(WP), INTENT(OUT) :: Y,DY
        END SUBROUTINE RATINT
    END INTERFACE
    INTERFACE
        SUBROUTINE RATLSQ(FUNC,A,B,MM,KK,COF,DEV)
        USE NRTYPE
        REAL(DP), INTENT(IN) :: A,B
        INTEGER(I4B), INTENT(IN) :: MM,KK
        REAL(DP), DIMENSION(:), INTENT(OUT) :: COF
        REAL(DP), INTENT(OUT) :: DEV
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(DP), DIMENSION(:), INTENT(IN) :: X
            REAL(DP), DIMENSION(SIZE(X)) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END SUBROUTINE RATLSQ
    END INTERFACE
    INTERFACE RATVAL
        FUNCTION RATVAL_W(X,COF,MM,KK)
        USE NRTYPE
        REAL(DP), INTENT(IN) :: X
        INTEGER(I4B), INTENT(IN) :: MM,KK
        REAL(DP), DIMENSION(MM+KK+1), INTENT(IN) :: COF
        REAL(DP) :: RATVAL_W
        END FUNCTION RATVAL_W
!BL
        FUNCTION RATVAL_V(X,COF,MM,KK)
        USE NRTYPE
        REAL(DP), DIMENSION(:), INTENT(IN) :: X
        INTEGER(I4B), INTENT(IN) :: MM,KK
        REAL(DP), DIMENSION(MM+KK+1), INTENT(IN) :: COF
        REAL(DP), DIMENSION(SIZE(X)) :: RATVAL_V
        END FUNCTION RATVAL_V
    END INTERFACE
    INTERFACE RC
        FUNCTION RC_W(X,Y)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X,Y
        REAL(WP) :: RC_W
        END FUNCTION RC_W
!BL
        FUNCTION RC_V(X,Y)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,Y
        REAL(WP), DIMENSION(SIZE(X)) :: RC_V
        END FUNCTION RC_V
    END INTERFACE
    INTERFACE RD
        FUNCTION RD_W(X,Y,Z)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X,Y,Z
        REAL(WP) :: RD_W
        END FUNCTION RD_W
!BL
        FUNCTION RD_V(X,Y,Z)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,Y,Z
        REAL(WP), DIMENSION(SIZE(X)) :: RD_V
        END FUNCTION RD_V
    END INTERFACE
    INTERFACE REALFT_WP
!        SUBROUTINE REALFT_DP(DATA1,ISGN,ZDATA1)
!        USE NRTYPE
!        REAL(DP), DIMENSION(:), INTENT(INOUT) :: DATA1
!        INTEGER(I4B), INTENT(IN) :: ISGN
!        COMPLEX(DPC), DIMENSION(:), OPTIONAL, TARGET :: ZDATA1
!        END SUBROUTINE REALFT_DP
!BL
        SUBROUTINE REALFT_WP(NN,DATA1,ISGN,ZDATA)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: ISGN, NN
        REAL(WP), DIMENSION(1:NN), INTENT(INOUT) :: DATA1
        COMPLEX(WPC), DIMENSION(1:NN/2), OPTIONAL, TARGET :: ZDATA
        END SUBROUTINE REALFT_WP
    END INTERFACE
    INTERFACE
        RECURSIVE FUNCTION RECUR1(A,B) RESULT(U)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: A,B
        REAL(WP), DIMENSION(SIZE(A)) :: U
        END FUNCTION RECUR1
    END INTERFACE
    INTERFACE
        FUNCTION RECUR2(A,B,C)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: A,B,C
        REAL(WP), DIMENSION(SIZE(A)) :: RECUR2
        END FUNCTION RECUR2
    END INTERFACE
    INTERFACE
        SUBROUTINE RELAX(U,RHS)
        USE NRTYPE
        REAL(DP), DIMENSION(:,:), INTENT(INOUT) :: U
        REAL(DP), DIMENSION(:,:), INTENT(IN) :: RHS
        END SUBROUTINE RELAX
    END INTERFACE
    INTERFACE
        SUBROUTINE RELAX2(U,RHS)
        USE NRTYPE
        REAL(DP), DIMENSION(:,:), INTENT(INOUT) :: U
        REAL(DP), DIMENSION(:,:), INTENT(IN) :: RHS
        END SUBROUTINE RELAX2
    END INTERFACE
    INTERFACE
    FUNCTION RESID(U,RHS)
        USE NRTYPE
        REAL(DP), DIMENSION(:,:), INTENT(IN) :: U,RHS
        REAL(DP), DIMENSION(SIZE(U,1),SIZE(U,1)) :: RESID
        END FUNCTION RESID
    END INTERFACE
    INTERFACE RF
        FUNCTION RF_W(X,Y,Z)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X,Y,Z
        REAL(WP) :: RF_W
        END FUNCTION RF_W
!BL
        FUNCTION RF_V(X,Y,Z)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,Y,Z
        REAL(WP), DIMENSION(SIZE(X)) :: RF_V
        END FUNCTION RF_V
    END INTERFACE
    INTERFACE RJ
        FUNCTION RJ_W(X,Y,Z,P)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X,Y,Z,P
        REAL(WP) :: RJ_W
        END FUNCTION RJ_W
!BL
        FUNCTION RJ_V(X,Y,Z,P)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,Y,Z,P
        REAL(WP), DIMENSION(SIZE(X)) :: RJ_V
        END FUNCTION RJ_V
    END INTERFACE
    INTERFACE
        SUBROUTINE RK4(Y,DYDX,X,H,YOUT,DERIVS)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: Y,DYDX
        REAL(WP), INTENT(IN) :: X,H
        REAL(WP), DIMENSION(:), INTENT(OUT) :: YOUT
        INTERFACE
            SUBROUTINE DERIVS(X,Y,DYDX)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP), DIMENSION(:), INTENT(IN) :: Y
            REAL(WP), DIMENSION(:), INTENT(OUT) :: DYDX
            END SUBROUTINE DERIVS
        END INTERFACE
        END SUBROUTINE RK4
    END INTERFACE
    INTERFACE
        SUBROUTINE RKCK(Y,DYDX,X,H,YOUT,YERR,DERIVS)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: Y,DYDX
        REAL(WP), INTENT(IN) :: X,H
        REAL(WP), DIMENSION(:), INTENT(OUT) :: YOUT,YERR
        INTERFACE
            SUBROUTINE DERIVS(X,Y,DYDX)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP), DIMENSION(:), INTENT(IN) :: Y
            REAL(WP), DIMENSION(:), INTENT(OUT) :: DYDX
            END SUBROUTINE DERIVS
        END INTERFACE
        END SUBROUTINE RKCK
    END INTERFACE
    INTERFACE
        SUBROUTINE RKDUMB(VSTART,X1,X2,NSTEP,DERIVS)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: VSTART
        REAL(WP), INTENT(IN) :: X1,X2
        INTEGER(I4B), INTENT(IN) :: NSTEP
        INTERFACE
            SUBROUTINE DERIVS(X,Y,DYDX)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP), DIMENSION(:), INTENT(IN) :: Y
            REAL(WP), DIMENSION(:), INTENT(OUT) :: DYDX
            END SUBROUTINE DERIVS
        END INTERFACE
        END SUBROUTINE RKDUMB
    END INTERFACE
    INTERFACE
        SUBROUTINE RKQS(Y,DYDX,X,HTRY,EPS,YSCAL,HDID,HNEXT,DERIVS)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: Y
        REAL(WP), DIMENSION(:), INTENT(IN) :: DYDX,YSCAL
        REAL(WP), INTENT(INOUT) :: X
        REAL(WP), INTENT(IN) :: HTRY,EPS
        REAL(WP), INTENT(OUT) :: HDID,HNEXT
        INTERFACE
            SUBROUTINE DERIVS(X,Y,DYDX)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP), DIMENSION(:), INTENT(IN) :: Y
            REAL(WP), DIMENSION(:), INTENT(OUT) :: DYDX
            END SUBROUTINE DERIVS
        END INTERFACE
        END SUBROUTINE RKQS
    END INTERFACE
    INTERFACE
        SUBROUTINE RLFT2(DATA1,SPEC,SPEQ,ISGN)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(INOUT) :: DATA1
        COMPLEX(WPC), DIMENSION(:,:), INTENT(OUT) :: SPEC
        COMPLEX(WPC), DIMENSION(:), INTENT(OUT) :: SPEQ
        INTEGER(I4B), INTENT(IN) :: ISGN
        END SUBROUTINE RLFT2
    END INTERFACE
    INTERFACE
        SUBROUTINE RLFT3(DATA1,SPEC,SPEQ,ISGN)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:,:), INTENT(INOUT) :: DATA1
        COMPLEX(WPC), DIMENSION(:,:,:), INTENT(OUT) :: SPEC
        COMPLEX(WPC), DIMENSION(:,:), INTENT(OUT) :: SPEQ
        INTEGER(I4B), INTENT(IN) :: ISGN
        END SUBROUTINE RLFT3
    END INTERFACE
    INTERFACE
        SUBROUTINE ROTATE(R,QT,I,A,B)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), TARGET, INTENT(INOUT) :: R,QT
        INTEGER(I4B), INTENT(IN) :: I
        REAL(WP), INTENT(IN) :: A,B
        END SUBROUTINE ROTATE
    END INTERFACE
    INTERFACE
        SUBROUTINE RSOLV(A,D,B)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(IN) :: A
        REAL(WP), DIMENSION(:), INTENT(IN) :: D
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: B
        END SUBROUTINE RSOLV
    END INTERFACE
    INTERFACE
        FUNCTION RSTRCT(UF)
        USE NRTYPE
        REAL(DP), DIMENSION(:,:), INTENT(IN) :: UF
        REAL(DP), DIMENSION((SIZE(UF,1)+1)/2,(SIZE(UF,1)+1)/2) :: RSTRCT
        END FUNCTION RSTRCT
    END INTERFACE
    INTERFACE
        FUNCTION RTBIS(FUNC,X1,X2,XACC)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X1,X2,XACC
        REAL(WP) :: RTBIS
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END FUNCTION RTBIS
    END INTERFACE
    INTERFACE
        FUNCTION RTFLSP(FUNC,X1,X2,XACC)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X1,X2,XACC
        REAL(WP) :: RTFLSP
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END FUNCTION RTFLSP
    END INTERFACE
    INTERFACE
        FUNCTION RTNEWT(FUNCD,X1,X2,XACC)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X1,X2,XACC
        REAL(WP) :: RTNEWT
        INTERFACE
            SUBROUTINE FUNCD(X,FVAL,FDERIV)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP), INTENT(OUT) :: FVAL,FDERIV
            END SUBROUTINE FUNCD
        END INTERFACE
        END FUNCTION RTNEWT
    END INTERFACE
    INTERFACE
        FUNCTION RTSAFE(FUNCD,X1,X2,XACC)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X1,X2,XACC
        REAL(WP) :: RTSAFE
        INTERFACE
            SUBROUTINE FUNCD(X,FVAL,FDERIV)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP), INTENT(OUT) :: FVAL,FDERIV
            END SUBROUTINE FUNCD
        END INTERFACE
        END FUNCTION RTSAFE
    END INTERFACE
    INTERFACE
        FUNCTION RTSEC(FUNC,X1,X2,XACC)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X1,X2,XACC
        REAL(WP) :: RTSEC
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END FUNCTION RTSEC
    END INTERFACE
    INTERFACE
        SUBROUTINE RZEXTR(IEST,XEST,YEST,YZ,DY)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: IEST
        REAL(WP), INTENT(IN) :: XEST
        REAL(WP), DIMENSION(:), INTENT(IN) :: YEST
        REAL(WP), DIMENSION(:), INTENT(OUT) :: YZ,DY
        END SUBROUTINE RZEXTR
    END INTERFACE
    INTERFACE
        FUNCTION SAVGOL(NL,NRR,LD,M)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: NL,NRR,LD,M
        REAL(WP), DIMENSION(NL+NRR+1) :: SAVGOL
        END FUNCTION SAVGOL
    END INTERFACE
    INTERFACE
        SUBROUTINE SCRSHO(FUNC)
        USE NRTYPE
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END SUBROUTINE SCRSHO
    END INTERFACE
    INTERFACE
        FUNCTION SELECT(K,ARR)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: K
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: ARR
        REAL(WP) :: SELECT
        END FUNCTION SELECT
    END INTERFACE
    INTERFACE
        FUNCTION SELECT_BYPACK(K,ARR)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: K
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: ARR
        REAL(WP) :: SELECT_BYPACK
        END FUNCTION SELECT_BYPACK
    END INTERFACE
    INTERFACE
        SUBROUTINE SELECT_HEAP(ARR,HEAP)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: ARR
        REAL(WP), DIMENSION(:), INTENT(OUT) :: HEAP
        END SUBROUTINE SELECT_HEAP
    END INTERFACE
    INTERFACE
        FUNCTION SELECT_INPLACE(K,ARR)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: K
        REAL(WP), DIMENSION(:), INTENT(IN) :: ARR
        REAL(WP) :: SELECT_INPLACE
        END FUNCTION SELECT_INPLACE
    END INTERFACE
    INTERFACE
        SUBROUTINE SIMPLX(A,M1,M2,M3,ICASE,IZROV,IPOSV)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(INOUT) :: A
        INTEGER(I4B), INTENT(IN) :: M1,M2,M3
        INTEGER(I4B), INTENT(OUT) :: ICASE
        INTEGER(I4B), DIMENSION(:), INTENT(OUT) :: IZROV,IPOSV
        END SUBROUTINE SIMPLX
    END INTERFACE
    INTERFACE
        SUBROUTINE SIMPR(Y,DYDX,DFDX,DFDY,XS,HTOT,NSTEP,YOUT,DERIVS)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: XS,HTOT
        REAL(WP), DIMENSION(:), INTENT(IN) :: Y,DYDX,DFDX
        REAL(WP), DIMENSION(:,:), INTENT(IN) :: DFDY
        INTEGER(I4B), INTENT(IN) :: NSTEP
        REAL(WP), DIMENSION(:), INTENT(OUT) :: YOUT
        INTERFACE
            SUBROUTINE DERIVS(X,Y,DYDX)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP), DIMENSION(:), INTENT(IN) :: Y
            REAL(WP), DIMENSION(:), INTENT(OUT) :: DYDX
            END SUBROUTINE DERIVS
        END INTERFACE
        END SUBROUTINE SIMPR
    END INTERFACE
    INTERFACE
        SUBROUTINE SINFT(Y)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: Y
        END SUBROUTINE SINFT
    END INTERFACE
    INTERFACE
        SUBROUTINE SLVSM2(U,RHS)
        USE NRTYPE
        REAL(DP), DIMENSION(3,3), INTENT(OUT) :: U
        REAL(DP), DIMENSION(3,3), INTENT(IN) :: RHS
        END SUBROUTINE SLVSM2
    END INTERFACE
    INTERFACE
        SUBROUTINE SLVSML(U,RHS)
        USE NRTYPE
        REAL(DP), DIMENSION(3,3), INTENT(OUT) :: U
        REAL(DP), DIMENSION(3,3), INTENT(IN) :: RHS
        END SUBROUTINE SLVSML
    END INTERFACE
    INTERFACE
        SUBROUTINE SNCNDN(UU,EMMC,SN,CN,DN)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: UU,EMMC
        REAL(WP), INTENT(OUT) :: SN,CN,DN
        END SUBROUTINE SNCNDN
    END INTERFACE
    INTERFACE
        FUNCTION SNRM(SX,ITOL)
        USE NRTYPE
        REAL(DP), DIMENSION(:), INTENT(IN) :: SX
        INTEGER(I4B), INTENT(IN) :: ITOL
        REAL(DP) :: SNRM
        END FUNCTION SNRM
    END INTERFACE
    INTERFACE
        SUBROUTINE SOBSEQ(X,INIT)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(OUT) :: X
        INTEGER(I4B), OPTIONAL, INTENT(IN) :: INIT
        END SUBROUTINE SOBSEQ
    END INTERFACE
    INTERFACE
        SUBROUTINE SOLVDE(ITMAX,CONV,SLOWC,SCALV,INDEXV,NB,Y)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: ITMAX,NB
        REAL(WP), INTENT(IN) :: CONV,SLOWC
        REAL(WP), DIMENSION(:), INTENT(IN) :: SCALV
        INTEGER(I4B), DIMENSION(:), INTENT(IN) :: INDEXV
        REAL(WP), DIMENSION(:,:), INTENT(INOUT) :: Y
        END SUBROUTINE SOLVDE
    END INTERFACE
    INTERFACE
        SUBROUTINE SOR(A,B,C,D,E,F,U,RJAC)
        USE NRTYPE
        REAL(DP), DIMENSION(:,:), INTENT(IN) :: A,B,C,D,E,F
        REAL(DP), DIMENSION(:,:), INTENT(INOUT) :: U
        REAL(DP), INTENT(IN) :: RJAC
        END SUBROUTINE SOR
    END INTERFACE
    INTERFACE
        SUBROUTINE SORT(ARR)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: ARR
        END SUBROUTINE SORT
    END INTERFACE
    INTERFACE
        SUBROUTINE SORT2(ARR,SLAVE)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: ARR,SLAVE
        END SUBROUTINE SORT2
    END INTERFACE
    INTERFACE
        SUBROUTINE SORT3(ARR,SLAVE1,SLAVE2)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: ARR,SLAVE1,SLAVE2
        END SUBROUTINE SORT3
    END INTERFACE
    INTERFACE
        SUBROUTINE SORT_BYPACK(ARR)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: ARR
        END SUBROUTINE SORT_BYPACK
    END INTERFACE
    INTERFACE
        SUBROUTINE SORT_BYRESHAPE(ARR)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: ARR
        END SUBROUTINE SORT_BYRESHAPE
    END INTERFACE
    INTERFACE
        SUBROUTINE SORT_HEAP(ARR)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: ARR
        END SUBROUTINE SORT_HEAP
    END INTERFACE
    INTERFACE
        SUBROUTINE SORT_PICK(ARR)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: ARR
        END SUBROUTINE SORT_PICK
    END INTERFACE
    INTERFACE
        SUBROUTINE SORT_RADIX(ARR)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: ARR
        END SUBROUTINE SORT_RADIX
    END INTERFACE
    INTERFACE
        SUBROUTINE SORT_WHELL(ARR)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: ARR
        END SUBROUTINE SORT_WHELL
    END INTERFACE
    INTERFACE
        SUBROUTINE SPCTRM(P,K,OVRLAP,UNIT,N_WINDOW)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(OUT) :: P
        INTEGER(I4B), INTENT(IN) :: K
        LOGICAL(TLG), INTENT(IN) :: OVRLAP
        INTEGER(I4B), OPTIONAL, INTENT(IN) :: N_WINDOW,UNIT
        END SUBROUTINE SPCTRM
    END INTERFACE
    INTERFACE
        SUBROUTINE SPEAR(DATA11,DATA12,D,ZD,PROBD,RS,PROBRS)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: DATA11,DATA12
        REAL(WP), INTENT(OUT) :: D,ZD,PROBD,RS,PROBRS
        END SUBROUTINE SPEAR
    END INTERFACE
    INTERFACE SPHBES
        SUBROUTINE SPHBES_W(N,X,SJ,SY,SJP,SYP)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N
        REAL(WP), INTENT(IN) :: X
        REAL(WP), INTENT(OUT) :: SJ,SY,SJP,SYP
        END SUBROUTINE SPHBES_W
!BL
        SUBROUTINE SPHBES_V(N,X,SJ,SY,SJP,SYP)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N
        REAL(WP), DIMENSION(:), INTENT(IN) :: X
        REAL(WP), DIMENSION(:), INTENT(OUT) :: SJ,SY,SJP,SYP
        END SUBROUTINE SPHBES_V
    END INTERFACE
    INTERFACE
        SUBROUTINE SPLIE2(X1A,X2A,YA,Y2A)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X1A,X2A
        REAL(WP), DIMENSION(:,:), INTENT(IN) :: YA
        REAL(WP), DIMENSION(:,:), INTENT(OUT) :: Y2A
        END SUBROUTINE SPLIE2
    END INTERFACE
    INTERFACE
        FUNCTION SPLIN2(X1A,X2A,YA,Y2A,X1,X2)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X1A,X2A
        REAL(WP), DIMENSION(:,:), INTENT(IN) :: YA,Y2A
        REAL(WP), INTENT(IN) :: X1,X2
        REAL(WP) :: SPLIN2
        END FUNCTION SPLIN2
    END INTERFACE
    INTERFACE
        SUBROUTINE SPLINE(X,Y,YP1,YPN,Y2)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,Y
        REAL(WP), INTENT(IN) :: YP1,YPN
        REAL(WP), DIMENSION(:), INTENT(OUT) :: Y2
        END SUBROUTINE SPLINE
    END INTERFACE
    INTERFACE
        FUNCTION SPLINT(XA,YA,Y2A,X)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: XA,YA,Y2A
        REAL(WP), INTENT(IN) :: X
        REAL(WP) :: SPLINT
        END FUNCTION SPLINT
    END INTERFACE
    INTERFACE SPRSAX
        SUBROUTINE SPRSAX_DP(SA,X,B)
        USE NRTYPE
        TYPE(SPRS2_DP), INTENT(IN) :: SA
        REAL(DP), DIMENSION (:), INTENT(IN) :: X
        REAL(DP), DIMENSION (:), INTENT(OUT) :: B
        END SUBROUTINE SPRSAX_DP
!BL
        SUBROUTINE SPRSAX_QP(SA,X,B)
        USE NRTYPE
        TYPE(SPRS2_QP), INTENT(IN) :: SA
        REAL(QP), DIMENSION (:), INTENT(IN) :: X
        REAL(QP), DIMENSION (:), INTENT(OUT) :: B
        END SUBROUTINE SPRSAX_QP
    END INTERFACE
    INTERFACE SPRSDIAG
        SUBROUTINE SPRSDIAG_DP(SA,B)
        USE NRTYPE
        TYPE(SPRS2_DP), INTENT(IN) :: SA
        REAL(DP), DIMENSION(:), INTENT(OUT) :: B
        END SUBROUTINE SPRSDIAG_DP
!BL
        SUBROUTINE SPRSDIAG_QP(SA,B)
        USE NRTYPE
        TYPE(SPRS2_QP), INTENT(IN) :: SA
        REAL(QP), DIMENSION(:), INTENT(OUT) :: B
        END SUBROUTINE SPRSDIAG_QP
    END INTERFACE
    INTERFACE SPRSIN
        SUBROUTINE SPRSIN_WP(A,THRESH,SA)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(IN) :: A
        REAL(WP), INTENT(IN) :: THRESH
        TYPE(SPRS2_QP), INTENT(OUT) :: SA
        END SUBROUTINE SPRSIN_WP
!BL
        SUBROUTINE SPRSIN_DP(A,THRESH,SA)
        USE NRTYPE
        REAL(DP), DIMENSION(:,:), INTENT(IN) :: A
        REAL(DP), INTENT(IN) :: THRESH
        TYPE(SPRS2_DP), INTENT(OUT) :: SA
        END SUBROUTINE SPRSIN_DP
    END INTERFACE
    INTERFACE
        SUBROUTINE SPRSTP(SA)
        USE NRTYPE
        TYPE(SPRS2_QP), INTENT(INOUT) :: SA
        END SUBROUTINE SPRSTP
    END INTERFACE
    INTERFACE SPRSTX
        SUBROUTINE SPRSTX_DP(SA,X,B)
        USE NRTYPE
        TYPE(SPRS2_DP), INTENT(IN) :: SA
        REAL(DP), DIMENSION (:), INTENT(IN) :: X
        REAL(DP), DIMENSION (:), INTENT(OUT) :: B
        END SUBROUTINE SPRSTX_DP
!BL
        SUBROUTINE SPRSTX_WP(SA,X,B)
        USE NRTYPE
        TYPE(SPRS2_QP), INTENT(IN) :: SA
        REAL(WP), DIMENSION (:), INTENT(IN) :: X
        REAL(WP), DIMENSION (:), INTENT(OUT) :: B
        END SUBROUTINE SPRSTX_WP
    END INTERFACE
    INTERFACE
        SUBROUTINE STIFBS(Y,DYDX,X,HTRY,EPS,YSCAL,HDID,HNEXT,DERIVS)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: Y
        REAL(WP), DIMENSION(:), INTENT(IN) :: DYDX,YSCAL
        REAL(WP), INTENT(IN) :: HTRY,EPS
        REAL(WP), INTENT(INOUT) :: X
        REAL(WP), INTENT(OUT) :: HDID,HNEXT
        INTERFACE
            SUBROUTINE DERIVS(X,Y,DYDX)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP), DIMENSION(:), INTENT(IN) :: Y
            REAL(WP), DIMENSION(:), INTENT(OUT) :: DYDX
            END SUBROUTINE DERIVS
        END INTERFACE
        END SUBROUTINE STIFBS
    END INTERFACE
    INTERFACE
        SUBROUTINE STIFF(Y,DYDX,X,HTRY,EPS,YSCAL,HDID,HNEXT,DERIVS)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: Y
        REAL(WP), DIMENSION(:), INTENT(IN) :: DYDX,YSCAL
        REAL(WP), INTENT(INOUT) :: X
        REAL(WP), INTENT(IN) :: HTRY,EPS
        REAL(WP), INTENT(OUT) :: HDID,HNEXT
        INTERFACE
            SUBROUTINE DERIVS(X,Y,DYDX)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP), DIMENSION(:), INTENT(IN) :: Y
            REAL(WP), DIMENSION(:), INTENT(OUT) :: DYDX
            END SUBROUTINE DERIVS
        END INTERFACE
        END SUBROUTINE STIFF
    END INTERFACE
    INTERFACE
        SUBROUTINE STOERM(Y,D2Y,XS,HTOT,NSTEP,YOUT,DERIVS)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: Y,D2Y
        REAL(WP), INTENT(IN) :: XS,HTOT
        INTEGER(I4B), INTENT(IN) :: NSTEP
        REAL(WP), DIMENSION(:), INTENT(OUT) :: YOUT
        INTERFACE
            SUBROUTINE DERIVS(X,Y,DYDX)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP), DIMENSION(:), INTENT(IN) :: Y
            REAL(WP), DIMENSION(:), INTENT(OUT) :: DYDX
            END SUBROUTINE DERIVS
        END INTERFACE
        END SUBROUTINE STOERM
    END INTERFACE
    INTERFACE SVBKSB
!        SUBROUTINE SVBKSB_DP(U,W,V,B,X)
!        USE NRTYPE
!        REAL(DP), DIMENSION(:,:), INTENT(IN) :: U,V
!        REAL(DP), DIMENSION(:), INTENT(IN) :: W,B
!        REAL(DP), DIMENSION(:), INTENT(OUT) :: X
!        END SUBROUTINE SVBKSB_DP
!BL
        SUBROUTINE SVBKSB_WP(U,W,V,B,X)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(IN) :: U,V
        REAL(WP), DIMENSION(:), INTENT(IN) :: W,B
        REAL(WP), DIMENSION(:), INTENT(OUT) :: X
        END SUBROUTINE SVBKSB_WP
    END INTERFACE
    INTERFACE SVDCMP
!        SUBROUTINE SVDCMP_DP(A,W,V)
!        USE NRTYPE
!        REAL(DP), DIMENSION(:,:), INTENT(INOUT) :: A
!        REAL(DP), DIMENSION(:), INTENT(OUT) :: W
!        REAL(DP), DIMENSION(:,:), INTENT(OUT) :: V
!        END SUBROUTINE SVDCMP_DP
!BL
        SUBROUTINE SVDCMP_WP(A,W,V)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(INOUT) :: A
        REAL(WP), DIMENSION(:), INTENT(OUT) :: W
        REAL(WP), DIMENSION(:,:), INTENT(OUT) :: V
        END SUBROUTINE SVDCMP_WP
    END INTERFACE
    INTERFACE
        SUBROUTINE SVDFIT(X,Y,SIG,A,V,W,CHISQ,FUNCS)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: X,Y,SIG
        REAL(WP), DIMENSION(:), INTENT(OUT) :: A,W
        REAL(WP), DIMENSION(:,:), INTENT(OUT) :: V
        REAL(WP), INTENT(OUT) :: CHISQ
        INTERFACE
            FUNCTION FUNCS(X,N)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            INTEGER(I4B), INTENT(IN) :: N
            REAL(WP), DIMENSION(N) :: FUNCS
            END FUNCTION FUNCS
        END INTERFACE
        END SUBROUTINE SVDFIT
    END INTERFACE
    INTERFACE
        SUBROUTINE SVDVAR(V,W,CVM)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(IN) :: V
        REAL(WP), DIMENSION(:), INTENT(IN) :: W
        REAL(WP), DIMENSION(:,:), INTENT(OUT) :: CVM
        END SUBROUTINE SVDVAR
    END INTERFACE
    INTERFACE
        FUNCTION TOEPLZ(R,Y)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: R,Y
        REAL(WP), DIMENSION(SIZE(Y)) :: TOEPLZ
        END FUNCTION TOEPLZ
    END INTERFACE
    INTERFACE
        SUBROUTINE TPTEST(DATA11,DATA12,T,PROB)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: DATA11,DATA12
        REAL(WP), INTENT(OUT) :: T,PROB
        END SUBROUTINE TPTEST
    END INTERFACE
    INTERFACE
        SUBROUTINE TQLI(D,E,Z)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: D,E
        REAL(WP), DIMENSION(:,:), OPTIONAL, INTENT(INOUT) :: Z
        END SUBROUTINE TQLI
    END INTERFACE
    INTERFACE
        SUBROUTINE TRAPZD(FUNC,A,B,S,N)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: A,B
        REAL(WP), INTENT(INOUT) :: S
        INTEGER(I4B), INTENT(IN) :: N
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: X
            REAL(WP), DIMENSION(SIZE(X)) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END SUBROUTINE TRAPZD
    END INTERFACE
    INTERFACE
        SUBROUTINE TRED2(A,D,E,NOVECTORS)
        USE NRTYPE
        REAL(WP), DIMENSION(:,:), INTENT(INOUT) :: A
        REAL(WP), DIMENSION(:), INTENT(OUT) :: D,E
        LOGICAL(TLG), OPTIONAL, INTENT(IN) :: NOVECTORS
        END SUBROUTINE TRED2
    END INTERFACE
!	ON A PURELY SERIAL MACHINE, FOR GREATER EFFICIENCY, REMOVE
!	THE GENERIC NAME TRIDAG FROM THE FOLLOWING INTERFACE,
!	AND PUT IT ON THE NEXT ONE AFTER THAT.
    INTERFACE TRIDAG
        RECURSIVE SUBROUTINE TRIDAG_PAR(A,B,C,R,U)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: A,B,C,R
        REAL(WP), DIMENSION(:), INTENT(OUT) :: U
        END SUBROUTINE TRIDAG_PAR
    END INTERFACE
    INTERFACE
        SUBROUTINE TRIDAG_WER(A,B,C,R,U)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: A,B,C,R
        REAL(WP), DIMENSION(:), INTENT(OUT) :: U
        END SUBROUTINE TRIDAG_WER
    END INTERFACE
    INTERFACE
        SUBROUTINE TTEST(DATA11,DATA12,T,PROB)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: DATA11,DATA12
        REAL(WP), INTENT(OUT) :: T,PROB
        END SUBROUTINE TTEST
    END INTERFACE
    INTERFACE
        SUBROUTINE TUTEST(DATA11,DATA12,T,PROB)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: DATA11,DATA12
        REAL(WP), INTENT(OUT) :: T,PROB
        END SUBROUTINE TUTEST
    END INTERFACE
    INTERFACE
        SUBROUTINE TWOFFT(DATA11,DATA12,FFT1,FFT2)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: DATA11,DATA12
        COMPLEX(WPC), DIMENSION(:), INTENT(OUT) :: FFT1,FFT2
        END SUBROUTINE TWOFFT
    END INTERFACE
    INTERFACE
        FUNCTION VANDER(X,Q)
        USE NRTYPE
        REAL(DP), DIMENSION(:), INTENT(IN) :: X,Q
        REAL(DP), DIMENSION(SIZE(X)) :: VANDER
        END FUNCTION VANDER
    END INTERFACE
    INTERFACE
        SUBROUTINE VEGAS(REGION,FUNC,INIT,NCALL,ITMX,NPRN,TGRAL,SD,CHI2A)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: REGION
        INTEGER(I4B), INTENT(IN) :: INIT,NCALL,ITMX,NPRN
        REAL(WP), INTENT(OUT) :: TGRAL,SD,CHI2A
        INTERFACE
            FUNCTION FUNC(PT,WGT)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(IN) :: PT
            REAL(WP), INTENT(IN) :: WGT
            REAL(WP) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END SUBROUTINE VEGAS
    END INTERFACE
    INTERFACE
        SUBROUTINE VOLTRA(T0,H,T,F,G,AK)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: T0,H
        REAL(WP), DIMENSION(:), INTENT(OUT) :: T
        REAL(WP), DIMENSION(:,:), INTENT(OUT) :: F
        INTERFACE
            FUNCTION G(T)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: T
            REAL(WP), DIMENSION(:), POINTER :: G
            END FUNCTION G
!BL
            FUNCTION AK(T,S)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: T,S
            REAL(WP), DIMENSION(:,:), POINTER :: AK
            END FUNCTION AK
        END INTERFACE
        END SUBROUTINE VOLTRA
    END INTERFACE
    INTERFACE
        SUBROUTINE WT1(A,ISGN,WTSTEP)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: A
        INTEGER(I4B), INTENT(IN) :: ISGN
        INTERFACE
            SUBROUTINE WTSTEP(A,ISGN)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(INOUT) :: A
            INTEGER(I4B), INTENT(IN) :: ISGN
            END SUBROUTINE WTSTEP
        END INTERFACE
        END SUBROUTINE WT1
    END INTERFACE
    INTERFACE
        SUBROUTINE WTN(A,NN,ISGN,WTSTEP)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(INOUT) :: A
        INTEGER(I4B), DIMENSION(:), INTENT(IN) :: NN
        INTEGER(I4B), INTENT(IN) :: ISGN
        INTERFACE
            SUBROUTINE WTSTEP(A,ISGN)
            USE NRTYPE
            REAL(WP), DIMENSION(:), INTENT(INOUT) :: A
            INTEGER(I4B), INTENT(IN) :: ISGN
            END SUBROUTINE WTSTEP
        END INTERFACE
        END SUBROUTINE WTN
    END INTERFACE
    INTERFACE
        FUNCTION WWGHTS(N,H,KERMOM)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N
        REAL(WP), INTENT(IN) :: H
        REAL(WP), DIMENSION(N) :: WWGHTS
        INTERFACE
            FUNCTION KERMOM(Y,M)
            USE NRTYPE
            REAL(DP), INTENT(IN) :: Y
            INTEGER(I4B), INTENT(IN) :: M
            REAL(DP), DIMENSION(M) :: KERMOM
            END FUNCTION KERMOM
        END INTERFACE
        END FUNCTION WWGHTS
    END INTERFACE
    INTERFACE
        SUBROUTINE ZBRAC(FUNC,X1,X2,SUCCES)
        USE NRTYPE
        REAL(WP), INTENT(INOUT) :: X1,X2
        LOGICAL(TLG), INTENT(OUT) :: SUCCES
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END SUBROUTINE ZBRAC
    END INTERFACE
    INTERFACE
        SUBROUTINE ZBRAK(FUNC,X1,X2,N,XB1,XB2,NB)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN) :: N
        INTEGER(I4B), INTENT(OUT) :: NB
        REAL(WP), INTENT(IN) :: X1,X2
        REAL(WP), DIMENSION(:), POINTER :: XB1,XB2
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END SUBROUTINE ZBRAK
    END INTERFACE
    INTERFACE
        FUNCTION ZBRENT(FUNC,X1,X2,TOL)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X1,X2,TOL
        REAL(WP) :: ZBRENT
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END FUNCTION ZBRENT
    END INTERFACE
    INTERFACE
        SUBROUTINE ZRHQR(A,RTR,RTI)
        USE NRTYPE
        REAL(WP), DIMENSION(:), INTENT(IN) :: A
        REAL(WP), DIMENSION(:), INTENT(OUT) :: RTR,RTI
        END SUBROUTINE ZRHQR
    END INTERFACE
    INTERFACE
        FUNCTION ZRIDDR(FUNC,X1,X2,XACC)
        USE NRTYPE
        REAL(WP), INTENT(IN) :: X1,X2,XACC
        REAL(WP) :: ZRIDDR
        INTERFACE
            FUNCTION FUNC(X)
            USE NRTYPE
            REAL(WP), INTENT(IN) :: X
            REAL(WP) :: FUNC
            END FUNCTION FUNC
        END INTERFACE
        END FUNCTION ZRIDDR
    END INTERFACE
    INTERFACE
        SUBROUTINE ZROOTS(A,ROOTS,POLISH)
        USE NRTYPE
        COMPLEX(WPC), DIMENSION(:), INTENT(IN) :: A
        COMPLEX(WPC), DIMENSION(:), INTENT(OUT) :: ROOTS
        LOGICAL(TLG), INTENT(IN) :: POLISH
        END SUBROUTINE ZROOTS
    END INTERFACE
!...
!===========================================================================
!...
    INTERFACE
        SUBROUTINE NASHSU(X,Y,N,ES)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN)                            :: N
        REAL(SP), DIMENSION(1:N), INTENT(IN)                :: X, Y
        REAL(SP), INTENT(OUT)                               :: ES
        END SUBROUTINE NASHSU
    END INTERFACE
!...
    INTERFACE
        SUBROUTINE ROOT_MEAN(X,Y,XAVE,ME,MAE,MSE,MLE,MALE,MSLE,RMSE,RMSLE,NRMSE,CVRMSE,RSR,N)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN)                            :: N
        REAL(SP), INTENT(IN)                                :: XAVE
        REAL(SP), DIMENSION(1:N), INTENT(IN)                :: X, Y
        REAL(SP), INTENT(OUT)                               :: ME, MAE, MSE, MLE, MALE, MSLE, RMSE, RMSLE, NRMSE, CVRMSE, RSR
        END SUBROUTINE ROOT_MEAN
    END INTERFACE
!...
    INTERFACE
        SUBROUTINE DURBIN(N,YD,YM,DWS,PROBDW)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN)                            :: N
        REAL(SP), INTENT(OUT)                               :: DWS, PROBDW
        REAL(SP), DIMENSION(1:N), INTENT(IN)                :: YD, YM
        END SUBROUTINE DURBIN
    END INTERFACE
!...
    INTERFACE
        SUBROUTINE AND_DAR(N,Y,A2,A3,ADP)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN)                            :: N
        REAL(WP), INTENT(OUT)                               :: A2, ADP, A3
        REAL(WP), DIMENSION(1:N), INTENT(IN)                :: Y
        END SUBROUTINE AND_DAR
    END INTERFACE
!...
    INTERFACE
        SUBROUTINE PERCENT_BIAS(X,Y,BIAS,PBIAS,N)
        USE NRTYPE
        INTEGER(I4B), INTENT(IN)                            :: N
        REAL(SP), DIMENSION(1:N), INTENT(IN)                :: X, Y
        REAL(SP), INTENT(OUT)                               :: BIAS, PBIAS
        END SUBROUTINE PERCENT_BIAS
    END INTERFACE
END MODULE NR
